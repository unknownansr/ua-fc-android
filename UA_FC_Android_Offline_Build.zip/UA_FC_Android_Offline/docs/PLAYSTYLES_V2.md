# PlayStyles v2 — 11 new styles (app + manager)

New: Target, Target+, Reach, Thunder, Thunder+, Power Header, Hardshot, Chip Pass, Sliding Tackle, Long Throw, Vision.
Icons: `playstyles/<slug>1.png` silver, `2` gold, `3` diamond (real art), `4` elite/black. Slug = lower-case, "+" -> " plus"
(e.g. `target plus3.png`). Classic styles are untouched (diamond still = gold icon recoloured by CSS).

## Numbers
Single source of truth: `PS_NEW_SPEC` in player.js. Values are the exact percentages from the design and apply at SILVER.
Positive boosts scale by tier via `PS_NEW_TIER_MULT` = silver 1.0 / gold 1.25 / diamond 1.5 / elite 2.0 (edit to taste).
Penalties (Thunder's ball control / passing, Power Header accuracy) are never scaled.

## How each one plays
- Target / Target+ — receiving a THROUGH pass starts a 4.5s buff: pace, finishing (less shot error), dribbling (skill-move shield + harder to tackle). Target+ and Target never stack (stronger wins).
- Reach — bigger ball-pickup radius and height; goalkeepers reach further.
- Thunder / Thunder+ — ⚡ button (key T), 8s. Deliberately small boost: Thunder pace +6 / shot speed +8 / shot power +6 (ball control -6, passing -20); Thunder+ +10 / +12 / +14 (ball control -10, passing -30). Thunder = 1 use. Thunder+ = 2 uses; 2nd use needs RELENTLESS equipped and >=40% stamina, drains 40%. Tune in `PS_NEW_SPEC`.
  Thunder = 1 use. Thunder+ = 2 uses; 2nd use needs RELENTLESS equipped and >=40% stamina, drains 40%. AI uses it when bearing down on goal.
- Power Header — on a high ball, 70% chance (rolled per contest): +head reach, +header power, -accuracy.
- Hardshot — full-power shots (>=80%) and every clearance: shot power +125% (power = energy, so speed x sqrt(1+power)); keepers hold these less often.
- Chip Pass — new LOB button (key F), shown when not in shooting range. Anyone can lob; the style adds accuracy, flight consistency, speed, interception resistance. AI with the style lobs ~30% of passes.
- Sliding Tackle — longer slide, higher tackle success, clean ball-winning (ball falls to the tackler), faster recovery after a miss.
- Long Throw — throw-ins fly far on an exact lob arc to the target (distance/power/hang time/accuracy).
- Vision — passes home in harder (accuracy), harder to intercept, receivers get a bigger first-touch radius.

## Manager
New styles in the picker (tooltips show the numbers). Target/Target+ and Thunder/Thunder+ can't both be equipped (the game only uses the stronger one).
Keep the `playstyles/` folder next to the manager html.

## Weak Foot (manager)
New 1–5 ★ field on the add and edit forms (saved as `weak_foot`). Run `add_weak_foot.sql` once in Supabase; until then saves still work (without it) and a warning shows. In game, about half of shots use the weak foot: 3★ neutral, 1★ +24% aim error, 5★ −24%.

## ai.js — opponent brain (new file, loaded after game.js)
Replaces the opponent's decisions (team 1). Falls back to the old AI automatically if it ever errors; `AIBRAIN.enabled = false` in the console switches it off.
- Reads the match (score, minute) and sets a mode: cruise (up 3+), protect (up, later on), balanced, chase (down 1-2), desperate (down 3+ or late).
- Picks a tactic (possession / wings / direct / longshots / counter / highpress), checks every window whether it is producing shots/goals, and TRIES ANOTHER if not. It also scouts you (your favourite flank, how high your back line is).
- Down 2+ goals it "plays a little better": up to ~28% faster reactions, +4.5% pace, sharper decisions (capped, never teleporting).
- Winning: holds the ball, safe passes, deeper compact line, corner-flag time wasting, counters only.
- Off the ball: pressing with cover, goal-side marking, compact shifting lines, runs into space, interceptions on loose balls.
- On the ball: scores shoot / pass / through ball / chip pass / cross / dribble / hold / clear (xG + lane safety), difficulty-scaled noise.
- Uses playstyles: Thunder/Thunder+ on open runs (2nd use only when chasing), Hardshot, Target through balls, Chip Pass, Power Header crosses, Sliding Tackle, Vision, Finesse Expert, Chip Shot, Trickster.
- Tackling: jockeys instead of diving in, stands up to head-on carriers, slides when beaten / last man.
