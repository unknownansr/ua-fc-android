# UA FC MOBILE - Offline

100% offline: no CDN, no Supabase, no accounts, no network calls (an in-app guard also blocks any outside request).

## How to run
Open `index.html` (no server, no internet, no setup). `three_bundle.js` (three.js r160 + GLTFLoader + SkeletonUtils) is already built in.
To host it, just upload the whole folder to any static host or wrap it in a WebView/APK; nothing else is required.

## What changed
- Opens in landscape: first tap (TAP TO ENTER) goes fullscreen and locks landscape (`landscape.js`). iPhone Safari has no lock API, so the ROTATE YOUR DEVICE screen stays as fallback.
- `local_backend.js` replaces Supabase; progress saves on-device (localStorage). Reset with `UA_LOCAL_DB.reset()` in the console.
- `local_roster.js`: 200 players (ovr 200-288, all rarities) using the PlayStyles v2 set: all 11 new styles (Target, Target+, Reach, Thunder, Thunder+, Power Header, Hardshot, Chip Pass, Sliding Tackle, Long Throw, Vision) plus the classics, in 2 tiers only (silver and gold). Gold is the silver icon recolored by CSS.
- 3D model and kit mask are embedded in `assets_data.js` (works from file://).
- Online-only features (friends, leagues, online rooms, accounts, AI chat APIs) are removed or hidden.

## Later
Player career mode.

## Career mode (in progress, built step by step)
- Step 1 done: the Events tabs on the Play screen are replaced by **Career**. Tap it to create your player: name, age, nation (48), jersey number, with a live jersey preview (`career_create.js`, `career_create.css`). Saved on-device in `career_save` (id `career-main`).
- Step 2 done: after the jersey number there is a **LOOK** step: 3D player (Player_White_Kit.glb, embedded) with all face, skin, hair, beard, face-shape and kit-colour options from the Player Rig. Name and number are printed on the shirt automatically. Saved in the same `career_save` profile as `profile.look`.
- Next steps: position, club, attributes, fixtures, matches. (In-match model still uses the old player mesh; swapping to the new look comes later.)

## Player Look (Character Studio) - update
- LOOK step now opens the full UA Character Studio v2.6 (247 hairstyles, 78 facial-hair styles, wearables, flower, face/body sliders, kit editor) on the new player model.
- New model: `assets/New_player_opt.glb` (0.92 MB, was 7.5 MB; head kept full detail). It is embedded in `player_glb_data.js` so it works from file://.
- Quality selector defaults to Normal; auto-downgrade and benchmark are removed.
- The look is saved in `career_save.profile.look.studio`.
- In match: every player uses the new body (low-poly build, ~12k verts). The old rig still drives all animations; its pose is retargeted onto the new skeleton (`new_player_swap.js`). Kits are tinted from team colours.
- A player built with `info._career = true` (or `_regId === 'career-main'`) gets the full-detail model, the saved Studio face/body shape, and live hair + facial hair (`ua_hair_engine.js`).
- Not included in match: wearables, and name/number printing (the number 10 is baked into the texture).

## Match looks
- Every match player gets a seeded random look (hair style + colour, 40% facial hair, one of 6 body types by role, height and face-shape variation). The same name/number/role always gives the same look.
- Hair engine is multi-instance (`UAHairEngine.create()`), shares one head SDF, uses the light `match` preset (6.5k strands), grows one player at a time after the match starts, and hides hair that is >70 m away or off screen.
- The career player (`info._career`) keeps the full Studio look and the Normal preset.

## Celebration+ (ua_celeb_plus.js)
- Pick-your-celebration bottom sheet (33 celebrations, animated pose previews, Random/favourite saved). Open from Settings ("Goal Celebration") or "ALL ›" in the in-match picker.
- New: HUDDLE JUMP, SLIDE TRAIN, TEAM BOW (team-wide), TORPEDO.
- 4 rotating goal camera shots (orbit, low hero push-in, crane pull-back, side track), team-colour glow, confetti/fireworks scaled down on phones.
- Rim + warm key light grade, exposure bump. Hair stays Normal.

- Camera mode "Ultra Close" (Settings → Camera, or Q to cycle). Goal celebration shots are now close-ups (face, low hero, tight orbit, side track) with a narrow FOV; canvas colour grade added.

- Celebrations reduced to 3 hand-tuned ones (SIUUU, KNEE SLIDE, ARMS WIDE). Goal camera now locks to the scorer (match.celScorer) instead of last ball-toucher (was jumping to the GK); shots are close, with handheld drift and slow zoom.

- Duo celebrations: HIGH CLASP (hands clasped overhead, from the reference photo) and DOUBLE HIGH-FIVE. The nearest outfield teammate runs to the scorer, both turn to face each other, and a closed loop measures the hand bones so the hands meet regardless of body size. Pick them in the Celebrations sheet or let Random choose.

- Kickoff now waits until the scorer's celebration has fully finished (game.js goal state). KNEE SLIDE physically slides the player ~3.6 m along the ground with a low close-up camera ahead of the slide.

## Phase 1 (structure, Luck Royale, card faces)
- Folders: src/core (utils, cloud, backend, roster, ovr), src/match (game, players, celebrations), src/ui, src/vendor, src/data (embedded assets), src/features (new: royale_drafts.js, player_card.js), styles/, assets/, docs/.
- Ratings: roster keeps raw 200-288 for the match engine; players see 50-130 via ovrD() (src/core/ovr.js).
- Luck Royale: 15 drafts generated from the roster (royale_drafts.js). Pull price from the draft's best player: <80 → 80, 80+ → 110, 96+ → 150, 106+ → 190, 116+ → 240, 121+ → 300, 130 → 500. 10-pull bundle = 9x.
- Gems: 100 per match + WIN 40 / DRAW 15 / goals 15 each (max 5) / assists 10 each / clean sheet 25 / MVP 40 / 5+ shots on target 10.
- Card faces: no images shipped. player_card.js builds a look recipe per player id and captures a small face from the 3D model + hair engine on demand (put data-pid="<id>" on an <img> or element). Faces are freed on every screen change and re-captured when needed. window.UACard.describe(id) prints the recipe text.

- Settings → "BETA TEST / DEV MODE": one switch turns on unlimited coins and gems (shown as ∞), saved between launches. God Stamina and the other dev tools appear underneath.

## Phase 2 — Theme, simple hub, Club Creator Studio
- styles/theme.css: dark neutrals + one green accent; hub simplified (Club, Luck Royale, Play); Activities/Featured/UA Pass/Bonus/News/Friends/Quests hidden.
- src/features/club_studio.js: name, short name, badge shape+icon, kit colours/pattern, GK kit, identity (sets formation), motto, stadium + capacity. Saved in localStorage, applied to the home team (kit, name, formation). Shortcuts to Luck Royale / Market / My Club for squad building.

## Phase 3 — Walkout, broadcast UI, cinematic goals
- src/features/walkout.js: both teams walk out of the tunnel to their kickoff spots before the first kickoff (tap to skip). Main-loop sim is paused via match.walkout.
- Broadcast UI: flat scorebug, accent clock, possession bar, commentary lower-third (styles/theme.css).
- Cinematic goals: ball-tracking low camera in the first ~1.9 s of a goal, blending into the celebration shot; existing slow-mo and instant replay kept.

## Phase 4 — Fatigue, injuries, referee AI, tactics (src/features/match_extras.js)
- Fatigue: every outfield player has a fitness value that drains with running (faster when attacking, slower when parking) and slows them as it drops.
- Injuries: fouls can injure the victim; he is auto-substituted (if subs remain) and your injured players miss your next match (stored in localStorage `ua_inj_v1`).
- Referee AI: each match gets a random referee (Lenient / Balanced / Strict) that changes how many fouls are whistled and how quickly cards come out. Shown in a toast after the walkout.
- Tactics: ATK / BAL / DEF / PARK buttons under the minimap move your team's line live. The opponent's AI manager also reacts to score and time.

## Walkout rework + Phase 5
- Walkout (src/features/walkout.js): lit tunnel run-out inside the pitch apron (no wall clipping), wide opening shot, then 6 s of close-ups on 5 random players (1.2 s each), then eases into kickoff. Pixel ratio is capped to 1.25 while it plays. Tap to skip.
- Penalty shootout (src/features/shootout.js): after a drawn match when Settings > Match Rules > "Shootout on draw" is on (or match.knockout / match.isCup is set). Drag to aim, release, then tap to stop the power meter (green zone is best); when the opponent shoots, tap a goal area to dive. 5 kicks each, then sudden death. SKIP auto-plays.
- Ball physics (game.js updateBall, PHYS.adv in utils.js): quadratic air drag, knuckle wobble on hard spinless shots, spin shown on the ball, speed-dependent bounce, topspin/backspin changing the bounce, rolling resistance that settles the ball. Set PHYS.adv = false to restore the old feel.

## Shootout is now 3D
Real pitch, real players and keeper (dive clips), run-up, ball flight and a goal-side result camera. The 2D layer is only the HUD (crosshair, power meter, score).
