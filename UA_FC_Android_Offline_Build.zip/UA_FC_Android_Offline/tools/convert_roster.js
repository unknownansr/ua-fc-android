#!/usr/bin/env node
/* Build-time tool: converts the old offline game's players.js (const D = {...})
   into local_roster.js, a set of players_registry-shaped rows for the offline
   hub. Run:  node tools/convert_roster.js <old players.js> <out local_roster.js>
   Scale: hub registry uses stats 1-500 and OVR 1-300 (the engine normalises
   them back to 1-99), so values are multiplied by 500/99 and 300/99. */
'use strict';
const fs = require('fs');
const src = process.argv[2], out = process.argv[3];
if (!src || !out) { console.error('usage: convert_roster.js <players.js> <out.js>'); process.exit(1); }
const D = new Function(fs.readFileSync(src, 'utf8') + ';return D;')();

const S5 = (v) => Math.max(1, Math.min(500, Math.round(v * 500 / 99)));
const O3 = (v) => Math.max(1, Math.min(300, Math.round(v * 300 / 99)));

// classic names exactly as the engine spells them
const CLASSIC = {
  'accelerator': 'Accelerator', 'anticipate': 'Anticipate', 'bruiser': 'Bruiser', 'bullet pass': 'Bullet Pass',
  'chip shot': 'Chip Shot', 'clinical finsher': 'Clinical Finsher', 'deflector': 'Deflector',
  'finesse expert': 'Finesse Expert', 'guardian': 'Guardian', 'header': 'Header', 'penalty expert': 'Penalty Expert',
  'power shot': 'Power Shot', 'rapid': 'Rapid', 'relentless': 'Relentless', 'rush out': 'Rush Out',
  'tiki taka': 'Tiki Taka', 'whipped cross': 'Whipped Cross', 'trickster': 'Trickster',
};
const POS = (p, id) => {
  switch (p.pos) {
    case 'FB': return id % 2 ? 'RB' : 'LB';
    case 'AM': return 'CAM';
    case 'W': return id % 2 ? 'RW' : 'LW';
    default: return p.pos; // GK CB DM CM ST
  }
};
// new (v2) styles that make sense for each position
const NEW_POOL = {
  GK: ['Reach', 'Long Throw'],
  CB: ['Power Header', 'Sliding Tackle', 'Hardshot', 'Reach'],
  LB: ['Sliding Tackle', 'Long Throw', 'Chip Pass', 'Thunder'],
  RB: ['Sliding Tackle', 'Long Throw', 'Chip Pass', 'Thunder'],
  DM: ['Sliding Tackle', 'Vision', 'Chip Pass', 'Long Throw'],
  CM: ['Vision', 'Chip Pass', 'Long Throw', 'Hardshot'],
  CAM: ['Vision', 'Chip Pass', 'Thunder', 'Hardshot'],
  LW: ['Thunder', 'Chip Pass', 'Target', 'Hardshot'],
  RW: ['Thunder', 'Chip Pass', 'Target', 'Hardshot'],
  ST: ['Target', 'Thunder', 'Hardshot', 'Power Header', 'Target+', 'Thunder+'],
};
const NEW_COUNT = { bronze: [0, 1], silver: [1, 1], gold: [1, 2], hero: [2, 2], icon: [2, 3] };
const CLASSIC_TIER = { bronze: 'silver', silver: 'silver', gold: 'gold', hero: 'diamond', icon: 'elite' };
const NEW_TIER = { bronze: 'silver', silver: 'silver', gold: 'gold', hero: 'diamond', icon: 'elite' };

function rng(seed) { let a = seed >>> 0; return () => { a |= 0; a = a + 0x6D2B79F5 | 0; let t = Math.imul(a ^ a >>> 15, 1 | a); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; }; }
const family = (n) => n.startsWith('Target') ? 'T' : n.startsWith('Thunder') ? 'H' : n;

const rows = D.players.map((p) => {
  const pos = POS(p, p.id);
  const rnd = rng(p.id * 7919 + 13);
  const rar = p.rar;
  const ps = [];
  const have = new Set();
  for (const [nm, t] of p.ps) {
    const name = CLASSIC[nm]; if (!name || have.has(name)) continue;
    have.add(name);
    // old data: tier 0 = silver, 1 = gold. Higher rarities are promoted.
    let tier = t === 1 ? 'gold' : 'silver';
    if (t === 1 && rar === 'hero') tier = 'diamond';
    if (t === 1 && rar === 'icon') tier = 'elite';
    if (t === 0 && (rar === 'hero' || rar === 'icon')) tier = 'gold';
    ps.push({ name, tier });
  }
  const [lo, hi] = NEW_COUNT[rar] || [0, 1];
  const want = lo + Math.floor(rnd() * (hi - lo + 1));
  const pool = (NEW_POOL[pos] || []).slice();
  const famUsed = new Set();
  for (let i = 0; i < want && pool.length; i++) {
    const name = pool.splice(Math.floor(rnd() * pool.length), 1)[0];
    if (famUsed.has(family(name))) { i--; continue; }   // never both Target & Target+, or both Thunders
    famUsed.add(family(name));
    ps.push({ name, tier: NEW_TIER[rar] || 'silver' });
  }
  // Thunder+ needs RELENTLESS for its second use: give it to the few that carry it
  if (ps.some((x) => x.name === 'Thunder+') && !ps.some((x) => x.name === 'Relentless')) ps.push({ name: 'Relentless', tier: CLASSIC_TIER[rar] || 'silver' });

  const st = p.st; // [PAC SHO PAS DRI DEF PHY] or GK [DIV HAN KIC REF SPD POS]
  let pace, shooting, passing, dribbling, defending;
  if (p.pos === 'GK') {
    pace = st[4]; shooting = st[2]; passing = st[2]; dribbling = st[3];
    defending = Math.round((st[0] + st[1] + st[3] + st[5]) / 4);
  } else { [pace, shooting, passing, dribbling, defending] = st; }
  return {
    id: p.id, name: p.n, position: pos, rarity: rar, ovr: O3(p.ovr),
    nationality: D.nats[p.nat] ? D.nats[p.nat][0] : null,
    club: D.clubs[p.cl] ? D.clubs[p.cl].n : null,
    age: p.age, height: p.h, foot: p.ft,
    pace: S5(pace), shooting: S5(shooting), passing: S5(passing), dribbling: S5(dribbling), defending: S5(defending),
    weak_foot: p.wf, skill_moves: p.sm, playstyles: ps.slice(0, 8),
    av: p.av, media_path: null, media_type: null, model_data: null, model_version: 0, is_active: true,
  };
});

// Balanced starter XI (4-3-3) from the middle of the pool, so a new save is fair, not a super-team.
const want433 = ['GK', 'LB', 'CB', 'CB', 'RB', 'CM', 'DM', 'CAM', 'LW', 'ST', 'RW'];
const used = new Set(), starters = [];
const mid = rows.filter((r) => r.rarity === 'gold' || r.rarity === 'silver').sort((a, b) => b.ovr - a.ovr);
for (const pos of want433) {
  const cand = mid.filter((r) => r.position === pos && !used.has(r.id));
  const pick = cand[Math.floor(cand.length * 0.45)] || cand[0] || rows.find((r) => !used.has(r.id));
  used.add(pick.id); starters.push(pick.id);
}
const nat = {}; D.nats.forEach((n) => { nat[n[0]] = { c1: n[1], c2: n[2] }; });
fs.writeFileSync(out,
  '/* AUTO-GENERATED by tools/convert_roster.js - 200 local players in players_registry shape. */\n' +
  'window.UA_LOCAL = ' + JSON.stringify({ players: rows, starters, nats: nat }) + ';\n');
const cnt = {}; rows.forEach((r) => r.playstyles.forEach((s) => { cnt[s.name + ':' + s.tier] = (cnt[s.name + ':' + s.tier] || 0) + 1; }));
console.log('rows', rows.length, 'starters', starters.length);
console.log(Object.entries(cnt).sort().map(([k, v]) => k + '=' + v).join('  '));
