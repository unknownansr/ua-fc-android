#!/usr/bin/env node
/* One-time build: packs three.js r160 + GLTFLoader + SkeletonUtils into the
   single classic script three_bundle.js, which index.html loads locally.
   A classic script (not an ES module) is what lets the game run when
   index.html is opened straight from the file system, with no server.

   Needs internet ONCE, on any computer with Node.js:
       npm i three@0.160.0 esbuild
       node tools/build_three.js
   Afterwards nothing needs the internet again; copy the folder anywhere. */
'use strict';
const path = require('path');
const root = path.join(__dirname, '..');
let esbuild;
try { esbuild = require('esbuild'); } catch (e) {
  console.error('esbuild not found. Run:  npm i three@0.160.0 esbuild'); process.exit(1);
}
esbuild.build({
  stdin: {
    contents: [
      "import * as THREE from 'three';",
      "import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader.js';",
      "import * as SkeletonUtils from 'three/examples/jsm/utils/SkeletonUtils.js';",
      'window.THREE = THREE; window.GLTFLoader = GLTFLoader; window.SkeletonUtils = SkeletonUtils;',
    ].join('\n'),
    resolveDir: root,
  },
  bundle: true, minify: true, format: 'iife', target: 'es2019',
  outfile: path.join(root, 'three_bundle.js'),
}).then(() => console.log('Built three_bundle.js'))
  .catch((e) => { console.error(e.message); process.exit(1); });
