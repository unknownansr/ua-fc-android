/* Legacy 2-direction wrapper kept so any other call sites keep working
   unchanged (up + left only, e.g. context buttons). */
function bindSwipe(el, onDown, onTap, onSwipeUp, onSwipeLeft) {
  bindDrag4(el, { onDown, onTap, onSwipeUp, onSwipeLeft, deadzone: 34 });
}
let shootDownMode = null;
const dragHintEl = $('drag-hint');
bindDrag4($('b-shoot'), {
  deadzone: 26,
  onDown: () => {
    if (match.screen !== 'match') return;
    if (userDefending()) { shootDownMode = 'tackle'; userAction('shoot'); return; }
    shootDownMode = 'charge';
    input.charging = true;
    input.power = 0;
    $('power-wrap').classList.add('show');
    dragHintEl.classList.add('show');
  },
  onDragMove: (dx, dy, dir) => {
    if (!dragHintEl) return;
    dragHintEl.querySelectorAll('.dh-arrow').forEach((el) => el.classList.remove('active'));
    if (dir) {
      const cls = dir === 'up' ? '.dh-up' : dir === 'down' ? '.dh-down' : dir === 'left' ? '.dh-left' : '.dh-right';
      const el = dragHintEl.querySelector(cls);
      if (el) el.classList.add('active');
    }
  },
  onUp: () => { dragHintEl.classList.remove('show'); },
  onTap: () => {
    // No direction held -> straight power shot on release (charge still applies).
    if (shootDownMode === 'charge') userAction('shoot');
    shootDownMode = null;
  },
  onSwipeUp: () => { resetChargeUI(); shootDownMode = null; userAction('chip'); },
  onSwipeDown: () => { resetChargeUI(); shootDownMode = null; userAction('curl'); },
  onSwipeLeft: () => { if (shootDownMode === 'charge') userAction('shoot'); else { resetChargeUI(); } shootDownMode = null; },
  onSwipeRight: () => { resetChargeUI(); shootDownMode = null; userAction('curl2'); },
});
bindSwipe($('b-pass'),
  null,
  () => userAction('pass'),
  () => userAction('through'),
  null
);
bindHold($('b-def'), () => userAction('defdrib'));
bindHold($('b-sprint'),
  () => {
    const now = performance.now();
    input.sprint = true;
    if (now - lastRunTap < 300) doBurst();
    lastRunTap = now;
  },
  () => { input.sprint = false; }
);
bindHold($('ctx-thru'), () => userAction('through'));
bindHold($('ctx-chip'), () => userAction('chip'));
bindHold($('ctx-switch'), () => userAction('switch'));
bindHold($('ctx-chippass'), () => userAction('chippass'));
bindHold($('b-thunder'), () => userAction('thunder'));
const keysDown = new Set();
function isTypingInField() {
  const el = document.activeElement;
  return !!el && (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA' || el.isContentEditable);
}
window.addEventListener('keydown', (e) => {
  if (isTypingInField()) return; // never hijack keystrokes meant for a text field (search boxes, chat, etc.)
  if (e.repeat) return;
  keysDown.add(e.code);
  audio.init();
  audio.resume();
  switch (e.code) {
    case 'KeyX': userAction('pass'); break;
    case 'KeyZ': userAction('through'); break;
    case 'KeyV': userAction('chip'); break;
    case 'KeyB': userAction('curl'); break;
    case 'KeyF': userAction('chippass'); break;   // Chip Pass (lob)
    case 'KeyT': userAction('thunder'); break;    // Thunder / Thunder+ ability
    case 'KeyE': userAction('defdrib'); break;
    case 'Space': e.preventDefault(); userAction('switch'); break;
    case 'ShiftLeft': case 'ShiftRight': {
      input.sprint = true;
      const now = performance.now();
      if (now - lastRunTap < 300) doBurst();
      lastRunTap = now;
      break;
    }
    case 'KeyC':
      if (!userDefending()) { input.charging = true; input.power = 0; $('power-wrap').classList.add('show'); }
      else userAction('shoot');
      break;
    case 'KeyQ': cycleCamera(); break;
    case 'KeyP': case 'Escape': togglePause(); break;
  }
});
window.addEventListener('keyup', (e) => {
  if (isTypingInField()) return;
  keysDown.delete(e.code);
  if (e.code === 'ShiftLeft' || e.code === 'ShiftRight') input.sprint = false;
  if (e.code === 'KeyC' && input.charging) userAction('shoot');
});
function pollKeyboard() {
  if (isTypingInField()) return; // don't let stale keysDown drive movement while a field is focused
  let kx = 0, ky = 0;
  if (keysDown.has('KeyA') || keysDown.has('ArrowLeft')) kx -= 1;
  if (keysDown.has('KeyD') || keysDown.has('ArrowRight')) kx += 1;
  if (keysDown.has('KeyW') || keysDown.has('ArrowUp')) ky += 1;
  if (keysDown.has('KeyS') || keysDown.has('ArrowDown')) ky -= 1;
  if (joyId === null && !mouseMoveActive) { input.mx = kx; input.my = ky; }
}

/* ==========================================================================
   DEVICE-AWARE CONTROLS
   Mobile/touch devices -> on-screen joystick + buttons (#touch, already built).
   Desktop/mouse+keyboard -> #touch is hidden; movement comes from keyboard
   (WASD/arrows) plus an invisible right-click-and-drag mouse-move layer;
   actions stay on keyboard (X/Z/V/B/E/Space/Shift/C) and an optional
   connected gamepad (left stick = move, face buttons = actions).
   ========================================================================== */
const isTouchDevice = ('ontouchstart' in window) || navigator.maxTouchPoints > 0;
function setupControlsForDevice() {
  const touchEl = $('touch');
  if (!touchEl) return;
  const inMatch = match.screen === 'match';
  if (isTouchDevice) {
    touchEl.classList.toggle('hidden', !inMatch);
    touchEl.classList.remove('desktop-mode');
  } else {
    // Desktop: keep the on-screen buttons invisible/inert — keyboard + mouse
    // drive the game instead. Buttons still exist in the DOM (harmless) but
    // are not shown or interactive on desktop.
    touchEl.classList.add('hidden');
    touchEl.classList.add('desktop-mode');
  }
}
/* ---------- invisible mouse-drag movement (desktop) ---------- */
let mouseMoveActive = false;
let mouseOrigin = { x: 0, y: 0 };
const gameCanvas = $('game-canvas');
if (gameCanvas) {
  gameCanvas.addEventListener('mousedown', (e) => {
    if (isTouchDevice || match.screen !== 'match') return;
    if (e.button !== 0) return; // left click only; keep right-click free for camera/menus if added later
    mouseMoveActive = true;
    mouseOrigin = { x: e.clientX, y: e.clientY };
  });
  window.addEventListener('mousemove', (e) => {
    if (!mouseMoveActive) return;
    const dx = e.clientX - mouseOrigin.x, dy = e.clientY - mouseOrigin.y;
    const max = 90;
    const len = Math.hypot(dx, dy);
    const cx = len > max ? (dx / len) * max : dx;
    const cy = len > max ? (dy / len) * max : dy;
    input.mx = cx / max;
    input.my = -cy / max;
  });
  const endMouseMove = () => {
    if (!mouseMoveActive) return;
    mouseMoveActive = false;
    input.mx = 0;
    input.my = 0;
  };
  window.addEventListener('mouseup', endMouseMove);
  gameCanvas.addEventListener('mouseleave', endMouseMove);
  // Left click alone (no drag) still fires a pass, mirroring the mobile
  // pass button, so mouse-only play has an action without touching keys.
  gameCanvas.addEventListener('click', () => {
    if (isTouchDevice || match.screen !== 'match' || mouseMoveActive) return;
    userAction('pass');
  });
}
/* ---------- gamepad / joystick support (desktop) ---------- */
let gamepadIndex = null;
window.addEventListener('gamepadconnected', (e) => { gamepadIndex = e.gamepad.index; toast('Controller connected'); });
window.addEventListener('gamepaddisconnected', (e) => { if (gamepadIndex === e.gamepad.index) gamepadIndex = null; });
let gpPrevButtons = [];
function pollGamepad() {
  if (gamepadIndex === null) return;
  const gp = navigator.getGamepads ? navigator.getGamepads()[gamepadIndex] : null;
  if (!gp) return;
  const dead = 0.18;
  let gx = gp.axes[0] || 0, gy = gp.axes[1] || 0;
  if (Math.abs(gx) < dead) gx = 0;
  if (Math.abs(gy) < dead) gy = 0;
  if ((gx !== 0 || gy !== 0) && joyId === null && !mouseMoveActive) {
    input.mx = gx;
    input.my = -gy;
  }
  input.sprint = !!(gp.buttons[10] && gp.buttons[10].pressed); // L3/left stick click or shoulder, common sprint mapping
  const pressed = (i) => gp.buttons[i] && gp.buttons[i].pressed;
  const justPressed = (i) => pressed(i) && !gpPrevButtons[i];
  if (justPressed(0)) userAction('pass');    // A / Cross
  if (justPressed(1)) userAction('shoot');   // B / Circle
  if (justPressed(2)) userAction('through'); // X / Square
  if (justPressed(3)) userAction('chip');    // Y / Triangle
  if (justPressed(5)) userAction('defdrib'); // Right bumper
  if (justPressed(9)) togglePause();         // Start/Options
  gpPrevButtons = gp.buttons.map((b) => b.pressed);
}
function cycleCamera() {
  const idx = CAM_MODES.indexOf(settings.camera);
  settings.camera = CAM_MODES[(idx + 1) % CAM_MODES.length];
  saveSettings();
  syncSeg('seg-cam', settings.camera);
  syncSeg('set-cam', settings.camera);
  toast('CAMERA · ' + CAM_LABELS[settings.camera].toUpperCase());
}

/* ==========================================================================
   30 · SCREENS
   ========================================================================== */
function showScreen(id) {
  for (const s of ['scr-main', 'scr-team', 'scr-royale', 'scr-settings', 'scr-pause', 'scr-half', 'scr-full', 'scr-load', 'scr-none', 'scr-market', 'scr-store', 'scr-exchange', 'scr-club', 'scr-friends', 'scr-league', 'scr-trophy', 'scr-activities', 'scr-featured', 'scr-uapass', 'scr-bonus', 'scr-quests', 'scr-mail', 'scr-play']) {
    $(s).classList.toggle('hidden', s !== id);
  }
  const inMatch = id === null;
  $('hud').classList.toggle('hidden', !(inMatch || ['scr-pause', 'scr-half', 'scr-full'].includes(id)));
  $('touch').classList.toggle('hidden', !inMatch || !isTouchDevice);
  $('btn-ai-fab').classList.toggle('show', !inMatch && id !== 'scr-load' && id !== 'scr-none');
}
function enterMenu() {
  match.screen = 'menu';
  match.state = 'idle';
  voiceStopSpeaking();
  updateCoinUI();
  updateHubTopbar();
  showScreen('scr-main');
  renderHubCarousels();
  if (!homeBannersLoaded) { homeBannersLoaded = true; loadHomeBanners().then(() => renderHubCarousels()); }
  if (!royaleDraftsCache.length) loadRoyaleDrafts().catch(() => {});
  if (cloudUser && !mailGameLoaded) { loadMailGame().then(updateMailBadge).catch(() => {}); }
  if (pendingDaily > 0) {
    pendingDaily = 0;
    setTimeout(() => toast('DAILY BONUS +150 🪙'), 500);
  }
}

/* ==========================================================================
   HOME HUB — MAIN + SIDE ROTATING BANNER CAROUSELS
   Slides pull from existing promo/event data already in the app (no new
   backend needed). Add more slides to HUB_MAIN_SLIDES / uses royale drafts
   for the side carousel automatically once loaded.
   ========================================================================== */
/* ==========================================================================
   HOME BANNERS — images managed from UA FC MANAGER (home_banners table +
   home-banners storage bucket). Falls back to the existing gradients/emoji
   if a slot has no image yet, so nothing breaks before an admin uploads one.
   ========================================================================== */
let homeBannersLoaded = false;
let homeBannersCache = {}; // slot_key -> { image_path, title, subtitle }
function homeBannerUrl(path) {
  if (!path) return null;
  return getAssetUrl('home-banners', path);
}
function focalPos(row) {
  const fx = row && row.focal_x != null ? row.focal_x : 50;
  const fy = row && row.focal_y != null ? row.focal_y : 50;
  return `${fx}% ${fy}%`;
}
async function loadHomeBanners() {
  try {
    const { data, error } = await sb.from('home_banners').select('*');
    if (error) throw error;
    homeBannersCache = {};
    (data || []).forEach((row) => { homeBannersCache[row.slot_key] = row; });
    applyLoadingScreenBanners();
    await preloadLoadingScreenBanner();
  } catch (e) {
    ;
  }
}
function applyLoadingScreenBanners() {
  // scr-load / scr-none / scr-team share one background image set inline;
  // override with the admin-uploaded 'loading' banner (from Supabase's
  // home-banners bucket) if one exists, otherwise they keep the plain
  // dark fallback background defined in ui.css.
  const loading = homeBannersCache['loading'];
  const url = loading && homeBannerUrl(loading.image_path);
  if (!url) return;
  ['scr-load', 'scr-none', 'scr-team'].forEach((id) => {
    const el = $(id);
    if (el) {
      el.style.backgroundImage = `linear-gradient(180deg, rgba(3,8,18,.55), rgba(3,8,18,.92)), url('${url}')`;
      el.style.backgroundSize = 'cover';
      el.style.backgroundPosition = focalPos(loading);
      el.style.backgroundRepeat = 'no-repeat';
    }
  });
}
/* Preloads the loading-screen background as a real Image() so it's
   already decoded in the browser cache before we reveal the screen —
   used by boot()'s asset-preload phase (see PRELOAD_WEIGHTS below). */
function preloadLoadingScreenBanner() {
  return new Promise((resolve) => {
    const loading = homeBannersCache['loading'];
    const url = loading && homeBannerUrl(loading.image_path);
    if (!url) { resolve(); return; }
    const img = new Image();
    img.onload = () => resolve();
    img.onerror = () => resolve(); // never block boot on a bad/missing banner
    img.src = url;
  });
}

/* ==========================================================================
   ACTIVITIES — official news/updates feed, admin-managed from UA FC MANAGER
   (`activities` table + `activity-media` storage bucket). This is purely
   informational: news, next-update teasers, announcements, maintenance
   notices, patch notes, community posts. NOT quests, NOT events — nothing
   here is completable or time-limited gameplay, it's just communication
   from the dev/admin team, editable remotely with no client update needed.
   ========================================================================== */
const ACT_CATEGORIES = ['NEXT UPDATE', 'NEWS', 'ANNOUNCEMENT', 'TEASER', 'MAINTENANCE', 'PATCH NOTES', 'COMMUNITY'];
let activitiesCache = [];       // all published, non-archived rows, pinned-first then newest-first
let activitiesLoaded = false;
let activitiesActiveCat = 'all';
let activitiesReadIds = new Set(); // read-state, kept client-side per device (see below)

function activityMediaUrl(path) {
  if (!path) return null;
  return getAssetUrl('activity-media', path);
}
function activityReadStorageKey() {
  // Read/unread is a lightweight per-device UX nicety, not account data —
  // deliberately NOT synced to Supabase (mirrors how uafc-guest-onboarded
  // stays local: it's a "have I seen this" flag, not currency/progress).
  return 'uafc-activities-read';
}
function loadActivitiesReadState() {
  try {
    const raw = localStorage.getItem(activityReadStorageKey());
    activitiesReadIds = new Set(raw ? JSON.parse(raw) : []);
  } catch (e) { activitiesReadIds = new Set(); }
}
function markActivityRead(id) {
  if (activitiesReadIds.has(id)) return;
  activitiesReadIds.add(id);
  try { localStorage.setItem(activityReadStorageKey(), JSON.stringify([...activitiesReadIds])); } catch (e) {}
}
function activityCatClass(cat) {
  return 'cat-' + String(cat || '').replace(/\s+/g, '-').toUpperCase();
}
function activityCatEmoji(cat) {
  const map = {
    'NEXT UPDATE': '🚀', NEWS: '📰', ANNOUNCEMENT: '📢', TEASER: '👀',
    MAINTENANCE: '🔧', 'PATCH NOTES': '📋', COMMUNITY: '🎉',
  };
  return map[cat] || '🔔';
}
function activityTimeAgo(iso) {
  if (!iso) return '';
  const diffMs = Date.now() - new Date(iso).getTime();
  const mins = Math.floor(diffMs / 60000);
  if (mins < 1) return 'just now';
  if (mins < 60) return mins + 'm ago';
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return hrs + 'h ago';
  const days = Math.floor(hrs / 24);
  if (days < 30) return days + 'd ago';
  return new Date(iso).toLocaleDateString();
}
async function loadActivities() {
  $('act-loading').classList.remove('hidden');
  $('act-empty').classList.add('hidden');
  try {
    const { data, error } = await sb
      .from('activities')
      .select('*')
      .eq('status', 'published')
      .order('pinned', { ascending: false })
      .order('published_at', { ascending: false });
    if (error) throw error;
    activitiesCache = data || [];
    activitiesLoaded = true;
    renderActivityFeed();
    updateActivitiesBadge();
  } catch (err) {
    ;
    activitiesCache = [];
    renderActivityFeed();
  } finally {
    $('act-loading').classList.add('hidden');
  }
}
function renderActivityFeed() {
  const feed = $('act-feed');
  const filtered = activitiesActiveCat === 'all'
    ? activitiesCache
    : activitiesCache.filter((a) => a.category === activitiesActiveCat);
  $('act-empty').classList.toggle('hidden', filtered.length > 0);
  feed.innerHTML = filtered.map((a) => {
    const bannerUrl = activityMediaUrl(a.cover_path);
    const unread = !activitiesReadIds.has(a.id);
    const catCls = activityCatClass(a.category);
    return `
    <div class="act-card ${a.pinned ? 'pinned' : ''}" data-id="${a.id}">
      ${a.pinned ? '<div class="act-pin-flag">📌 PINNED</div>' : ''}
      ${bannerUrl ? `<img class="act-cover" src="${bannerUrl}" alt="" loading="lazy" />` : ''}
      <div class="act-badge ${catCls}">${activityCatEmoji(a.category)} ${escHtml(a.category || 'NEWS')}</div>
      <div class="act-title">${escHtml(a.title)}</div>
      ${a.description ? `<div class="act-desc">${escHtml(a.description)}</div>` : ''}
      <div class="act-meta-row">
        ${unread ? '<span class="act-unread-dot"></span>' : ''}
        <span>${activityTimeAgo(a.published_at)}</span>
        ${a.version ? `<span class="act-version">v${escHtml(a.version)}</span>` : ''}
      </div>
    </div>`;
  }).join('');
  feed.querySelectorAll('.act-card').forEach((card) => {
    card.addEventListener('click', () => openActivityDetail(card.dataset.id));
  });
}
function updateActivitiesBadge() {
  const unreadCount = activitiesCache.filter((a) => !activitiesReadIds.has(a.id)).length;
  const dot = $('activities-badge-dot');
  if (dot) dot.classList.toggle('hidden', unreadCount === 0);
}
function openActivityDetail(id) {
  const a = activitiesCache.find((x) => String(x.id) === String(id));
  if (!a) return;
  markActivityRead(a.id);
  updateActivitiesBadge();
  const bannerUrl = activityMediaUrl(a.cover_path);
  const banner = $('act-detail-banner');
  banner.style.backgroundImage = bannerUrl ? `url('${bannerUrl}')` : '';
  banner.innerHTML = '';
  const catEl = $('act-detail-cat');
  catEl.className = 'act-badge ' + activityCatClass(a.category);
  catEl.textContent = `${activityCatEmoji(a.category)} ${a.category || 'NEWS'}`;
  $('act-detail-title').textContent = a.title;
  $('act-detail-meta').textContent = [activityTimeAgo(a.published_at), a.version ? 'v' + a.version : null].filter(Boolean).join(' · ');
  $('act-detail-content').textContent = a.content || a.description || '';
  $('act-detail-backdrop').classList.remove('hidden');
  // Re-render the feed in the background so its unread dot disappears
  // once the person returns to it, without needing to reopen the screen.
  renderActivityFeed();
}
$('act-detail-close').addEventListener('click', () => { audio.ui(); $('act-detail-backdrop').classList.add('hidden'); });
$('act-detail-backdrop').addEventListener('click', (e) => { if (e.target === $('act-detail-backdrop')) $('act-detail-backdrop').classList.add('hidden'); });
qsa('#act-cat-tabs .fr-tab').forEach((btn) => {
  btn.addEventListener('click', () => {
    audio.ui();
    qsa('#act-cat-tabs .fr-tab').forEach((b) => b.classList.toggle('on', b === btn));
    activitiesActiveCat = btn.dataset.cat;
    renderActivityFeed();
  });
});
function enterActivities() {
  showScreen('scr-activities');
  if (!activitiesLoaded) loadActivities();
  else { renderActivityFeed(); updateActivitiesBadge(); }
}
$('act-back').addEventListener('click', () => { audio.ui(); enterMenu(); });

/* ==========================================================================
   FEATURED — football trivia. Pre-seeded question pool in Supabase
   (`trivia_questions` table), optionally extended by admins from
   UA FC MANAGER. Correct answers pay gems by difficulty tier:
   easy 10, medium 25, hard 50, very_hard 100, expert 200. Signed-in
   players can't re-earn gems from a question they've already answered
   correctly (tracked in user_trivia_answered); guests can play for fun
   but earn nothing, since gems require a cloud account to persist.
   ========================================================================== */
const TRIVIA_GEM_REWARDS = { easy: 10, medium: 25, hard: 50, very_hard: 100, expert: 200 };
const TRIVIA_DIFF_LABELS = { easy: '🟢 Easy', medium: '🔵 Medium', hard: '🟣 Hard', very_hard: '🔴 Very Hard', expert: '🟡 Expert' };
const TRIVIA_CAT_LABELS = {
  players: '⚽ Players', trophies: '🏆 Trophies', countries: '🌍 Countries',
  clubs: '🏟️ Clubs', history: '📜 History', records: '📊 Records',
  who_am_i: '🧠 Who Am I?', guess_player: '🖼️ Guess the Player',
};
let triviaPoolCache = null;      // all active questions, fetched once and reused for the session
let triviaAnsweredIds = new Set(); // question ids this signed-in user has already earned gems for
let triviaCurrentQuestion = null;
let triviaAnswerLocked = false;

function triviaMediaUrl(path) {
  if (!path) return null;
  return getAssetUrl('trivia-media', path);
}
async function loadTriviaAnsweredIds() {
  if (!cloudUser) { triviaAnsweredIds = new Set(); return; }
  try {
    const { data, error } = await sb.from('user_trivia_answered').select('question_id').eq('user_id', cloudUser.id);
    if (error) throw error;
    triviaAnsweredIds = new Set((data || []).map((r) => r.question_id));
  } catch (err) {
    ;
    triviaAnsweredIds = new Set();
  }
}
async function ensureTriviaPoolLoaded() {
  if (triviaPoolCache) return triviaPoolCache;
  try {
    const { data, error } = await sb.from('trivia_questions').select('*').eq('is_active', true);
    if (error) throw error;
    triviaPoolCache = data || [];
  } catch (err) {
    ;
    triviaPoolCache = [];
  }
  return triviaPoolCache;
}
function pickNextTriviaQuestion() {
  const pool = triviaPoolCache || [];
  // Prefer a question this account hasn't already earned gems from, so
  // repeat play keeps surfacing fresh content; once everything has been
  // answered at least once, fall back to the full pool (replayable for
  // fun, just with no further reward — enforced server-side via the
  // insert-if-not-exists check in submitTriviaAnswer).
  const unanswered = pool.filter((q) => !triviaAnsweredIds.has(q.id));
  const candidates = unanswered.length ? unanswered : pool;
  if (!candidates.length) return null;
  return candidates[Math.floor(Math.random() * candidates.length)];
}
function enterFeatured() {
  showScreen('scr-featured');
  $('feat-intro').classList.remove('hidden');
  $('feat-question').classList.add('hidden');
  $('feat-result').classList.add('hidden');
  $('feat-empty').classList.add('hidden');
  $('feat-signin-note').classList.toggle('hidden', !!cloudUser);
}
$('feat-back').addEventListener('click', () => { audio.ui(); enterMenu(); });
$('feat-start-btn').addEventListener('click', async () => {
  audio.ui();
  await startTriviaQuestion();
});
$('feat-next-btn').addEventListener('click', async () => {
  audio.ui();
  await startTriviaQuestion();
});
async function startTriviaQuestion() {
  $('feat-intro').classList.add('hidden');
  $('feat-result').classList.add('hidden');
  $('feat-empty').classList.add('hidden');
  await ensureTriviaPoolLoaded();
  if (cloudUser) await loadTriviaAnsweredIds();
  const q = pickNextTriviaQuestion();
  if (!q) {
    $('feat-question').classList.add('hidden');
    $('feat-empty').classList.remove('hidden');
    return;
  }
  triviaCurrentQuestion = q;
  triviaAnswerLocked = false;
  $('feat-q-diff-badge').className = 'feat-diff-badge diff-' + q.difficulty;
  $('feat-q-diff-badge').textContent = TRIVIA_DIFF_LABELS[q.difficulty] || q.difficulty;
  $('feat-q-cat-badge').textContent = TRIVIA_CAT_LABELS[q.category] || q.category;
  const imgUrl = triviaMediaUrl(q.image_path);
  const imgEl = $('feat-q-image');
  imgEl.classList.toggle('hidden', !imgUrl);
  if (imgUrl) imgEl.src = imgUrl;
  $('feat-q-text').textContent = q.question;
  const choicesEl = $('feat-q-choices');
  choicesEl.innerHTML = (q.choices || []).map((c, i) => `<button class="feat-choice-btn" data-idx="${i}">${escHtml(c)}</button>`).join('');
  choicesEl.querySelectorAll('.feat-choice-btn').forEach((btn) => {
    btn.addEventListener('click', () => submitTriviaAnswer(parseInt(btn.dataset.idx, 10)));
  });
  $('feat-question').classList.remove('hidden');
}
async function submitTriviaAnswer(chosenIdx) {
  if (triviaAnswerLocked || !triviaCurrentQuestion) return;
  triviaAnswerLocked = true;
  audio.ui();
  const q = triviaCurrentQuestion;
  const correct = chosenIdx === q.correct_index;
  const choicesEl = $('feat-q-choices');
  choicesEl.querySelectorAll('.feat-choice-btn').forEach((btn) => {
    const idx = parseInt(btn.dataset.idx, 10);
    btn.classList.add('disabled');
    if (idx === q.correct_index) btn.classList.add('correct');
    else if (idx === chosenIdx) btn.classList.add('wrong');
  });
  const reward = TRIVIA_GEM_REWARDS[q.difficulty] || 0;
  let actuallyAwarded = 0;
  if (correct && cloudUser && !triviaAnsweredIds.has(q.id)) {
    // Insert-if-not-exists is the real gate against double rewards (a
    // unique primary key on (user_id, question_id) makes this safe even
    // against a rapid double-submit); the in-memory Set above is just a
    // fast local check to avoid an unnecessary round-trip in the common case.
    try {
      const { error } = await sb.from('user_trivia_answered').insert({ user_id: cloudUser.id, question_id: q.id });
      if (!error) {
        triviaAnsweredIds.add(q.id);
        const ok = await addGems(reward);
        if (ok) actuallyAwarded = reward;
      } else if (error.code !== '23505') { // 23505 = already answered (race with another tab) — not a real error
        ;
      }
    } catch (err) {
      ;
    }
  }
  setTimeout(() => showTriviaResult(correct, q, actuallyAwarded), 700);
}
function showTriviaResult(correct, q, awarded) {
  $('feat-question').classList.add('hidden');
  const icon = $('feat-result-icon');
  const title = $('feat-result-title');
  const explain = $('feat-result-explain');
  const rewardEl = $('feat-result-reward');
  if (correct) {
    icon.textContent = '🎉';
    title.textContent = 'Correct!';
    title.style.color = 'var(--fc-green)';
  } else {
    icon.textContent = '❌';
    title.textContent = 'Not quite!';
    title.style.color = 'var(--fc-danger)';
  }
  explain.textContent = q.explanation || '';
  if (awarded > 0) {
    rewardEl.textContent = `+${awarded} 💎`;
    rewardEl.classList.remove('hidden');
  } else if (correct && !cloudUser) {
    rewardEl.textContent = 'Sign in to earn gems from trivia!';
    rewardEl.style.color = 'var(--fc-dim)';
    rewardEl.style.fontSize = '12px';
    rewardEl.classList.remove('hidden');
  } else if (correct && cloudUser) {
    rewardEl.textContent = 'Already earned gems for this one — nice recall though!';
    rewardEl.style.color = 'var(--fc-dim)';
    rewardEl.style.fontSize = '12px';
    rewardEl.classList.remove('hidden');
  } else {
    rewardEl.classList.add('hidden');
  }
  $('feat-result').classList.remove('hidden');
}

/* ==========================================================================
   UA PASS — seasonal progression system (spec calls it "UA Pass", was
   previously named "Star Pass" in the rail button). Free + Premium tracks
   per level; Premium is unlocked by spending UA Points (not real money).
   All XP grants and reward claims go through SECURITY DEFINER Postgres
   functions (ua_pass_add_xp / ua_pass_claim_reward / ua_pass_buy_premium)
   — the client never writes XP, level, premium status or claims directly,
   so a modified client can't fake progress. See the ua_pass_* migrations
   for the server-side validation logic itself.
   ========================================================================== */
const UAP_REWARD_ICONS = {
  coins: '🪙', gems: '💎', ua_points: '⭐', player: '⚽', special_card: '🃏',
  pack: '🎁', kit: '👕', card_design: '🎨', cosmetic: '🏟️', other: '👑',
};
let uapSeason = null;
let uapLevels = [];         // [{...level, rewards: {free, premium}}]
let uapProgress = null;     // {xp, is_premium} for this user+season, or null if not signed in / no row yet
let uapClaimedIds = new Set();

function uapBannerUrl(path) {
  if (!path) return null;
  return getAssetUrl('ua-pass-media', path);
}
function uapRewardLabel(r) {
  if (!r) return '';
  if (r.reward_type === 'coins') return (r.reward_amount || 0).toLocaleString();
  if (r.reward_type === 'gems') return (r.reward_amount || 0).toLocaleString();
  if (r.reward_type === 'ua_points') return (r.reward_amount || 0).toLocaleString();
  return r.reward_label || r.reward_type.replace('_', ' ');
}
async function loadActiveUAPassSeason() {
  try {
    const { data: season, error } = await sb.from('ua_pass_seasons').select('*').in('status', ['active', 'paused']).order('created_at', { ascending: false }).limit(1).maybeSingle();
    if (error) throw error;
    uapSeason = season || null;
    if (!uapSeason) { uapLevels = []; return; }
    const { data: levels, error: lErr } = await sb.from('ua_pass_levels').select('*').eq('season_id', uapSeason.id).order('level_number', { ascending: true });
    if (lErr) throw lErr;
    const levelIds = (levels || []).map((l) => l.id);
    let rewards = [];
    if (levelIds.length) {
      const { data: rData, error: rErr } = await sb.from('ua_pass_rewards').select('*').in('level_id', levelIds);
      if (rErr) throw rErr;
      rewards = rData || [];
    }
    uapLevels = (levels || []).map((l) => ({
      ...l,
      free: rewards.find((r) => r.level_id === l.id && r.track === 'free') || null,
      premium: rewards.find((r) => r.level_id === l.id && r.track === 'premium') || null,
    }));
  } catch (err) {
    ;
    uapSeason = null;
    uapLevels = [];
  }
}
async function loadUAPassProgress() {
  uapProgress = null;
  uapClaimedIds = new Set();
  if (!cloudUser || !uapSeason) return;
  try {
    const { data, error } = await sb.from('ua_pass_progress').select('*').eq('user_id', cloudUser.id).eq('season_id', uapSeason.id).maybeSingle();
    if (error) throw error;
    uapProgress = data || { xp: 0, is_premium: false };
    const rewardIds = uapLevels.flatMap((l) => [l.free && l.free.id, l.premium && l.premium.id]).filter(Boolean);
    if (rewardIds.length) {
      const { data: claims, error: cErr } = await sb.from('ua_pass_claims').select('reward_id').eq('user_id', cloudUser.id).in('reward_id', rewardIds);
      if (cErr) throw cErr;
      uapClaimedIds = new Set((claims || []).map((c) => c.reward_id));
    }
  } catch (err) {
    ;
    uapProgress = { xp: 0, is_premium: false };
  }
}
/* ==========================================================================
   BONUS — player-linked reward unlocks, fully admin-controlled from
   UA FC MANAGER (bonus_players table). Obtaining a marked Bonus Player
   unlocks the entry here; rewards are never auto-granted, the user must
   open this screen and tap Claim. All validation (active, not expired,
   player actually owned, not already claimed, rewards valid) plus the
   atomic grant happens server-side in the bonus_claim_reward RPC —
   mirrors ua_pass_claim_reward's pattern exactly. This screen only
   reflects what the server has already decided; nothing here is trusted
   for the actual grant.
   ========================================================================== */
const BONUS_REWARD_ICONS = { coins: '🪙', gems: '💎', pack: '📦' };
let bonusCache = null;         // [{ ...bonus_players row, rewards:[...], claimed:bool, owned:bool }]
let bonusClaimedIds = new Set(); // bonus_players.id this account has already claimed
let bonusOwnedPlayerIds = new Set(); // player_id this account owns (from user_players)
let bonusLoaded = false;

function bonusRewardLabel(r) {
  if (r.reward_type === 'coins') return `${Number(r.amount || 0).toLocaleString()} Coins`;
  if (r.reward_type === 'gems') return `${Number(r.amount || 0).toLocaleString()} Gems`;
  if (r.reward_type === 'pack') return `${r.amount > 1 ? r.amount + 'x ' : ''}${r.pack_name || 'Special Pack'}`;
  return 'Reward';
}
function bonusStatusOf(b) {
  const now = Date.now();
  const starts = b.starts_at ? new Date(b.starts_at).getTime() : null;
  const expires = b.expires_at ? new Date(b.expires_at).getTime() : null;
  if (!b.is_active) return 'inactive';
  if (starts && now < starts) return 'inactive';
  if (expires && now > expires) return 'expired';
  if (bonusClaimedIds.has(b.id)) return 'claimed';
  if (bonusOwnedPlayerIds.has(b.player_id)) return 'unlocked';
  return 'locked';
}
async function loadBonusOwnedAndClaimed() {
  if (!cloudUser) { bonusOwnedPlayerIds = new Set(); bonusClaimedIds = new Set(); return; }
  try {
    const [{ data: owned, error: oErr }, { data: claims, error: cErr }] = await Promise.all([
      sb.from('user_players').select('player_id').eq('user_id', cloudUser.id),
      sb.from('user_bonus_claims').select('bonus_id').eq('user_id', cloudUser.id),
    ]);
    if (oErr) throw oErr;
    if (cErr) throw cErr;
    bonusOwnedPlayerIds = new Set((owned || []).map((r) => r.player_id));
    bonusClaimedIds = new Set((claims || []).map((r) => r.bonus_id));
  } catch (err) {
    ;
    bonusOwnedPlayerIds = new Set();
    bonusClaimedIds = new Set();
  }
}
async function loadBonuses() {
  $('bonus-loading').classList.remove('hidden');
  $('bonus-empty').classList.add('hidden');
  try {
    const { data: bonuses, error: bErr } = await sb.from('bonus_players')
      .select('*, players_registry(name, ovr, rarity, media_path, media_type)')
      .order('created_at', { ascending: false });
    if (bErr) throw bErr;
    const ids = (bonuses || []).map((b) => b.id);
    let rewardsByBonus = new Map();
    if (ids.length) {
      const { data: rewards, error: rErr } = await sb.from('bonus_rewards').select('*').in('bonus_id', ids);
      if (rErr) throw rErr;
      for (const r of (rewards || [])) {
        if (!rewardsByBonus.has(r.bonus_id)) rewardsByBonus.set(r.bonus_id, []);
        rewardsByBonus.get(r.bonus_id).push(r);
      }
    }
    await loadBonusOwnedAndClaimed();
    bonusCache = (bonuses || []).map((b) => ({ ...b, rewards: rewardsByBonus.get(b.id) || [] }));
    bonusLoaded = true;
    updateBonusBadge();
  } catch (err) {
    ;
    bonusCache = [];
  } finally {
    $('bonus-loading').classList.add('hidden');
    renderBonus();
  }
}
function updateBonusBadge() {
  const dot = $('bonus-badge-dot');
  if (!dot) return;
  const hasClaimable = (bonusCache || []).some((b) => bonusStatusOf(b) === 'unlocked');
  dot.classList.toggle('hidden', !hasClaimable);
}
function renderBonus() {
  $('bonus-signin-note').classList.toggle('hidden', !!cloudUser);
  const list = bonusCache || [];
  // Only ever show bonuses that are (or recently were) active/published —
  // never-activated drafts stay invisible to players, same as trivia's
  // is_active filter.
  const visible = list.filter((b) => b.is_active || bonusClaimedIds.has(b.id));
  $('bonus-empty').classList.toggle('hidden', visible.length !== 0);
  $('bonus-list').innerHTML = visible.map((b) => {
    const p = b.players_registry || {};
    const status = bonusStatusOf(b);
    const media = p.media_path ? mediaUrlFor(p.media_path) : null;
    const rewardsHtml = (b.rewards || []).map((r) =>
      `<div class="bonus-reward-chip"><span>${BONUS_REWARD_ICONS[r.reward_type] || '🎁'}</span><span>${escHtmlGame(bonusRewardLabel(r))}</span></div>`
    ).join('');
    let stateHtml = '';
    if (status === 'locked') {
      stateHtml = `<div class="bonus-state bonus-state-locked">🔒 Obtain <b>${escHtmlGame(p.name || 'this player')}</b> to unlock this Bonus.</div>`;
    } else if (status === 'expired') {
      stateHtml = `<div class="bonus-state bonus-state-expired">⏰ BONUS EXPIRED</div>`;
    } else if (status === 'claimed') {
      stateHtml = `<div class="bonus-state bonus-state-claimed">✅ CLAIMED</div>`;
    } else if (status === 'unlocked') {
      stateHtml = `<button class="btn big bonus-claim-btn" data-bonus-id="${b.id}"><span>Claim Rewards</span></button>`;
    }
    return `<div class="bonus-card bonus-card-${status}">
      <div class="bonus-card-top">
        <img class="bonus-card-img" src="${media || ''}" alt="" loading="lazy" onerror="this.style.visibility='hidden'" />
        <div class="bonus-card-info">
          <div class="bonus-card-name">${escHtmlGame(p.name || 'Unknown Player')}</div>
          <div class="bonus-card-sub">${p.ovr ? ovrD(p.ovr) + ' OVR' : ''}${p.ovr && p.rarity ? ' · ' : ''}${escHtmlGame(p.rarity || '')}</div>
        </div>
      </div>
      <div class="bonus-rewards-row">${rewardsHtml}</div>
      ${stateHtml}
    </div>`;
  }).join('');
  qsaGame('.bonus-claim-btn', $('bonus-list')).forEach((btn) => {
    btn.addEventListener('click', () => attemptClaimBonus(btn.dataset.bonusId));
  });
}
// mainui.js has no qsa helper of its own (utils.js's qsa is global, but
// scoped lookups here follow the same $(id) convention as everywhere else)
function qsaGame(sel, root) { return Array.from((root || document).querySelectorAll(sel)); }
async function attemptClaimBonus(bonusId) {
  if (!cloudUser) { toast('Sign in to claim Bonus rewards.'); return; }
  audio.ui();
  try {
    const { data, error } = await sb.rpc('bonus_claim_reward', { p_bonus_id: bonusId });
    if (error) throw error;
    const result = Array.isArray(data) ? data[0] : data;
    if (!result || !result.ok) {
      toast(result ? result.message : 'Could not claim this Bonus.');
      return;
    }
    bonusClaimedIds.add(bonusId);
    // The RPC already granted coins/gems atomically server-side — just
    // refresh local balances so the topbar reflects the claim immediately.
    await pullCloudState();
    await refreshGemsBalance();
    updateHubTopbar();
    updateCoinUI();
    showBonusClaimPopup(result);
    updateBonusBadge();
    renderBonus();
  } catch (err) {
    toast('Claim failed — please try again');
  }
}
function showBonusClaimPopup(result) {
  const rewards = Array.isArray(result.rewards) ? result.rewards : [];
  $('bonus-claim-rewards').innerHTML = rewards.map((r) =>
    `<div class="bonus-reward-chip"><span>${BONUS_REWARD_ICONS[r.reward_type] || '🎁'}</span><span>${escHtmlGame(bonusRewardLabel(r))}</span></div>`
  ).join('');
  $('bonus-claim-backdrop').classList.remove('hidden');
}
$('bonus-claim-close').addEventListener('click', () => { audio.ui(); $('bonus-claim-backdrop').classList.add('hidden'); });
$('bonus-claim-backdrop').addEventListener('click', (e) => { if (e.target === $('bonus-claim-backdrop')) $('bonus-claim-backdrop').classList.add('hidden'); });
function enterBonus() {
  match.screen = 'bonus';
  showScreen('scr-bonus');
  if (!bonusLoaded) loadBonuses();
  else { loadBonusOwnedAndClaimed().then(renderBonus); }
}
$('bonus-back').addEventListener('click', () => { audio.ui(); enterMenu(); });

/* ==========================================================================
   QUESTS — personal daily/weekly tasks, admin-authored from UA FC MANAGER's
   Quest Register (quests table). Progress accrues server-side: whenever a
   relevant in-game action happens (match won/played, goal scored, clean
   sheet kept, Royale opened, player signed) the game calls
   quest_progress_increment(task_type, amount) — see the call sites at
   match end (game.js), Royale pull, and market purchase. This screen only
   ever reads user_quest_progress and calls quest_claim_reward to cash in
   a completed quest; it never writes progress/completion directly (RLS
   no longer allows that from the client at all).
   ========================================================================== */
const QUEST_TASK_LABELS_GAME = {
  win_matches: 'Win Matches', play_matches: 'Play Matches', score_goals: 'Score Goals',
  clean_sheets: 'Clean Sheets', open_luck_royale: 'Open Luck Royale', sign_player: 'Sign a Player',
};
let questsGameCache = null;      // available quests, fetched once and reused for the session
let questsProgressCache = new Map(); // `${quest_id}:${cycle_key}` -> progress row (this account only)
let questsGameCycle = 'daily';
let questsGameLoaded = false;

function questCycleKeyNow(cycle) {
  const d = new Date();
  if (cycle === 'weekly') {
    // ISO week key, matching the server's to_char(now(), 'IYYY-IW').
    const target = new Date(d.valueOf());
    const dayNr = (d.getUTCDay() + 6) % 7;
    target.setUTCDate(target.getUTCDate() - dayNr + 3);
    const firstThursday = new Date(Date.UTC(target.getUTCFullYear(), 0, 4));
    const week = 1 + Math.round(((target - firstThursday) / 86400000 - 3 + ((firstThursday.getUTCDay() + 6) % 7)) / 7);
    return `${target.getUTCFullYear()}-${String(week).padStart(2, '0')}`;
  }
  return d.toISOString().slice(0, 10);
}
async function loadQuestsGamePool() {
  try {
    const { data, error } = await sb.from('quests').select('*').eq('is_available', true);
    if (error) throw error;
    questsGameCache = data || [];
  } catch (err) {
    ;
    questsGameCache = [];
  }
}
async function loadQuestsGameProgress() {
  questsProgressCache = new Map();
  if (!cloudUser) return;
  try {
    const { data, error } = await sb.from('user_quest_progress').select('*').eq('user_id', cloudUser.id);
    if (error) throw error;
    for (const row of (data || [])) {
      questsProgressCache.set(`${row.quest_id}:${row.cycle_key}`, row);
    }
  } catch (err) {
    ;
  }
}
function questRewardChipsGame(q) {
  const chips = [];
  if (q.reward_coins) chips.push(`<div class="bonus-reward-chip"><span>🪙</span><span>${q.reward_coins.toLocaleString()}</span></div>`);
  if (q.reward_gems) chips.push(`<div class="bonus-reward-chip"><span>💎</span><span>${q.reward_gems.toLocaleString()}</span></div>`);
  if (q.reward_shards) chips.push(`<div class="bonus-reward-chip"><span>⭐</span><span>${q.reward_shards.toLocaleString()}</span></div>`);
  if (q.reward_uap) chips.push(`<div class="bonus-reward-chip"><span>🏅</span><span>${q.reward_uap.toLocaleString()}</span></div>`);
  return chips.join('');
}
function renderQuestsGame() {
  $('quests-signin-note').classList.toggle('hidden', !!cloudUser);
  const visible = (questsGameCache || []).filter((q) => q.cycle === questsGameCycle);
  $('quests-empty-game').classList.toggle('hidden', visible.length !== 0);
  $('quests-list-game').innerHTML = visible.map((q) => {
    const cycleKey = questCycleKeyNow(q.cycle);
    const progRow = questsProgressCache.get(`${q.id}:${cycleKey}`);
    const progress = progRow ? progRow.progress : 0;
    const completed = !!(progRow && progRow.completed_at);
    const claimed = !!(progRow && progRow.claimed_at);
    const pct = Math.min(100, Math.round((progress / q.target_count) * 100));
    let stateHtml;
    if (claimed) {
      stateHtml = `<div class="bonus-state bonus-state-claimed">✅ CLAIMED</div>`;
    } else if (completed) {
      stateHtml = `<button class="btn big bonus-claim-btn" data-progress-id="${progRow.id}"><span>Claim Rewards</span></button>`;
    } else {
      stateHtml = `<div class="quest-progress-track"><div class="quest-progress-fill" style="width:${pct}%"></div></div>
        <div class="quest-progress-label">${progress} / ${q.target_count}</div>`;
    }
    return `<div class="bonus-card ${claimed ? 'bonus-card-claimed' : completed ? 'bonus-card-unlocked' : ''}">
      <div class="bonus-card-info">
        <div class="bonus-card-name">${escHtmlGame(q.title)}</div>
        <div class="bonus-card-sub">${escHtmlGame(q.description || QUEST_TASK_LABELS_GAME[q.task_type] || q.task_type)}</div>
      </div>
      <div class="bonus-rewards-row">${questRewardChipsGame(q)}</div>
      ${stateHtml}
    </div>`;
  }).join('');
  qsaGame('.bonus-claim-btn', $('quests-list-game')).forEach((btn) => {
    btn.addEventListener('click', () => attemptClaimQuest(btn.dataset.progressId));
  });
}
qsaGame('#quests-cycle-tabs-game button').forEach((btn) => {
  btn.addEventListener('click', () => {
    audio.ui();
    questsGameCycle = btn.dataset.cycle;
    qsaGame('#quests-cycle-tabs-game button').forEach((b) => b.classList.toggle('on', b === btn));
    renderQuestsGame();
  });
});
async function enterQuestsGame() {
  match.screen = 'quests';
  showScreen('scr-quests');
  $('quests-loading-game').classList.remove('hidden');
  if (!questsGameLoaded) { await loadQuestsGamePool(); questsGameLoaded = true; }
  await loadQuestsGameProgress();
  $('quests-loading-game').classList.add('hidden');
  renderQuestsGame();
}
$('quests-back').addEventListener('click', () => { audio.ui(); enterMenu(); });

// Best-effort progress ping — called from match-end, Royale pull, and
// market purchase hooks. Never blocks or throws into its caller; a
// failed ping just means progress catches up next time this screen (or
// another ping) succeeds, same tolerance as the League quest hooks.
async function questPostProgress(taskType, amount = 1) {
  if (!cloudUser) return;
  try {
    await sb.rpc('quest_progress_increment', { p_task_type: taskType, p_amount: amount });
  } catch (err) {
    ;
  }
}
async function attemptClaimQuest(progressId) {
  if (!cloudUser) { toast('Sign in to claim quest rewards.'); return; }
  audio.ui();
  try {
    const { data, error } = await sb.rpc('quest_claim_reward', { p_progress_id: progressId });
    if (error) throw error;
    const result = Array.isArray(data) ? data[0] : data;
    if (!result || !result.ok) {
      toast(result ? result.message : 'Could not claim this quest.');
      return;
    }
    await pullCloudState();
    await refreshGemsBalance();
    if (typeof refreshUAPointsBalance === 'function') await refreshUAPointsBalance();
    updateHubTopbar();
    updateCoinUI();
    showQuestsClaimPopup(result);
    await loadQuestsGameProgress();
    renderQuestsGame();
  } catch (err) {
    toast('Claim failed — please try again');
  }
}
function showQuestsClaimPopup(result) {
  const chips = [];
  if (result.reward_coins) chips.push(`<div class="bonus-reward-chip"><span>🪙</span><span>${result.reward_coins.toLocaleString()} Coins</span></div>`);
  if (result.reward_gems) chips.push(`<div class="bonus-reward-chip"><span>💎</span><span>${result.reward_gems.toLocaleString()} Gems</span></div>`);
  if (result.reward_shards) chips.push(`<div class="bonus-reward-chip"><span>⭐</span><span>${result.reward_shards.toLocaleString()} Star Shards</span></div>`);
  if (result.reward_uap) chips.push(`<div class="bonus-reward-chip"><span>🏅</span><span>${result.reward_uap.toLocaleString()} UA Points</span></div>`);
  $('quests-claim-rewards').innerHTML = chips.join('');
  $('quests-claim-backdrop').classList.remove('hidden');
}
$('quests-claim-close').addEventListener('click', () => { audio.ui(); $('quests-claim-backdrop').classList.add('hidden'); });
$('quests-claim-backdrop').addEventListener('click', (e) => { if (e.target === $('quests-claim-backdrop')) $('quests-claim-backdrop').classList.add('hidden'); });

/* ==========================================================================
   MAIL — inbox for broadcast/targeted messages (mail_messages table),
   authored from UA FC MANAGER's Mail Register or sent server-side as
   system mail. Visibility is enforced by RLS itself (a targeted message
   simply isn't returned to anyone but its recipient), so the client-side
   filtering here is just presentation, not the actual access control.
   Read state is best-effort (mail_mark_read); claiming a reward-bearing
   message goes through mail_claim_reward, same atomic pattern as Bonus
   and Quests — this screen only ever reflects what the server decided.
   ========================================================================== */
const MAIL_REWARD_ICONS_GAME = { coins: '🪙', gems: '💎', shards: '⭐', uap: '🏅', pack: '📦' };
let mailGameCache = null;       // this account's visible mail (broadcast + targeted-at-them)
let mailGameReads = new Map();  // mail_id -> { read_at, claimed_at }
let mailGameLoaded = false;

function mailRewardLabelGame(r) {
  if (r.reward_type === 'pack') return `${r.amount > 1 ? r.amount + 'x ' : ''}${r.pack_name || 'Special Pack'}`;
  const names = { coins: 'Coins', gems: 'Gems', shards: 'Star Shards', uap: 'UA Points' };
  return `${Number(r.amount || 0).toLocaleString()} ${names[r.reward_type] || ''}`;
}
async function loadMailGame() {
  if (!cloudUser) { mailGameCache = []; mailGameReads = new Map(); return; }
  try {
    const { data: mail, error: mErr } = await sb.from('mail_messages')
      .select('*, mail_rewards(*)').order('sent_at', { ascending: false }).limit(100);
    if (mErr) throw mErr;
    mailGameCache = mail || [];
    const { data: reads, error: rErr } = await sb.from('user_mail_reads').select('*').eq('user_id', cloudUser.id);
    if (rErr) throw rErr;
    mailGameReads = new Map((reads || []).map((r) => [r.mail_id, r]));
  } catch (err) {
    ;
    mailGameCache = [];
  }
  updateMailBadge();
}
function updateMailBadge() {
  const dot = $('mail-badge-dot');
  if (!dot) return;
  const hasUnread = (mailGameCache || []).some((m) => !mailGameReads.has(m.id) || !mailGameReads.get(m.id).read_at);
  dot.classList.toggle('hidden', !hasUnread);
}
function renderMailGame() {
  $('mail-signin-note').classList.toggle('hidden', !!cloudUser);
  const list = mailGameCache || [];
  $('mail-empty-game').classList.toggle('hidden', list.length !== 0);
  $('mail-list-game').innerHTML = list.map((m) => {
    const read = mailGameReads.get(m.id);
    const isUnread = !read || !read.read_at;
    const isClaimed = !!(read && read.claimed_at);
    const expired = new Date(m.expires_at) < new Date();
    const hasRewards = (m.mail_rewards || []).length > 0;
    let stateHtml = '';
    if (hasRewards) {
      if (isClaimed) stateHtml = `<div class="bonus-state bonus-state-claimed">✅ CLAIMED</div>`;
      else if (expired) stateHtml = `<div class="bonus-state bonus-state-expired">⏰ EXPIRED</div>`;
    }
    return `<div class="bonus-card ${isUnread ? 'bonus-card-unlocked' : ''} ${isClaimed ? 'bonus-card-claimed' : ''}" data-mail-id="${m.id}">
      <div class="bonus-card-info">
        <div class="bonus-card-name">${isUnread ? '📩 ' : '📨 '}${escHtmlGame(m.title)}</div>
        <div class="bonus-card-sub">${new Date(m.sent_at).toLocaleDateString()}${m.source === 'system' ? ' · System' : ''}</div>
      </div>
      ${hasRewards ? `<div class="bonus-rewards-row">${(m.mail_rewards || []).map((r) => `<div class="bonus-reward-chip"><span>${MAIL_REWARD_ICONS_GAME[r.reward_type] || '🎁'}</span><span>${escHtmlGame(mailRewardLabelGame(r))}</span></div>`).join('')}</div>` : ''}
      ${stateHtml}
    </div>`;
  }).join('');
  qsaGame('[data-mail-id]', $('mail-list-game')).forEach((card) => {
    card.addEventListener('click', () => openMailDetail(card.dataset.mailId));
  });
}
async function enterMailGame() {
  match.screen = 'mail';
  showScreen('scr-mail');
  $('mail-loading-game').classList.remove('hidden');
  await loadMailGame();
  mailGameLoaded = true;
  $('mail-loading-game').classList.add('hidden');
  renderMailGame();
}
$('mail-back').addEventListener('click', () => { audio.ui(); enterMenu(); });

async function openMailDetail(mailId) {
  const m = (mailGameCache || []).find((x) => x.id === mailId);
  if (!m) return;
  audio.ui();
  const read = mailGameReads.get(mailId);
  const isClaimed = !!(read && read.claimed_at);
  const expired = new Date(m.expires_at) < new Date();
  const hasRewards = (m.mail_rewards || []).length > 0;

  $('mail-detail-title').textContent = m.title;
  $('mail-detail-body').textContent = m.body || '';
  $('mail-detail-rewards').innerHTML = hasRewards
    ? (m.mail_rewards || []).map((r) => `<div class="bonus-reward-chip"><span>${MAIL_REWARD_ICONS_GAME[r.reward_type] || '🎁'}</span><span>${escHtmlGame(mailRewardLabelGame(r))}</span></div>`).join('')
    : '';
  let stateHtml = '';
  if (hasRewards) {
    if (isClaimed) stateHtml = `<div class="bonus-state bonus-state-claimed">✅ CLAIMED</div>`;
    else if (expired) stateHtml = `<div class="bonus-state bonus-state-expired">⏰ EXPIRED</div>`;
    else stateHtml = `<button class="btn big bonus-claim-btn" id="mail-detail-claim-btn"><span>Claim Rewards</span></button>`;
  }
  $('mail-detail-state').innerHTML = stateHtml;
  if (!isClaimed) {
    const btn = document.getElementById('mail-detail-claim-btn');
    if (btn) btn.addEventListener('click', () => attemptClaimMail(mailId));
  }
  $('mail-detail-backdrop').classList.remove('hidden');

  // Mark read (best-effort, never blocks the detail view from opening).
  if (cloudUser && (!read || !read.read_at)) {
    try {
      await sb.rpc('mail_mark_read', { p_mail_id: mailId });
      mailGameReads.set(mailId, { ...(read || {}), read_at: new Date().toISOString() });
      updateMailBadge();
      renderMailGame();
    } catch (err) {
      ;
    }
  }
}
$('mail-detail-close').addEventListener('click', () => { audio.ui(); $('mail-detail-backdrop').classList.add('hidden'); });
$('mail-detail-backdrop').addEventListener('click', (e) => { if (e.target === $('mail-detail-backdrop')) $('mail-detail-backdrop').classList.add('hidden'); });

async function attemptClaimMail(mailId) {
  if (!cloudUser) { toast('Sign in to claim mail rewards.'); return; }
  audio.ui();
  try {
    const { data, error } = await sb.rpc('mail_claim_reward', { p_mail_id: mailId });
    if (error) throw error;
    const result = Array.isArray(data) ? data[0] : data;
    if (!result || !result.ok) {
      toast(result ? result.message : 'Could not claim this mail.');
      return;
    }
    await pullCloudState();
    await refreshGemsBalance();
    if (typeof refreshUAPointsBalance === 'function') await refreshUAPointsBalance();
    updateHubTopbar();
    updateCoinUI();
    $('mail-detail-backdrop').classList.add('hidden');
    showMailClaimPopup(result);
    await loadMailGame();
    renderMailGame();
  } catch (err) {
    toast('Claim failed — please try again');
  }
}
function showMailClaimPopup(result) {
  const rewards = Array.isArray(result.rewards) ? result.rewards : [];
  $('mail-claim-rewards').innerHTML = rewards.map((r) =>
    `<div class="bonus-reward-chip"><span>${MAIL_REWARD_ICONS_GAME[r.reward_type] || '🎁'}</span><span>${escHtmlGame(mailRewardLabelGame(r))}</span></div>`
  ).join('');
  $('mail-claim-backdrop').classList.remove('hidden');
}
$('mail-claim-close').addEventListener('click', () => { audio.ui(); $('mail-claim-backdrop').classList.add('hidden'); });
$('mail-claim-backdrop').addEventListener('click', (e) => { if (e.target === $('mail-claim-backdrop')) $('mail-claim-backdrop').classList.add('hidden'); });

async function enterUAPass() {
  match.screen = 'uapass';
  showScreen('scr-uapass');
  $('uap-signin-note').classList.toggle('hidden', !!cloudUser);
  if (!uapSeason) await loadActiveUAPassSeason();
  await loadUAPassProgress();
  renderUAPass();
}
function renderUAPass() {
  if (!uapSeason) {
    $('uap-season-banner').classList.add('hidden');
    $('uap-xp-row').classList.add('hidden');
    $('uap-premium-cta').classList.add('hidden');
    $('uap-track-labels').classList.add('hidden');
    $('uap-levels-scroll').classList.add('hidden');
    $('uap-empty').classList.remove('hidden');
    return;
  }
  $('uap-season-banner').classList.remove('hidden');
  $('uap-xp-row').classList.remove('hidden');
  $('uap-track-labels').classList.remove('hidden');
  $('uap-levels-scroll').classList.remove('hidden');
  $('uap-empty').classList.add('hidden');

  const bannerUrl = uapBannerUrl(uapSeason.banner_path);
  const banner = $('uap-season-banner');
  banner.style.backgroundImage = bannerUrl ? `linear-gradient(180deg, rgba(3,8,18,.35), rgba(3,8,18,.75)), url('${bannerUrl}')` : '';
  banner.style.backgroundSize = 'cover';
  banner.style.backgroundPosition = 'center';
  $('uap-season-name').textContent = `SEASON ${uapSeason.season_number}: ${uapSeason.name}`;
  $('uap-season-sub').textContent = uapSeason.description || '';

  const xp = uapProgress ? uapProgress.xp : 0;
  const isPremium = uapProgress ? uapProgress.is_premium : false;
  const maxLevel = uapLevels[uapLevels.length - 1];
  const maxXp = maxLevel ? maxLevel.xp_required : 0;
  const nextLevel = uapLevels.find((l) => l.xp_required > xp);
  const xpPct = maxXp > 0 ? clamp((xp / maxXp) * 100, 0, 100) : 0;
  $('uap-xp-bar').style.width = xpPct + '%';
  $('uap-xp-label').textContent = nextLevel ? `${xp.toLocaleString()} / ${nextLevel.xp_required.toLocaleString()} XP` : `${xp.toLocaleString()} XP · MAX LEVEL`;
  $('uap-header-uap').textContent = `— ${(typeof userUAPoints === 'number' ? userUAPoints : 0).toLocaleString()} ⭐`;

  const ctaBtn = $('uap-premium-cta');
  ctaBtn.classList.toggle('hidden', !cloudUser || isPremium);
  $('uap-premium-price').textContent = (uapSeason.premium_price_ua_points || 0).toLocaleString();

  const track = $('uap-levels-track');
  track.innerHTML = uapLevels.map((l) => {
    const unlocked = xp >= l.xp_required;
    return `<div class="uap-level-col">
      <div class="uap-level-num ${unlocked ? 'unlocked' : ''}">LV.${l.level_number}</div>
      ${renderUAPassCell(l.free, unlocked, true)}
      ${renderUAPassCell(l.premium, unlocked, isPremium)}
    </div>`;
  }).join('');
  qsa('.uap-reward-cell[data-reward-id]', track).forEach((cell) => {
    cell.addEventListener('click', () => attemptClaimUAPassReward(cell.dataset.rewardId));
  });
  // Auto-scroll to the player's current level so they land somewhere
  // relevant instead of always the very start of a long pass.
  const scrollWrap = $('uap-levels-scroll');
  const currentCol = track.children[Math.max(0, (nextLevel ? uapLevels.indexOf(nextLevel) : uapLevels.length - 1) - 1)];
  if (currentCol) scrollWrap.scrollLeft = Math.max(0, currentCol.offsetLeft - 20);
}
function renderUAPassCell(reward, levelUnlocked, trackUnlocked) {
  if (!reward) return '<div class="uap-reward-cell uap-empty-track">—</div>';
  const claimed = uapClaimedIds.has(reward.id);
  const canClaim = levelUnlocked && trackUnlocked && !claimed && cloudUser;
  let cls = 'uap-reward-cell';
  if (claimed) cls += ' claimed';
  else if (canClaim) cls += ' claimable';
  else if (!levelUnlocked) cls += ' locked';
  else if (!trackUnlocked) cls += ' premium-locked';
  const icon = UAP_REWARD_ICONS[reward.reward_type] || '🎁';
  return `<div class="${cls}" ${canClaim ? `data-reward-id="${reward.id}"` : ''}>
    <div class="uap-reward-icon">${icon}</div>
    <div class="uap-reward-amount">${escHtml(uapRewardLabel(reward))}</div>
    ${claimed ? '<div class="uap-reward-check">✓</div>' : ''}
    ${!levelUnlocked ? '<div class="uap-reward-lock">🔒</div>' : ''}
    ${levelUnlocked && !trackUnlocked ? '<div class="uap-reward-lock">💎</div>' : ''}
  </div>`;
}
async function attemptClaimUAPassReward(rewardId) {
  if (!cloudUser) { toast('Sign in to claim UA Pass rewards.'); return; }
  audio.ui();
  try {
    const { data, error } = await sb.rpc('ua_pass_claim_reward', { p_reward_id: rewardId });
    if (error) throw error;
    const result = Array.isArray(data) ? data[0] : data;
    if (!result || !result.ok) {
      toast(result ? result.message : 'Could not claim reward.');
      return;
    }
    uapClaimedIds.add(rewardId);
    // Finish granting non-currency rewards client-side — the RPC already
    // credited coins/gems/ua_points atomically with the claim itself.
    if (result.reward_type === 'player' && result.player_id) {
      try { await sb.from('user_players').insert({ user_id: cloudUser.id, player_id: result.player_id, acquired_via: 'ua_pass' }); } catch (e) {}
    }
    if (result.reward_type === 'coins' || result.reward_type === 'gems' || result.reward_type === 'ua_points') {
      // Refresh the in-memory balances so the topbar reflects the claim
      // immediately rather than waiting for the next unrelated refresh.
      if (result.reward_type === 'coins') { await pullCloudState(); }
      if (result.reward_type === 'gems') { await refreshGemsBalance(); }
      if (result.reward_type === 'ua_points') {
        try {
          const { data: uapRow } = await sb.from('user_ua_points').select('ua_points').eq('user_id', cloudUser.id).maybeSingle();
          userUAPoints = (uapRow && uapRow.ua_points) || 0;
        } catch (e) {}
      }
      updateHubTopbar();
    }
    showUAPassClaimPopup(result);
    renderUAPass();
  } catch (err) {
    toast('Claim failed — please try again');
  }
}
function showUAPassClaimPopup(result) {
  $('uap-claim-icon').textContent = UAP_REWARD_ICONS[result.reward_type] || '🎁';
  $('uap-claim-desc').textContent = uapRewardLabel(result) + (result.reward_type === 'coins' ? ' Coins' : result.reward_type === 'gems' ? ' Gems' : result.reward_type === 'ua_points' ? ' UA Points' : '');
  $('uap-claim-backdrop').classList.remove('hidden');
}
$('uap-claim-close').addEventListener('click', () => { audio.ui(); $('uap-claim-backdrop').classList.add('hidden'); });
$('uap-claim-backdrop').addEventListener('click', (e) => { if (e.target === $('uap-claim-backdrop')) $('uap-claim-backdrop').classList.add('hidden'); });
$('uap-premium-cta').addEventListener('click', async () => {
  if (!cloudUser || !uapSeason) return;
  audio.ui();
  const price = uapSeason.premium_price_ua_points || 0;
  if ((typeof userUAPoints === 'number' ? userUAPoints : 0) < price) {
    toast(`Not enough UA Points — need ${price.toLocaleString()} ⭐`);
    return;
  }
  try {
    const { data, error } = await sb.rpc('ua_pass_buy_premium', { p_season_id: uapSeason.id });
    if (error) throw error;
    const result = Array.isArray(data) ? data[0] : data;
    if (!result || !result.ok) { toast(result ? result.message : 'Purchase failed.'); return; }
    try {
      const { data: uapRow } = await sb.from('user_ua_points').select('ua_points').eq('user_id', cloudUser.id).maybeSingle();
      userUAPoints = (uapRow && uapRow.ua_points) || 0;
    } catch (e) {}
    updateHubTopbar();
    toast('💎 Premium UA Pass unlocked!');
    await loadUAPassProgress();
    renderUAPass();
  } catch (err) {
    toast('Purchase failed — please try again');
  }
});
$('uap-back').addEventListener('click', () => { audio.ui(); enterMenu(); });


/* ==========================================================================
   HOME HUB — MAIN + SIDE ROTATING BANNER CAROUSELS
   Slides pull from existing promo/event data already in the app (no new
   backend needed). Add more slides to HUB_MAIN_SLIDES / uses royale drafts
   for the side carousel automatically once loaded.
   ========================================================================== */
const HUB_MAIN_SLIDES = [
  { key: 'squad',    title: 'UA FC MOBILE', sub: 'Build your dream squad', cta: 'GO NOW', bg: 'linear-gradient(135deg,#241a3d,#3a2a5c)' },
  { key: 'featured', title: 'SIGNATURE ARCHIVE', sub: 'Legendary icons return', cta: 'GO NOW', bg: 'linear-gradient(135deg,#2b2016,#4a3418)' },
];
let hubMainIdx = 0, hubSideIdx = 0, hubMainTimer = null, hubSideTimer = null;

function renderHubCarousels() {
  renderHubMainCarousel();
  renderHubSideCarousel();
  renderHubTileBanners();
  clearInterval(hubMainTimer); clearInterval(hubSideTimer);
  hubMainTimer = setInterval(() => { hubMainIdx = (hubMainIdx + 1) % HUB_MAIN_SLIDES.length; renderHubMainCarousel(); }, 5000);
  hubSideTimer = setInterval(() => {
    const n = Math.max(1, royaleDraftsCache.length);
    hubSideIdx = (hubSideIdx + 1) % n;
    renderHubSideCarousel();
  }, 4000);
}
function renderHubMainCarousel() {
  const track = $('hub-carousel-track');
  const dots = $('hub-carousel-dots');
  if (!track) return;
  const slide = HUB_MAIN_SLIDES[hubMainIdx];
  const banner = homeBannersCache[slide.key];
  const bannerUrl = banner && homeBannerUrl(banner.image_path);
  const title = (banner && banner.title) || slide.title;
  const sub = (banner && banner.subtitle) || slide.sub;
  const bgStyle = bannerUrl ? `background-image:url('${bannerUrl}'); background-size:cover; background-position:${focalPos(banner)}; background-repeat:no-repeat;` : `background:${slide.bg};`;
  track.innerHTML = `<div class="hub-slide" style="${bgStyle}">
    <div class="hub-slide-text">
      <div class="hub-slide-title">${escHtmlGame(title)}</div>
      <div class="hub-slide-sub">${escHtmlGame(sub)}</div>
    </div>
    <button class="btn big hub-slide-cta" id="btn-promo-go"><span>${escHtmlGame(slide.cta)}</span></button>
  </div>`;
  $('btn-promo-go').addEventListener('click', () => { audio.ui(); toast('More coming soon!'); });
  dots.innerHTML = HUB_MAIN_SLIDES.map((_, i) => `<span class="hub-dot ${i === hubMainIdx ? 'on' : ''}"></span>`).join('');
}
function renderHubSideCarousel() {
  const track = $('hub-side-track');
  const dots = $('hub-side-dots');
  if (!track) return;
  const royaleBanner = homeBannersCache['luckroyale'];
  const royaleBannerUrl = royaleBanner && homeBannerUrl(royaleBanner.image_path);
  const royaleLabel = (royaleBanner && royaleBanner.title) || 'LUCK ROYALE';
  if (!royaleDraftsCache.length) {
    track.innerHTML = `<button class="hub-side-slide" id="hub-royale-banner-slide" style="${royaleBannerUrl ? `background-image:url('${royaleBannerUrl}'); background-size:cover; background-position:${focalPos(royaleBanner)}; background-repeat:no-repeat;` : ''}"><div class="hub-royale-label">${escHtmlGame(royaleLabel)}</div><div class="hub-royale-name">${escHtmlGame((royaleBanner && royaleBanner.subtitle) || 'No active drafts')}</div></button>`;
    dots.innerHTML = '';
  } else {
    const idx = hubSideIdx % royaleDraftsCache.length;
    const d = royaleDraftsCache[idx];
    const bg = d.bg_media_path ? draftMediaUrlGame(d.bg_media_path) : royaleBannerUrl;
    const bgPos = d.bg_media_path ? 'center' : focalPos(royaleBanner);
    track.innerHTML = `<button class="hub-side-slide" id="hub-royale-banner-slide" style="${bg ? `background-image:url('${bg}'); background-size:cover; background-position:${bgPos}; background-repeat:no-repeat;` : ''}">
      <div class="hub-royale-label">${escHtmlGame(d.name)}</div>
      <div class="hub-royale-name">${d.single_pull_gems} 💎 / pull</div>
    </button>`;
    dots.innerHTML = royaleDraftsCache.map((_, i) => `<span class="hub-dot ${i === idx ? 'on' : ''}"></span>`).join('');
  }
  $('hub-royale-banner-slide').addEventListener('click', () => { audio.init(); audio.ui(); enterRoyale(); });
}
function renderHubTileBanners() {
  const club = homeBannersCache['club'];
  const clubUrl = club && homeBannerUrl(club.image_path);
  const clubTile = $('btn-hub-club');
  if (clubTile) clubTile.style.background = clubUrl ? `linear-gradient(rgba(10,15,30,.35),rgba(10,15,30,.65)), url('${clubUrl}') ${focalPos(club)}/cover no-repeat` : '';

  const play = homeBannersCache['play'];
  const playUrl = play && homeBannerUrl(play.image_path);
  const playTile = $('btn-hub-play');
  if (playTile) playTile.style.background = playUrl ? `linear-gradient(rgba(10,20,5,.35),rgba(10,20,5,.65)), url('${playUrl}') ${focalPos(play)}/cover no-repeat` : '';
}

async function startMatch() {
  reportedFrameErrors.clear();
  // Refresh the cloud registry right before kickoff so any player/model
  // updates made in UA FC MANAGER since the app was opened are picked up
  // immediately — without this, model_data changes only appeared after a
  // full page reload, since autoLoadRegistry otherwise only runs at boot().
  try {
    const refreshed = await autoLoadRegistryCloud(() => {});
    if (refreshed) await buildSquadsFromRegistry();
  } catch (e) {
    ;
  }
  applyLockerKitToHomeTeam();
  if (window.PlayHub) { try { await PlayHub.prepareMatch(); } catch (e) { ; } }
  match.screen = 'match';
  match.clock = 0; match.over = false; match.playerStats = {}; match.goalScorers = []; goalCountByName = {};
  match.stats = freshMatchStats();
  match.state = 'idle';
  match.paused = false;
  match.half = 1;
  match.kickTeam = 0;
  match.possession = 0;
  match.time = 0;
  match.score = [0, 0];
  match.events = [];
  if (window.PlayHub) PlayHub.applyMatchStart();
  showScreen(null);
  spawnTeams();
  placeKickoff(match.kickTeam);
  controlled = players.find((p) => p.team === 0 && p.role === 'ST') || players[9];
  updateScoreboard();
  startSetPiece('kickoff', match.kickTeam, null);
  setupControlsForDevice();
}

function enterSettings() {
  match.screen = 'settings';
  match.state = 'idle';
  showScreen('scr-settings');
}

function renderTeamGrids() {
  const buildGrid = (gridId, nameId, currentIdx, onPick) => {
    const grid = $(gridId);
    if (!grid) return;
    grid.innerHTML = TEAMS.map((t, i) => `
      <div class="ts-card ${i === currentIdx ? 'sel' : ''}" data-idx="${i}" style="--tc1:${t.c1}; --tc2:${t.c2};">
        <div class="ts-card-crest" style="background:linear-gradient(135deg,${t.c1},${t.c2});"></div>
        <div class="ts-card-name">${t.abbr}</div>
        <div class="ts-card-rating">${t.rating}</div>
      </div>`).join('');
    $(nameId).textContent = TEAMS[currentIdx] ? TEAMS[currentIdx].name : '—';
    qsa('.ts-card', grid).forEach((card) => {
      card.addEventListener('click', () => {
        const idx = parseInt(card.dataset.idx, 10);
        onPick(idx);
        audio.ui();
      });
    });
  };
  buildGrid('grid-home', 'sel-home-name', settings.homeTeam, (idx) => {
    settings.homeTeam = idx;
    saveSettings();
    renderTeamGrids();
  });
  buildGrid('grid-away', 'sel-away-name', settings.awayTeam, (idx) => {
    settings.awayTeam = idx;
    saveSettings();
    renderTeamGrids();
  });
}
function enterTeamSelect() {
  match.screen = 'team';
  renderTeamGrids();
  showScreen('scr-team');
}

/* ==========================================================================
   LUCK ROYALE — real drafts from Supabase (drafts, draft_pool_players,
   draft_pulls). Single pull and bundle pull both gem-priced per draft;
   each pull picks a pool (A/B/C) by the draft's odds, then a random
   player from that pool, weighted flat (equal chance within a pool).
   ========================================================================== */
let royaleDraftsCache = [];
let royaleActiveDraft = null;
let royaleActivePools = { A: [], B: [], C: [] };
// Pity/guarantee counters, per-draft, loaded from draft_pity_counters.
// Pool A is guaranteed by the 100th spin without one, Pool B by the 20th
// spin without one. Whichever pool's counter triggers a guarantee resets
// to 0; the other counter keeps counting until it hits its own cap.
const PITY_CAP_A = 100;
const PITY_CAP_B = 20;
let royalePity = { spins_since_a: 0, spins_since_b: 0 };

async function loadRoyalePity(draftId) {
  royalePity = { spins_since_a: 0, spins_since_b: 0 };
  if (!cloudUser || !draftId) return;
  try {
    const { data } = await sb.from('draft_pity_counters').select('spins_since_a, spins_since_b').eq('user_id', cloudUser.id).eq('draft_id', draftId).maybeSingle();
    if (data) royalePity = { spins_since_a: data.spins_since_a, spins_since_b: data.spins_since_b };
  } catch (err) {
    ;
  }
}
async function saveRoyalePity(draftId) {
  if (!cloudUser || !draftId) return;
  try {
    await sb.from('draft_pity_counters').upsert({
      user_id: cloudUser.id, draft_id: draftId,
      spins_since_a: royalePity.spins_since_a, spins_since_b: royalePity.spins_since_b,
      updated_at: new Date().toISOString(),
    }, { onConflict: 'user_id,draft_id' });
  } catch (err) {
    ;
  }
}

function draftMediaUrlGame(path) {
  if (!path) return null;
  return getAssetUrl('draft-media', path);
}
async function enterRoyale() {
  showScreen('scr-royale');
  royaleMode = 'gems';
  qsa('.rl-mode-tab', $('rl-mode-tabs')).forEach((t) => t.classList.toggle('on', t.dataset.mode === 'gems'));
  $('rl-draft-list').classList.remove('hidden');
  $('rl-draft-detail').classList.add('hidden');
  $('ub-box-list').classList.add('hidden');
  $('ub-box-detail').classList.add('hidden');
  $('rl-title-text').textContent = 'LUCK ROYALE';
  updateRoyaleGemsUI();
  await loadRoyaleDrafts();
}
function updateRoyaleGemsUI() {
  const el = $('rl-gems');
  if (el) el.textContent = settings.infGems ? '∞' : (typeof userGems === 'number' ? userGems : 0).toLocaleString();
}
async function loadRoyaleDrafts() {
  $('rl-loading').classList.remove('hidden');
  $('rl-draft-cards').innerHTML = '';
  try {
    const { data, error } = await sb.from('drafts').select('*').eq('is_active', true).order('created_at', { ascending: false });
    if (error) throw error;
    royaleDraftsCache = data || [];
    renderRoyaleDraftList();
  } catch (err) {
    toast('Failed to load Luck Royale — please try again');
    ;
  } finally {
    $('rl-loading').classList.add('hidden');
  }
}
function renderRoyaleDraftList() {
  const grid = $('rl-draft-cards');
  const empty = $('rl-drafts-empty');
  if (!royaleDraftsCache.length) {
    empty.classList.remove('hidden');
    grid.innerHTML = '';
    return;
  }
  empty.classList.add('hidden');
  grid.innerHTML = royaleDraftsCache.map((d, i) => {
    const bg = d.bg_media_path ? draftMediaUrlGame(d.bg_media_path) : '';
    const active = royaleActiveDraft && royaleActiveDraft.id === d.id;
    const grad = d.color_a ? `background-image:linear-gradient(150deg,${d.color_a},${d.color_b})` : (bg ? `background-image:url('${bg}')` : '');
    return `<div class="rl-draft-card ${active ? 'active' : ''}" data-draft-id="${d.id}" style="${grad}">
      <span class="rldc-hot">${escHtmlGame(d.draft_type || 'HOT')}</span>
      <div class="rldc-name">${escHtmlGame(d.name)}</div>
      <div class="rldc-sub">${d.single_pull_gems} 💎 / pull${d.top_ovr ? ' · TOP ' + d.top_ovr : ''}</div>
    </div>`;
  }).join('');
  qsa('.rl-draft-card', grid).forEach((card) => {
    card.addEventListener('click', () => openRoyaleDraft(royaleDraftsCache.find((d) => d.id === card.dataset.draftId)));
  });
  // Feature active drafts on the home hub's side carousel too.
  hubSideIdx = 0;
  renderHubSideCarousel();
}
function escHtmlGame(s) {
  return String(s || '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}
async function openRoyaleDraft(draft) {
  if (!draft) return;
  royaleActiveDraft = draft;
  $('rl-title-text').textContent = draft.name;
  // Sidebar list stays visible alongside the detail panel (matches reference
  // video: tapping another box in the left list swaps the detail in place).
  $('rl-draft-list').classList.remove('hidden');
  $('rl-draft-detail').classList.remove('hidden');
  renderRoyaleDraftList();
  const bg = draft.bg_media_path ? draftMediaUrlGame(draft.bg_media_path) : '';
  $('rl-detail-hero').style.backgroundImage = draft.color_a ? `linear-gradient(150deg,${draft.color_a},${draft.color_b})` : (bg ? `url('${bg}')` : '');
  $('rl-detail-name').textContent = draft.name;
  $('rl-detail-odds').textContent = `POOL A ${draft.pool_a_odds}% · POOL B ${draft.pool_b_odds}% · POOL C ${draft.pool_c_odds}%`;
  if (draft.top_ovr) $('rl-detail-odds').textContent += `  ·  BEST ${draft.top_ovr} OVR`;
  try {
    const pl = $('rl-detail-pool'), D = window.UA_DRAFTS;
    if (pl && D) {
      const rows = D.pool.filter((x) => x.draft_id === draft.id).map((x) => ({ x, p: window.UACard.byId.get(String(x.player_id)) })).filter((r) => r.p)
        .sort((a, b) => b.p.ovr - a.p.ovr).slice(0, 8);
      pl.innerHTML = rows.map(({ x, p }) => `<div class="rlp-card rar-${escHtmlGame(p.rarity)}"><span class="rlp-ovr">${ovrD(p.ovr)}</span><span class="rlp-pos">${escHtmlGame(p.position)}</span><img data-pid="${p.id}" alt="" /><div class="rlp-name">${escHtmlGame(p.name)}</div><span class="rlp-pool">${x.pool}</span></div>`).join('');
    }
  } catch (e) { console.warn('pool preview', e); }
  $('rl-pull-single').querySelector('span').textContent = `1 PULL · ${draft.single_pull_gems} 💎`;
  $('rl-pull-bundle').querySelector('span').textContent = `${draft.bundle_pull_count} PULLS · ${draft.bundle_pull_gems} 💎`;

  try {
    const { data, error } = await sb.from('draft_pool_players').select('player_id, pool, players_registry(*)').eq('draft_id', draft.id);
    if (error) throw error;
    royaleActivePools = { A: [], B: [], C: [] };
    (data || []).forEach((row) => {
      if (row.players_registry) royaleActivePools[row.pool].push(row.players_registry);
    });
  } catch (err) {
    toast('Failed to load draft pools — please try again');
    royaleActivePools = { A: [], B: [], C: [] };
  }
  await loadRoyalePity(draft.id);
}
$('rl-detail-back').addEventListener('click', () => {
  audio.ui();
  $('rl-draft-list').classList.remove('hidden');
  $('rl-draft-detail').classList.add('hidden');
  $('rl-title-text').textContent = 'LUCK ROYALE';
  royaleActiveDraft = null;
});
$('rl-back').addEventListener('click', () => { audio.ui(); enterMenu(); showScreen('scr-main'); });

function pickRoyalePool(draft) {
  // Pity check first: Pool A is guaranteed once 100 spins have passed
  // without landing one, Pool B once 20 spins have passed without one.
  // Pool A's guarantee takes priority if both would trigger together.
  if (royalePity.spins_since_a >= PITY_CAP_A - 1 && royaleActivePools.A.length) return 'A';
  if (royalePity.spins_since_b >= PITY_CAP_B - 1 && royaleActivePools.B.length) return 'B';
  const roll = Math.random() * 100;
  if (roll < draft.pool_a_odds) return 'A';
  if (roll < draft.pool_a_odds + draft.pool_b_odds) return 'B';
  return 'C';
}
function pickRoyalePlayer(draft) {
  // Fall back down the pool chain (A->B->C) if the chosen pool has no
  // players assigned yet, so a half-configured draft never hard-fails
  // a pull the admin already sold gems for.
  let pool = pickRoyalePool(draft);
  const order = pool === 'A' ? ['A', 'B', 'C'] : pool === 'B' ? ['B', 'C', 'A'] : ['C', 'B', 'A'];
  for (const p of order) {
    if (royaleActivePools[p] && royaleActivePools[p].length) {
      const list = royaleActivePools[p];
      const landedPool = p;
      // Update pity counters: a pool that was hit resets to 0, every
      // other pool's counter increments by one spin.
      royalePity.spins_since_a = landedPool === 'A' ? 0 : royalePity.spins_since_a + 1;
      royalePity.spins_since_b = landedPool === 'B' ? 0 : royalePity.spins_since_b + 1;
      return { player: list[Math.floor(Math.random() * list.length)], pool: landedPool };
    }
  }
  return null;
}
async function executeRoyalePulls(count, totalGemCost) {
  if (!cloudUser) { toast('Sign in to use Luck Royale.'); return; }
  if (!royaleActiveDraft) return;
  const draft = royaleActiveDraft;
  const hasAnyPlayers = ['A', 'B', 'C'].some((p) => royaleActivePools[p].length);
  if (!hasAnyPlayers) { toast('This draft has no players configured yet.'); return; }

  const spent = await spendGems(totalGemCost);
  if (!spent) { toast(`Not enough gems — need ${totalGemCost.toLocaleString()} 💎`); return; }
  if (myLeague) leaguePostQuestProgress('royale_pulls', count);
  questPostProgress('open_luck_royale', count);

  const results = [];
  for (let i = 0; i < count; i++) {
    const pick = pickRoyalePlayer(draft);
    if (!pick) continue;
    results.push(pick);
  }

  // Outcome is already fully decided locally (pickRoyalePlayer), so this
  // delay is purely cosmetic — a brief spin/blur beat (matches the
  // reference video's stadium-blur transition) before the reveal lands.
  let totalCoins = 0;
  for (const r of results) totalCoins += (draft.coin_bonus_per_pull || 0);
  if (totalCoins > 0) addCoins(totalCoins);
  updateHubTopbar();
  const best = results.length ? results.reduce((a, b) => (RARITY_RANK[b.player.rarity] > RARITY_RANK[a.player.rarity] ? b : a)) : null;
  playPackOpenAnimation(best ? best.player : null, () => {
    showRoyaleResults(results, totalCoins);
  });

  // Persist to Supabase in the background, in parallel (not sequentially),
  // so a 12-pull bundle doesn't do 24 chained round-trips before the user
  // sees anything. Any row that fails is just logged — the pull itself is
  // already shown and the coins/gems are already applied.
  Promise.all(results.map((r) => Promise.all([
    sb.from('user_players').insert({ user_id: cloudUser.id, player_id: r.player.id, acquired_via: 'draft' }).then(() => { reservesOwnedCache = null; }),
    sb.from('draft_pulls').insert({ user_id: cloudUser.id, draft_id: draft.id, player_id: r.player.id, pool: r.pool, coin_bonus: draft.coin_bonus_per_pull }),
  ]))).catch(() => {});
  saveRoyalePity(draft.id);
}
function showRoyaleResults(results, totalCoins) {
  $('rl-result-title').textContent = results.length === 1 ? 'You Pulled!' : `You Pulled ${results.length} Players!`;
  const cardsEl = $('rl-result-cards');
  cardsEl.innerHTML = `<div class="vcard rar-gold" style="justify-content:center;"><div class="vn">🪙 +${totalCoins.toLocaleString()} Coins</div></div>` +
    results.map((r, i) => {
      const p = r.player;
      const img = p.media_path ? mediaUrlFor(p.media_path) : '';
      return `<div class="vcard rar-${escHtmlGame(p.rarity)}" data-result-idx="${i}">
        <div class="vo">${ovrD(p.ovr)}</div>
        <img data-pid="${p.id}" alt="${escHtmlGame(p.name)}" />
        <div class="vn">${escHtmlGame(p.name)}</div>
      </div>`;
    }).join('');
  qsa('.vcard[data-result-idx]', cardsEl).forEach((card) => {
    card.addEventListener('click', () => {
      const p = results[parseInt(card.dataset.resultIdx, 10)].player;
      openPlayerPreview({ pid: p.id, name: p.name, ovr: ovrD(p.ovr), rarity: p.rarity, pos: p.position, img: p.media_path ? mediaUrlFor(p.media_path) : '' });
    });
  });
  $('rl-result-backdrop').classList.remove('hidden');
  audio.reveal(results.some((r) => ['gold', 'icon', 'hero'].includes(r.player.rarity)) ? 'gold' : 'bronze');
}
$('rl-result-continue').addEventListener('click', () => {
  audio.ui();
  $('rl-result-backdrop').classList.add('hidden');
});
$('rl-pull-single').addEventListener('click', () => {
  audio.init(); audio.ui();
  if (!royaleActiveDraft) return;
  executeRoyalePulls(1, royaleActiveDraft.single_pull_gems);
});
$('rl-pull-bundle').addEventListener('click', () => {
  audio.init(); audio.ui();
  if (!royaleActiveDraft) return;
  executeRoyalePulls(royaleActiveDraft.bundle_pull_count, royaleActiveDraft.bundle_pull_gems);
});

/* ==========================================================================
   UA POINTS BOXES — paid player draft boxes, priced in UA Points
   (1,000,000 gems = 1 UA Point). Each box has a fixed numbered slot pool
   set up in UA FC MANAGER; every spin permanently removes that slot from
   what THIS player can land on next (no repeats, ua_box_progress tracks
   remaining slot numbers server-side). Odds are intentionally hidden from
   the player — no percentages are shown anywhere in this UI.
   ========================================================================== */
let uaBoxesCache = [];
let uaActiveBox = null;
let uaActiveBoxSlots = [];      // full slot definitions for the active box
let uaActiveProgress = null;    // { slots_remaining: [...], spins_done }
let userUAPoints = 0;
let royaleMode = 'gems';

function boxMediaUrlGame(path) {
  if (!path) return null;
  try {
    return getAssetUrl('box-media', path);
  } catch (err) {
    ;
    return null;
  }
}
async function refreshUAPointsBalance() {
  if (!cloudUser) { userUAPoints = 0; return; }
  try {
    const { data, error } = await sb.from('user_ua_points').select('ua_points').eq('user_id', cloudUser.id).maybeSingle();
    if (error) throw error;
    userUAPoints = (data && data.ua_points) || 0;
  } catch (err) {
    ;
  }
  const el = $('rl-gems');
  if (el && royaleMode === 'ua') el.textContent = `⭐ ${userUAPoints.toLocaleString()}`;
  else if (el) el.textContent = settings.infGems ? '∞' : (typeof userGems === 'number' ? userGems : 0).toLocaleString();
}
async function spendUAPoints(amount) {
  if (!cloudUser) return false;
  try {
    const { data, error } = await sb.from('user_ua_points').select('ua_points').eq('user_id', cloudUser.id).maybeSingle();
    if (error) throw error;
    const current = (data && data.ua_points) || 0;
    if (current < amount) { userUAPoints = current; return false; }
    const next = current - amount;
    const { error: upErr } = await sb.from('user_ua_points').upsert({ user_id: cloudUser.id, ua_points: next, updated_at: new Date().toISOString() }, { onConflict: 'user_id' });
    if (upErr) throw upErr;
    userUAPoints = next;
    return true;
  } catch (err) {
    ;
    toast('Could not complete purchase — try again.');
    return false;
  }
}

function setRoyaleMode(mode) {
  if (mode === royaleMode) return;
  audio.ui();
  royaleMode = mode;
  qsa('.rl-mode-tab', $('rl-mode-tabs')).forEach((t) => t.classList.toggle('on', t.dataset.mode === mode));
  $('rl-draft-list').classList.add('hidden');
  $('rl-draft-detail').classList.add('hidden');
  $('ub-box-list').classList.add('hidden');
  $('ub-box-detail').classList.add('hidden');
  $('rl-title-text').textContent = mode === 'ua' ? 'UA POINTS BOXES' : 'LUCK ROYALE';
  if (mode === 'ua') {
    $('ub-box-list').classList.remove('hidden');
    refreshUAPointsBalance();
    loadUABoxes();
  } else {
    $('rl-draft-list').classList.remove('hidden');
    updateRoyaleGemsUI();
  }
}
qsa('.rl-mode-tab', $('rl-mode-tabs')).forEach((tab) => {
  tab.addEventListener('click', () => setRoyaleMode(tab.dataset.mode));
});
// Swipe left/right on the royale body to switch between Gem Drafts and
// UA Points Boxes, matching the reference video's swipeable box/royale switch.
(() => {
  const body = $('rl-body');
  let touchStartX = null;
  body.addEventListener('touchstart', (e) => { touchStartX = e.touches[0].clientX; }, { passive: true });
  body.addEventListener('touchend', (e) => {
    if (touchStartX === null) return;
    const dx = e.changedTouches[0].clientX - touchStartX;
    touchStartX = null;
    if (Math.abs(dx) < 60) return;
    // Only swipe between top-level lists, not while inside a detail view,
    // so an in-progress draft/box selection isn't accidentally discarded.
    const inDetail = !$('rl-draft-detail').classList.contains('hidden') || !$('ub-box-detail').classList.contains('hidden');
    if (inDetail) return;
    setRoyaleMode(dx < 0 ? 'ua' : 'gems');
  }, { passive: true });
})();

async function loadUABoxes() {
  $('ub-loading').classList.remove('hidden');
  $('ub-box-cards').innerHTML = '';
  try {
    const { data, error } = await sb.from('ua_boxes').select('*').eq('is_active', true).order('created_at', { ascending: false });
    if (error) throw error;
    uaBoxesCache = data || [];
    $('ub-loading').textContent = `Loading boxes… (found ${uaBoxesCache.length})`;
    renderUABoxList();
  } catch (err) {
    $('ub-boxes-empty').classList.remove('hidden');
    $('ub-boxes-empty').textContent = 'Couldn\'t load boxes — please try again.';
    toast('Failed to load boxes — please try again');
    ;
  } finally {
    $('ub-loading').classList.add('hidden');
  }
}
function renderUABoxList() {
  const grid = $('ub-box-cards');
  const empty = $('ub-boxes-empty');
  if (!uaBoxesCache.length) {
    empty.classList.remove('hidden');
    grid.innerHTML = '';
    return;
  }
  empty.classList.add('hidden');
  grid.innerHTML = uaBoxesCache.map((b) => {
    const bg = b.bg_media_path ? boxMediaUrlGame(b.bg_media_path) : '';
    const priceLabel = b.price_mode === 'increasing'
      ? `From ${b.base_price_ua_points} ⭐ / spin`
      : `${b.base_price_ua_points} ⭐ / spin`;
    return `<div class="ub-box-card" data-box-id="${b.id}" style="${bg ? `background-image:url('${bg}')` : ''}">
      <div class="ubc-name">${escHtmlGame(b.name)}</div>
      <div class="ubc-sub">${priceLabel} · ${b.total_slots} slots</div>
    </div>`;
  }).join('');
  qsa('.ub-box-card', grid).forEach((card) => {
    card.addEventListener('click', () => openUABoxDetail(uaBoxesCache.find((b) => b.id === card.dataset.boxId)));
  });
}
async function ensureUAProgress(box) {
  if (!cloudUser) { uaActiveProgress = null; return; }
  try {
    const { data, error } = await sb.from('ua_box_progress').select('*').eq('user_id', cloudUser.id).eq('box_id', box.id).maybeSingle();
    if (error) throw error;
    if (data) {
      uaActiveProgress = data;
    } else {
      // First time opening this box — every slot is available.
      const allSlots = uaActiveBoxSlots.map((s) => s.slot_number);
      uaActiveProgress = { user_id: cloudUser.id, box_id: box.id, slots_remaining: allSlots, spins_done: 0 };
      await sb.from('ua_box_progress').upsert(uaActiveProgress, { onConflict: 'user_id,box_id' });
    }
  } catch (err) {
    ;
    uaActiveProgress = { user_id: cloudUser.id, box_id: box.id, slots_remaining: uaActiveBoxSlots.map((s) => s.slot_number), spins_done: 0 };
  }
}
function uaNextSpinPrice(box, progress) {
  if (box.price_mode === 'flat') return box.base_price_ua_points;
  return box.base_price_ua_points + (progress.spins_done * box.price_increment_ua_points);
}
async function openUABoxDetail(box) {
  if (!box) return;
  if (!cloudUser) { toast('Sign in to open UA Points boxes.'); return; }
  uaActiveBox = box;
  $('ub-box-list').classList.add('hidden');
  $('ub-box-detail').classList.remove('hidden');
  $('rl-title-text').textContent = box.name;
  const bg = box.bg_media_path ? boxMediaUrlGame(box.bg_media_path) : '';
  $('ub-detail-hero').style.backgroundImage = bg ? `url('${bg}')` : '';
  $('ub-detail-name').textContent = box.name;

  try {
    const { data, error } = await sb.from('ua_box_slots').select('*').eq('box_id', box.id).order('slot_number');
    if (error) throw error;
    uaActiveBoxSlots = data || [];
  } catch (err) {
    toast('Failed to load box — please try again');
    uaActiveBoxSlots = [];
  }
  await ensureUAProgress(box);
  renderUABoxDetail();
}
function uaRewardIcon(s) {
  if (s.reward_type === 'coins') return '🪙';
  if (s.reward_type === 'gems') return '💎';
  if (s.reward_type === 'ua_points') return '⭐';
  if (s.reward_type === 'player') return null; // uses player headshot instead
  return '🎁';
}
function renderUABoxDetail() {
  const box = uaActiveBox;
  const progress = uaActiveProgress;
  const remaining = progress ? progress.slots_remaining.length : uaActiveBoxSlots.length;
  const soldOut = remaining <= 0;
  $('ub-detail-sub').textContent = soldOut ? 'ALL SLOTS CLAIMED' : `${remaining} / ${box.total_slots} SLOTS LEFT`;
  // Reward grid — mirrors the reference "Numero 4 Box" claim-card layout:
  // each slot is its own tile showing icon + amount, greyed out once claimed.
  $('ub-slots-track').innerHTML = uaActiveBoxSlots.map((s) => {
    const claimed = progress && !progress.slots_remaining.includes(s.slot_number);
    const icon = uaRewardIcon(s);
    const amountLabel = s.reward_amount ? `x${s.reward_amount.toLocaleString()}` : (s.label || '');
    const body = icon
      ? `<div class="ub-tile-icon">${icon}</div><div class="ub-tile-amt">${amountLabel}</div>`
      : `<div class="ub-tile-player">🧑</div><div class="ub-tile-amt">${escHtmlGame(s.label || 'Player')}</div>`;
    return `<div class="ub-reward-tile ${claimed ? 'claimed' : ''}">${body}${claimed ? '<div class="ub-tile-check">✓</div>' : ''}</div>`;
  }).join('');
  const price = soldOut ? 0 : uaNextSpinPrice(box, progress);
  const btn = $('ub-spin-btn');
  btn.querySelector('span').textContent = soldOut ? 'SOLD OUT' : `SPIN · ${price.toLocaleString()} ⭐`;
  btn.disabled = soldOut;
  btn.style.opacity = soldOut ? '.5' : '';
}
$('ub-detail-back').addEventListener('click', () => {
  audio.ui();
  $('ub-box-list').classList.remove('hidden');
  $('ub-box-detail').classList.add('hidden');
  $('rl-title-text').textContent = 'UA POINTS BOXES';
  uaActiveBox = null;
});

async function executeUABoxSpin() {
  if (!cloudUser) { toast('Sign in to use UA Points Boxes.'); return; }
  if (!uaActiveBox || !uaActiveProgress) return;
  const box = uaActiveBox;
  const progress = uaActiveProgress;
  if (!progress.slots_remaining.length) { toast('This box is sold out for you.'); return; }

  const price = uaNextSpinPrice(box, progress);
  const spent = await spendUAPoints(price);
  if (!spent) { toast(`Not enough UA Points — need ${price.toLocaleString()} ⭐`); return; }

  // Pick uniformly among the slots this player has NOT already won —
  // the confirmed pity model: once a slot is spun it locks and can never
  // come up again for this player, so odds shrink and the pool empties.
  const remaining = progress.slots_remaining;
  const pickedSlotNumber = remaining[Math.floor(Math.random() * remaining.length)];
  const slotDef = uaActiveBoxSlots.find((s) => s.slot_number === pickedSlotNumber);
  if (!slotDef) { toast('Something went wrong — try again.'); return; }

  progress.slots_remaining = remaining.filter((n) => n !== pickedSlotNumber);
  progress.spins_done += 1;

  // Apply the reward locally first so the player sees it instantly.
  let resolvedPlayer = null;
  if (slotDef.reward_type === 'coins') {
    addCoins(slotDef.reward_amount || 0);
  } else if (slotDef.reward_type === 'gems' && cloudUser) {
    try {
      const { data } = await sb.from('user_gems').select('gems').eq('user_id', cloudUser.id).maybeSingle();
      const cur = (data && data.gems) || 0;
      await sb.from('user_gems').upsert({ user_id: cloudUser.id, gems: cur + (slotDef.reward_amount || 0) }, { onConflict: 'user_id' });
      userGems = cur + (slotDef.reward_amount || 0);
    } catch (err) { ; }
  } else if (slotDef.reward_type === 'ua_points') {
    userUAPoints += (slotDef.reward_amount || 0);
    try { await sb.from('user_ua_points').upsert({ user_id: cloudUser.id, ua_points: userUAPoints, updated_at: new Date().toISOString() }, { onConflict: 'user_id' }); } catch (err) { ; }
  } else if (slotDef.reward_type === 'player' && slotDef.player_id) {
    try {
      const { data } = await sb.from('players_registry').select('*').eq('id', slotDef.player_id).maybeSingle();
      resolvedPlayer = data;
      await sb.from('user_players').insert({ user_id: cloudUser.id, player_id: slotDef.player_id, acquired_via: 'ua_box' });
      reservesOwnedCache = null;
    } catch (err) { ; }
  }

  updateHubTopbar();
  refreshUAPointsBalance();
  if (slotDef.reward_type === 'player' && resolvedPlayer) {
    playPackOpenAnimation(resolvedPlayer, () => {
      showUABoxResult(slotDef, resolvedPlayer);
      renderUABoxDetail();
    });
  } else {
    showUABoxResult(slotDef, resolvedPlayer);
    renderUABoxDetail();
  }

  // Persist progress + audit log in the background.
  Promise.all([
    sb.from('ua_box_progress').upsert({ user_id: cloudUser.id, box_id: box.id, slots_remaining: progress.slots_remaining, spins_done: progress.spins_done, updated_at: new Date().toISOString() }, { onConflict: 'user_id,box_id' }),
    sb.from('ua_box_spins').insert({ user_id: cloudUser.id, box_id: box.id, slot_number: pickedSlotNumber, reward_type: slotDef.reward_type, reward_amount: slotDef.reward_amount, player_id: slotDef.player_id, price_paid_ua_points: price }),
  ]).catch(() => {});
}
function showUABoxResult(slotDef, player) {
  let html = '';
  if (slotDef.reward_type === 'player' && player) {
    const img = player.media_path ? mediaUrlFor(player.media_path) : '';
    html = `<div class="vcard rar-${escHtmlGame(player.rarity)}">
      <div class="vo">${ovrD(player.ovr)}</div>
      <img data-pid="${player.id}" alt="${escHtmlGame(player.name)}" />
      <div class="vn">${escHtmlGame(player.name)}</div>
    </div>`;
  } else {
    const icon = slotDef.reward_type === 'coins' ? '🪙' : slotDef.reward_type === 'gems' ? '💎' : '⭐';
    const label = slotDef.label || (slotDef.reward_type === 'coins' ? 'Coins' : slotDef.reward_type === 'gems' ? 'Gems' : 'UA Points');
    html = `<div class="vcard rar-gold" style="justify-content:center;"><div class="vn">${icon} +${(slotDef.reward_amount || 0).toLocaleString()} ${escHtmlGame(label)}</div></div>`;
  }
  $('ub-result-card').innerHTML = html;
  qsa('.vcard', $('ub-result-card')).forEach((card) => {
    if (slotDef.reward_type === 'player' && player) {
      card.addEventListener('click', () => openPlayerPreview({ pid: player.id, name: player.name, ovr: ovrD(player.ovr), rarity: player.rarity, pos: player.position, img: player.media_path ? mediaUrlFor(player.media_path) : '' }));
    }
  });
  $('ub-result-backdrop').classList.remove('hidden');
  audio.reveal(slotDef.reward_type === 'player' && player && ['gold', 'icon', 'hero'].includes(player.rarity) ? 'gold' : 'bronze');
}
$('ub-result-continue').addEventListener('click', () => { audio.ui(); $('ub-result-backdrop').classList.add('hidden'); });
$('ub-spin-btn').addEventListener('click', () => { audio.init(); audio.ui(); executeUABoxSpin(); });

/* ---- Gems → UA Points converter ---- */
$('ub-convert-btn').addEventListener('click', async () => {
  audio.ui();
  if (!cloudUser) { toast('Sign in to convert gems.'); return; }
  $('ub-convert-amount').value = '';
  $('ub-convert-error').textContent = '';
  $('ub-cv-gems').textContent = (typeof userGems === 'number' ? userGems : 0).toLocaleString();
  $('ub-cv-uap').textContent = userUAPoints.toLocaleString();
  $('ub-convert-backdrop').classList.remove('hidden');
});
$('ub-convert-cancel').addEventListener('click', () => { audio.ui(); $('ub-convert-backdrop').classList.add('hidden'); });
$('ub-convert-confirm').addEventListener('click', async () => {
  audio.ui();
  const raw = parseInt($('ub-convert-amount').value, 10) || 0;
  const errEl = $('ub-convert-error');
  errEl.textContent = '';
  if (raw < 1000000) { errEl.textContent = 'Minimum is 1,000,000 gems.'; return; }
  const uapGained = Math.floor(raw / 1000000);
  const gemsUsed = uapGained * 1000000; // only whole-UAP amounts are converted; remainder stays as gems
  const spent = await spendGems(gemsUsed);
  if (!spent) { errEl.textContent = 'Not enough gems for that amount.'; return; }
  userUAPoints += uapGained;
  try {
    await sb.from('user_ua_points').upsert({ user_id: cloudUser.id, ua_points: userUAPoints, updated_at: new Date().toISOString() }, { onConflict: 'user_id' });
  } catch (err) { ; }
  toast(`Converted ${gemsUsed.toLocaleString()} 💎 → ${uapGained.toLocaleString()} ⭐`);
  $('ub-convert-backdrop').classList.add('hidden');
  refreshUAPointsBalance();
  updateHubTopbar();
});

/* ==========================================================================
   MARKET — buy players from the registry with coins, admin-priced via
   UA FC MANAGER's Market Register (market_listings table).
   ========================================================================== */
let marketGameCache = [];
async function enterMarket() {
  showScreen('scr-market');
  $('mkt-coins').textContent = settings.infMoney ? '∞' : coins.toLocaleString();
  await loadMarketGame();
}

/* ==========================================================================
   STORE — spend coins on Diamonds (gems) and UA FC Points. Two fixed
   bundles for now; both debit the real coin balance (respecting the
   infMoney dev toggle) and credit the matching cloud currency the same
   way UA Points Box rewards do, so balances stay consistent everywhere.
   ========================================================================== */
const STORE_ITEMS = {
  diamonds_100: { label: '100 Diamonds', priceCoins: 100000, currency: 'gems', amount: 100 },
  uap_100: { label: '100 UA FC Points', priceCoins: 50000, currency: 'ua_points', amount: 100 },
};
async function creditGems(n) {
  if (!cloudUser) { userGems += n; return; }
  try {
    const { data } = await sb.from('user_gems').select('gems').eq('user_id', cloudUser.id).maybeSingle();
    const cur = (data && data.gems) || 0;
    await sb.from('user_gems').upsert({ user_id: cloudUser.id, gems: cur + n }, { onConflict: 'user_id' });
    userGems = cur + n;
  } catch (err) {
    ;
    userGems += n; // reflect it locally even if the cloud write failed
  }
}
async function creditUAPoints(n) {
  userUAPoints += n;
  if (!cloudUser) return;
  try {
    await sb.from('user_ua_points').upsert({ user_id: cloudUser.id, ua_points: userUAPoints, updated_at: new Date().toISOString() }, { onConflict: 'user_id' });
  } catch (err) { ; }
}
async function enterStore() {
  showScreen('scr-store');
  $('store-coins').textContent = settings.infMoney ? '∞' : coins.toLocaleString();
}
async function buyStoreItem(itemKey) {
  const item = STORE_ITEMS[itemKey];
  if (!item) return;
  if (!settings.infMoney && coins < item.priceCoins) { toast('Not enough coins.'); return; }
  if (!confirm(`Buy ${item.label} for ${item.priceCoins.toLocaleString()} coins?`)) return;
  const btn = document.querySelector(`.store-buy-btn[data-item="${itemKey}"]`);
  if (btn) { btn.disabled = true; btn.innerHTML = '<span>…</span>'; }
  try {
    if (!settings.infMoney) { coins -= item.priceCoins; saveCoins(); updateCoinUI(); }
    if (item.currency === 'gems') await creditGems(item.amount);
    else if (item.currency === 'ua_points') await creditUAPoints(item.amount);
    updateHubTopbar();
    $('store-coins').textContent = settings.infMoney ? '∞' : coins.toLocaleString();
    audio.ui();
    toast(`Purchased ${item.label}!`);
  } catch (err) {
    if (!settings.infMoney) { coins += item.priceCoins; saveCoins(); updateCoinUI(); }
    toast('Purchase failed — please try again');
  } finally {
    if (btn) { btn.disabled = false; btn.innerHTML = '<span>Buy</span>'; }
  }
}
qsa('.store-buy-btn').forEach((btn) => {
  btn.addEventListener('click', () => buyStoreItem(btn.dataset.item));
});
$('store-back').addEventListener('click', () => { audio.ui(); enterMenu(); showScreen('scr-main'); });

async function loadMarketGame() {
  $('mkt-loading').classList.remove('hidden');
  $('mkt-grid').innerHTML = '';
  try {
    const { data: listings, error: lErr } = await sb.from('market_listings').select('*, players_registry(*)').eq('is_available', true);
    if (lErr) throw lErr;
    marketGameCache = (listings || []).filter((l) => l.players_registry && l.players_registry.is_active)
      .map((l) => ({ ...l.players_registry, price: l.price_coins }));
    renderMarketGame();
  } catch (err) {
    toast('Failed to load market — please try again');
  } finally {
    $('mkt-loading').classList.add('hidden');
  }
}
function renderMarketGame() {
  const q = ($('mkt-search').value || '').trim().toLowerCase();
  const filtered = q ? marketGameCache.filter((p) => p.name.toLowerCase().includes(q)) : marketGameCache;
  const grid = $('mkt-grid');
  const empty = $('mkt-empty');
  if (!filtered.length) { empty.classList.remove('hidden'); grid.innerHTML = ''; return; }
  empty.classList.add('hidden');
  grid.innerHTML = filtered.map((p) => {
    const img = p.media_path ? mediaUrlFor(p.media_path) : '';
    return `<div class="mkt-card" data-player-id="${p.id}">
      <div class="mc-ovr">${ovrD(p.ovr)}</div>
      <img class="mkt-card-img" data-pid="${p.id}" alt="${escHtmlGame(p.name)}" />
      <div class="mc-name">${escHtmlGame(p.name)}</div>
      <div class="mc-price">🪙 ${p.price.toLocaleString()}</div>
    </div>`;
  }).join('');
  qsa('.mkt-card', grid).forEach((card) => {
    const id = card.dataset.playerId;
    const img = card.querySelector('.mkt-card-img');
    if (img) img.addEventListener('click', (e) => {
      e.stopPropagation();
      const p = marketGameCache.find((x) => x.id === id);
      if (!p) return;
      openPlayerPreview({ pid: p.id, name: p.name, ovr: ovrD(p.ovr), rarity: p.rarity, pos: p.position, img: p.media_path ? mediaUrlFor(p.media_path) : '' });
    });
    card.addEventListener('click', () => buyMarketPlayer(id));
  });
}
async function buyMarketPlayer(playerId) {
  if (!cloudUser) { toast('Sign in to buy players.'); return; }
  const p = marketGameCache.find((x) => x.id === playerId);
  if (!p) return;
  if (!settings.infMoney && coins < p.price) { toast('Not enough coins.'); return; }
  if (!confirm(`Buy ${p.name} for ${p.price.toLocaleString()} coins?`)) return;
  try {
    if (!settings.infMoney) { coins -= p.price; saveCoins(); updateCoinUI(); }
    const { error } = await sb.from('user_players').insert({ user_id: cloudUser.id, player_id: p.id, acquired_via: 'market' });
    if (!error) reservesOwnedCache = null;
    if (error) throw error;
    $('mkt-coins').textContent = settings.infMoney ? '∞' : coins.toLocaleString();
    questPostProgress('sign_player', 1);
    playPackOpenAnimation(p, () => { toast(`Bought ${p.name}!`); });
  } catch (err) {
    // Refund on failure so a DB error never silently costs the player coins.
    if (!settings.infMoney) { coins += p.price; saveCoins(); updateCoinUI(); }
    toast('Purchase failed — please try again');
  }
}
$('mkt-search').addEventListener('input', debounce(renderMarketGame, 150));
$('mkt-back').addEventListener('click', () => { audio.ui(); enterMenu(); showScreen('scr-main'); });

/* ==========================================================================
   EXCHANGE — trade duplicate/unwanted players for a specific player you
   want. Offered players' combined exchange value must meet or exceed the
   target's value. Values come from exchange_values overrides, falling
   back to a formula scaled against exchange_config.max_ovr_reference.
   ========================================================================== */
let exchangeGamePlayers = [];
let exchangeGameMaxOvr = 27;
let exchangeGameOverrides = new Map();
let exchangeTarget = null;
let exchangeOffered = new Set();
async function enterExchange() {
  showScreen('scr-exchange');
  await loadExchangeGame();
}
function computeExchangeValue(p) {
  if (exchangeGameOverrides.has(p.id)) return exchangeGameOverrides.get(p.id);
  return Math.max(1, Math.round((p.ovr / Math.max(1, exchangeGameMaxOvr)) * 100));
}
async function loadExchangeGame() {
  $('exch-loading').classList.remove('hidden');
  exchangeTarget = null;
  exchangeOffered = new Set();
  updateExchangeUI();
  try {
    const { data: config } = await sb.from('exchange_config').select('*').eq('id', true).maybeSingle();
    exchangeGameMaxOvr = (config && config.max_ovr_reference) || 27;

    if (!cloudUser) { exchangeGamePlayers = []; renderExchangeGame(); toast('Sign in to use Exchange.'); return; }
    const { data: owned, error: oErr } = await sb.from('user_players').select('player_id, players_registry(*)').eq('user_id', cloudUser.id);
    if (oErr) throw oErr;
    exchangeGamePlayers = (owned || []).filter((r) => r.players_registry).map((r) => r.players_registry);

    const { data: overrides } = await sb.from('exchange_values').select('*');
    exchangeGameOverrides = new Map((overrides || []).map((o) => [o.player_id, o.exchange_value]));

    renderExchangeGame();
  } catch (err) {
    toast('Failed to load exchange — please try again');
  } finally {
    $('exch-loading').classList.add('hidden');
  }
}
function renderExchangeGame() {
  const q = ($('exch-search').value || '').trim().toLowerCase();
  const filtered = q ? exchangeGamePlayers.filter((p) => p.name.toLowerCase().includes(q)) : exchangeGamePlayers;
  const grid = $('exch-grid');
  grid.innerHTML = filtered.map((p) => {
    const img = p.media_path ? mediaUrlFor(p.media_path) : '';
    const isTarget = exchangeTarget && exchangeTarget.id === p.id;
    const isOffered = exchangeOffered.has(p.id);
    return `<div class="mkt-card ${isTarget || isOffered ? 'selected' : ''}" data-player-id="${p.id}">
      <div class="mc-ovr">${ovrD(p.ovr)}</div>
      <img class="mkt-card-img" data-pid="${p.id}" alt="${escHtmlGame(p.name)}" />
      <div class="mc-name">${escHtmlGame(p.name)}</div>
      <div class="mc-price">Value: ${computeExchangeValue(p)}</div>
    </div>`;
  }).join('');
  qsa('.mkt-card', grid).forEach((card) => {
    const id = card.dataset.playerId;
    const imgEl = card.querySelector('.mkt-card-img');
    if (imgEl) imgEl.addEventListener('click', (e) => {
      e.stopPropagation();
      const p = exchangeGamePlayers.find((x) => x.id === id);
      if (!p) return;
      openPlayerPreview({ pid: p.id, name: p.name, ovr: ovrD(p.ovr), rarity: p.rarity, pos: p.position, img: p.media_path ? mediaUrlFor(p.media_path) : '' });
    });
    card.addEventListener('click', () => {
      const p = exchangeGamePlayers.find((x) => x.id === id);
      if (!p) return;
      // Tap sets the target the first time; subsequent taps on other
      // players toggle them as "offered" to cover that target's value.
      if (!exchangeTarget) {
        exchangeTarget = p;
      } else if (exchangeTarget.id === id) {
        exchangeTarget = null;
        exchangeOffered.clear();
      } else if (exchangeOffered.has(id)) {
        exchangeOffered.delete(id);
      } else {
        exchangeOffered.add(id);
      }
      renderExchangeGame();
      updateExchangeUI();
    });
  });
}
function updateExchangeUI() {
  const targetEl = $('exch-target-card');
  if (!exchangeTarget) {
    targetEl.innerHTML = '<div class="exch-target-empty">Tap a player below</div>';
  } else {
    const img = exchangeTarget.media_path ? mediaUrlFor(exchangeTarget.media_path) : '';
    targetEl.innerHTML = `<div class="vcard rar-${escHtmlGame(exchangeTarget.rarity)}"><div class="vo">${ovrD(exchangeTarget.ovr)}</div><img data-pid="${exchangeTarget.id}" alt="" /><div class="vn">${escHtmlGame(exchangeTarget.name)}</div></div>`;
    const t = exchangeTarget;
    targetEl.querySelector('.vcard').addEventListener('click', () => {
      openPlayerPreview({ pid: t.id, name: t.name, ovr: ovrD(t.ovr), rarity: t.rarity, pos: t.position, img: t.media_path ? mediaUrlFor(t.media_path) : '' });
    });
  }
  const needed = exchangeTarget ? computeExchangeValue(exchangeTarget) : 0;
  const offeredValue = [...exchangeOffered].reduce((sum, id) => {
    const p = exchangeGamePlayers.find((x) => x.id === id);
    return sum + (p ? computeExchangeValue(p) : 0);
  }, 0);
  $('exch-progress-fill').style.width = needed ? clamp01(offeredValue / needed) * 100 + '%' : '0%';
  $('exch-progress-label').textContent = `${offeredValue} / ${needed} value offered`;
  $('exch-confirm-btn').disabled = !exchangeTarget || offeredValue < needed || needed === 0;
}
$('exch-confirm-btn').addEventListener('click', async () => {
  if (!exchangeTarget || !cloudUser) return;
  const offeredIds = [...exchangeOffered];
  if (!confirm(`Trade ${offeredIds.length} player(s) for ${exchangeTarget.name}? Traded players are gone permanently.`)) return;
  try {
    // Remove one owned copy per offered player_id (their user_players row IDs).
    const { data: ownedRows, error: rErr } = await sb.from('user_players').select('id, player_id').eq('user_id', cloudUser.id);
    if (rErr) throw rErr;
    const idsToDelete = [];
    for (const pid of offeredIds) {
      const row = (ownedRows || []).find((r) => r.player_id === pid && !idsToDelete.includes(r.id));
      if (row) idsToDelete.push(row.id);
    }
    if (idsToDelete.length) {
      const { error: delErr } = await sb.from('user_players').delete().in('id', idsToDelete);
      if (delErr) throw delErr;
    }
    const { error: insErr } = await sb.from('user_players').insert({ user_id: cloudUser.id, player_id: exchangeTarget.id, acquired_via: 'exchange' });
    if (!insErr) reservesOwnedCache = null;
    if (insErr) throw insErr;
    toast(`Exchanged for ${exchangeTarget.name}!`);
    audio.ui();
    await loadExchangeGame();
  } catch (err) {
    toast('Exchange failed — please try again');
  }
});
$('exch-search').addEventListener('input', debounce(renderExchangeGame, 150));
$('exch-back').addEventListener('click', () => { audio.ui(); enterMenu(); showScreen('scr-main'); });

/* ==========================================================================
   HUB BUTTON ROUTING (Market / Exchange / Club / locked Signings & Store)
   ========================================================================== */
// STORE tab = existing Market screen/logic (player market), per new bottom bar mapping
$('btn-hub-store').addEventListener('click', () => { audio.init(); audio.ui(); enterStore(); });
$('btn-hub-exchange').addEventListener('click', () => { audio.init(); audio.ui(); enterExchange(); });
$('btn-hub-club').addEventListener('click', () => { audio.init(); audio.ui(); enterClub(); });
$('btn-hub-league').addEventListener('click', () => { audio.init(); audio.ui(); enterLeagues(); });
function showComingSoon(title) {
  $('cs-title').textContent = title || 'Coming Soon';
  $('comingsoon-backdrop').classList.remove('hidden');
}
$('btn-hub-signings').addEventListener('click', () => { audio.ui(); enterMarket(); });
$('btn-hub-quests').addEventListener('click', () => { audio.ui(); enterQuestsGame(); });
$('cs-close').addEventListener('click', () => { audio.ui(); $('comingsoon-backdrop').classList.add('hidden'); });
$('comingsoon-backdrop').addEventListener('click', (e) => { if (e.target === $('comingsoon-backdrop')) $('comingsoon-backdrop').classList.add('hidden'); });
$('btn-add-coins').addEventListener('click', (e) => { e.stopPropagation(); audio.ui(); showComingSoon('Coin Store'); });
$('btn-add-gems').addEventListener('click', (e) => { e.stopPropagation(); audio.ui(); showComingSoon('Gem Store'); });
$('btn-add-uap').addEventListener('click', (e) => { e.stopPropagation(); audio.ui(); enterRoyale(); });
// Left icon rail — Activities/Featured/Star Pass/Extra Time route to Coming Soon
// (no backend content yet); Bonus opens the existing daily-bonus flow if present,
// otherwise also Coming Soon. Swap each for its real screen as it's built.
$('btn-rail-activities').addEventListener('click', () => { audio.ui(); enterActivities(); });
$('btn-rail-featured').addEventListener('click', () => { audio.ui(); enterFeatured(); });
$('btn-rail-starpass').addEventListener('click', () => { audio.ui(); enterUAPass(); });
$('btn-rail-bonus').addEventListener('click', () => { audio.ui(); enterBonus(); });
$('btn-hub-news').addEventListener('click', () => { audio.ui(); enterActivities(); });
$('btn-hub-mail').addEventListener('click', () => { audio.ui(); enterMailGame(); });

/* ==========================================================================
   CLUB / MY TEAM — freeform drag-drop formation editor. Starters + subs
   share one drag-drop pool with Reserves. Captain and penalty taker are
   set via Team Editing; penalty taker overrides the AI's auto-pick.
   ========================================================================== */
let clubSlotPositions = []; // [{x,z (0-1 normalized), regId}] loaded/saved per user
let clubDraggingSlot = null;
let clubCaptainRegId = null;
let clubPenaltyRegId = null;

function defaultClubFormation() {
  // Sensible default freeform layout (roughly 4-2-4-ish spread), used
  // the first time a user opens Club before they've customized anything.
  const roles = squads[0].map((s) => s.role);
  const spread = [
    { x: 0.5, z: 0.92 }, { x: 0.18, z: 0.74 }, { x: 0.38, z: 0.78 }, { x: 0.62, z: 0.78 }, { x: 0.82, z: 0.74 },
    { x: 0.32, z: 0.52 }, { x: 0.68, z: 0.52 }, { x: 0.15, z: 0.22 }, { x: 0.4, z: 0.14 }, { x: 0.6, z: 0.14 }, { x: 0.85, z: 0.22 },
  ];
  return squads[0].map((s, i) => ({ x: spread[i] ? spread[i].x : 0.5, z: spread[i] ? spread[i].z : 0.5, regId: s._regId || null, role: s.role }));
}
async function enterClub() {
  showScreen('scr-club');
  clubSetTab('myclub');
  if (!clubSlotPositions.length) clubSlotPositions = defaultClubFormation();
  renderClubPitch();
  updateClubValue();
}
function clubSetTab(tab) {
  document.querySelectorAll('#club-tabs .club-tab').forEach((b) => b.classList.toggle('on', b.dataset.tab === tab));
  $('club-pane-myclub').classList.toggle('hidden', tab !== 'myclub');
  $('club-pane-locker').classList.toggle('hidden', tab !== 'locker');
  $('club-title').textContent = tab === 'locker' ? 'LOCKER ROOM' : 'MY TEAM';
  if (tab === 'locker') renderLockerRoom();
}
$('club-tabs').addEventListener('click', (e) => {
  const b = e.target.closest('.club-tab'); if (!b) return;
  audio.ui();
  clubSetTab(b.dataset.tab);
});

/* ==========================================================================
   🎽 LOCKER ROOM — team-wide kit color (shirt+shorts+socks together, per
   spec) and per-player squad numbers. Both are pure presentation: they
   never touch a player's model_data (the exact model built in
   PLAYER_MODEL_EDITOR.html always stays byte-for-byte what was published),
   they only change which colors/numbers get drawn on top of it at spawn
   time — see applyLockerKitToHomeTeam() and squads[0][i].num overrides.
   ========================================================================== */
function applyLockerKitToHomeTeam() {
  if (!cloudProfile) return;
  const def = TEAMS[settings.homeTeam];
  if (!def) return;
  if (cloudProfile.kit_primary_color) def.c1 = cloudProfile.kit_primary_color;
  if (cloudProfile.kit_secondary_color) def.c2 = cloudProfile.kit_secondary_color;
  def._kitTex = null; // bust the cached kit texture so the new colors actually render
}
function lockerUpdatePreview() {
  const p = $('locker-kit-primary').value, s = $('locker-kit-secondary').value;
  $('locker-kit-preview').style.background = `linear-gradient(90deg, ${p} 0%, ${p} 50%, ${s} 50%, ${s} 100%)`;
}
function renderLockerRoom() {
  $('locker-kit-primary').value = cloudProfile?.kit_primary_color || TEAMS[settings.homeTeam].c1;
  $('locker-kit-secondary').value = cloudProfile?.kit_secondary_color || TEAMS[settings.homeTeam].c2;
  lockerUpdatePreview();
  lockerRenderNumbers();
}
$('locker-kit-primary').addEventListener('input', lockerUpdatePreview);
$('locker-kit-secondary').addEventListener('input', lockerUpdatePreview);
$('locker-kit-save').addEventListener('click', async () => {
  if (!cloudUser) { toast('Sign in to save your kit.'); return; }
  const primary = $('locker-kit-primary').value;
  const secondary = $('locker-kit-secondary').value;
  try {
    const { error } = await sb.from('profiles').update({ kit_primary_color: primary, kit_secondary_color: secondary }).eq('id', cloudUser.id);
    if (error) throw error;
    if (cloudProfile) { cloudProfile.kit_primary_color = primary; cloudProfile.kit_secondary_color = secondary; }
    toast('Kit colors saved!');
  } catch (e) { toast('Could not save kit colors.'); ; }
});
async function lockerRenderNumbers() {
  const wrap = $('locker-numbers-list');
  if (!cloudUser) { wrap.innerHTML = '<div class="fr-empty">Sign in to manage squad numbers.</div>'; return; }
  wrap.innerHTML = '<div class="fr-empty">Loading…</div>';
  try {
    const { data: owned, error } = await sb.from('user_players')
      .select('id, player_id, jersey_number, players_registry(id,name)')
      .eq('user_id', cloudUser.id);
    if (error) throw error;
    const rows = (owned || []).filter((r) => r.players_registry);
    if (!rows.length) { wrap.innerHTML = '<div class="fr-empty">No owned players yet.</div>'; return; }
    wrap.innerHTML = rows.map((r) => `
      <div class="locker-num-row" data-upid="${r.id}">
        <div class="locker-num-name">${escHtmlGame(r.players_registry.name)}</div>
        <input type="number" class="locker-num-input" min="1" max="99" value="${r.jersey_number || ''}" placeholder="—" />
      </div>`).join('');
  } catch (e) { wrap.innerHTML = '<div class="fr-empty">Could not load squad.</div>'; ; }
}
$('locker-numbers-list').addEventListener('change', async (e) => {
  const input = e.target.closest('.locker-num-input'); if (!input) return;
  const row = input.closest('.locker-num-row');
  const upId = row.dataset.upid;
  const raw = input.value.trim();
  if (!raw) {
    // Cleared -> free up that number.
    try { await sb.from('user_players').update({ jersey_number: null }).eq('id', upId); } catch (err) {}
    return;
  }
  const num = parseInt(raw, 10);
  if (!Number.isInteger(num) || num < 1 || num > 99) {
    toast('Number must be 1–99.');
    input.value = '';
    return;
  }
  try {
    const { error } = await sb.from('user_players').update({ jersey_number: num }).eq('id', upId);
    if (error) {
      if (error.code === '23505') toast('Someone already has that number.');
      else toast('Could not save number.');
      input.value = '';
      return;
    }
    toast(`Set to #${num}`);
  } catch (err) { toast('Could not save number.'); input.value = ''; }
});
function updateClubOvrBadgeState(hasIssue) {
  $('club-ovr-badge').classList.toggle('has-issue', !!hasIssue);
}
async function updateClubValue() {
  const rating = computeTeamRating();
  $('club-ovr-badge').textContent = rating.display;
  $('club-ovr-badge').title = rating.tooltip;
  updateClubOvrBadgeState(rating.tooltip.includes('empty slot'));
  // Real club value: sum of owned players' market price (falls back to
  // OVR*1000 for players with no market listing, so the total is never 0).
  try {
    const { data: owned } = await sb.from('user_players').select('player_id').eq('user_id', cloudUser ? cloudUser.id : '');
    const { data: listings } = await sb.from('market_listings').select('player_id, price_coins');
    const priceById = new Map((listings || []).map((l) => [l.player_id, l.price_coins]));
    let total = 0;
    for (const row of owned || []) total += priceById.get(row.player_id) || 1000;
    $('club-value-label').textContent = total.toLocaleString() + ' coins';
  } catch (err) {
    $('club-value-label').textContent = '—';
  }
}

/* ==========================================================================
   TEAM OVR CALCULATOR (v2)
   Old version was a flat mean of the 11 OVRs. This version instead accounts
   for: position fit (playing a CB at RB costs rating, same idea as
   Auto Build's fallback tiers), squad chemistry (players who share a
   playstyle link up and give each other a small boost), and empty slots
   (an unfilled starting XI slot counts as 0, not "skip it" — so the badge
   always reflects a real, fieldable XI rather than best-case average).
   ========================================================================== */
const POS_FIT_TIERS = { GK: ['GK'], CB: ['CB', 'LB', 'RB'], LB: ['LB', 'CB'], RB: ['RB', 'CB'], CDM: ['CDM', 'CM'], CM: ['CM', 'CDM', 'CAM'], CAM: ['CAM', 'CM'], LM: ['LM', 'LW', 'CM'], RM: ['RM', 'RW', 'CM'], LW: ['LW', 'LM'], RW: ['RW', 'RM'], ST: ['ST', 'CAM'] };
function posFitPenalty(slotRole, playerPos) {
  if (!playerPos) return -6;
  if (playerPos === slotRole) return 0;
  const tiers = POS_FIT_TIERS[slotRole] || [slotRole];
  const tierIdx = tiers.indexOf(playerPos);
  if (tierIdx === -1) return -6; // wrong pos entirely (e.g. ST dropped into GK)
  return -2 * tierIdx; // -2 per tier of mismatch (e.g. CB filling in at RB: -2)
}
function computeTeamRating() {
  const filled = clubSlotPositions.map((slot) => ({ slot, rec: slot.regId ? regById(slot.regId) : null }));
  const n = clubSlotPositions.length || 11;
  let sum = 0;
  filled.forEach(({ slot, rec }) => {
    if (!rec) { sum += 0; return; } // empty slot: counts as 0, not skipped
    const penalty = posFitPenalty(slot.role, rec.pos);
    sum += Math.max(0, (rec.ovr || 0) + penalty);
  });
  let base = sum / n;

  // Chemistry: every pair of starters sharing a playstyle adds a small
  // team-wide bump, capped so a handful of links matter without letting a
  // huge playstyle-stacked squad blow past realistic OVR ranges.
  const starters = filled.filter((f) => f.rec).map((f) => f.rec);
  let links = 0;
  for (let i = 0; i < starters.length; i++) {
    for (let j = i + 1; j < starters.length; j++) {
      const a = (starters[i].playstyles || []).map((p) => p.name || p);
      const b = (starters[j].playstyles || []).map((p) => p.name || p);
      if (a.some((name) => b.includes(name))) links++;
    }
  }
  const chemBonus = Math.min(3, links * 0.25);

  const emptyCount = filled.filter((f) => !f.rec).length;
  const final = Math.max(0, Math.round(base + chemBonus));
  const tooltip = emptyCount
    ? `${emptyCount} empty slot${emptyCount > 1 ? 's' : ''} dragging your rating down — fill your XI to raise it.`
    : `Base ${ovrD(Math.round(base))} + chemistry ${chemBonus.toFixed(1)} from ${links} linked pair${links === 1 ? '' : 's'}.`;
  return { display: String(ovrD(final)), tooltip };
}
function renderClubPitch() {
  const pitch = $('club-pitch');
  pitch.innerHTML = '';
  const rect = { w: pitch.clientWidth || 600, h: pitch.clientHeight || 400 };
  clubSlotPositions.forEach((slot, idx) => {
    const rec = slot.regId ? regById(slot.regId) : null;
    const el = document.createElement('div');
    el.className = 'club-slot' + (rec ? ' rar-' + rec.rarity : ' empty');
    el.style.left = (slot.x * 100) + '%';
    el.style.top = (slot.z * 100) + '%';
    el.dataset.idx = idx;
    const img = rec && rec.img ? rec.img : '';
    const fitPenalty = rec ? posFitPenalty(slot.role, rec.pos) : 0;
    el.innerHTML = rec
      ? `<div class="cs-card" data-pid="${String(rec.id).replace(/^cloud-/, '')}">
           <span class="cs-ovr">${ovrD(rec.ovr)}</span>
           ${fitPenalty < 0 ? '<span class="cs-offpos" title="Out of position">!</span>' : ''}
           ${clubCaptainRegId === slot.regId ? '<span class="cs-captain">🅲</span>' : ''}
           ${clubPenaltyRegId === slot.regId ? '<span class="cs-sub-tag">PK</span>' : ''}
         </div><div class="cs-name">${escHtmlGame(rec.name)}</div>`
      : `<div class="cs-card">${escHtmlGame(slot.role || '')}</div><div class="cs-name">Empty</div>`;
    el.style.animation = 'clubSlotIn .28s ease both';
    el.style.animationDelay = (idx * 0.02) + 's';
    bindClubSlotDrag(el);
    pitch.appendChild(el);
  });
}
function bindClubSlotDrag(el) {
  let startX, startY, origLeft, origTop, moved = false;
  const pitch = $('club-pitch');
  el.addEventListener('pointerdown', (e) => {
    e.preventDefault();
    clubDraggingSlot = el;
    moved = false;
    el.classList.add('dragging');
    el.setPointerCapture(e.pointerId);
    startX = e.clientX; startY = e.clientY;
    origLeft = parseFloat(el.style.left); origTop = parseFloat(el.style.top);
  });
  el.addEventListener('pointermove', (e) => {
    if (clubDraggingSlot !== el) return;
    if (Math.hypot(e.clientX - startX, e.clientY - startY) > 8) moved = true;
    const rect = pitch.getBoundingClientRect();
    const dxPct = ((e.clientX - startX) / rect.width) * 100;
    const dyPct = ((e.clientY - startY) / rect.height) * 100;
    el.style.left = clamp(origLeft + dxPct, 4, 96) + '%';
    el.style.top = clamp(origTop + dyPct, 4, 96) + '%';
  });
  el.addEventListener('pointerup', () => {
    if (clubDraggingSlot !== el) return;
    clubDraggingSlot = null;
    el.classList.remove('dragging');
    const idx = parseInt(el.dataset.idx, 10);
    if (moved) {
      clubSlotPositions[idx].x = clamp(parseFloat(el.style.left), 4, 96) / 100;
      clubSlotPositions[idx].z = clamp(parseFloat(el.style.top), 4, 96) / 100;
      saveClubFormation();
      updateClubValue();
    } else {
      // A tap (no meaningful drag) opens the big player preview instead.
      const slot = clubSlotPositions[idx];
      const rec = slot && slot.regId ? regById(slot.regId) : null;
      if (rec) openPlayerPreview({ pid: rec.id, name: rec.name, ovr: rec.ovr, rarity: rec.rarity, pos: rec.pos, img: rec.img || '' });
    }
  });
}
function saveClubFormation() {
  if (!cloudUser) return;
  markCloudDirty(); // reuse existing debounce; formation stored alongside other cloud state below
}
$('club-back').addEventListener('click', () => { audio.ui(); enterMenu(); showScreen('scr-main'); });

// ---- Auto Build: places owned players into the nearest-matching-position slot ----
$('btn-club-autobuild').addEventListener('click', async () => {
  audio.ui();
  if (!cloudUser) { toast('Sign in to use Auto Build.'); return; }
  try {
    const { data: owned, error } = await sb.from('user_players').select('player_id, players_registry(*)').eq('user_id', cloudUser.id);
    if (error) throw error;
    const pool = (owned || []).filter((r) => r.players_registry).map((r) => r.players_registry);
    const posOrder = { GK: ['GK'], CB: ['CB', 'LB', 'RB'], LB: ['LB', 'CB'], RB: ['RB', 'CB'], CDM: ['CDM', 'CM'], CM: ['CM', 'CDM', 'CAM'], CAM: ['CAM', 'CM'], LM: ['LM', 'LW', 'CM'], RM: ['RM', 'RW', 'CM'], LW: ['LW', 'LM'], RW: ['RW', 'RM'], ST: ['ST', 'CAM'] };
    const used = new Set();
    for (const slot of clubSlotPositions) {
      const wantOrder = posOrder[slot.role] || [slot.role];
      let best = null;
      for (const posTry of wantOrder) {
        best = pool.find((p) => p.position === posTry && !used.has(p.id));
        if (best) break;
      }
      if (!best) best = pool.find((p) => !used.has(p.id)); // closest fallback: anyone unused
      if (best) { slot.regId = 'cloud-' + best.id; used.add(best.id); }
    }
    renderClubPitch();
    updateClubValue();
    saveClubFormation();
    toast('Auto Build complete!');
  } catch (err) {
    toast('Auto Build failed — please try again');
  }
});

// ---- Reserves drawer ----
$('btn-club-reserves').addEventListener('click', async () => { audio.ui(); await openReservesDrawer(); });
$('reserves-close').addEventListener('click', () => { audio.ui(); $('reserves-backdrop').classList.add('hidden'); });
let reservesOwnedCache = null; // cached full owned-players list; re-filtered locally on every swap so re-renders are instant, no re-fetch
async function openReservesDrawer(forceRefresh) {
  $('reserves-backdrop').classList.remove('hidden');
  if (!cloudUser) { $('reserves-loading').classList.remove('hidden'); $('reserves-loading').textContent = 'Sign in to see your players.'; return; }
  if (reservesOwnedCache && !forceRefresh) { renderReservesList(reservesOwnedCache); return; }
  $('reserves-loading').classList.remove('hidden');
  $('reserves-list').innerHTML = '';
  try {
    const { data: owned, error } = await sb.from('user_players').select('player_id, players_registry(*)').eq('user_id', cloudUser.id);
    if (error) throw error;
    reservesOwnedCache = (owned || []).filter((r) => r.players_registry).map((r) => r.players_registry);
    renderReservesList(reservesOwnedCache);
  } catch (err) {
    $('reserves-loading').textContent = 'Couldn\'t load your squad — please try again.';
  }
}
function renderReservesList(allOwned) {
  $('reserves-loading').classList.add('hidden');
  // Reserves = owned players not currently occupying a pitch slot. This
  // is what keeps the squad honestly at 11: a player can only be in one
  // place at a time, so dragging one onto the pitch necessarily removes
  // them from this list, and whoever they displaced reappears here.
  const startingIds = new Set(clubSlotPositions.filter((s) => s.regId).map((s) => s.regId.replace('cloud-', '')));
  const list = allOwned.filter((p) => !startingIds.has(String(p.id)));
  if (!allOwned.length) { $('reserves-list').innerHTML = '<div class="reg-empty-state">No players owned yet — try the Market or Luck Royale!</div>'; return; }
  if (!list.length) { $('reserves-list').innerHTML = '<div class="reg-empty-state">Your whole squad is on the pitch — drag a starter here to swap.</div>'; return; }
  $('reserves-list').innerHTML = list.map((p) => {
    const img = p.media_path ? mediaUrlFor(p.media_path) : '';
    return `<div class="reserve-card" data-reg-id="cloud-${p.id}"><img class="reserve-card-img" data-pid="${p.id}" alt="" /><div class="rc-name">${escHtmlGame(p.name)}</div></div>`;
  }).join('');
  qsa('.reserve-card', $('reserves-list')).forEach((card) => {
    const imgEl = card.querySelector('.reserve-card-img');
    const p = list.find((x) => `cloud-${x.id}` === card.dataset.regId);
    bindReserveCardDrag(card, p, imgEl);
  });
}

/**
 * Drag-and-drop a reserve card straight onto a pitch slot. A plain tap
 * (no meaningful movement) still opens the player preview, same as before.
 * On drop over a valid slot: the reserve player takes that slot, and
 * whoever was previously in it is returned to reserves — so the pitch
 * always holds exactly 11 players, never more.
 */
function bindReserveCardDrag(card, playerRow, imgEl) {
  if (!playerRow) return;
  let startX, startY, moved = false, dragging = false;
  const ghost = $('reserve-drag-ghost');
  const backdrop = $('reserves-backdrop');

  card.addEventListener('pointerdown', (e) => {
    startX = e.clientX; startY = e.clientY;
    moved = false; dragging = false;
    try { card.setPointerCapture(e.pointerId); } catch (err) { /* card may already be mid-teardown from a prior render */ }
  });
  card.addEventListener('pointercancel', () => {
    // Defensive cleanup: if the OS/browser cancels the gesture mid-drag
    // (e.g. a system gesture interrupts it), the old code left `dragging`
    // true and the ghost element stuck visible, which blocked the next
    // drag attempt from working until a full page reload.
    qsa('.club-slot').forEach((s) => s.classList.remove('drop-target'));
    card.classList.remove('dragging-source');
    backdrop.classList.remove('dragging');
    ghost.classList.add('hidden');
    dragging = false; moved = false;
  });
  card.addEventListener('pointermove', (e) => {
    if (!card.hasPointerCapture || !card.hasPointerCapture(e.pointerId)) return;
    if (!moved && Math.hypot(e.clientX - startX, e.clientY - startY) > 10) {
      moved = true; dragging = true;
      card.classList.add('dragging-source');
      backdrop.classList.add('dragging');
      const img = imgEl ? imgEl.src : '';
      ghost.style.backgroundImage = img ? `url('${img}')` : '';
      ghost.innerHTML = `<div class="rdg-name">${escHtmlGame(playerRow.name)}</div>`;
      ghost.classList.remove('hidden');
    }
    if (dragging) {
      ghost.style.left = e.clientX + 'px';
      ghost.style.top = e.clientY + 'px';
      // highlight whichever pitch slot is currently under the pointer
      qsa('.club-slot').forEach((s) => s.classList.remove('drop-target'));
      const under = document.elementFromPoint(e.clientX, e.clientY);
      const slotEl = under && under.closest ? under.closest('.club-slot') : null;
      if (slotEl) slotEl.classList.add('drop-target');
    }
  });
  card.addEventListener('pointerup', (e) => {
    qsa('.club-slot').forEach((s) => s.classList.remove('drop-target'));
    card.classList.remove('dragging-source');
    backdrop.classList.remove('dragging');
    ghost.classList.add('hidden');
    if (!moved) {
      // plain tap: open the big preview, matching pitch-card tap behavior
      openPlayerPreview({ pid: playerRow.id, name: playerRow.name, ovr: playerRow.ovr, rarity: playerRow.rarity, pos: playerRow.position, img: imgEl ? imgEl.src : '' });
      return;
    }
    const under = document.elementFromPoint(e.clientX, e.clientY);
    const slotEl = under && under.closest ? under.closest('.club-slot') : null;
    if (!slotEl) return; // dropped somewhere invalid — cancel, card stays in reserves
    const idx = parseInt(slotEl.dataset.idx, 10);
    if (Number.isNaN(idx) || !clubSlotPositions[idx]) return;
    // Swap: the reserve player takes this slot. Whoever was previously in
    // it is explicitly cleared here (not just overwritten) so captain/
    // penalty-taker refs pointing at the outgoing regId don't silently
    // keep pointing at a player no longer on the pitch.
    const outgoingRegId = clubSlotPositions[idx].regId;
    if (outgoingRegId === 'cloud-' + playerRow.id) return; // no-op: dropped on own slot
    clubSlotPositions[idx].regId = 'cloud-' + playerRow.id;
    if (clubCaptainRegId === outgoingRegId) clubCaptainRegId = null;
    if (clubPenaltyRegId === outgoingRegId) clubPenaltyRegId = null;
    renderClubPitch();
    updateClubValue();
    saveClubFormation();
    audio.ui();
    toast(`${playerRow.name} is starting!`);
    // Rebuild the reserves list from scratch (fresh DOM + fresh listeners)
    // rather than only re-filtering in place. The previous version reused
    // stale card elements/listeners across re-renders, which on some
    // mobile browsers left pointer capture on an orphaned node and made
    // the *next* drag silently fail to start — the "glitchy, can't swap"
    // symptom. A full re-render guarantees every card gets a live,
    // correctly-bound listener every time.
    $('reserves-list').innerHTML = '';
    renderReservesList(reservesOwnedCache);
  });
}

// ---- Team Editing: captain + penalty taker ----
$('btn-club-editing').addEventListener('click', () => { audio.ui(); openTeamEditing(); });
$('teamedit-close').addEventListener('click', () => { audio.ui(); $('teamedit-backdrop').classList.add('hidden'); });
function openTeamEditing() {
  $('teamedit-backdrop').classList.remove('hidden');
  const capSel = $('te-captain');
  const pkSel = $('te-penalty');
  capSel.innerHTML = '<option value="">— None —</option>';
  pkSel.innerHTML = '<option value="">— Auto (best shooter) —</option>';
  clubSlotPositions.filter((s) => s.regId).forEach((s) => {
    const rec = regById(s.regId);
    if (!rec) return;
    const optCap = document.createElement('option');
    optCap.value = s.regId; optCap.textContent = rec.name;
    if (s.regId === clubCaptainRegId) optCap.selected = true;
    capSel.appendChild(optCap);
    const optPk = document.createElement('option');
    optPk.value = s.regId; optPk.textContent = rec.name;
    if (s.regId === clubPenaltyRegId) optPk.selected = true;
    pkSel.appendChild(optPk);
  });
}
$('te-save').addEventListener('click', () => {
  audio.ui();
  clubCaptainRegId = $('te-captain').value || null;
  clubPenaltyRegId = $('te-penalty').value || null;
  renderClubPitch();
  saveClubFormation();
  $('teamedit-backdrop').classList.add('hidden');
  toast('Team updated!');
});

/* ==========================================================================
   32 · SETTINGS UI BINDINGS
   ========================================================================== */
function bindSwitch(id, get, set, extra) {
  const el = $(id);
  el.classList.toggle('on', !!get());
  el.classList.toggle('dev-on', !!get() && id.startsWith('set-') && ['set-infmoney', 'set-infgems', 'set-godstam'].includes(id));
  el.addEventListener('click', () => {
    set(!get());
    el.classList.toggle('on', !!get());
    el.classList.toggle('dev-on', !!get() && ['set-infmoney', 'set-infgems', 'set-godstam'].includes(id));
    audio.ui();
    saveSettings();
    if (extra) extra();
  });
}
function bindSeg(id, cb) {
  const seg = $(id);
  if (!seg) return;
  seg.querySelectorAll('button').forEach((b) => {
    b.addEventListener('click', () => {
      seg.querySelectorAll('button').forEach((x) => x.classList.remove('on'));
      b.classList.add('on');
      audio.init();
      audio.ui();
      cb(b.dataset.v);
    });
  });
}
function syncSeg(id, val) {
  const seg = $(id);
  if (!seg) return;
  seg.querySelectorAll('button').forEach((b) => b.classList.toggle('on', b.dataset.v === String(val)));
}
function buildCamSegs() {
  for (const id of ['seg-cam', 'set-cam']) {
    const seg = $(id);
    seg.innerHTML = '';
    for (const c of CAM_MODES) {
      const b = document.createElement('button');
      b.dataset.v = c;
      b.textContent = CAM_LABELS[c].toUpperCase();
      if (c === settings.camera) b.classList.add('on');
      seg.appendChild(b);
    }
  }
}
function bindSettingsUI() {
  buildCamSegs();
  bindSeg('set-diff', (v) => { settings.diff = parseInt(v, 10); syncSeg('seg-diff', v); });
  bindSeg('set-len', (v) => { settings.halfDur = parseInt(v, 10); });
  bindSeg('seg-diff', (v) => { settings.diff = parseInt(v, 10); syncSeg('set-diff', v); }); // pre-match team-select screen
  bindSeg('seg-len', (v) => { settings.halfDur = parseInt(v, 10); syncSeg('set-len', v); });
  bindSeg('set-assist', (v) => { settings.passAssist = v; });
  bindSeg('set-ctlsize', (v) => { settings.ctlScale = v; applyCtlScale(); });
  bindSeg('seg-cam', (v) => { settings.camera = v; syncSeg('set-cam', v); });
  bindSeg('set-cam', (v) => { settings.camera = v; syncSeg('seg-cam', v); });
  bindSwitch('set-autosw', () => settings.autoSwitch, (v) => settings.autoSwitch = v);
  bindSwitch('set-haptics', () => settings.haptics, (v) => settings.haptics = v);
  bindSeg('set-weather', (v) => { settings.weather = v; saveSettings(); });
  bindSeg('set-season', (v) => { settings.season = v; saveSettings(); });
  bindSeg('set-tod', (v) => { settings.tod = v; saveSettings(); });
  bindSeg('set-stadq', (v) => { settings.stadQuality = v; saveSettings(); toast('STADIUM QUALITY APPLIES NEXT LAUNCH'); });
  bindSwitch('set-wetpitch', () => settings.wetPitch, (v) => settings.wetPitch = v);
  bindSwitch('set-flashes', () => settings.flashes, (v) => settings.flashes = v);
  bindSwitch('set-wave', () => settings.wave, (v) => settings.wave = v);
  bindSwitch('set-sound', () => settings.sound, (v) => settings.sound, null);
  $('set-sound').addEventListener('click', () => { audio.setEnabled(settings.sound); });
  bindSwitch('sw-sound', () => settings.sound, (v) => settings.sound = v, () => audio.setEnabled(settings.sound));
  bindSwitch('sw-autosw', () => settings.autoSwitch, (v) => settings.autoSwitch = v);
  bindSwitch('set-commentary', () => settings.commentary, (v) => settings.commentary = v);
  bindSwitch('set-voice', () => settings.voiceCommentary, (v) => { settings.voiceCommentary = v; if (!v) voiceStopSpeaking(); });
  bindSwitch('set-replay', () => settings.instantReplay, (v) => settings.instantReplay = v);
  const voiceVolEl = $('set-voice-vol');
  voiceVolEl.value = settings.voiceVol;
  voiceVolEl.addEventListener('input', () => { settings.voiceVol = parseInt(voiceVolEl.value, 10); saveSettings(); });
  voicePopulateList();
  if (window.speechSynthesis) window.speechSynthesis.onvoiceschanged = voicePopulateList;
  $('set-voice-pick').addEventListener('change', (e) => { settings.voiceURI = e.target.value; saveSettings(); });
  bindSwitch('set-dev', () => settings.devMode, (v) => settings.devMode = v, () => {
    $('dev-tools').style.display = settings.devMode ? 'flex' : 'none';
    // master switch: unlimited coins + gems on/off together
    settings.infMoney = settings.infGems = settings.devMode;
    if (settings.devMode) coins = Math.max(coins, 999999); else settings.godStamina = false;
    ['set-infmoney', 'set-infgems', 'set-godstam'].forEach((id) => { const el = $(id); if (el) el.classList.toggle('on', id === 'set-godstam' ? settings.godStamina : settings.devMode); });
    saveSettings(); updateCoinUI(); updateHubTopbar(); if (typeof updateRoyaleGemsUI === 'function') updateRoyaleGemsUI();
    toast(settings.devMode ? '🧪 DEV MODE ON — ∞ coins & gems' : 'DEV MODE OFF');
  });
  bindSwitch('set-infmoney', () => settings.infMoney, (v) => settings.infMoney = v, () => {
    if (settings.infMoney) { coins = Math.max(coins, 999999); }
    updateCoinUI();
    toast(settings.infMoney ? '♾️ UNLIMITED MONEY ON' : 'UNLIMITED MONEY OFF');
  });
  bindSwitch('set-infgems', () => settings.infGems, (v) => settings.infGems = v, () => {
    updateHubTopbar();
    toast(settings.infGems ? '♾️ UNLIMITED GEMS ON' : 'UNLIMITED GEMS OFF');
  });
  bindSwitch('set-godstam', () => settings.godStamina, (v) => settings.godStamina = v, () => {
    toast(settings.godStamina ? 'GOD STAMINA ON' : 'GOD STAMINA OFF');
  });
  bindSwitch('set-fps', () => settings.fps, (v) => settings.fps = v);
  const ch = $('set-camheight');
  ch.value = settings.camHeight;
  ch.addEventListener('input', () => { settings.camHeight = parseFloat(ch.value); saveSettings(); });
  const fov = $('set-fov');
  fov.value = settings.camFov;
  fov.addEventListener('input', () => { settings.camFov = parseFloat(fov.value); saveSettings(); });
  const cs = $('set-camsmooth');
  cs.value = settings.camSmooth;
  cs.addEventListener('input', () => { settings.camSmooth = parseFloat(cs.value); saveSettings(); });
  const cv = $('set-crowd');
  cv.value = settings.crowdVol;
  cv.addEventListener('input', () => {
    settings.crowdVol = parseFloat(cv.value);
    audio.setCrowdBase((settings.crowdVol / 100) * 0.32);
    saveSettings();
  });
  const ts = $('set-timescale');
  ts.value = settings.timeScale;
  ts.addEventListener('input', () => { settings.timeScale = parseFloat(ts.value); saveSettings(); });
  $('btn-give-coins').addEventListener('click', () => { addCoins(5000); toast('+5,000 COINS 🪙'); audio.ui(); });
  $('btn-unlock-all').addEventListener('click', () => {
    toast('Not applicable — Luck Royale now uses real draft pools.');
  });
  $('btn-reset-save').addEventListener('click', async () => {
    try { localStorage.removeItem('uafc-settings'); } catch (e) {}
    if (cloudUser) {
      try {
        await sb.from('user_game_state').delete().eq('user_id', cloudUser.id);
      } catch (e) { ; }
    }
    toast('SAVE RESET — RELOADING');
    setTimeout(() => location.reload(), 900);
  });
  $('dev-tools').style.display = settings.devMode ? 'flex' : 'none';
  syncSeg('set-diff', String(settings.diff)); syncSeg('seg-diff', String(settings.diff));
  syncSeg('set-len', String(settings.halfDur));
  syncSeg('set-assist', settings.passAssist);
  syncSeg('set-ctlsize', settings.ctlScale);
  syncSeg('set-weather', settings.weather);
  syncSeg('set-season', settings.season);
  syncSeg('set-tod', settings.tod);
  syncSeg('set-stadq', settings.stadQuality);
}

/* ==========================================================================
   33 · NAVIGATION BINDINGS
   ========================================================================== */
$('btn-hub-play').addEventListener('click', () => { audio.init(); audio.resume(); audio.ui(); if (window.PlayHub) PlayHub.open(); else enterTeamSelect(); });
$('btn-hub-settings').addEventListener('click', () => { audio.init(); audio.ui(); enterSettings(); });
$('btn-open-controls-help').addEventListener('click', () => { audio.ui(); $('modal-help').classList.remove('hidden'); });
$('btn-close-help').addEventListener('click', () => { audio.ui(); $('modal-help').classList.add('hidden'); });
$('btn-ts-back').addEventListener('click', () => { audio.ui(); if (window.PlayHub) PlayHub.open({ tab: 'rivals' }); else enterMenu(); });
function togglePause() {
  if (match.screen !== 'match') return;
  if (match.state === 'halftime' || match.state === 'fulltime') return;
  match.paused = !match.paused;
  $('scr-pause').classList.toggle('hidden', !match.paused);
  if (match.paused) { voiceStopSpeaking(); $('subs-remaining').textContent = 5 - subsUsed[0]; }
}
$('btn-start').addEventListener('click', () => { audio.init(); audio.ui(); startMatch(); });
$('btn-pause').addEventListener('click', () => { audio.init(); togglePause(); });
$('btn-ai-hud').addEventListener('click', () => { audio.init(); toggleAI(true); });
$('btn-resume').addEventListener('click', () => togglePause());
$('btn-p-settings').addEventListener('click', () => {
  if (NET.mode !== 'off') { toast("Settings are locked during a friend match — quit to change them."); return; }
  match.paused = false; $('scr-pause').classList.add('hidden'); enterSettings();
});
$('btn-p-ai').addEventListener('click', () => { toggleAI(true); });
/* ==========================================================================
   🔄 SUBSTITUTIONS — swap one of the human team's (team 0) on-pitch players
   for a bench reserve. Capped at 5 per match, only usable during a
   stoppage (not mid-play), and disabled for the away/opponent team and for
   networked matches (each side only ever controls their own team's roster
   here — team 1 stays AI-managed as it always has been).
   ========================================================================== */
const SUBS = { offPick: null, onPick: null };
function subsOpen() {
  if (match.screen !== 'match') return;
  if (NET.mode !== 'off') { toast('Substitutions are disabled in friend matches for now.'); return; }
  if (subsUsed[0] >= 5) { toast('No substitutions remaining.'); return; }
  SUBS.offPick = null; SUBS.onPick = null;
  match.paused = false; $('scr-pause').classList.add('hidden');
  $('subs-backdrop').classList.remove('hidden');
  subsRender();
}
function subsClose() {
  $('subs-backdrop').classList.add('hidden');
  match.paused = true; $('scr-pause').classList.remove('hidden');
}
function subsRender() {
  $('subs-count-label').textContent = (5 - subsUsed[0]) + ' remaining';
  $('subs-confirm').disabled = !(SUBS.offPick !== null && SUBS.onPick !== null);
  const onPitch = players.filter((p) => p.team === 0 && !p.sentOff);
  $('subs-onpitch').innerHTML = onPitch.map((p) => `
    <div class="subs-row ${SUBS.offPick === p.uid ? 'picked' : ''}" data-uid="${p.uid}">
      <span class="subs-row-role">${p.role}</span>
      <span class="subs-row-name">${escHtmlGame(p.name)}</span>
      <span class="subs-row-meta">${Math.round(p.stamina)}% stam</span>
    </div>`).join('');
  const bench = (benches[0] || []).filter((b) => !b._subbedIn);
  $('subs-bench').innerHTML = bench.map((b, i) => `
    <div class="subs-row ${SUBS.onPick === i ? 'picked' : ''}" data-benchidx="${i}">
      <span class="subs-row-role">${b.role}</span>
      <span class="subs-row-name">${escHtmlGame(b.name)}</span>
      <span class="subs-row-meta">${b.ovr} OVR</span>
    </div>`).join('') || '<div class="fr-empty">No reserves left.</div>';
}
$('subs-onpitch').addEventListener('click', (e) => {
  const row = e.target.closest('.subs-row'); if (!row) return;
  audio.ui();
  SUBS.offPick = parseInt(row.dataset.uid, 10);
  subsRender();
});
$('subs-bench').addEventListener('click', (e) => {
  const row = e.target.closest('.subs-row'); if (!row) return;
  audio.ui();
  SUBS.onPick = parseInt(row.dataset.benchidx, 10);
  subsRender();
});
$('subs-cancel').addEventListener('click', () => { audio.ui(); subsClose(); });
$('btn-p-subs').addEventListener('click', () => { audio.ui(); subsOpen(); });
$('subs-confirm').addEventListener('click', () => {
  if (SUBS.offPick === null || SUBS.onPick === null) return;
  const outgoing = players.find((p) => p.uid === SUBS.offPick);
  const incomingInfo = (benches[0] || [])[SUBS.onPick];
  if (!outgoing || !incomingInfo) return;
  performSubstitution(0, outgoing, incomingInfo);
  incomingInfo._subbedIn = true;
  subsUsed[0]++;
  $('subs-remaining').textContent = 5 - subsUsed[0];
  toast(`🔄 ${incomingInfo.name} replaces ${outgoing.name}`);
  sayPick([`Substitution for ${teamDefs[0].name}: ${incomingInfo.name} comes on for ${outgoing.name}.`]);
  audio.ui();
  subsClose();
});
/* Actually perform the swap: remove the outgoing Player's mesh, spawn a
   fresh Player at the same formation slot/position/role, and repoint
   `controlled` if the human happened to be controlling the player who just
   came off — otherwise the joystick would silently stop affecting anyone. */
function performSubstitution(team, outgoing, incomingInfo) {
  const info = {
    ...incomingInfo,
    role: outgoing.role, fx: outgoing.homeFx, fz: outgoing.homeFz, num: incomingInfo.num,
  };
  const wasControlled = controlled === outgoing;
  const idx = players.indexOf(outgoing);
  scene.remove(outgoing.mesh);
  const fresh = new Player(team, info);
  fresh.pos.copy(outgoing.pos);
  fresh.vel.set(0, 0, 0);
  if (idx >= 0) players[idx] = fresh;
  else players.push(fresh);
  if (wasControlled) controlled = fresh;
  if (controlledP2 === outgoing) controlledP2 = fresh;
  if (ball.owner === outgoing) ball.owner = fresh;
}
$('btn-restart').addEventListener('click', () => {
  match.paused = false; $('scr-pause').classList.add('hidden');
  if (NET.mode !== 'off') { toast("Can't restart a friend match — quit instead."); match.paused = true; $('scr-pause').classList.remove('hidden'); return; }
  if (window.PlayHub && PlayHub.inEvent()) { toast("Can't restart an event match — quit instead."); match.paused = true; $('scr-pause').classList.remove('hidden'); return; }
  startMatch();
});
$('btn-quit').addEventListener('click', () => {
  match.paused = false; $('scr-pause').classList.add('hidden');
  if (NET.mode !== 'off') { rtcSend({ t: 'matchEnd', reason: RM.peerName + ' left the match.' }); netEndMatch('You left the match.'); return; }
  if (window.PlayHub && PlayHub.inEvent()) { PlayHub.abort(); return; }
  enterMenu();
});
$('btn-half').addEventListener('click', () => {
  audio.ui();
  $('scr-half').classList.add('hidden');
  match.half = 2;
  match.kickTeam = 1;
  match.state = 'idle';
  startSetPiece('kickoff', 1, null);
  match.awaitUser = false;
  match.restartTimer = 1.4;
  updateScoreboard();
});
$('btn-rematch').addEventListener('click', () => { audio.ui(); $('scr-full').classList.add('hidden'); if (window.PlayHub && PlayHub.inEvent()) { PlayHub.retryCurrent(); return; } startMatch(); });
$('btn-menu2').addEventListener('click', () => { audio.ui(); $('scr-full').classList.add('hidden'); if (window.PlayHub && PlayHub.inEvent()) { PlayHub.abort(); return; } enterMenu(); });
$('btn-ft-royale').addEventListener('click', () => { audio.ui(); $('scr-full').classList.add('hidden'); enterRoyale(); });
$('rl-back').addEventListener('click', () => { audio.ui(); enterMenu(); });
$('st-back').addEventListener('click', () => { audio.ui(); enterMenu(); });
$('btn-rv-ok').addEventListener('click', (e) => { e.stopPropagation(); closeReveal(); });
$('ov-reveal').addEventListener('click', closeReveal);
// Old spin bindings removed — Luck Royale rebuilt below with real drafts/pools.
function showNoPlayers(reason) {
  $('scr-load').classList.add('hidden');
  const reasonEl = $('none-reason');
  if (reasonEl) reasonEl.textContent = reason || 'Could not reach the player server. Check your connection and try again.';
  $('scr-none').classList.remove('hidden');
}
$('btn-none-retry').addEventListener('click', async () => {
  audio.init();
  audio.ui();
  $('scr-none').classList.add('hidden');
  $('scr-load').classList.remove('hidden');
  setLoadProgress(20, 'RETRYING…');
  let ok = false;
  try { ok = await autoLoadRegistry((s) => setLoadProgress(null, s)); } catch (e) { ok = false; }
  if (ok) {
    dedupeReg();
    setLoadProgress(35, 'BUILDING SQUADS…');
    await buildSquadsFromRegistry();
    spawnTeams();
    await preloadAllGameAssets((pct, tip) => setLoadProgress(pct, null, tip));
    setLoadProgress(100, `✓ ${REG.length} PLAYER${REG.length === 1 ? '' : 'S'} LOADED FROM CLOUD`);
    showTapToStart();
  } else {
    showNoPlayers();
  }
});
// AI assistant is reachable via the floating btn-ai-fab (already shown on the menu screen).
$('btn-ai-fab').addEventListener('click', () => { audio.init(); toggleAI(true); });
$('ai-close').addEventListener('click', () => toggleAI(false));
$('btn-ai-send').addEventListener('click', () => askAI($('ai-input').value));
$('ai-input').addEventListener('keydown', (e) => { if (e.key === 'Enter') askAI($('ai-input').value); });
function buildAIChips() {
  const chips = ['Who is my best player?', 'How many coins do I have?', 'How do I shoot?', 'List my players', 'How do I unlock more players?', 'Tips to win'];
  const wrap = $('ai-chips');
  wrap.innerHTML = '';
  for (const c of chips) {
    const b = document.createElement('button');
    b.className = 'ai-chip';
    b.textContent = c;
    b.addEventListener('click', () => askAI(c));
    wrap.appendChild(b);
  }
}

/* ==========================================================================
   34 · MAIN LOOP
   ========================================================================== */
const clock = new THREE.Clock();
let hudTick = 0;
const reportedFrameErrors = new Set();
function reportFrameError(system, err) {
  // Silent by design: a recoverable render/logic hiccup must never surface raw error text to the player.
  reportedFrameErrors.add(system);
}
function loop() {
  try { if (typeof UAStadium !== 'undefined') UAStadium.update(); } catch (e) { try { UAStadium.fail(e); } catch (e2) {} }
  try {
    loopInner();
  } catch (err) {
    // Last-resort safety net: NOTHING should be able to freeze the game.
    // Log it, self-heal WHATEVER state we're in (not just setpiece — a
    // throw during 'play' used to fall through here and silently freeze
    // every player forever while the referee/camera/crowd kept animating
    // outside this try block), and keep rendering next frame no matter
    // what broke.
    ;
    try {
      if (match && match.screen === 'match') {
        if (match.state === 'goal') endGoalCelebration();
        else if (match.state === 'setpiece') { match.awaitUser = false; match.restartTimer = 0.05; }
        else if (match.state === 'play') {
          // A throw mid-play left player objects in a possibly-inconsistent
          // state (e.g. mid-update when the error hit). Clear locks/actions
          // on every player so the next frame's update() calls can't
          // immediately throw again on the same bad state, and make sure
          // someone is controlled so input has somewhere to go.
          for (const p of players) { p.action = null; p.stunTimer = 0; }
          if (!controlled || controlled.sentOff) controlled = players.find((pl) => pl.team === 0 && !pl.sentOff) || null;
        }
        match.paused = false;
      }
    } catch (err2) { ; }
    try { renderer.render(scene, camera); } catch (err3) {}
  }
}
/* ==========================================================================
   📼 INSTANT REPLAY — continuous ring-buffer recorder of every player's
   position/facing + the ball's position, replayed from a sweeping camera
   after a goal or foul. Fouls/goals are real existing events (onGoal(),
   commitFoul()); no-goal and offside calls hook into this exact same
   replayTrigger() entry point the moment those rules exist — the recorder
   itself doesn't care what triggered it.
   ========================================================================== */
const REPLAY = {
  buffer: [],           // ring buffer of {t, ball:{x,y,z}, players:[{x,z,facing}]}
  bufferSeconds: 8,      // how far back we can always rewind to
  recording: true,
  playing: false,
  playbackFrames: [],
  playIdx: 0,
  playElapsed: 0,
  playSpeed: 0.65,       // slight slow-motion, like a broadcast replay
  camOrbit: 0,
  skipRequested: false,
  pendingGoalFrames: null, // captured at the moment of a goal, played back once the live celebration ends
  afterPlaybackFn: null,   // callback run once replayEnd() fires — used to resume kickoff after a goal replay
};
function replayRecordFrame(dt) {
  if (!REPLAY.recording || !ball || !players.length) return;
  REPLAY.buffer.push({
    t: elapsedT,
    ball: { x: ball.pos.x, y: ball.pos.y, z: ball.pos.z },
    players: players.map((p) => ({ x: p.pos.x, z: p.pos.z, facing: p.facing, team: p.team })),
  });
  const cutoff = elapsedT - REPLAY.bufferSeconds;
  while (REPLAY.buffer.length && REPLAY.buffer[0].t < cutoff) REPLAY.buffer.shift();
}
/* Call this from any event that should trigger a replay (goal, foul, and —
   once built — no-goal/offside). secondsBack is how far into the just-
   recorded buffer to rewind before playing forward again. */
/* Low-level: actually start playback of a given, already-captured frame
   array. Used directly by the deferred goal-replay path (frames captured
   at the moment of the goal, played back once the live celebration ends)
   and indirectly by replayTrigger() below (frames sliced fresh from the
   live ring buffer, for events with no separate "wait for X" step, like
   fouls). */
function replayPlayFrames(frames) {
  if (REPLAY.playing) return;
  if (NET.mode === 'guest') return; // the guest paints from host snapshots; replaying local history here would show the wrong match state
  if (!frames || frames.length < 8) return; // not enough history — skip rather than show a stub replay
  REPLAY.playbackFrames = frames;
  REPLAY.playIdx = 0;
  REPLAY.playElapsed = 0;
  REPLAY.playing = true;
  REPLAY.skipRequested = false;
  REPLAY.camOrbit = rand(0, Math.PI * 2);
  $('ov-replay').classList.remove('hidden');
  $('replay-bar-fill').style.width = '0%';
}
function replayTrigger(secondsBack = 5) {
  if (REPLAY.playing) return; // don't double-trigger if somehow already mid-replay
  if (!settings.instantReplay) return;
  const startT = elapsedT - secondsBack;
  const frames = REPLAY.buffer.filter((f) => f.t >= startT);
  replayPlayFrames(frames);
}
function replayEnd() {
  REPLAY.playing = false;
  $('ov-replay').classList.add('hidden');
  if (REPLAY.afterPlaybackFn) {
    const fn = REPLAY.afterPlaybackFn;
    REPLAY.afterPlaybackFn = null;
    fn();
  }
}
$('replay-skip').addEventListener('click', () => { REPLAY.skipRequested = true; audio.ui(); });
function replayUpdate(rawDt) {
  if (!REPLAY.playing) return;
  if (REPLAY.skipRequested) { replayEnd(); return; }
  REPLAY.playElapsed += rawDt * REPLAY.playSpeed;
  const frames = REPLAY.playbackFrames;
  const totalSpan = frames[frames.length - 1].t - frames[0].t;
  if (totalSpan <= 0) { replayEnd(); return; }
  const targetT = frames[0].t + REPLAY.playElapsed;
  $('replay-bar-fill').style.width = clamp01(REPLAY.playElapsed / totalSpan) * 100 + '%';
  if (targetT >= frames[frames.length - 1].t) { replayEnd(); return; }
  // Advance playIdx to the frame pair straddling targetT, then lerp between them.
  while (REPLAY.playIdx < frames.length - 2 && frames[REPLAY.playIdx + 1].t < targetT) REPLAY.playIdx++;
  const fa = frames[REPLAY.playIdx], fb = frames[REPLAY.playIdx + 1] || fa;
  const span = Math.max(1e-4, fb.t - fa.t);
  const lt = clamp01((targetT - fa.t) / span);
  if (ball) {
    ball.pos.set(lerp(fa.ball.x, fb.ball.x, lt), lerp(fa.ball.y, fb.ball.y, lt), lerp(fa.ball.z, fb.ball.z, lt));
  }
  for (let i = 0; i < players.length && i < fa.players.length; i++) {
    const p = players[i], pa = fa.players[i], pb = fb.players[i] || pa;
    p.pos.x = lerp(pa.x, pb.x, lt);
    p.pos.z = lerp(pa.z, pb.z, lt);
    p.facing = pa.facing; // snap facing rather than lerp across the wrap-around angle — smoother than fighting -π/π seams
    p.mesh.rotation.y = p.facing;
    p.updateAnimOnly(0.001); // tiny nonzero dt so run-cycle animation keeps a subtle pulse rather than freezing mid-pose
  }
  // Sweeping orbit camera around the ball for the replay, independent of
  // whatever camera mode the player normally uses.
  REPLAY.camOrbit += rawDt * 0.5;
  const r = 9, camH = 4.2;
  camera.position.set(ball.pos.x + Math.cos(REPLAY.camOrbit) * r, camH, ball.pos.z + Math.sin(REPLAY.camOrbit) * r);
  camera.lookAt(ball.pos.x, 1.0, ball.pos.z);
}

function loopInner() {
  const rawDt = Math.min(clock.getDelta(), 0.05);
  elapsedT += rawDt;
  pollKeyboard();
  pollGamepad();
  flickCd = Math.max(0, flickCd - rawDt);
  updateFPS();
  if (match.screen === 'match') watchdogTick(rawDt);
  if (match.screen === 'match' && !match.paused) {
    const dt = rawDt * match.timeScale;
    if (input.charging) {
      input.power = Math.min(1, input.power + rawDt * 0.85);
      $('power-fill').style.height = (input.power * 100) + '%';
    }
    updateMatchFlow(NET.mode === 'guest' || REPLAY.playing ? 0 : rawDt);
    if (!REPLAY.playing && !match.walkout && (match.state === 'play' || match.state === 'setpiece' || match.state === 'goal')) {
      // Each system below is isolated in its own try/catch. Previously a
      // throw in ANY one of these (AI, ball physics, officials, etc.)
      // aborted the whole frame — including updateControlled and the
      // players' own p.update(dt), which is why a crash anywhere in this
      // block could look exactly like "joystick/buttons do nothing,
      // only the referee moves": officials are rendered independently
      // and kept animating while player movement silently stopped
      // updating every single frame after the first throw.
      //
      // NET.mode === 'guest': none of this runs. The guest's ball/player
      // positions come entirely from host snapshots (netGuestApplySnapshot)
      // — running physics here too would fight those snapshots and diverge
      // within a second or two. The guest still animates cosmetically below.
      if (NET.mode !== 'guest') {
        if (match.state === 'setpiece') { try { enforceSetPieceLaws(dt); } catch (e) { reportFrameError('enforceSetPieceLaws', e); } }
        try { updateControlled(dt); } catch (e) { reportFrameError('updateControlled', e); }
        if (NET.mode === 'host') { try { updateControlledP2(dt); } catch (e) { reportFrameError('updateControlledP2', e); } }
        try { aiUpdate(dt); } catch (e) { reportFrameError('aiUpdate', e); }
        for (const p of players) { try { p.update(dt); } catch (e) { reportFrameError('player.update:' + p.name, e); } }
        try { updateBall(dt); } catch (e) { reportFrameError('updateBall', e); }
        try { updateOfficials(dt); } catch (e) { reportFrameError('updateOfficials', e); }
        if (match.state === 'play') { try { autoSwitchIfNeeded(); } catch (e) { reportFrameError('autoSwitchIfNeeded', e); } }
        try { replayRecordFrame(rawDt); } catch (e) {}
      } else {
        for (const p of players) { try { p.updateAnimOnly(dt); } catch (e) { reportFrameError('player.updateAnimOnly:' + p.name, e); } }
        try { updateTrail(); } catch (e) {}
      }
    }
    if (confetti) confetti.update(dt);
    if (grassFx) grassFx.update(dt);
    if (sparkFx) sparkFx.update(dt);
    switchCooldown = Math.max(0, switchCooldown - rawDt);
    match.autoSwitchGraceT = Math.max(0, (match.autoSwitchGraceT || 0) - rawDt);
    if (NET.mode === 'host') {
      NET.lastSnapT += rawDt;
      const snapInterval = 1 / NET.snapHz;
      if (NET.lastSnapT >= snapInterval) {
        NET.lastSnapT = 0;
        try { rtcSend(netBuildSnapshot()); } catch (e) { /* data channel hiccup, next tick will retry */ }
      }
    } else if (NET.mode === 'guest') {
      try { rtcSend({ t: 'input', mx: input.mx, my: input.my, sprint: input.sprint }); } catch (e) {}
    }
    for (const m of scrollAdMats) if (m.map) m.map.offset.x = (m.map.offset.x + rawDt * 0.03) % 1;
    for (const f of waveFlags) f.rotation.y = S(elapsedT * 3 + f.position.x * 0.3) * 0.35;
    for (const ct of crowdTiers) ct.m.position.y = ct.base + S(elapsedT * 2.2 + ct.ph) * 0.1;
    if (netShake > 0) {
      const net = backNets[netShakeSide];
      if (net) net.position.x = net.userData.baseX + S(elapsedT * 38) * 0.1 * netShake;
      netShake = Math.max(0, netShake - rawDt * 0.8);
    }
    if (trailPoints) {
      if (perfectTrailT > 0) { trailPoints.material.color.set('#ffc400'); perfectTrailT -= rawDt; }
      else if (curlTrailT > 0) { trailPoints.material.color.set('#ff7be0'); curlTrailT -= rawDt; }
      else trailPoints.material.color.set('#9ff3ff');
    }
    crowdTimer += rawDt;
    if (crowdTimer > 0.5) {
      crowdTimer = 0;
      const tension = ball && ball.pos.x > 20 && match.state === 'play';
      audio.setCrowd(tension);
    }
    flashTimer -= rawDt;
    if (flashTimer <= 0) {
      flashTimer = rand(0.5, 1.3);
      emitSpark(rand(-70, 70), rand(8, 22), pick([-1, 1]) * (FIELD.halfWid + rand(16, 24)), 3);
    }
    bsTimer += rawDt;
    if (bsTimer > 1) { bsTimer = 0; drawBigScreen(); }
    hudTick += rawDt;
    if (hudTick > 0.12) {
      hudTick = 0;
      updateScoreboard();
      updateStaminaBar();
      updatePossBar();
      updateChainUI();
      drawMinimap();
      refreshButtons();
    }
    updateCommentary(rawDt);
    updateToast(rawDt);
    updateOwnerTag();
  }
  if (REPLAY.playing) {
    try { replayUpdate(rawDt); } catch (e) { replayEnd(); }
  } else {
    updateCamera(rawDt);
  }
  renderer.render(scene, camera);
}

/* ==========================================================================
   35 · RESIZE + BOOT
   ========================================================================== */
window.addEventListener('resize', () => {
  const vp = getGameViewportSize();
  camera.aspect = vp.w / vp.h;
  camera.updateProjectionMatrix();
  renderer.setSize(vp.w, vp.h);
});
window.addEventListener('pointerdown', () => { audio.init(); audio.resume(); });
document.addEventListener('contextmenu', (e) => e.preventDefault());
const LOAD_TIPS = [
  'HOLD SHOOT — RELEASE IN THE GREEN ZONE FOR A PERFECT POWER SHOT…',
  'SWIPE ▲ ON SHOOT = CHIP · SWIPE ◀ = CURL…',
  'HIGH BALL COMING? PRESS SHOOT FOR A BICYCLE KICK…',
  'FLICK THE STICK WHILE DRIBBLING = SKILL MOVE…',
  'BUILD AN 8 CHAIN TO GO ON FIRE 🔥…',
  'DOUBLE-TAP RUN FOR A SPEED BURST…',
  'ASK THE 🤖 AI ANYTHING ABOUT YOUR PLAYERS…',
  'WIN MATCHES TO EARN COINS FOR LUCK ROYALE…',
  'THERE ARE 28 CELEBRATIONS — SCORE TO SEE THEM ALL…',
  'TRY THE FIRST-PERSON CAMERA FOR FULL IMMERSION…',
];
/* ==========================================================================
   ☁️ ACCOUNT SYSTEM v2 — built from scratch, fully self-contained.
   - ob-*   : first-launch 3-step onboarding wizard (create/sign-in)
   - acc-*  : persistent post-onboarding account panel
   Design choices that specifically avoid the previous "stuck" bug:
     1. Exactly ONE place resolves the initial session (resolveAuthOnce),
        guarded by a boolean so it can never run twice.
     2. onAuthStateChange is used ONLY for events after boot (real sign-in/
        sign-out button presses) — it explicitly ignores INITIAL_SESSION.
     3. Every async handler is wrapped so a network failure always
        re-enables its button and shows an error, never leaves the UI
        frozen mid-request.
   ========================================================================== */
let obPendingEmail = '';
let obPendingPassword = '';

function busy(btn, isBusy, labelWhenBusy) {
  if (!btn) return;
  if (isBusy) {
    btn.dataset.origHtml = btn.innerHTML;
    btn.disabled = true;
    btn.innerHTML = `<span>${labelWhenBusy || 'Working…'}</span>`;
  } else {
    btn.disabled = false;
    if (btn.dataset.origHtml) btn.innerHTML = btn.dataset.origHtml;
  }
}
function obShowError(stepId, msg) {
  const el = $('ob-error-' + stepId);
  if (!el) return;
  el.textContent = msg;
  el.classList.add('show');
}
function obClearError(stepId) {
  const el = $('ob-error-' + stepId);
  if (el) el.classList.remove('show');
}
function humanizeAuthErr(err) {
  const msg = (err && err.message) || '';
  if (/invalid login credentials/i.test(msg)) return 'Incorrect email or password.';
  if (/already registered/i.test(msg)) return 'An account with this email already exists — try signing in instead.';
  if (/rate limit/i.test(msg)) return 'Too many attempts. Please wait a moment and try again.';
  if (/password/i.test(msg) && /6/.test(msg)) return 'Password must be at least 6 characters.';
  return 'Something went wrong. Please try again.';
}

/* ---------- onboarding wizard: step navigation ---------- */
function obGoToStep(n) {
  ['1', 'signin', '2', '3'].forEach((s) => $('ob-step-' + s).classList.add('hidden'));
  $('ob-step-' + n).classList.remove('hidden');
  if (n === '1' || n === '2' || n === '3') {
    $('ob-steps-fill').style.width = (n === '1' ? 33.3 : n === '2' ? 66.6 : 100) + '%';
    $('ob-step-n').textContent = n;
    $('ob-step-label').style.display = '';
  } else {
    $('ob-step-label').style.display = 'none';
  }
}
function openOnboarding() { $('ob-backdrop').classList.remove('hidden'); obGoToStep('1'); }
function closeOnboarding() { $('ob-backdrop').classList.add('hidden'); }

// STEP 1 -> 2: create the Supabase auth user (email + password), then
// move straight to the profile step without waiting on email confirmation.
$('ob-next-1').addEventListener('click', async () => {
  obClearError('1');
  const email = $('ob-email').value.trim();
  const password = $('ob-password').value;
  if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) { obShowError('1', 'Please enter a valid email address.'); return; }
  if (!password || password.length < 6) { obShowError('1', 'Password must be at least 6 characters.'); return; }

  const btn = $('ob-next-1');
  busy(btn, true, 'Creating…');
  try {
    const { data, error } = await sb.auth.signUp({ email, password });
    if (error) throw error;
    obPendingEmail = email;
    obPendingPassword = password;
    cloudUser = data.user || (data.session && data.session.user) || null;
    obGoToStep('2');
  } catch (err) {
    obShowError('1', humanizeAuthErr(err));
  } finally {
    busy(btn, false);
  }
});
$('ob-skip-1').addEventListener('click', () => {
  audio.ui();
  closeOnboarding();
  try { localStorage.setItem('uafc-guest-onboarded', '1'); } catch (e) {}
});
$('ob-goto-signin').addEventListener('click', () => obGoToStep('signin'));
$('ob-back-to-create').addEventListener('click', () => obGoToStep('1'));

$('ob-signin-btn').addEventListener('click', async () => {
  obClearError('signin');
  const email = $('ob-si-email').value.trim();
  const password = $('ob-si-password').value;
  if (!email || !password) { obShowError('signin', 'Please enter both email and password.'); return; }

  const btn = $('ob-signin-btn');
  busy(btn, true, 'Signing in…');
  try {
    const { error } = await sb.auth.signInWithPassword({ email, password });
    if (error) throw error;
    // A returning user who signs in here already has a profile — skip
    // straight to the success screen instead of asking for a username again.
    cloudUser = (await sb.auth.getUser()).data.user;
    const { data: profile } = await sb.from('profiles').select('*').eq('id', cloudUser.id).maybeSingle();
    cloudProfile = profile;
    $('ob-success-msg').textContent = `Welcome back, ${(profile && (profile.display_name || profile.username)) || 'Player'}!`;
    $('ob-finish').querySelector('span').textContent = 'Continue';
    obGoToStep('3');
    await refreshAccPanel();
  } catch (err) {
    obShowError('signin', humanizeAuthErr(err));
  } finally {
    busy(btn, false);
  }
});

// STEP 2 -> 3: set username + display name on the profile row that was
// auto-created by the signup trigger, then show the success screen.
$('ob-next-2').addEventListener('click', async () => {
  obClearError('2');
  const username = $('ob-username').value.trim();
  const displayName = $('ob-displayname').value.trim();
  if (!username || username.length < 3) { obShowError('2', 'Username must be at least 3 characters.'); return; }
  if (!/^[a-zA-Z0-9_]+$/.test(username)) { obShowError('2', 'Username can only contain letters, numbers, and underscores.'); return; }

  const btn = $('ob-next-2');
  busy(btn, true, 'Saving…');
  try {
    if (!cloudUser) {
      // Session wasn't established yet (e.g. email confirmation still on) —
      // sign in explicitly with the credentials from step 1 to get one.
      const { data, error } = await sb.auth.signInWithPassword({ email: obPendingEmail, password: obPendingPassword });
      if (error) throw error;
      cloudUser = data.user;
    }
    const { error: upErr } = await sb.from('profiles').update({
      username, display_name: displayName || username,
    }).eq('id', cloudUser.id);
    if (upErr) throw upErr;

    const { data: profile } = await sb.from('profiles').select('*').eq('id', cloudUser.id).maybeSingle();
    cloudProfile = profile;
    $('ob-success-msg').textContent = `Welcome, ${displayName || username}! Your account is ready.`;
    obGoToStep('3');
    await refreshAccPanel();
  } catch (err) {
    obShowError('2', humanizeAuthErr(err));
  } finally {
    busy(btn, false);
  }
});

// STEP 3: finish -> tear the whole onboarding UI down for good.
$('ob-finish').addEventListener('click', async () => {
  audio.ui();
  closeOnboarding();
  toast('Signed in!');
  const pulled = await pullCloudState();
  if (pulled) toast('Cloud save restored!');
  await grantDailyBonusIfDue();
  frStartPresenceHeartbeat();
  frSubscribeRealtime();
  frLoadAll();
});

/* ---------- account panel (post-onboarding) ---------- */
function openAccPanel() { $('acc-backdrop').classList.remove('hidden'); refreshAccPanel(); }
function closeAccPanel() { $('acc-backdrop').classList.add('hidden'); }
$('btn-profile-chip').addEventListener('click', () => {
  audio.ui();
  if (cloudUser) openAccPanel();
  else openOnboarding();
});
$('acc-close').addEventListener('click', closeAccPanel);
$('acc-backdrop').addEventListener('click', (e) => { if (e.target === $('acc-backdrop')) closeAccPanel(); });
$('acc-signout-btn').addEventListener('click', async () => {
  const btn = $('acc-signout-btn');
  busy(btn, true, 'Signing out…');
  try { await sb.auth.signOut(); } catch (err) { ; }
  cloudUser = null;
  cloudProfile = null;
  unlockedAchievements = new Set();
  achievementsLoaded = false;
  achLoadedForUser = null;
  closeAccPanel();
  updateAccPill();
  busy(btn, false);
});
$('acc-sync-now').addEventListener('click', async () => {
  const btn = $('acc-sync-now');
  busy(btn, true, '…');
  await pushCloudState();
  busy(btn, false);
  toast('Synced!');
});
$('acc-trophy-btn').addEventListener('click', () => {
  if (!cloudUser) { toast('Sign in to track achievements.'); return; }
  audio.ui();
  closeAccPanel();
  match.screen = 'menu';
  match.state = 'idle';
  showScreen('scr-trophy');
  renderTrophyCabinet();
});
$('trophy-back').addEventListener('click', () => { audio.ui(); enterMenu(); showScreen('scr-main'); });

function updateAccPill() {
  updateHubTopbar();
}

async function refreshAccPanel() {
  if (!cloudUser) return;
  updateAccPill();
  if (!achievementsLoaded || achLoadedForUser !== cloudUser.id) { achLoadedForUser = cloudUser.id; loadAchievements(); }
  const label = (cloudProfile && (cloudProfile.display_name || cloudProfile.username)) || cloudUser.email.split('@')[0];
  $('acc-avatar').textContent = (label || '?').charAt(0).toUpperCase();
  $('acc-name').textContent = label;
  $('acc-email-label').textContent = cloudUser.email || '';
  $('acc-stat-coins').textContent = settings.infMoney ? '∞' : coins;
  updateSyncStatusUI(true);

  try {
    const { data } = await sb.from('match_history').select('result').eq('user_id', cloudUser.id);
    if (data) {
      const total = data.length;
      const wins = data.filter((m) => m.result === 'win').length;
      $('acc-stat-matches').textContent = total;
      $('acc-stat-wr').textContent = total ? Math.round((wins / total) * 100) + '%' : '—';
    }
  } catch (err) { /* non-fatal */ }

  const listEl = $('acc-history-list');
  try {
    const { data, error } = await sb
      .from('match_history')
      .select('opponent_name, user_score, opponent_score, result, coins_earned, played_at')
      .eq('user_id', cloudUser.id)
      .order('played_at', { ascending: false })
      .limit(8);
    if (error) throw error;
    if (!data || !data.length) {
      listEl.innerHTML = '<div class="acc-history-empty">No matches played yet.</div>';
    } else {
      listEl.innerHTML = data.map((m) => {
        const when = new Date(m.played_at);
        const dateStr = when.toLocaleDateString([], { month: 'short', day: 'numeric' });
        return `<div class="acc-hist-row">
          <div class="ahr-left"><span class="ahr-result ${m.result}"></span>${m.user_score}-${m.opponent_score}<span class="ahr-opp">vs ${escHtml(m.opponent_name)}</span></div>
          <div class="ahr-right"><span>${dateStr}</span><span class="ahr-coins">+${m.coins_earned}</span></div>
        </div>`;
      }).join('');
    }
  } catch (err) {
    listEl.innerHTML = '<div class="acc-history-empty">Couldn\'t load match history.</div>';
  }
}
function escHtml(s) {
  return String(s || '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}
function updateSyncStatusUI(ok) {
  const el = $('acc-sync-status');
  if (!el) return;
  if (!cloudUser) { el.textContent = ''; return; }
  el.textContent = ok ? 'Synced ✓' : 'Sync pending…';
  el.style.color = ok ? '' : '#ffc93c';
}

/* ---------- one-shot session resolution: runs exactly once on boot ---------- */
let authResolved = false;
async function resolveAuthOnce() {
  if (authResolved) return; // hard guard — this function can never run twice
  authResolved = true;
  try {
    const { data } = await sb.auth.getSession();
    if (data.session) {
      cloudUser = data.session.user;
      const { data: profile } = await sb.from('profiles').select('*').eq('id', cloudUser.id).maybeSingle();
      cloudProfile = profile;
      await refreshGemsBalance();
      updateAccPill();
      const pulled = await pullCloudState();
      if (pulled) ;
      await grantDailyBonusIfDue();
      frStartPresenceHeartbeat();
      frSubscribeRealtime();
      frLoadAll();
      leagueMarkDailyLogin();
    } else {
      updateAccPill();
      // First-ever launch on this device (no session, never skipped guest before) -> show onboarding.
      let alreadyOnboarded = false;
      try { alreadyOnboarded = localStorage.getItem('uafc-guest-onboarded') === '1'; } catch (e) {}
      if (!alreadyOnboarded) {
        setTimeout(openOnboarding, 400); // small delay so it appears after the load screen settles
      }
    }
  } catch (err) {
    ;
    updateAccPill();
  }
}
// Real auth changes AFTER boot (explicit sign-in/out button presses) are
// handled directly by their own button handlers above — this listener only
// catches sign-outs triggered from elsewhere (e.g. token expiry).
sb.auth.onAuthStateChange((event, session) => {
  if (!authResolved) return; // ignore anything before resolveAuthOnce has run
  if (event === 'SIGNED_OUT' && cloudUser) {
    frTouchPresence('offline').finally(() => {
      cloudUser = null;
      cloudProfile = null;
      unlockedAchievements = new Set();
      achievementsLoaded = false;
      achLoadedForUser = null;
      updateAccPill();
      FR.channel?.unsubscribe(); FR.channel = null;
      clearInterval(FR.presenceHeartbeat); FR.presenceHeartbeat = null;
    });
  }
});

/* ==========================================================================
   👥 FRIENDS + WEBRTC — full social layer.
   -------------------------------------------------------------------------
   DB tables (public, RLS-scoped to the two participants):
     friendships   : requester_id, addressee_id, status(pending/accepted/declined/blocked)
     user_presence : user_id, status(online/offline/in_match), last_seen
     match_rooms   : host_id, guest_id, status, offer_sdp, answer_sdp,
                     host_ice[], guest_ice[]  -> WebRTC signaling handshake

   Flow:
     1. Friends button -> scr-friends (list / requests / add-by-uid-or-name)
     2. Realtime subscriptions keep the list, requests, and online dots live
        without polling.
     3. Presence: heartbeat every 20s while a session exists + on visibility
        change; other clients see it instantly via postgres_changes.
     4. Challenge: creates a match_rooms row (status 'pending'). Guest sees
        an incoming challenge modal live via realtime. On accept, both sides
        run the WebRTC offer/answer/ICE exchange through that same row, and
        a live RTCDataChannel opens between the two devices directly (peer-
        to-peer — no game traffic touches Supabase once connected; it's used
        purely for the initial signaling handshake, which is what it's for).
   ========================================================================== */

async function boot() {
  try {
    // Fetch admin-managed home banners in parallel with everything else so
    // the loading screen's background can update as soon as possible.
    homeBannersLoaded = true;
    const homeBannersPromise = loadHomeBanners();
    loadActivitiesReadState();
    const activitiesPromise = loadActivities(); // fetch in background so the unread badge is accurate before the player ever opens the screen
    // Resolve any existing Supabase session first so cloud coins/vault/settings
    // are restored before squads are generated from them. resolveAuthOnce is
    // guarded to run exactly once, ever — see its definition above.
    await resolveAuthOnce();
    // Always boot with a clean multiplayer slate — a reload/crash mid
    // connection attempt is the one case nothing else guards, and starting
    // up with a phantom RM.roomId/pc would misroute the first real attempt.
    roomHide();
    roomCleanup();
    applyCtlScale();
    bindSettingsUI();
    buildAIChips();
    aiAddMsg('Welcome to <b>UA FC MOBILE</b>! 👋 Ask me about your players, coins, controls, cameras or awards.', 'bot');
    initThree();

    // The player model is now a real GLB (Universal_Player_Model.glb, ~9.6MB)
    // instead of procedural geometry, so it has to actually finish
    // downloading and parsing before ANY player mesh can be built —
    // createOfficials() below builds the ref/linesman via buildPlayerModel()
    // and spawnTeams() builds all 22 players, so this await must land
    // strictly before both, which it does since it's placed right here.
    // loadPlayerModelTemplate() is itself guarded to run its network fetch
    // exactly once (see its definition) — safe to call again on retry.
    setLoadProgress(2, 'LOADING PLAYER MODEL…');
    await loadPlayerModelTemplate();

    teamDefs = [TEAMS[settings.homeTeam], TEAMS[settings.awayTeam]];
    applyLockerKitToHomeTeam();
    // Fixed match kit colors: Team 1 (home) always plays in black, Team 2
    // (away) always plays in white, overriding both teams' own TEAMS[]
    // colors and any locker-room customization above. Shorts (c2) match
    // the shirt here since only a single "team color" was asked for; split
    // c1/c2 again later if shirt/shorts should differ.
    teamDefs[0].c1 = '#000000'; teamDefs[0].c2 = '#000000';
    teamDefs[1].c1 = '#ffffff'; teamDefs[1].c2 = '#ffffff';
    squads = [generateSquad(teamDefs[0]), generateSquad(teamDefs[1])];
  benches = [generateBench(teamDefs[0]), generateBench(teamDefs[1])];
  subsUsed = [0, 0];
    addSceneLights();
    buildStadium();
    createBall();
    createParticles();
    createIndicator();
    createOfficials();
    renderer.setAnimationLoop(loop);

    setLoadProgress(5, 'CONNECTING TO PLAYER SERVER…');
    let found = false;
    try {
      found = await autoLoadRegistry((s) => setLoadProgress(null, s));
    } catch (e) { found = false; }
    if (!found) {
      showNoPlayers();
      return;
    }
    setLoadProgress(35, 'BUILDING SQUADS…');
    await buildSquadsFromRegistry();
    spawnTeams();
    updateCoinUI();

    // Wait for the loading-screen banner (kicked off above) before starting
    // the asset-preload phase, so it's ready to be preloaded alongside
    // everything else rather than racing it separately.
    await homeBannersPromise;

    // ---- PRELOAD PHASE: every card texture except GIFs, so nothing needs
    // to load again later in the session (Royale, market, club, exchange
    // all reuse these same cached images). ----
    await preloadAllGameAssets((pct, tip) => setLoadProgress(pct, null, tip));

    setLoadProgress(100, `✓ ${REG.length} PLAYER${REG.length === 1 ? '' : 'S'} LOADED FROM CLOUD`);
    showTapToStart();
  } catch (err) {
    showLoadFailure();
    ;
  }
}
/* ==========================================================================
   LOADING SCREEN — progress helper + full asset preloader.

   boot() starts running the instant the page loads, in the background,
   WHILE the opening splash/video is still covering the screen — so by the
   time the loading screen actually becomes visible, real progress might
   already be at 70%+. Showing that as a jump-cut would look broken, so
   the displayed bar is decoupled from the true progress: it always starts
   its own animation from 0% and catches up to the real value quickly
   (never jumping backwards, never stalling if real progress is ahead).
   ========================================================================== */
let _loadTrueProgress = 0;   // the real, underlying progress (0-100)
let _loadShownProgress = 0;  // what's currently animated on screen (0-100)
let _loadCatchupRAF = null;
let _loadScreenRevealed = false; // becomes true once the splash/video is dismissed

const LOAD_STAGES = [
  { from: 0,  label: 'INITIALIZING' },
  { from: 15, label: 'LOADING ASSETS' },
  { from: 60, label: 'BUILDING STADIUM' },
  { from: 100, label: 'READY' },
];
const LD_TIPS = [
  'Tip: hold sprint to burst past defenders.',
  'Tip: charge a shot for power — release at the green zone for a perfect strike.',
  'Tip: swap your controlled player quickly when the ball is loose.',
  'Tip: build your Club formation to boost your squad rating.',
  'Tip: claim your Bonus and Mail rewards before every match day.',
  'Tip: weather and time of day change the stadium atmosphere in Settings.',
  'Tip: set your best penalty taker in Team Editing.',
  'Tip: clean sheets and comebacks earn bonus coins.',
];
let _loadStageIdx = -1, _loadTipTimer = null, _loadTipI = 0;
function _loadApplyStage(shown) {
  let idx = 0;
  for (let i = 0; i < LOAD_STAGES.length; i++) if (shown >= LOAD_STAGES[i].from) idx = i;
  if (idx === _loadStageIdx) return;
  _loadStageIdx = idx;
  const st = $('load-status'); if (st) st.textContent = LOAD_STAGES[idx].label;
  document.querySelectorAll('#scr-load .ld-step').forEach((el, i) => {
    el.classList.toggle('done', i < idx);
    el.classList.toggle('on', i === idx);
  });
}
function _loadStartTips() {
  if (_loadTipTimer) return;
  _loadTipI = Math.floor(Math.random() * LD_TIPS.length);
  const tip = $('load-tip'); if (tip) tip.textContent = LD_TIPS[_loadTipI];
  _loadTipTimer = setInterval(() => {
    const scr = $('scr-load'), el = $('load-tip');
    if (!scr || !el || scr.classList.contains('hidden')) { clearInterval(_loadTipTimer); _loadTipTimer = null; return; }
    el.classList.add('swap');
    setTimeout(() => { _loadTipI = (_loadTipI + 1) % LD_TIPS.length; el.textContent = LD_TIPS[_loadTipI]; el.classList.remove('swap'); }, 350);
  }, 3600);
}
function showLoadFailure() {
  const scr = $('scr-load'); if (scr) scr.classList.add('ld-failed');
  const st = $('load-status'); if (st) st.textContent = 'CONNECTION PROBLEM';
  const tip = $('load-tip'); if (tip) tip.textContent = 'Check your internet connection and try again.';
  const btn = $('btn-tap-start');
  if (btn) { btn.textContent = 'RETRY'; btn.classList.remove('hidden'); btn.onclick = () => location.reload(); }
}
function _loadTickCatchup() {
  // Animate the shown bar toward the true value at a fast, fixed rate —
  // fast enough to feel snappy, slow enough to still read as "loading"
  // rather than teleporting.
  const gap = _loadTrueProgress - _loadShownProgress;
  if (Math.abs(gap) < 0.15) {
    _loadShownProgress = _loadTrueProgress;
  } else {
    _loadShownProgress += gap * 0.18; // ease toward target each frame
  }
  $('load-bar').style.width = _loadShownProgress + '%';
  $('load-pct').textContent = Math.round(_loadShownProgress) + '%';
  _loadApplyStage(_loadShownProgress);
  if (_loadShownProgress < _loadTrueProgress - 0.15 || _loadShownProgress < 99.9) {
    _loadCatchupRAF = requestAnimationFrame(_loadTickCatchup);
  } else {
    _loadCatchupRAF = null;
  }
}
function _loadStartCatchup() {
  if (_loadCatchupRAF != null) return; // already animating
  _loadCatchupRAF = requestAnimationFrame(_loadTickCatchup);
}
/* Call this the moment the loading screen actually becomes visible to the
   viewer (splash/video dismissed). Resets the displayed bar to 0% so the
   catch-up animation always has a visible run-up, even if real loading
   finished loading while the video was still playing. */
function revealLoadingScreen() {
  _loadScreenRevealed = true;
  _loadShownProgress = 0;
  _loadStageIdx = -1;
  _loadApplyStage(0);
  _loadStartTips();
  $('load-bar').style.width = '0%';
  $('load-pct').textContent = '0%';
  _loadStartCatchup();
}
function setLoadProgress(pct, status, tip) {
  if (pct != null) {
    _loadTrueProgress = clamp(pct, 0, 100);
    if (_loadScreenRevealed) _loadStartCatchup();
    else { _loadShownProgress = _loadTrueProgress; } // not visible yet — no need to animate, just track it
  }
  // status/tip arguments are intentionally ignored: players only see the clean stage labels above.
  if (!_loadScreenRevealed) _loadApplyStage(_loadShownProgress);
}
/* Full-registry preload REMOVED: it downloaded every card image on every
   launch (the main source of Supabase cached egress). Kept as a no-op so the
   boot and retry call sites still work. Images now load only when a screen
   shows them, and sw.js keeps each file on the device after the first download. */
function preloadAllGameAssets(onProgress) {
  if (onProgress) onProgress(95, 'FINALIZING…');
  return Promise.resolve();
}
function showTapToStart() {
  const btn = $('btn-tap-start');
  btn.classList.remove('hidden');
  audio.ui();
  const onTap = () => {
    btn.removeEventListener('click', onTap);
    audio.init();
    audio.ui();
    btn.classList.add('hidden');
    $('scr-load').classList.add('hidden');
    enterMenu();
  };
  btn.addEventListener('click', onTap);
}
/* ==========================================================================
   🛡 LEAGUES — social guild system. Up to 20 players per league, custom
   name/crest, shared quest board earning shared League Points, group
   milestone rewards (10 -> 5000 pts), 30-day season (points/rank reset,
   the league itself persists), member list, and live league chat.

   Supabase tables (create in the same project as everything else):
     leagues          : id, name, photo_path, owner_id, member_count,
                         season_started_at, points, created_at
     league_members   : id, league_id, user_id, joined_at
     league_progress  : id, league_id, user_id, quest_key, progress, season_started_at
                         (per-player per-quest counters for the CURRENT season only)
     league_milestones_claimed : id, league_id, season_started_at, milestone_pts
                         (marks a milestone as already paid out this season,
                         so the reward is granted exactly once per league/season)
     league_chat       : id, league_id, user_id, display_name, body, created_at

   Storage bucket: 'league-media' (public), same pattern as player-media /
   draft-media / box-media buckets already used elsewhere in this app.
   ========================================================================== */
const LEAGUE_MEDIA_BUCKET = 'league-media';
const LEAGUE_MAX_MEMBERS = 20;
const LEAGUE_SEASON_DAYS = 30;

// Quest board — shared by the whole league. Every member's progress on a
// quest adds to one league-wide counter per quest per season. Built from
// stats this game already tracks (trackStat/onGoal/commitFoul/match_history)
// so nothing needs a new tracking system, just hooks into the existing ones.

/* ==========================================================================
   BOOT — entry point. Must run after utils.js, cloud.js, game.js, mainui.js
   are all loaded (classic scripts share one global scope, so load order
   matters — see game.html: utils -> cloud -> game -> mainui).
   ========================================================================== */
// If the opening splash/video was already dismissed before this script
// finished loading (edge case — normally the ~10s video gives plenty of
// time), catch up immediately instead of waiting for a dismiss event that
// already happened.
if (window._openingDismissedAt) revealLoadingScreen();
boot();
window._gameBooted = true;
setInterval(() => {
  if (match.screen === 'match' && match.state === 'play' && Math.random() < 0.25) audio.chant();
}, 9000);
;
;
