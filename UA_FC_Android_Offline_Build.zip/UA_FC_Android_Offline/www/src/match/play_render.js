/* ==========================================================================
   play_render.js — shared EVENT PAGE renderer.
   Used by the game (play.js) AND inlined into UA FC MANAGER so the editor
   preview is drawn by the exact same code players see.
   Pure functions: data in -> HTML string out. No DOM access, no globals.
   ========================================================================== */
(function (root) {
  'use strict';

  const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const col = (c, d) => (/^#[0-9a-f]{3,8}$/i.test(c || '') ? c : d);
  const num = (v, d) => (Number.isFinite(+v) ? +v : d);
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  const cssUrl = (u) => (u ? `background-image:url('${String(u).replace(/['"<>\\]/g, (c) => '%' + c.charCodeAt(0).toString(16).toUpperCase())}');` : '');

  const ICON = {
    back: '<svg viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="3.2" stroke-linecap="round" stroke-linejoin="round"><path d="M15 5l-7 7 7 7"/></svg>',
    clock: '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10.5" fill="#fff"/><path d="M12 6.2V12l4 2.4" stroke="#171236" stroke-width="2.6" fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg>',
    lock: '<svg viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><rect x="4.5" y="10.5" width="15" height="10" rx="2.4" fill="#e8c46a" stroke="#e8c46a"/><path d="M8 10.5V8a4 4 0 018 0v2.5" stroke="#e8c46a"/><circle cx="12" cy="15.4" r="1.5" fill="#6b4c0a" stroke="none"/></svg>',
    check: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3.8" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12.5l4.6 4.6L19 7.4"/></svg>',
  };
  const DIFF = ['AMATEUR', 'PRO', 'LEGEND', 'TRASH', 'GOD MODE'];
  const OBJ = {
    win: () => 'Win the match', no_loss: () => "Don't lose", score_goals: (v) => `Score ${v}+ goals`, clean_sheet: () => 'Win with a clean sheet',
    win_margin: (v) => `Win by ${v}+ goals`, concede_max: (v) => (v === 0 ? 'Concede no goals' : `Concede ${v} or fewer`),
  };
  const objective = (s) => (OBJ[s.win_condition] || OBJ.win)(Math.trunc(num(s.win_value, 1)));
  const cap = (s) => { s = String(s || ''); return s.charAt(0).toUpperCase() + s.slice(1); };

  function chips(s) {
    const out = [{ t: `${s.match_minutes} min` }];
    if (s.start_minute > 0) out.push({ t: `Kick-off ${s.start_minute}'` });
    if (s.start_home_score || s.start_away_score) out.push({ t: `Starts ${s.start_home_score}-${s.start_away_score}` });
    out.push({ t: DIFF[clamp(Math.trunc(num(s.difficulty, 1)), 0, 4)] });
    const r = s.rules || {};
    if (r.golden_goal) out.push({ t: 'Golden goal', hot: true });
    if (r.no_fouls) out.push({ t: 'No fouls', hot: true });
    if (r.no_cards) out.push({ t: 'No cards', hot: true });
    if (num(r.home_goal_value, 1) > 1) out.push({ t: `Goals x${clamp(Math.trunc(r.home_goal_value), 1, 3)}`, hot: true });
    if (r.weather && r.weather !== 'clear') out.push({ t: cap(r.weather) });
    if (r.tod && r.tod !== 'day') out.push({ t: cap(r.tod) });
    return out;
  }

  /* ------------------------------------------------------------ time */
  const p2 = (n) => String(n).padStart(2, '0');
  function fmtSecs(s) {
    if (s >= 48 * 3600) return Math.ceil(s / 86400) + ' Days';
    return `${p2(Math.floor(s / 3600))}:${p2(Math.floor((s % 3600) / 60))}:${p2(s % 60)}`;
  }
  function fmtLeft(e, now) {
    now = now || Date.now();
    if (e.starts_at && new Date(e.starts_at).getTime() > now) return 'COMING SOON';
    if (!e.ends_at) return 'NO END DATE';
    const ms = new Date(e.ends_at).getTime() - now;
    return ms <= 0 ? 'ENDED' : fmtSecs(Math.floor(ms / 1000));
  }
  const fmtUnlock = (iso, now) => fmtSecs(Math.max(0, Math.floor((new Date(iso).getTime() - (now || Date.now())) / 1000)));
  function fmtDates(e) {
    const f = (d) => new Date(d).toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' });
    if (e.starts_at && e.ends_at) return `${f(e.starts_at)} - ${f(e.ends_at)}`;
    if (e.ends_at) return `Until ${f(e.ends_at)}`;
    if (e.starts_at) return `From ${f(e.starts_at)}`;
    return '';
  }

  /* ------------------------------------------------------------ rewards */
  const R_ICON = { coins: '🪙', gems: '💎', ua_points: 'UA', shards: '✦', player: '👤' };
  function fmtAmt(n) {
    n = Math.trunc(num(n, 0));
    if (n >= 1e6) return (n / 1e6).toFixed(n % 1e6 ? 1 : 0).replace(/\.0$/, '') + 'M';
    if (n >= 1e4) return Math.round(n / 1e3) + 'K';
    return n.toLocaleString('en-US');
  }
  /* r: DB row {reward_type,...} or RPC result {type,...}; o: {media, player, got} */
  function rewardTile(r, o) {
    o = o || {};
    const type = r.reward_type || r.type;
    const custom = r.icon_path && o.media ? o.media(r.icon_path) : null;
    let inner, txt;
    if (type === 'player') {
      const pl = o.player ? o.player(r.player_id) : null;
      inner = custom ? `<img src="${esc(custom)}" alt="" draggable="false">` : pl && pl.img ? `<img src="${esc(pl.img)}" alt="" draggable="false">` : '👤';
      txt = r.label || (pl && pl.name) || 'Player';
    } else {
      inner = custom ? `<img class="cut" src="${esc(custom)}" alt="" draggable="false">` : (R_ICON[type] || '🎁');
      const base = type === 'ua_points' ? 'UAP' : type === 'shards' ? 'Shards' : '';
      txt = r.label || (type === 'coins' || type === 'gems' ? fmtAmt(r.amount) : `${fmtAmt(r.amount)} ${base}`);
    }
    return `<div class="pe-rw ${o.got ? 'got' : ''}" data-t="${esc(type)}"><div class="pe-rw-ic">${inner}</div><div class="pe-rw-tx">${esc(txt)}</div>${o.got ? `<i class="pe-rw-ck">${ICON.check}</i>` : ''}</div>`;
  }
  function rewardsHtml(list, o, max) {
    if (!list || !list.length) return '';
    const shown = max ? list.slice(0, max) : list;
    return `<div class="pe-rws ${o && o.dark ? 'on-dark' : ''}">${shown.map((r) => rewardTile(r, o)).join('')}${max && list.length > max ? `<div class="pe-rw"><div class="pe-rw-ic" style="font-size:calc(var(--rs,9cqh)*.34)">+${list.length - max}</div></div>` : ''}</div>`;
  }

  /* ------------------------------------------------------------ layers */
  const SHADOW = {
    none: 'none', soft: '0 .4cqh 1.2cqh rgba(0,0,0,.55)', hard: '.35cqh .35cqh 0 rgba(0,0,0,.6)', glow: '0 0 2cqh currentColor, 0 0 .6cqh currentColor',
  };
  function layerHtml(l, o, i) {
    const t = l.type || 'image';
    const st = `left:${num(l.x, 0)}%;top:${num(l.y, 0)}%;width:${num(l.w, 10)}%;height:${num(l.h, 10)}%;transform:rotate(${num(l.rot, 0)}deg)${l.flip ? ' scaleX(-1)' : ''};opacity:${l.op == null ? 1 : clamp(num(l.op, 1), 0, 1)};`;
    const cls = `pe-layer${l.anim && l.anim !== 'none' ? ' pe-an-' + esc(l.anim) : ''}`;
    const at = o.edit ? ` data-li="${i}" data-lf="${l.front ? 1 : 0}"` : '';
    let body = '';
    if (t === 'image') {
      const u = l.url || (o.media && l.path ? o.media(l.path) : null);
      body = u ? `<img src="${esc(u)}" alt="" draggable="false" style="object-fit:${l.fit === 'cover' ? 'cover' : l.fit === 'fill' ? 'fill' : 'contain'}">` : '<div class="pe-ph">IMG</div>';
    } else if (t === 'shape') {
      const sh = l.shape || 'rect';
      const rad = sh === 'circle' ? '50%' : sh === 'pill' ? '999cqh' : sh === 'round' ? '2cqh' : '0';
      const clip = sh === 'triangle' ? 'clip-path:polygon(50% 0,100% 100%,0 100%);' : sh === 'diamond' ? 'clip-path:polygon(50% 0,100% 50%,50% 100%,0 50%);' : '';
      const bd = num(l.bw, 0) > 0 ? `border:${num(l.bw, 0)}cqh solid ${col(l.bc, '#ffffff')};` : '';
      body = `<div class="pe-ls" style="background:linear-gradient(${num(l.ang, 135)}deg,${col(l.c1, '#ff2d95')},${col(l.c2, l.c1 || '#7c3aed')});border-radius:${rad};${clip}${bd}"></div>`;
    } else {
      let txt = l.text || '';
      let attr = '';
      if (t === 'timer') { txt = (l.text || '') + (o.event ? fmtLeft(o.event, o.now) : '10 Days'); attr = o.event ? ` data-end-ev="${esc(o.event.id)}" data-pre="${esc(l.text || '')}"` : ''; }
      if (t === 'dates') txt = o.event ? (fmtDates(o.event) || 'Start - End dates') : 'Start - End dates';
      const jc = l.align === 'left' ? 'flex-start' : l.align === 'right' ? 'flex-end' : 'center';
      body = `<div class="pe-lt" ${attr} style="font-size:${num(l.fs, 5)}cqh;color:${col(l.color, '#ffffff')};font-weight:${l.bold === false ? 500 : 900};font-style:${l.italic ? 'italic' : 'normal'};justify-content:${jc};text-align:${esc(l.align || 'center')};text-transform:${l.upper ? 'uppercase' : 'none'};letter-spacing:${num(l.ls, 0)}em;text-shadow:${SHADOW[l.shadow] || SHADOW.soft};">${esc(txt)}</div>`;
    }
    return `<div class="${cls}"${at} style="${st}">${body}</div>`;
  }
  function layersHtml(layers, o, front) {
    return (layers || []).map((l, i) => ({ l, i })).filter((x) => !!x.l.front === front).map((x) => layerHtml(x.l, o, x.i)).join('');
  }

  /* ------------------------------------------------------------ stage pieces */
  function crest(st, o) {
    const t = o.team ? o.team(st.opponent_team) : null;
    const name = st.opponent_name || (t && t.name) || st.title || '?';
    const abbr = ((st.opponent_name || (t && t.abbr) || st.title || '?') + '').replace(/[^A-Za-z0-9]/g, '').slice(0, 3).toUpperCase();
    return `<div class="pe-crest" title="${esc(name)}" style="background:linear-gradient(135deg,${col(t && t.c1, '#8a7cff')},${col(t && t.c2, '#3b2f9a')})">${esc(abbr)}</div>`;
  }
  function art(st, o) {
    const u = st.icon_path && o.media ? (st.icon_url || o.media(st.icon_path)) : null;
    return u ? `<img src="${esc(u)}" alt="" draggable="false">` : crest(st, o);
  }
  function lockOverlay(s) {
    if (!s.locked) return '';
    const timed = s.timeLock && s.unlockAt;
    return `<div class="pe-lockov">${ICON.lock}${timed ? `<div class="pe-unl">${ICON.clock}<span>Unlocks in:</span> <b data-unl="${esc(s.unlockAt)}">${esc(fmtUnlock(s.unlockAt))}</b></div>` : '<div class="pe-unl"><span>Clear the previous stage</span></div>'}</div>`;
  }
  function btnLabel(s, o) {
    if (s.cleared) return s.repeatable === false ? 'CLEARED' : 'REPLAY';
    if (s.left === 0) return 'NO ATTEMPTS';
    return o.btn || 'START';
  }
  function stageRw(p, st, s) {
    return (p.rewards && p.rewards.stage && p.rewards.stage[st.id]) || [];
  }
  const sattr = (st, s, extra) => `data-stage="${esc(st.id)}" class="${extra} ${s.cleared ? 'cleared' : ''} ${s.locked ? 'locked' : ''}"`;

  function cardHtml(st, i, p, style) {
    const o = p.o, s = p.state(st), rw = stageRw(p, st, s);
    const tile = style === 'banner' ? 'banner' : 'crest';
    const bgu = st.bg_path && o.media ? (st.bg_url || o.media(st.bg_path)) : null;
    return `<button ${sattr(st, s, 'pe-card ' + tile)}>
      ${s.cleared ? `<div class="pe-done">${ICON.check}DONE</div>` : `<div class="pe-num">${i + 1}</div>`}
      <div class="pe-card-art" style="${tile === 'banner' ? cssUrl(bgu) : ''}">${art(st, o)}</div>
      <div class="pe-card-name">${esc(st.title)}</div>
      <div class="pe-card-sub">${esc(objective(st))}</div>
      ${rewardsHtml(rw, { media: o.media, player: o.player, got: s.cleared }, 3)}
      <div class="pe-btn">${esc(btnLabel(s, o))}</div>
      ${lockOverlay(s)}
    </button>`;
  }
  function rowHtml(st, i, p, ladder) {
    const o = p.o, s = p.state(st), rw = stageRw(p, st, s);
    return `<button ${sattr(st, s, 'pe-row')} data-no="${i + 1}">
      <div class="pe-ra">${art(st, o)}</div>
      <div class="pe-rt"><b>${esc(st.title)}</b><span>${esc(objective(st))}</span></div>
      ${rewardsHtml(rw, { media: o.media, player: o.player, got: s.cleared }, 4)}
      ${s.locked ? (s.timeLock && s.unlockAt ? `<div class="pe-unl">${ICON.clock}<b data-unl="${esc(s.unlockAt)}">${esc(fmtUnlock(s.unlockAt))}</b></div>` : `<div class="pe-unl">${ICON.lock.replace('stroke="#fff"', 'stroke="#555"')}</div>`) : `<div class="pe-btn">${esc(btnLabel(s, o))}</div>`}
    </button>`;
  }
  function nodeHtml(st, i, p) {
    const o = p.o, s = p.state(st), rw = stageRw(p, st, s);
    const u = st.icon_path && o.media ? (st.icon_url || o.media(st.icon_path)) : null;
    return `<button ${sattr(st, s, 'pe-node')}>
      <div class="pe-orb">${s.cleared ? ICON.check : s.locked ? ICON.lock : u ? `<img src="${esc(u)}" alt="">` : i + 1}</div>
      <div class="pe-nname">${esc(st.title)}</div>
      ${rewardsHtml(rw, { media: o.media, player: o.player, got: s.cleared, dark: true }, 2)}
      ${s.locked && s.timeLock && s.unlockAt ? `<div class="pe-unl">${ICON.clock}<b data-unl="${esc(s.unlockAt)}">${esc(fmtUnlock(s.unlockAt))}</b></div>` : ''}
    </button>`;
  }
  function spotHtml(stages, p) {
    const o = p.o;
    if (!stages.length) return '';
    let idx = o.spot;
    if (!(Number.isInteger(idx) && idx >= 0 && idx < stages.length)) {
      idx = stages.findIndex((st) => { const s = p.state(st); return !s.cleared && !s.locked; });
      if (idx < 0) idx = stages.length - 1;
    }
    const st = stages[idx], s = p.state(st), rw = stageRw(p, st, s);
    return `<div class="pe-spot">
      <button ${sattr(st, s, 'pe-spot-main')}>
        <div class="pe-spot-art">${art(st, o)}</div>
        <div class="pe-spot-info"><h3>${esc(st.title)}</h3><div class="pe-obj">${esc(objective(st))}</div>
          <div class="pe-chs">${chips(st).map((c) => `<span class="pe-ch ${c.hot ? 'hot' : ''}">${esc(c.t)}</span>`).join('')}</div>
          ${rewardsHtml(rw, { media: o.media, player: o.player, got: s.cleared }, 4)}
          ${s.locked ? '' : `<div class="pe-btn">${esc(btnLabel(s, o))}</div>`}</div>
        ${lockOverlay(s)}
      </button>
      <div class="pe-pips">${stages.map((x, k) => { const sx = p.state(x); return `<button class="pe-pip ${k === idx ? 'on' : ''} ${sx.cleared ? 'cleared' : ''} ${sx.locked ? 'locked' : ''}" data-spot="${k}">${sx.cleared ? '✓' : k + 1}</button>`; }).join('')}</div>
    </div>`;
  }

  /* ------------------------------------------------------------ zone + page */
  function sectionBar(p) {
    const o = p.o, groups = [];
    const sr = (p.rewards && p.rewards.section) || [], er = (p.rewards && p.rewards.event) || [];
    if (sr.length) {
      const st = p.secState || { done: 0, total: 0, completed: false };
      groups.push(`<div class="pe-sg ${st.completed ? 'full' : ''}"><div class="pe-sg-l"><b>${esc((p.section && p.section.style && p.section.style.reward_label) || 'Section reward')}</b><div class="pe-bar"><i style="width:${st.total ? Math.round((st.done / st.total) * 100) : 0}%"></i></div><small>${st.done}/${st.total}</small></div>${rewardsHtml(sr, { media: o.media, player: o.player, got: st.completed }, 4)}</div>`);
    }
    if (er.length) {
      const st = p.evState || { done: 0, total: 0, completed: false };
      groups.push(`<div class="pe-sg ${st.completed ? 'full' : ''}"><div class="pe-sg-l"><b>${esc((p.event.ui && p.event.ui.completion_label) || 'Event complete')}</b><div class="pe-bar"><i style="width:${st.total ? Math.round((st.done / st.total) * 100) : 0}%"></i></div><small>${st.done}/${st.total}</small></div>${rewardsHtml(er, { media: o.media, player: o.player, got: st.completed }, 4)}</div>`);
    }
    return groups.length ? `<div class="pe-secrw">${groups.join('')}</div>` : '';
  }
  function layoutHtml(sec, stages, p) {
    const sty = sec.style || {};
    const cstyle = sty.card_style === 'banner' ? 'banner' : 'crest';
    if (!stages.length) return `<div class="pe-empty">${p.o.edit ? 'NO STAGES YET' : 'COMING SOON'}</div>`;
    switch (sec.layout) {
      case 'grid': return `<div class="pe-grid" style="--cols:${clamp(Math.trunc(num(sty.columns, 3)), 2, 5)}">${stages.map((st, i) => cardHtml(st, i, p, cstyle)).join('')}</div>`;
      case 'path': return `<div class="pe-path"><div class="pe-path-in">${stages.map((st, i) => nodeHtml(st, i, p)).join('')}</div></div>`;
      case 'ladder': return `<div class="pe-col pe-ladder">${stages.map((st, i) => rowHtml(st, i, p, true)).join('')}</div>`;
      case 'list': return `<div class="pe-col">${stages.map((st, i) => rowHtml(st, i, p, false)).join('')}</div>`;
      case 'spotlight': return spotHtml(stages, p);
      default: return `<div class="pe-rail" style="--cw:${clamp(num(sty.card_w, 30), 20, 50)}">${stages.map((st, i) => cardHtml(st, i, p, cstyle)).join('')}</div>`;
    }
  }
  function headHtml(p) {
    const e = p.event, ui = e.ui || {}, o = p.o;
    const pills = [];
    if (ui.show_dates && fmtDates(e)) pills.push(`<div class="pe-pill">${esc(fmtDates(e))}</div>`);
    if (ui.show_timer !== false) pills.push(`<div class="pe-pill">${ICON.clock}<span data-end-ev="${esc(e.id)}">${esc(fmtLeft(e, o.now))}</span></div>`);
    return `<div class="pe-head"><button class="pe-back" data-act="close-detail" aria-label="Back">${ICON.back}</button><div class="pe-title">${esc(e.title)}</div><div class="pe-hsp"></div>${o.headRight || ''}${pills.join('')}</div>`;
  }
  function tabsHtml(p) {
    const secs = p.sections || [];
    if (secs.length < 2 && !p.o.edit) return '';
    return `<div class="pe-tabs">${secs.map((s) => {
      const lk = s.unlock_at && new Date(s.unlock_at).getTime() > (p.o.now || Date.now());
      const tc = col(s.style && s.style.tab_color, '');
      return `<button class="pe-tab ${p.section && s.id === p.section.id ? 'on' : ''}" data-sec="${esc(s.id)}" style="${tc ? '--tab:' + tc + ';' : ''}">${lk ? ICON.lock : ''}<span>${esc(s.title)}</span>${s.style && s.style.tab_badge ? `<i class="pe-tn">${esc(s.style.tab_badge)}</i>` : ''}</button>`;
    }).join('')}</div>`;
  }
  const DEFAULT_CONTENT = { x: 40, y: 28, w: 58, h: 66 };
  function pageHtml(p) {
    const e = p.event, sec = p.section || { layout: 'rail', style: {}, layers: [], content: DEFAULT_CONTENT };
    const o = p.o, sty = sec.style || {}, c = Object.assign({}, DEFAULT_CONTENT, sec.content || {});
    const bgu = sec.bg_path && o.media ? (sec.bg_url || o.media(sec.bg_path)) : null;
    const frame = sty.frame || 'none', theme = sty.card_theme || 'light';
    const secDecor = sectionBar(p);
    return `<div class="pe-root ${o.edit ? 'pe-edit' : ''}" data-tabs="${esc((e.ui && e.ui.tab_style) || 'dark')}" style="--a1:${col(e.accent_color, '#ff2d95')};--a2:${col(e.accent_color_2, '#7c3aed')};--tx:${col(e.text_color, '#ffffff')};--b1:${col(sec.bg_color_1, '#2b1a5e')};--b2:${col(sec.bg_color_2, '#0f0a2c')};">
      <div class="pe-bg" style="${cssUrl(bgu)}"></div>
      <div class="pe-dim" style="opacity:${clamp(num(sec.bg_dim, 0.25), 0, 0.9)}"></div>
      <div class="pe-safe">
        <div class="pe-layers back">${layersHtml(sec.layers, o, false)}</div>
        <div class="pe-zone" data-frame="${esc(frame)}" data-theme="${esc(theme)}" style="left:${c.x}%;top:${c.y}%;width:${c.w}%;height:${c.h}%;">
          <div class="pe-zbody">${layoutHtml(sec, p.stages || [], p)}</div>${secDecor}
        </div>
        <div class="pe-layers front">${layersHtml(sec.layers, o, true)}</div>
      </div>
      ${headHtml(p)}${tabsHtml(p)}
    </div>`;
  }

  root.PlayRender = { esc, col, cssUrl, ICON, objective, chips, fmtLeft, fmtUnlock, fmtDates, fmtSecs, fmtAmt, rewardTile, rewardsHtml, layerHtml, pageHtml, layoutHtml, DEFAULT_CONTENT };
})(typeof window !== 'undefined' ? window : globalThis);
