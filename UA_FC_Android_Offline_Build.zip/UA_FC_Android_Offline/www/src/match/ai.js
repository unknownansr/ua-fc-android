/* ==========================================================================
   ai.js — "COACH" brain for the opponent (team 1).  Loaded AFTER game.js.

   It replaces the opponent's decision-making by wrapping aiUpdate / aiDecide /
   aiCarrierAct (the originals stay as an automatic fallback if anything throws).

   What it does
   1. MATCH READING   score, minute, momentum, shots -> a game MODE:
        cruise   (winning by 3+)        hold the ball, safe passes, mid block
        protect  (winning, 2nd half)    compact low block, waste time, counter only
        balanced (level / early)        normal football
        chase    (losing by 1-2)        higher line, 2 pressers, more crosses/through balls
        desperate(losing by 3+ / late)  all-out: very high line, long shots, Thunder, 3 pressers
   2. TACTICS         possession | wings | direct | longshots | counter | highpress
        Every window it checks whether the current plan is producing (shots / goals).
        If not, it TRIES SOMETHING ELSE. It also scouts you (favourite flank, how high
        your back line is, how far you shoot from) and picks the plan that hurts you most.
   3. "PLAY A LITTLE BETTER" when losing heavily: faster reactions, a touch more pace and
        sharper decisions (small, capped) — never cheating by teleporting or ignoring physics.
   4. OFF THE BALL    pressing with cover, goal-side marking, compact lines that shift with the ball,
        runs into space, width, support triangles, interceptions of loose balls.
   5. ON THE BALL     scores every option (shoot / pass / through ball / chip pass / cross /
        dribble / hold / clear) with an xG model and lane-safety model, then picks the best.
   6. PLAYSTYLES      uses Thunder / Thunder+, Hardshot, Target, Chip Pass, Power Header,
        Sliding Tackle, Vision, Finesse Expert, Trickster... exactly like a player would.
   7. TACKLING        jockeys instead of diving in, times the tackle, slides only when it makes sense.

   Everything is tuned by the existing difficulty (AMATEUR / PRO / LEGEND) so easy stays easy.
   Debug in the console:  AIBRAIN.state()   AIBRAIN.enabled = false  (back to the old AI)
   ========================================================================== */
(function () {
  'use strict';
  if (typeof aiUpdate !== 'function' || typeof aiDecide !== 'function' || typeof aiCarrierAct !== 'function') {
    console.warn('[ai.js] game AI functions not found - brain not installed');
    return;
  }

  const TEAM = 1;
  const SKILL = [0.35, 0.7, 1.0, 0.0, 1.0]; // AMATEUR / PRO / LEGEND -> how sharp the brain's decisions are
  const orig = { update: aiUpdate, decide: aiDecide, carrier: aiCarrierAct };

  const B = {
    enabled: true,
    mode: 'balanced',
    tactic: 'possession',
    tacticSince: 0,
    lead: 0,            // goals ahead (+) / behind (-) from the opponent's side
    frac: 0,            // 0..1 of the whole match
    boost: 0,           // 0..1 "play a little better" factor (only when losing)
    reactScale: 1,
    speedMul: 1,
    hist: {},           // tactic -> running score
    win: { t0: 0, shots0: 0, goals0: 0, conceded0: 0, ballAtk: 0, samples: 0 },
    scout: { flank: 0, flankN: 0, lineHeight: 0, shotDist: 22, shotN: 0, lastShots: 0 },
    asg: new Map(),     // player -> { type, target, x, z }
    lastClock: -1, lastAsg: 0, lastEval: 0, lastScore: [0, 0], failed: 0,
    log: [],
  };
  window.AIBRAIN = B;

  /* ------------------------------ helpers ------------------------------ */
  const clampN = (v, a, b) => Math.max(a, Math.min(b, v));
  const rnd = (a, b) => a + Math.random() * (b - a);
  const d2 = (ax, az, bx, bz) => Math.hypot(ax - bx, az - bz);
  const diffCfg = () => DIFFS[settings.diff] || DIFFS[1];
  const skill = () => SKILL[settings.diff] != null ? SKILL[settings.diff] : 0.7;
  const aiPlayers = () => players.filter((q) => q.team === TEAM && !q.isGK && !q.sentOff && q !== controlledP2);
  const oppPlayers = () => players.filter((q) => q.team !== TEAM && !q.sentOff);
  const atkSign = () => Math.sign(attackGoalX(TEAM));     // x direction the opponent attacks in
  const ownGoalX = () => -attackGoalX(TEAM);
  const advance = (x) => x * atkSign();                    // bigger = closer to the goal we attack
  const roleBand = (p) => (p.homeFx < -0.45 ? 'DEF' : p.homeFx > 0.2 ? 'FWD' : 'MID');
  const goalPt = () => ({ x: attackGoalX(TEAM), z: 0 });
  function note(msg) { B.log.push(`${Math.floor(match.clock)}s ${msg}`); if (B.log.length > 40) B.log.shift(); }

  function laneClearance(ax, az, bx, bz, ignoreA, ignoreB) {
    // smallest distance from any opposing player to the segment a->b (ignoring the very ends)
    let best = 99;
    const abx = bx - ax, abz = bz - az, len2 = abx * abx + abz * abz + 1e-6;
    for (const q of players) {
      if (q.team === TEAM || q === ignoreA || q === ignoreB) continue;
      const t = clampN(((q.pos.x - ax) * abx + (q.pos.z - az) * abz) / len2, 0, 1);
      if (t < 0.06 || t > 0.94) continue;
      const dd = Math.hypot(ax + abx * t - q.pos.x, az + abz * t - q.pos.z);
      if (dd < best) best = dd;
    }
    return best;
  }
  function nearestOppTo(x, z, ex) {
    let best = 99;
    for (const q of players) { if (q.team === TEAM || q === ex) continue; const dd = d2(x, z, q.pos.x, q.pos.z); if (dd < best) best = dd; }
    return best;
  }
  function theirKeeper() { return players.find((q) => q.team !== TEAM && q.isGK); }
  const hasPS = (p, n) => !!hasStyle(p, n);

  /* --------------------------- match reading --------------------------- */
  function readMatch() {
    const total = Math.max(60, (settings.halfDur || 180) * 2);
    B.frac = clampN(match.clock / total, 0, 1);
    B.lead = match.score[TEAM] - match.score[1 - TEAM];
    const L = B.lead, late = B.frac > 0.62, veryLate = B.frac > 0.82;
    let mode = 'balanced';
    if (L <= -3 || (L <= -2 && late) || (L <= -1 && veryLate)) mode = 'desperate';
    else if (L <= -1) mode = 'chase';
    else if (L >= 3) mode = 'cruise';
    else if (L >= 1 && (B.frac > 0.5 || L >= 2)) mode = 'protect';
    if (mode !== B.mode) { note(`mode ${B.mode} -> ${mode} (lead ${L})`); B.mode = mode; pickTactic(true); }
    // "play a little better": scales with how badly we trail, capped, softened on easy difficulty
    B.boost = clampN((-L - 1) / 3, 0, 1) * (0.55 + 0.45 * skill());
    B.reactScale = 1 - 0.28 * B.boost;
    B.speedMul = 1 + 0.045 * B.boost;
  }

  /* ------------------------------ scouting ----------------------------- */
  function scoutYou() {
    const S = B.scout;
    const c = ball.owner;
    if (c && c.team !== TEAM && advance(c.pos.x) < 0) { // you attacking us
      S.flank = S.flank * 0.97 + Math.sign(c.pos.z || 0) * 0.03; S.flankN++;
    }
    const sh = match.stats.shots[1 - TEAM];
    if (sh > S.lastShots) { S.lastShots = sh; S.shotN++; const bx = d2(ball.pos.x, ball.pos.z, ownGoalX(), 0); S.shotDist = S.shotDist * 0.7 + bx * 0.3; }
    // how high is your back line? (average advance of your 3 deepest outfield players)
    const own = attackGoalX(TEAM); // the goal you defend is the one we attack
    const depth = oppPlayers().filter((q) => !q.isGK).map((q) => Math.abs(q.pos.x - own)).sort((a, b) => a - b);
    if (depth.length >= 3) S.lineHeight = S.lineHeight * 0.85 + (depth[0] + depth[1] + depth[2]) / 3 * 0.15; // distance of your 3 deepest players from your goal
  }

  /* ------------------------------ tactics ------------------------------ */
  const TACTICS_BY_MODE = {
    cruise:    ['possession', 'counter'],
    protect:   ['counter', 'possession'],
    balanced:  ['possession', 'wings', 'direct', 'highpress'],
    chase:     ['highpress', 'wings', 'direct', 'longshots', 'possession'],
    desperate: ['highpress', 'direct', 'longshots', 'wings'],
  };
  function tacticFit(t) {
    // scouting: which plan is most likely to hurt YOU right now
    const S = B.scout; let s = 0;
    const yourHighLine = S.lineHeight > FIELD.halfLen * 0.5; // your back line stands high (far from your own goal)
    if (t === 'direct' || t === 'counter') s += yourHighLine ? 2 : -0.5;
    if (t === 'possession' || t === 'wings') s += yourHighLine ? -0.5 : 1;
    if (t === 'longshots') s += S.shotN > 2 ? 0.5 : 0;
    if (t === 'highpress') s += B.mode === 'chase' || B.mode === 'desperate' ? 1.2 : 0.2;
    return s;
  }
  function pickTactic(force) {
    const list = TACTICS_BY_MODE[B.mode] || TACTICS_BY_MODE.balanced;
    let best = null, bs = -1e9;
    for (const t of list) {
      let s = (B.hist[t] || 0) + tacticFit(t) + rnd(0, 0.6);
      if (!force && t === B.tactic) s -= 3; // when we are re-picking because it isn't working, avoid the same plan
      if (s > bs) { bs = s; best = t; }
    }
    if (best && best !== B.tactic) { note(`tactic ${B.tactic} -> ${best}`); B.tactic = best; }
    B.tacticSince = match.clock;
    B.win = { t0: match.clock, shots0: match.stats.shots[TEAM], goals0: match.score[TEAM], conceded0: match.score[1 - TEAM], ballAtk: 0, samples: 0 };
  }
  function evaluateTactic() {
    const W = B.win, span = match.clock - W.t0;
    const windowLen = Math.max(24, (settings.halfDur || 180) * 0.16);
    const conceded = match.score[1 - TEAM] - W.conceded0, scored = match.score[TEAM] - W.goals0, shots = match.stats.shots[TEAM] - W.shots0;
    // reward = how well did this plan do (goals matter most)
    const reward = scored * 3 + shots * 0.8 - conceded * 2.5;
    if (conceded > 0 && (B.mode === 'protect' || B.mode === 'cruise' || B.mode === 'balanced')) {
      B.hist[B.tactic] = (B.hist[B.tactic] || 0) - 2; pickTactic(false); return;
    }
    if (span < windowLen) return;
    B.hist[B.tactic] = (B.hist[B.tactic] || 0) * 0.6 + reward;
    const needAttack = B.mode === 'chase' || B.mode === 'desperate';
    if (needAttack && shots === 0 && scored === 0) { note('plan not working -> switching'); pickTactic(false); }
    else if (needAttack && reward < 1.2 && span > windowLen * 1.6) pickTactic(false);
    else { B.win = { t0: match.clock, shots0: match.stats.shots[TEAM], goals0: match.score[TEAM], conceded0: match.score[1 - TEAM], ballAtk: 0, samples: 0 }; }
  }

  /* ------------------ team shape: pressing / marking plan -------------- */
  function lineDepth() {
    // how far from our own goal the defensive line stands (fraction of half-length)
    let f = 0.42;
    if (B.mode === 'protect' || B.mode === 'cruise') f = 0.26;
    if (B.mode === 'chase') f = 0.52;
    if (B.mode === 'desperate') f = 0.64;
    if (B.tactic === 'highpress') f += 0.08;
    if (B.tactic === 'counter') f -= 0.1;
    return clampN(f, 0.2, 0.72);
  }
  function pressersWanted() {
    let n = 1;
    if (B.tactic === 'highpress') n = 2;
    if (B.mode === 'desperate') n = 3;
    else if (B.mode === 'chase') n = Math.max(n, 2);
    if (B.mode === 'protect' || B.mode === 'cruise' || B.tactic === 'counter') n = 1;
    return n;
  }
  function etaTo(p, x, z) { return d2(p.pos.x, p.pos.z, x, z) / Math.max(1, p.baseSpeed * psSpeedMul(p) * 1.15); }

  function buildAssignments() {
    B.asg.clear();
    const mates = aiPlayers();
    if (!mates.length) return;
    const carrier = ball.owner;
    const dir = atkSign(), ownGx = ownGoalX();
    if (carrier && carrier.team === TEAM) return; // attacking phase handled in decide()
    if (!carrier) { // loose ball: the player who can get there first goes, a second covers if it is dangerous
      const tgt = predictBallPoint();
      const sorted = mates.slice().sort((a, b) => etaTo(a, tgt.x, tgt.z) - etaTo(b, tgt.x, tgt.z));
      sorted.slice(0, 1 + (Math.abs(tgt.x - ownGx) < 30 ? 1 : 0)).forEach((p, i) => B.asg.set(p, { type: i === 0 ? 'chase' : 'cover', x: tgt.x, z: tgt.z }));
      return;
    }
    // defending phase: carrier is one of yours
    const k = pressersWanted();
    const byEta = mates.slice().sort((a, b) => etaTo(a, carrier.pos.x, carrier.pos.z) - etaTo(b, carrier.pos.x, carrier.pos.z));
    const inMyHalf = advance(carrier.pos.x) < 0; // carrier is in our half (their attack)
    const used = new Set();
    // pressers: only commit if the carrier is reachable soon; keep a last man back when the danger is real
    let pressN = 0;
    for (const p of byEta) {
      if (pressN >= k) break;
      const eta = etaTo(p, carrier.pos.x, carrier.pos.z);
      if (eta > 3.4 && pressN > 0) break;
      B.asg.set(p, { type: pressN === 0 ? 'press' : 'press2', target: carrier });
      used.add(p); pressN++;
    }
    // cover: stand goal-side of the carrier between him and our goal
    const coverP = byEta.find((p) => !used.has(p) && roleBand(p) !== 'FWD') || byEta.find((p) => !used.has(p));
    if (coverP) { B.asg.set(coverP, { type: 'cover', target: carrier }); used.add(coverP); }
    // marking: dangerous attackers = closest to our goal, weighted by their distance from the ball (passing option)
    const threats = oppPlayers().filter((q) => !q.isGK && q !== carrier)
      .map((q) => ({ q, s: -d2(q.pos.x, q.pos.z, ownGx, 0) * 1.0 - d2(q.pos.x, q.pos.z, carrier.pos.x, carrier.pos.z) * 0.25 + (inMyHalf ? 8 : 0) }))
      .sort((a, b) => b.s - a.s);
    const free = mates.filter((p) => !used.has(p)).sort((a, b) => (roleBand(a) === 'DEF' ? -1 : 0) - (roleBand(b) === 'DEF' ? -1 : 0));
    for (const th of threats) {
      if (!free.length) break;
      // nearest free defender to this threat (by distance to the point goal-side of him)
      let bi = 0, bd = 1e9;
      free.forEach((p, i) => { const dd = d2(p.pos.x, p.pos.z, th.q.pos.x, th.q.pos.z) + (roleBand(p) === 'FWD' ? 14 : 0); if (dd < bd) { bd = dd; bi = i; } });
      const p = free.splice(bi, 1)[0];
      B.asg.set(p, { type: 'mark', target: th.q });
    }
    free.forEach((p) => B.asg.set(p, { type: 'shape' }));
  }

  /* --------------------- off-the-ball decision (decide) ---------------- */
  function spotScore(p, x, z, carrier) {
    // how good is (x,z) as a place to receive a pass from `carrier`
    const open = Math.min(nearestOppTo(x, z), 10);
    const lane = carrier ? Math.min(laneClearance(carrier.pos.x, carrier.pos.z, x, z, carrier, p), 6) : 3;
    const adv = advance(x) / FIELD.halfLen; // -1..1
    const dg = d2(x, z, attackGoalX(TEAM), 0);
    return open * 1.4 + lane * 1.8 + adv * 6 - dg * 0.05 - d2(x, z, p.pos.x, p.pos.z) * 0.12;
  }

  function attackPlan(p, carrier) {
    const wp = formationWorldPos(p.team, p.homeFx, p.homeFz);
    const band = roleBand(p), dir = atkSign();
    const gx = attackGoalX(TEAM);
    const bx = ball.pos.x;
    // squad moves up/down with the ball and the mode
    const push = B.mode === 'desperate' ? 14 : B.mode === 'chase' ? 8 : (B.mode === 'protect' || B.mode === 'cruise') ? -6 : 0;
    const tacticPush = B.tactic === 'highpress' ? 5 : B.tactic === 'counter' ? -5 : 0;
    let x = wp.x + clampN(bx * 0.42, -26, 26) * 0.8 + dir * (push + tacticPush) * (band === 'DEF' ? 0.5 : 1);
    let z = wp.z + (ball.pos.z - wp.z) * 0.15;
    let sprint = false;

    if (band === 'DEF') {
      // keep a line, but join the attack in chase/desperate (full-backs overlap)
      const full = Math.abs(p.homeFz) > 0.45;
      if (full && (B.mode === 'chase' || B.mode === 'desperate' || B.tactic === 'wings')) { x = Math.max(advance(x), advance(ball.pos.x) - 4) * dir; z = Math.sign(p.homeFz) * (FIELD.halfWid - 5); sprint = Math.random() < 0.35; }
      else x = Math.min(advance(x), advance(carrier.pos.x) - 14) * dir; // stay behind the ball
    } else {
      // forwards & midfielders: choose the best receiving spot among sampled candidates
      const reach = band === 'FWD' ? 18 : 12;
      let best = null, bs = -1e9;
      const cands = [];
      for (let i = 0; i < 7; i++) {
        let cx = wp.x + dir * rnd(-4, reach) + clampN(bx * 0.4, -24, 24) * 0.5;
        let cz = wp.z + rnd(-12, 12);
        if (B.tactic === 'wings' && Math.abs(p.homeFz) > 0.3) cz = Math.sign(p.homeFz) * rnd(FIELD.halfWid - 9, FIELD.halfWid - 3);
        if (B.tactic === 'direct' && band === 'FWD') cx = Math.min(gx - dir * 6, advance(carrier.pos.x) * dir + dir * rnd(12, 24));
        if (B.tactic === 'longshots' && band === 'MID') { cx = gx - dir * rnd(19, 25); cz = rnd(-10, 10); }
        if (B.tactic === 'counter' && band === 'FWD') cx = dir * Math.min(advance(carrier.pos.x) + 14, FIELD.halfLen - 8);
        if (B.tactic === 'possession' && band === 'MID') { const off = rnd(6, 11); cx = carrier.pos.x - dir * rnd(-3, 5); cz = carrier.pos.z + (Math.random() < 0.5 ? -1 : 1) * off; }
        cx = clampN(cx, -FIELD.halfLen + 3, FIELD.halfLen - 3); cz = clampN(cz, -FIELD.halfWid + 3, FIELD.halfWid - 3);
        cands.push([cx, cz]);
      }
      for (const [cx, cz] of cands) { const s = spotScore(p, cx, cz, carrier); if (s > bs) { bs = s; best = [cx, cz]; } }
      if (best) { x = best[0]; z = best[1]; }
      sprint = band === 'FWD' && (B.tactic === 'direct' || B.mode === 'desperate' || Math.random() < 0.3);
      // Target / Target+ runners dart behind the line when a through ball is on
      if ((hasPS(p, 'Target') || hasPS(p, 'Target+')) && band === 'FWD') { x = clampN(gx - dir * 8, -FIELD.halfLen + 3, FIELD.halfLen - 3); sprint = true; }
    }
    // being too close to the carrier is useless: give him space unless possession tactic wants support
    if (p !== carrier && d2(x, z, carrier.pos.x, carrier.pos.z) < 4) { z += (z >= carrier.pos.z ? 1 : -1) * 6; }
    // when protecting a lead, stay compact
    if (B.mode === 'protect' || B.mode === 'cruise') sprint = false;
    return { x: clampN(x, -FIELD.halfLen + 2, FIELD.halfLen - 2), z: clampN(z, -FIELD.halfWid + 2, FIELD.halfWid - 2), sprint, press: false };
  }

  function defendPlan(p, a, carrier) {
    const own = ownGoalX(), dir = atkSign();
    const depth = lineDepth() * FIELD.halfLen;
    const wp = formationWorldPos(p.team, p.homeFx, p.homeFz);
    // shape: x between home and our goal limited by the line, shifts toward the ball, z squeezes toward the ball
    const bx = ball.pos.x, bz = ball.pos.z;
    const lineX = own + dir * depth;                      // x of the defensive line
    const shiftZ = clampN(S_flank(), -1, 1) * 3;
    let shapeX = clampN(wp.x * 0.7 + lineX * 0.3 + clampN(bx * 0.3, -18, 18), -FIELD.halfLen + 4, FIELD.halfLen - 4);
    let shapeZ = wp.z * 0.7 + (bz - wp.z) * 0.32 + shiftZ;
    if (roleBand(p) === 'DEF') { const ballFromGoal = (bx - own) * dir; shapeX = own + dir * clampN(Math.min(depth, ballFromGoal - 6), 8, FIELD.halfLen); }
    if (!a || a.type === 'shape') return { x: shapeX, z: shapeZ, sprint: false, press: false };
    switch (a.type) {
      case 'chase': return { x: a.x, z: a.z, sprint: true, press: false };
      case 'press': case 'press2': {
        const c = a.target;
        const toGoal = new THREE.Vector3(own - c.pos.x, 0, 0 - c.pos.z).normalize();
        // approach goal-side of the carrier; stand off at ~2.2 until close (jockey), then commit
        const dd = d2(p.pos.x, p.pos.z, c.pos.x, c.pos.z);
        const stand = (a.type === 'press' ? 1.0 : 3.0) + (dd > 6 ? 0 : 0.8);
        const ahead = new THREE.Vector3(c.vel.x, 0, c.vel.z).multiplyScalar(0.35);
        return { x: c.pos.x + ahead.x + toGoal.x * stand, z: c.pos.z + ahead.z + toGoal.z * stand, sprint: dd > 4, press: a.type === 'press' };
      }
      case 'cover': {
        const c = a.target;
        if (!c) return { x: a.x, z: a.z, sprint: true, press: false };
        const toGoal = new THREE.Vector3(own - c.pos.x, 0, 0 - c.pos.z).normalize();
        return { x: c.pos.x + toGoal.x * 6.5, z: c.pos.z + toGoal.z * 6.5, sprint: false, press: false };
      }
      case 'mark': {
        const t = a.target;
        // stay between the attacker and our goal, shaded toward the ball so passes are cut
        const gx2 = own, gz2 = 0;
        const v = new THREE.Vector3(gx2 - t.pos.x, 0, gz2 - t.pos.z).normalize();
        const toBall = new THREE.Vector3(bx - t.pos.x, 0, bz - t.pos.z).normalize();
        const mx = t.pos.x + (v.x * 0.7 + toBall.x * 0.3) * 2.0, mz = t.pos.z + (v.z * 0.7 + toBall.z * 0.3) * 2.0;
        const danger = d2(t.pos.x, t.pos.z, own, 0) < 28;
        return { x: mx, z: mz, sprint: danger && d2(p.pos.x, p.pos.z, mx, mz) > 5, press: false };
      }
    }
    return { x: shapeX, z: shapeZ, sprint: false, press: false };
  }
  function S_flank() { return B.scout.flank; }

  function decide(p, diff) {
    const carrier = ball.owner;
    if (carrier === p) { // the carrier follows the plan he chose; default = carry the ball forward
      if (p._carryUntil > match.clock && p._carryPlan) p.plan = p._carryPlan;
      else p.plan = { x: clampN(p.pos.x + atkSign() * 8, -FIELD.halfLen + 2, FIELD.halfLen - 2), z: p.pos.z * 0.92, sprint: B.mode !== 'protect' && B.mode !== 'cruise', press: false };
      return;
    }
    if (carrier && carrier.team === TEAM) { p.plan = attackPlan(p, carrier); return; }
    if (!carrier) {
      const a = B.asg.get(p);
      if (a && (a.type === 'chase' || a.type === 'cover')) { p.plan = a.type === 'chase' ? { x: a.x, z: a.z, sprint: true, press: false } : defendPlan(p, { type: 'shape' }, null); if (a.type === 'cover') p.plan.sprint = false; return; }
      // attacking-minded shape when ball is loose
      p.plan = defendPlan(p, { type: 'shape' }, null);
      return;
    }
    p.plan = defendPlan(p, B.asg.get(p), carrier);
  }

  /* ------------------------------ tackling ----------------------------- */
  function tackle(p) {
    const c = ball.owner; if (!c) return;
    if (p._tkWait > 0) return;
    const own = ownGoalX();
    const dToGoal = d2(c.pos.x, c.pos.z, own, 0);
    const danger = dToGoal < 26;
    const inBox = dToGoal < 17 && Math.abs(c.pos.z) < 20;
    const toMe = { x: p.pos.x - c.pos.x, z: p.pos.z - c.pos.z };
    const cv = Math.hypot(c.vel.x, c.vel.z) || 1;
    const facing = (c.vel.x * toMe.x + c.vel.z * toMe.z) / (cv * (Math.hypot(toMe.x, toMe.z) || 1)); // 1 = running straight at me
    const behind = facing < -0.2; // I am behind the carrier, chasing
    // last man = no other outfield teammate between carrier and our goal
    const lastMan = !aiPlayers().some((q) => q !== p && d2(q.pos.x, q.pos.z, own, 0) < dToGoal - 1);
    const cover = aiPlayers().some((q) => q !== p && d2(q.pos.x, q.pos.z, c.pos.x, c.pos.z) < 7);
    // patience: alone and not behind -> jockey for a moment instead of diving in
    if (!cover && !behind && !danger && Math.random() < 0.45 * skill()) { p._tkWait = rnd(0.3, 0.6); return; }
    if (lastMan && danger && !behind && Math.random() < 0.5 * skill()) { p._tkWait = rnd(0.2, 0.4); return; }
    let slide = 0.08;
    if (behind) slide += 0.45;
    if (danger && lastMan) slide += 0.25;
    if (hasPS(p, 'Sliding Tackle')) slide += 0.3;
    if (inBox && !lastMan) slide -= 0.12;
    if (B.mode === 'protect' || B.mode === 'cruise') slide -= 0.08;
    if (B.mode === 'desperate' && !danger) slide += 0.1;
    if (!behind && facing > 0.6) slide -= 0.1; // head-on: stand up to him
    slide = clampN(slide, 0.02, 0.85);
    if (Math.random() < slide) slideTackle(p); else standingTackle(p);
  }

  /* --------------------------- the ball-carrier ------------------------- */
  function xG(p, x, z, power) {
    const gx = attackGoalX(TEAM);
    const dg = d2(x, z, gx, 0);
    const range = 33 * (hasPS(p, 'Hardshot') ? 1.25 : 1) * (psThunder(p, 'shot_power') > 0 ? 1.15 : 1);
    if (dg > range) return 0;
    const dist = Math.pow(clampN(1 - dg / range, 0, 1), 1.5) * 0.62;
    const ang = 2 * Math.atan2(3.66, Math.max(dg, 3));           // visible goal-mouth angle
    const angF = clampN(ang / 1.15, 0.2, 1) * clampN(1 - Math.abs(z) / 34, 0.35, 1);
    const clear = laneClearance(x, z, gx, clampN(z * 0.3, -2.5, 2.5), p, null);
    const blockF = clear < 1.2 ? 0.28 : clear < 2.2 ? 0.55 : clear < 3.5 ? 0.82 : 1;
    const gk = theirKeeper(); let gkF = 1;
    if (gk) { const gkLineZ = Math.abs(gk.pos.z - z * 0.3); gkF = gkLineZ > 2.4 ? 1.15 : 0.92; }
    const fin = clampN((p.stats.shooting || 70) / 100, 0.4, 1.15) * (p.team === 1 ? 1 : 1);
    let q = dist * angF * blockF * gkF * (0.6 + 0.5 * fin);
    q *= 1 + psTargetBuff(p, 'finishing') * 0.8 + styleBonus(p, 'Clinical Finsher', 0.12, 0.26) + styleBonus(p, 'Power Shot', 0.09, 0.2) * 0.5;
    return clampN(q, 0, 0.9);
  }

  function modeWeights() {
    switch (B.mode) {
      case 'cruise':    return { prog: 0.5, safe: 1.7, shoot: 0.75, risk: 0.5, hold: 1 };
      case 'protect':   return { prog: 0.6, safe: 1.5, shoot: 0.8,  risk: 0.6, hold: 1 };
      case 'chase':     return { prog: 1.2, safe: 0.9, shoot: 1.15, risk: 1.2, hold: 0 };
      case 'desperate': return { prog: 1.45, safe: 0.75, shoot: 1.4, risk: 1.5, hold: 0 };
      default:          return { prog: 1.0, safe: 1.0, shoot: 1.0, risk: 1.0, hold: 0 };
    }
  }

  function evaluateOptions(p) {
    const W = modeWeights();
    const gx = attackGoalX(TEAM), dir = atkSign();
    const dGoal = d2(p.pos.x, p.pos.z, gx, 0);
    const pressure = nearestOpponentDistOf(p);
    const myAdv = advance(p.pos.x);
    const thunderOn = p.thunderT > 0;
    const opts = [];

    // ---- shoot ----
    const q = xG(p, p.pos.x, p.pos.z, 1);
    if (q > 0.035) {
      const tacticBias = B.tactic === 'longshots' ? 1.3 : 1;
      let score = (q * 420 + (dGoal < 20 ? (20 - dGoal) * 3.5 : 0)) * W.shoot * tacticBias; // in the box an open shot beats almost any pass
      if (pressure < 1.6) score *= 0.85;        // snatched shot under pressure
      if (thunderOn) score *= 1.25;              // Thunder is on: use the burst
      let kind = 'shoot', power = clampN(0.78 + dGoal / 70, 0.7, 1);
      const gk = theirKeeper();
      if (hasPS(p, 'Finesse Expert') && dGoal > 10 && dGoal < 40) { kind = 'curl'; score *= 1.1; }
      else if (gk && dGoal < 20 && advance(gk.pos.x) < FIELD.halfLen - 6 && hasPS(p, 'Chip Shot')) { kind = 'chip'; score *= 1.15; }
      else if (hasPS(p, 'Hardshot') && dGoal > 16) { power = 1; score *= 1.08; }
      opts.push({ kind, score, power, tag: 'shoot' });
    }

    // ---- passes ----
    for (const m of players) {
      if (m.team !== TEAM || m === p || m.isGK || m.sentOff) continue;
      const d = d2(p.pos.x, p.pos.z, m.pos.x, m.pos.z);
      if (d < 3.2 || d > 46) continue;
      const lane = laneClearance(p.pos.x, p.pos.z, m.pos.x, m.pos.z, p, m);
      const free = Math.min(nearestOppTo(m.pos.x, m.pos.z), 10);
      const prog = (advance(m.pos.x) - myAdv);
      const threat = (1 - clampN(d2(m.pos.x, m.pos.z, gx, 0) / 62, 0, 1)) * 30;
      const spread = psPassSpread(p);
      const safeBase = Math.min(lane, 6) * 3.0 + free * 1.6;
      let s = prog * 0.85 * W.prog + threat * 0.55 * W.prog + safeBase * W.safe - Math.abs(d - 16) * 0.22;
      if (hasPS(p, 'Vision')) s += 4; // trusts the pass
      if (spread > 0) s -= spread * 60; // Thunder wrecks passing: don't pass
      // style/tactic synergies
      if (B.tactic === 'wings' && Math.abs(m.pos.z) > FIELD.halfWid - 12) s += 8;
      if (B.tactic === 'direct' && roleBand(m) === 'FWD') s += 9;
      if (B.tactic === 'possession') { s += d < 20 ? 5 : -6; if (prog < -2) s += 3; }
      if (B.tactic === 'counter' && roleBand(m) === 'FWD') s += 7;
      if (pressure < 2.6 && prog < -2) s += 4; // an honest back-pass under pressure is fine
      // ground
      if (lane > 1.7) opts.push({ kind: 'pass', mate: m, score: s, tag: 'pass' });
      else s -= 28 * W.safe;
      // through ball: receiver ahead of the ball and there is room behind the line
      const roomBehind = FIELD.halfLen - Math.abs(m.pos.x) > 12 && prog > 4;
      if (roomBehind && d > 8 && d < 38) {
        const tx = clampN(m.pos.x + dir * 9, -FIELD.halfLen + 3, FIELD.halfLen - 3), tz = m.pos.z * 0.8;
        const tl = laneClearance(p.pos.x, p.pos.z, tx, tz, p, m), runnerFree = nearestOppTo(tx, tz, null);
        let ts = prog * 0.9 * W.prog + threat * 0.7 * W.prog + Math.min(tl, 6) * 3 + Math.min(runnerFree, 9) * 2.2 - 6 / W.risk;
        if (hasPS(m, 'Target+')) ts += 14; else if (hasPS(m, 'Target')) ts += 9;
        if (hasPS(m, 'Accelerator') || hasPS(m, 'Rapid')) ts += 4;
        if (hasPS(p, 'Vision')) ts += 3;
        if (B.tactic === 'direct') ts += 6;
        if (spread > 0) ts -= spread * 60;
        if (tl > 1.5) opts.push({ kind: 'through', mate: m, score: ts, tag: 'through' });
      }
      // chip pass: ground lane blocked but receiver is free
      if (lane <= 1.7 && free > 4.5 && d > 10 && d < 38) {
        let cs = prog * 0.8 * W.prog + threat * 0.5 * W.prog + free * 2.4 - 3;
        if (hasPS(p, 'Chip Pass')) cs += 12;
        if (spread > 0) cs -= spread * 60;
        opts.push({ kind: 'chipPass', mate: m, score: cs, tag: 'chip' });
      }
    }

    // ---- cross ----
    const wide = Math.abs(p.pos.z) > 17 && advance(p.pos.x) > FIELD.halfLen * 0.28 && dGoal < 44;
    if (wide) {
      let inBox = 0, headers = 0, defs = 0;
      for (const q2 of players) {
        if (Math.abs(q2.pos.x - gx) < 17 && Math.abs(q2.pos.z) < 11) {
          if (q2.team === TEAM && q2 !== p) { inBox++; if (hasPS(q2, 'Power Header') || hasPS(q2, 'Header')) headers++; }
          else if (q2.team !== TEAM && !q2.isGK) defs++;
        }
      }
      if (inBox > 0) {
        let cr = 8 + inBox * 6 + headers * 7 - defs * 3.2 + (hasPS(p, 'Whipped Cross') ? 10 : 0);
        if (B.tactic === 'wings') cr += 12;
        if (B.mode === 'desperate' || B.mode === 'chase') cr += 6;
        if (spread0(p) > 0) cr -= spread0(p) * 40;
        opts.push({ kind: 'cross', score: cr * W.risk, tag: 'cross' });
      }
    }

    // ---- dribble / hold ----
    const heads = [[0, 0], [0.7, 1], [0.7, -1], [0.2, 1.3], [0.2, -1.3], [-0.3, 0]]; // [forward, sideways]
    let bestD = null, bds = -1e9;
    for (const [f, s2] of heads) {
      const tx = clampN(p.pos.x + dir * f * 9, -FIELD.halfLen + 2, FIELD.halfLen - 2);
      const tz = clampN(p.pos.z + s2 * 7, -FIELD.halfWid + 2, FIELD.halfWid - 2);
      const room = Math.min(nearestOppTo(tx, tz), 9), lane = Math.min(laneClearance(p.pos.x, p.pos.z, tx, tz, p, null), 6);
      const sc = room * 3.2 + lane * 2.2 + (advance(tx) - myAdv) * 1.1 * W.prog - (f < 0 ? 5 : 0);
      if (sc > bds) { bds = sc; bestD = { x: tx, z: tz }; }
    }
    const dribStat = clampN((p.stats.dribbling || 70) / 100, 0.4, 1.1);
    let ds = bds * (0.55 + 0.4 * dribStat) - 8 + (pressure > 4 ? 6 : 0);
    if (hasPS(p, 'Trickster')) ds += 4;
    if (psTargetBuff(p, 'dribbling') > 0) ds += 5;
    if (thunderOn) ds += 14; // sprinting with Thunder: run, don't pass
    opts.push({ kind: 'dribble', to: bestD, score: ds, tag: 'dribble' });

    // hold the ball in the corner when protecting a lead late
    if (W.hold && B.frac > 0.45 && advance(p.pos.x) > 0 && pressure > 3) {
      opts.push({ kind: 'dribble', to: { x: clampN(gx * 0.92, -FIELD.halfLen + 3, FIELD.halfLen - 3), z: Math.sign(p.pos.z || 1) * (FIELD.halfWid - 4) }, score: ds + 9, tag: 'hold' });
    }

    // ---- clear ----
    if (d2(p.pos.x, p.pos.z, ownGoalX(), 0) < 20 && pressure < 2.4) opts.push({ kind: 'clear', score: 22 + (B.mode === 'protect' ? 8 : 0), tag: 'clear' });
    return opts;
  }
  function spread0(p) { return psPassSpread(p); }

  function tryThunder(p) {
    const name = psThunderName(p);
    if (!name || p.thunderT > 0) return;
    const spec = PS_NEW_SPEC[name];
    if ((p.thunderUses || 0) >= spec.uses) return;
    const second = (p.thunderUses || 0) >= 1;
    const dGoal = d2(p.pos.x, p.pos.z, attackGoalX(TEAM), 0);
    const room = nearestOppTo(p.pos.x + atkSign() * 8, p.pos.z) > 7;       // space to run into
    const attackingThird = dGoal < 52 && dGoal > 16;
    let want = attackingThird && room && !(p.stamina < 45);
    if (second) want = want && (B.mode === 'chase' || B.mode === 'desperate' || B.frac > 0.7);
    if (!second && B.mode === 'cruise') want = false;                       // save it when comfortably ahead
    if (B.mode === 'desperate' && dGoal < 60 && room) want = true;
    if (want && Math.random() < 0.5) activateThunder(p, true);
  }

  function carrierAct(p, dt, diff) {
    p.decideTimer -= dt;
    if (p.decideTimer > 0) return;
    const sk = skill();
    p.decideTimer = (0.16 + rnd(0, 0.18)) * B.reactScale * (1.25 - 0.4 * sk);
    tryThunder(p);
    const opts = evaluateOptions(p);
    if (!opts.length) return orig.carrier(p, dt, diff);
    const noiseSd = (1 - sk) * 9 * (1 - 0.4 * B.boost) + 1.2;
    let best = null, bs = -1e9;
    for (const o of opts) { const s = o.score + rnd(-noiseSd, noiseSd); o._s = s; if (s > bs) { bs = s; best = o; } }
    const acc = clampN(diff.aiAcc * (1 + 0.06 * B.boost), 0.3, 1);
    switch (best.kind) {
      case 'shoot': case 'curl': case 'chip':
        performKick(p, best.kind, { power: clampN(best.power * (0.9 + 0.1 * acc), 0.5, 1) }); return;
      case 'pass': case 'through': case 'chipPass':
        performKick(p, best.kind, { target: best.mate }); return;
      case 'cross': performKick(p, 'cross', {}); return;
      case 'clear': performKick(p, 'clear', {}); return;
      case 'dribble':
        p.plan = { x: best.to.x, z: best.to.z, sprint: !(B.mode === 'protect' || B.mode === 'cruise') || best.tag !== 'hold', press: false };
        p._carryPlan = p.plan; p._carryUntil = match.clock + 0.45;
        return;
    }
  }

  /* ----------------------------- per-frame tick ------------------------- */
  function tick(dt) {
    if (match.clock < B.lastClock - 1) { // new match / restart
      B.mode = 'balanced'; B.tactic = 'possession'; B.hist = {}; B.log = []; B.asg.clear();
      B.scout = { flank: 0, flankN: 0, lineHeight: FIELD.halfLen * 0.4, shotDist: 22, shotN: 0, lastShots: 0 };
      pickTactic(true);
    }
    B.lastClock = match.clock;
    if (match.state !== 'play' || (DIFFS[settings.diff] || {}).trash) return;
    // goal conceded/scored -> re-read immediately
    if (match.score[0] !== B.lastScore[0] || match.score[1] !== B.lastScore[1]) { B.lastScore = match.score.slice(); readMatch(); evaluateTactic(); buildAssignments(); }
    if (match.clock - B.lastEval > 0.8) { B.lastEval = match.clock; readMatch(); scoutYou(); evaluateTactic(); }
    B.lastAsg += dt;
    if (B.lastAsg > 0.22 * B.reactScale) { B.lastAsg = 0; buildAssignments(); }
    for (const p of players) if (p._tkWait > 0) p._tkWait -= dt;
  }

  /* ------------------------------- install ------------------------------ */
  function safe(fn, fallback) {
    return function () {
      if (!B.enabled) return fallback.apply(this, arguments);
      try { return fn.apply(this, arguments); }
      catch (e) {
        B.failed++;
        console.warn('[ai.js] brain error (using classic AI for this call):', e);
        if (B.failed > 12) { B.enabled = false; console.warn('[ai.js] too many errors - brain disabled'); }
        return fallback.apply(this, arguments);
      }
    };
  }
  window.aiUpdate = function (dt) {
    if (B.enabled) { try { tick(dt); } catch (e) { B.failed++; console.warn('[ai.js] tick error', e); if (B.failed > 12) B.enabled = false; } }
    return orig.update(dt);
  };
  const decideSafe = safe(decide, orig.decide);
  window.aiDecide = function (p, diff) { return (p.team === TEAM && !diff.trash) ? decideSafe(p, diff) : orig.decide(p, diff); };
  const carrierSafe = safe(carrierAct, orig.carrier);
  window.aiCarrierAct = function (p, dt, diff) { return (p.team === TEAM && !diff.trash) ? carrierSafe(p, dt, diff) : orig.carrier(p, dt, diff); };
  B.tackle = safe(tackle, function (p) { if (Math.random() < 0.45) standingTackle(p); else slideTackle(p); });
  B.state = function () { return { mode: B.mode, tactic: B.tactic, lead: B.lead, boost: +B.boost.toFixed(2), hist: B.hist, scout: B.scout, log: B.log.slice(-12) }; };
  note('brain installed');
})();
