/* ==========================================================================
   UA STADIUM · ULTRA PRO MAX — integrated build
   --------------------------------------------------------------------------
   Replaces the old procedural stadium (pitch, stands, boards, goals, sky,
   floodlights) with the Ultra Pro Max stadium: striped + worn pitch texture,
   instanced wind-bending grass, tiered crowd (wave + camera flashes), verlet
   goal nets, day / dusk / night, 4 seasons, rain / snow / falling leaves and
   lightning.

   HOW IT FITS THE GAME
   - Everything is built in "design units" (15 per metre) inside one root group
     scaled by 1/15, so the game keeps its real-metre world. Pitch dimensions,
     goal size and line markings are all derived from FIELD (utils.js), so the
     white lines always match gameplay boundaries.
   - The standalone demo's ball / goal detection / score / camera / HUD are NOT
     used. The game owns those. This module only reads: ball, camera, match,
     settings. Hooks: goalHit(team) rings the net; the scoreboard reuses the
     game's drawBigScreen().
   - If build() throws, game.js falls back to the legacy stadium.

   TUNING: see LIGHT, FOG and QUALITY blocks below.
   ========================================================================== */
const UAStadium = (() => {
  const K = 15;                       // design units per metre
  const PI = Math.PI;
  const SEASONS = ['spring', 'summer', 'autumn', 'winter'];
  const TINT = [[1, 1.06, .95], [1.06, 1, .86], [1.12, .88, .62], [.86, .92, .94]];
  const TOD_PRESET = { day: 14, dusk: 17.6, night: 22 };
  const WX = 46.7, WY = 30;           // weather particle box (metres)

  // ---- tunables -----------------------------------------------------------
  const LIGHT = {                      // base intensities (match the game's original rig)
    hemi: 0.55, amb: 0.5, key: 2.3, fill: 0.7, spot: 2600,
    nightKey: 0.3,                     // key light loses this fraction at full night (spots + roof lights take over)
    nightFill: 0.35,                   // hemi/ambient GAIN at night (keeps pitch readable)
  };
  const FOG = { clear: [200, 900], rain: [60, 360], snow: [80, 420] };
  const QUALITY = {
    high: { tex: 2048, patches: 600, grass: 40000, crowdSp: 9.5, crowdSeg: [6, 6, 5], parts: 3200, flashes: 1800, stamps: true },
    low:  { tex: 1536, patches: 300, grass: 9000,  crowdSp: 26,  crowdSeg: [4, 4, 3], parts: 1200, flashes: 500,  stamps: false },
  };

  const st = { active: false, root: null, rig: null, Q: QUALITY.high, low: false };
  let U = null;
  let ptex = null, px = null, SK = 1;
  let grassMesh = null, grassGeo = null, grassMat = null;
  let crowd = null, crowdList = null;
  let goals = [], flags = [], adTex = [], roofLights = null;
  let weather = null;
  let skyMesh = null;
  let _dir = null;
  const sunVec = { x: 0, y: 1, z: 0 };

  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  const F = (n) => (Number.isInteger(n) ? n.toFixed(1) : String(n)); // GLSL float literal
  const NU = 22, NV = 14;

  /* ------------------------------------------------------------------ lights */
  function lights() {
    const touch = (typeof _isTouchGPU !== 'undefined') ? _isTouchGPU : false;
    const rig = {};
    rig.hemi = new THREE.HemisphereLight('#bfd8ff', '#1c3a20', LIGHT.hemi);
    rig.amb = new THREE.AmbientLight('#22334d', LIGHT.amb);
    const key = new THREE.DirectionalLight('#fff6e0', LIGHT.key);
    key.position.set(-40, 70, -30);
    key.castShadow = true;
    key.shadow.mapSize.set(touch ? 1024 : 2048, touch ? 1024 : 2048);
    key.shadow.camera.left = -70; key.shadow.camera.right = 70;
    key.shadow.camera.top = 60; key.shadow.camera.bottom = -60;
    key.shadow.camera.near = 10; key.shadow.camera.far = 200;
    key.shadow.bias = -0.0006;
    rig.key = key;
    rig.fill = new THREE.DirectionalLight('#9fc0ff', LIGHT.fill);
    rig.fill.position.set(50, 40, 40);
    scene.add(rig.hemi, rig.amb, rig.key, rig.fill);
    // Night floodlights: invisible spot sources (no tower meshes — the new bowl
    // sits where the old towers stood). Intensity is driven by time of day.
    rig.spots = [];
    for (const sx of [-1, 1]) for (const sz of [-1, 1]) {
      const spot = new THREE.SpotLight('#fff2cc', 0, 220, 0.62, 0.5, 1.8);
      spot.position.set(sx * (FIELD.halfLen + 14), 35, sz * (FIELD.halfWid + 12));
      spot.target.position.set(sx * (FIELD.halfLen - 6), 0, sz * (FIELD.halfWid - 2));
      scene.add(spot, spot.target);
      rig.spots.push(spot);
    }
    st.rig = rig;
    return rig;
  }

  /* ------------------------------------------------------------------- build */
  function build() {
    const q = settings.stadQuality || 'auto';
    const touch = (typeof _isTouchGPU !== 'undefined') ? _isTouchGPU : false;
    st.low = q === 'low' || (q === 'auto' && touch);
    st.Q = st.low ? QUALITY.low : QUALITY.high;
    const Q = st.Q;

    U = {
      uT: { value: 0 }, uJ: { value: 0 }, uW: { value: 0 }, uNight: { value: 0 }, uWet: { value: 0 },
      uSun: { value: new THREE.Vector3(0, 900, 400) }, uWarm: { value: 0 }, uOver: { value: 0 }, uFlash: { value: 0 },
      uTint: { value: new THREE.Vector3(1, 1, 1) }, uSnow: { value: 0 }, uFl: { value: 0 }, uLum: { value: 1 },
      uPx: { value: renderer.getPixelRatio() },
    };
    _dir = new THREE.Vector3();

    // design-unit dimensions, all derived from the game's FIELD
    const PL = FIELD.len * K, PW = FIELD.wid * K, HX = PL / 2, HZ = PW / 2;
    const GW = FIELD.goalW * K, GH = FIELD.goalH * K, GD = FIELD.goalDepth * K;
    const TX = HX + 120, TZ = HZ + 120, AX = HX + 60, BZ = HZ + 60, GR = 150;

    const root = new THREE.Group();
    root.scale.setScalar(1 / K);
    const canvasTex = (c, srgb = true) => { const t = new THREE.CanvasTexture(c); if (srgb) t.colorSpace = THREE.SRGBColorSpace; return t; };

    /* ---- sky dome ---- */
    skyMesh = new THREE.Mesh(new THREE.SphereGeometry(6000, 16, 8), new THREE.ShaderMaterial({
      side: THREE.BackSide, depthWrite: false, fog: false,
      uniforms: { uNight: U.uNight, uSun: U.uSun, uWarm: U.uWarm, uOver: U.uOver, uFlash: U.uFlash },
      vertexShader: 'varying vec3 p;void main(){p=position;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}',
      fragmentShader: 'varying vec3 p;uniform float uNight,uWarm,uOver,uFlash;uniform vec3 uSun;float hh(vec3 q){return fract(sin(dot(q,vec3(127.1,311.7,74.7)))*43758.5);}'
        + 'void main(){float h=clamp(normalize(p).y,0.,1.);vec3 d=mix(vec3(.78,.88,.98),vec3(.16,.4,.8),pow(h,.55));vec3 n=mix(vec3(.06,.08,.15),vec3(.01,.02,.06),pow(h,.5));vec3 c=mix(d,n,uNight);vec3 nn=normalize(p);'
        + 'float s=max(dot(nn,normalize(uSun)),0.);c+=mix(vec3(1.,.85,.6),vec3(1.,.4,.15),uWarm)*(pow(s,6.)*.3+pow(s,1200.)*4.)*(1.-uNight*.7)*(1.-uOver);'
        + 'c+=uNight*(1.-uOver)*step(.9985,hh(floor(nn*230.)))*step(.05,nn.y);float lu=dot(c,vec3(.3,.5,.2));c=mix(c,vec3(lu)*vec3(.82,.86,.92),uOver);c+=uFlash*vec3(.55,.6,.8);gl_FragColor=vec4(c,1.);}',
    }));
    skyMesh.renderOrder = -10;
    root.add(skyMesh);
    const outside = new THREE.Mesh(new THREE.PlaneGeometry(9000, 9000).rotateX(-PI / 2), new THREE.MeshLambertMaterial({ color: 0x4a4f55 }));
    outside.position.y = -0.6;
    root.add(outside);

    /* ---- pitch texture: stripes, patches, lines (from FIELD), wear ---- */
    const TW = Q.tex, TH = Math.round(TW * TZ / TX);
    SK = TW / (2 * TX);
    const pc = document.createElement('canvas'); pc.width = TW; pc.height = TH;
    px = pc.getContext('2d');
    for (let i = 0; i < 30; i++) { px.fillStyle = i % 2 ? '#2b7829' : '#3a8b34'; px.fillRect(i * TW / 30, 0, TW / 30 + 1, TH); }
    for (let i = 0; i < Q.patches; i++) {
      const a = Math.random() * TW, b = Math.random() * TH, r = 20 + Math.random() * 80, g = px.createRadialGradient(a, b, 0, a, b, r), l = Math.random() < .5;
      g.addColorStop(0, l ? 'rgba(130,200,70,.13)' : 'rgba(10,50,10,.16)'); g.addColorStop(1, 'rgba(0,0,0,0)');
      px.fillStyle = g; px.fillRect(a - r, b - r, 2 * r, 2 * r);
    }
    px.strokeStyle = px.fillStyle = 'rgba(255,255,255,.92)'; px.lineWidth = 3.4 * SK;
    {
      const X = (v) => (v + TX) * SK, Z = (v) => (v + TZ) * SK;
      const R = (a, b, w, h) => px.strokeRect(X(a), Z(b), w * SK, h * SK);
      const A = (x, z, r, a0, a1) => { px.beginPath(); px.arc(X(x), Z(z), r * SK, a0, a1); px.stroke(); };
      const Dt = (x, z) => { px.beginPath(); px.arc(X(x), Z(z), 5 * SK, 0, 7); px.fill(); };
      const bL = FIELD.boxLen * K, bW = FIELD.boxWid * K, sL = FIELD.sixLen * K, sW = FIELD.sixWid * K, cR = FIELD.circleR * K, pk = 11 * K;
      R(-HX, -HZ, PL, PW);
      px.beginPath(); px.moveTo(X(0), Z(-HZ)); px.lineTo(X(0), Z(HZ)); px.stroke();
      A(0, 0, cR, 0, 7); Dt(0, 0);
      [-1, 1].forEach((s) => {
        R(s > 0 ? HX - bL : -HX, -bW / 2, bL, bW);
        R(s > 0 ? HX - sL : -HX, -sW / 2, sL, sW);
        const sp = s * (HX - pk), ph = Math.acos((bL - pk) / cR);
        Dt(sp, 0); A(sp, 0, cR, s > 0 ? PI - ph : -ph, s > 0 ? PI + ph : ph);
        [-1, 1].forEach((t) => { const a0 = s > 0 ? (t > 0 ? PI : PI / 2) : (t > 0 ? 1.5 * PI : 0); A(s * HX, t * HZ, 15, a0, a0 + PI / 2); });
      });
      // goalmouth + centre-spot wear
      [-1, 1].forEach((s) => { stamp(s * (HX - 45), 0, 120, .5, 'rgba(95,70,40,A)'); stamp(s * (HX - pk), 0, 28, .5, 'rgba(95,70,40,A)'); });
      stamp(0, 0, 60, .4, 'rgba(95,70,40,A)');
    }
    ptex = canvasTex(pc); ptex.anisotropy = Math.min(8, renderer.capabilities.getMaxAnisotropy());
    st.dirty = false; st.lastStamp = 0;

    // Lit pitch (receives the game's player shadows) with season / snow / wet hooks.
    const gmat = new THREE.MeshStandardMaterial({ map: ptex, roughness: 0.95, metalness: 0 });
    gmat.onBeforeCompile = (sh) => {
      sh.uniforms.uTint = U.uTint; sh.uniforms.uSnow = U.uSnow; sh.uniforms.uWet = U.uWet;
      sh.fragmentShader = 'uniform vec3 uTint;uniform float uSnow,uWet;\nfloat uaH(vec2 p){return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5);}\n' + sh.fragmentShader
        .replace('#include <map_fragment>', '#include <map_fragment>\n diffuseColor.rgb*=.93+.14*uaH(floor(vMapUv*vec2(900.,600.)));\n diffuseColor.rgb*=uTint;\n diffuseColor.rgb=mix(diffuseColor.rgb,vec3(.75,.8,.9),uSnow*.75);\n diffuseColor.rgb*=mix(1.,.8,uWet);')
        .replace('#include <roughnessmap_fragment>', '#include <roughnessmap_fragment>\n roughnessFactor=mix(roughnessFactor,.4,uWet);');
    };
    const ground = new THREE.Mesh(new THREE.PlaneGeometry(2 * TX, 2 * TZ).rotateX(-PI / 2), gmat);
    ground.receiveShadow = true;
    root.add(ground);

    /* ---- instanced wind-bending grass (streams around the view) ---- */
    const gN = Q.grass;
    grassGeo = new THREE.InstancedBufferGeometry();
    grassGeo.setAttribute('position', new THREE.BufferAttribute(new Float32Array([-1, 0, 0, 1, 0, 0, 0, 1, 0]), 3));
    {
      const o = new Float32Array(gN * 2), r = new Float32Array(gN * 4);
      for (let i = 0; i < gN * 2; i++) o[i] = (Math.random() * 2 - 1) * GR;
      for (let i = 0; i < gN * 4; i++) r[i] = Math.random();
      grassGeo.setAttribute('aOff', new THREE.InstancedBufferAttribute(o, 2));
      grassGeo.setAttribute('aR', new THREE.InstancedBufferAttribute(r, 4));
      grassGeo.instanceCount = gN;
    }
    grassMat = new THREE.ShaderMaterial({
      side: THREE.DoubleSide,
      uniforms: { uTex: { value: ptex }, uC: { value: new THREE.Vector2() }, uT: U.uT, uWind: { value: 1 }, uBall: { value: new THREE.Vector3(0, 0, 0) }, uSp: { value: 0 },
        uNight: U.uNight, uWet: U.uWet, uTint: U.uTint, uSnow: U.uSnow, uLum: U.uLum },
      vertexShader: `attribute vec2 aOff;attribute vec4 aR;uniform vec2 uC;uniform float uT,uWind,uSp;uniform vec3 uBall;varying vec2 vUv;varying float vH,vR;
void main(){float S=${F(2 * GR)};vec2 w=aOff+S*floor((uC-aOff)/S+.5);float d=length(w-uC);float fade=1.-smoothstep(${F(GR * .65)},${F(GR)},d);
float inside=step(abs(w.x),${F(TX)})*step(abs(w.y),${F(TZ)});vec2 bd=w-uBall.xz;float bl=length(bd);float push=exp(-bl*bl/90.)*(1.-smoothstep(4.,16.,uBall.y));
float h=(1.3+aR.x*1.7)*fade*inside*(1.-.55*push);float a=aR.y*6.2832;vec2 dir=vec2(cos(a),sin(a));float y=position.y;
vec3 p=vec3(w.x,0.,w.y)+vec3(dir.x,0.,dir.y)*position.x*.3*(1.-y);
float wind=sin(uT*1.7+w.x*.02+w.y*.013)*.6+sin(uT*3.3+w.x*.09+aR.w*6.)*.25;float bend=y*y*h;
p.xz+=vec2(1.,.35)*(wind*uWind+.2)*bend*.9;p.xz+=(aR.z-.5)*bend*.6;p.xz+=normalize(bd+.001)*push*(1.+uSp*.03)*bend*1.2;p.y=y*h;
vUv=vec2(w.x/${F(2 * TX)}+.5,.5-w.y/${F(2 * TZ)});vH=y;vR=aR.x;gl_Position=projectionMatrix*modelViewMatrix*vec4(p,1.);}`,
      // uLum mirrors the lit pitch's brightness so blades blend into the ground at every time of day.
      fragmentShader: `varying vec2 vUv;varying float vH,vR;uniform sampler2D uTex;uniform float uNight,uWet,uSnow,uLum;uniform vec3 uTint;
void main(){vec3 c=texture2D(uTex,vUv).rgb;c*=.8+.5*vH+.1*vR;c+=vec3(.5,.6,.4)*pow(vH,3.)*.06*(1.+uWet*3.);
c*=uLum*mix(1.,.8,uWet);c*=uTint;c=mix(c,vec3(.75,.8,.9),uSnow*.75);gl_FragColor=vec4(c,1.);
#include <tonemapping_fragment>
#include <colorspace_fragment>
}`,
    });
    grassMesh = new THREE.Mesh(grassGeo, grassMat);
    grassMesh.frustumCulled = false;
    root.add(grassMesh);

    /* ---- stadium bowl ---- */
    const sg = (c) => Math.sign(c) * Math.pow(Math.abs(c), .74);
    const ringPt = (d, i, n) => { const a = i / n * 6.2832; return [(AX + d) * sg(Math.cos(a)), (BZ + d) * sg(Math.sin(a))]; };
    const loft = (rows, mat, seg, uv = [1, 1]) => {
      const pos = [], uvs = [], idx = [];
      rows.forEach((r, j) => { for (let i = 0; i <= seg; i++) { const p = ringPt(r[0], i, seg); pos.push(p[0], r[1], p[1]); uvs.push(i / seg * uv[0], j / (rows.length - 1) * uv[1]); } });
      for (let j = 0; j < rows.length - 1; j++) for (let i = 0; i < seg; i++) { const a = j * (seg + 1) + i, b = a + 1, c = a + seg + 1, d = c + 1; idx.push(a, c, b, b, c, d); }
      const g = new THREE.BufferGeometry();
      g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3)); g.setAttribute('uv', new THREE.Float32BufferAttribute(uvs, 2));
      g.setIndex(idx); g.computeVertexNormals();
      root.add(new THREE.Mesh(g, mat));
    };
    const seatC = document.createElement('canvas'); seatC.width = seatC.height = 16;
    { const x = seatC.getContext('2d'); x.fillStyle = '#1d3f8a'; x.fillRect(0, 0, 16, 16); x.fillStyle = '#14295c'; x.fillRect(0, 10, 16, 6); x.fillStyle = '#2f63c8'; x.fillRect(2, 2, 11, 6); }
    const seatT = canvasTex(seatC); seatT.wrapS = seatT.wrapT = THREE.RepeatWrapping;
    const DS = THREE.DoubleSide;
    const conc = new THREE.MeshLambertMaterial({ color: 0x8d939c, side: DS }), dark = new THREE.MeshLambertMaterial({ color: 0x1c2027, side: DS });
    const roofM = new THREE.MeshLambertMaterial({ color: 0x59616d, side: DS }), seatM = new THREE.MeshLambertMaterial({ map: seatT, side: DS });
    const SEG = st.low ? 120 : 240;
    loft([[60, 0], [60, 6]], conc, SEG); loft([[60, 6], [276, 150]], seatM, SEG, [380, 24]);
    loft([[276, 150], [276, 190], [300, 190]], conc, SEG); loft([[300, 190], [588, 382]], seatM, SEG, [400, 32]);
    loft([[600, 0], [600, 418]], dark, SEG); loft([[300, 440], [610, 420]], roofM, SEG);

    /* ---- crowd (bobbing, Mexican wave, goal jump) ---- */
    {
      const sp = Q.crowdSp, list = [];
      [[60, 6, 24], [300, 190, 32]].forEach(([d0, h0, n]) => {
        for (let j = 0; j < n; j++) {
          const d = d0 + 9 * j + 4.5, h = h0 + 6 * j + 3, seg = 900;
          let acc = 0, prev = ringPt(d, 0, seg), cnt = 0;
          for (let i = 1; i <= seg; i++) {
            const p = ringPt(d, i, seg); acc += Math.hypot(p[0] - prev[0], p[1] - prev[1]); prev = p;
            if (acc >= sp) { acc -= sp; cnt++; if (cnt % 36 > 1 && Math.random() > .06) list.push(p[0], h, p[1]); }
          }
        }
      });
      const n = list.length / 3;
      const patch = (m) => { m.onBeforeCompile = (s) => {
        s.uniforms.uT = U.uT; s.uniforms.uJ = U.uJ; s.uniforms.uW = U.uW;
        s.vertexShader = 'uniform float uT,uJ,uW;\n' + s.vertexShader.replace('#include <begin_vertex>',
          'vec3 transformed=position;vec4 ip=instanceMatrix[3];float ph=ip.x*.37+ip.z*.21;transformed.y+=abs(sin(uT*(2.+fract(ph)*2.)+ph*6.))*(.25+uJ*1.3)+max(0.,sin(uT*2.2-atan(ip.z,ip.x)*5.))*uW*.9;');
      }; };
      const mb = new THREE.MeshLambertMaterial(), mh = new THREE.MeshLambertMaterial(); patch(mb); patch(mh);
      const [cs, hw, hh] = Q.crowdSeg;
      const body = new THREE.InstancedMesh(new THREE.CylinderGeometry(.9, 1.15, 2.1, cs).translate(0, 1.05, 0), mb, n);
      const head = new THREE.InstancedMesh(new THREE.SphereGeometry(.75, hw, hh).translate(0, 2.9, 0), mh, n);
      const shirt = [0x1d4ed8, 0x1d4ed8, 0x1d4ed8, 0x2563eb, 0xffffff, 0xf1f5f9, 0xdc2626, 0xfbbf24, 0x111827, 0x10b981].map((c) => new THREE.Color(c));
      const skin = [0xf1c9a5, 0xe0ac85, 0xc68642, 0x8d5524, 0x5c3a21, 0xffdbb4].map((c) => new THREE.Color(c));
      const m4 = new THREE.Matrix4();
      for (let i = 0; i < n; i++) {
        const sc = 3.2 + Math.random() * .9;
        m4.makeScale(sc, sc * (.9 + Math.random() * .25), sc).setPosition(list[i * 3], list[i * 3 + 1], list[i * 3 + 2]);
        body.setMatrixAt(i, m4); head.setMatrixAt(i, m4);
        body.setColorAt(i, shirt[Math.random() * shirt.length | 0]); head.setColorAt(i, skin[Math.random() * skin.length | 0]);
      }
      body.frustumCulled = head.frustumCulled = false;
      root.add(body, head);
      crowd = { body, head, n, max: n }; crowdList = list;
    }

    /* ---- roof lights, ad boards, scoreboards, corner flags ---- */
    const dotC = document.createElement('canvas'); dotC.width = dotC.height = 32;
    { const x = dotC.getContext('2d'), g = x.createRadialGradient(16, 16, 0, 16, 16, 16); g.addColorStop(0, '#fff'); g.addColorStop(1, 'rgba(255,255,255,0)'); x.fillStyle = g; x.fillRect(0, 0, 32, 32); }
    const dotT = canvasTex(dotC, false);
    {
      const rl = []; for (let i = 0; i < 300; i++) { const p = ringPt(305, i, 300); rl.push(p[0], 432, p[1]); }
      const g = new THREE.BufferGeometry(); g.setAttribute('position', new THREE.Float32BufferAttribute(rl, 3));
      roofLights = new THREE.Points(g, new THREE.PointsMaterial({ map: dotT, size: 10 / K, color: 0xfff0c8, transparent: true, blending: THREE.AdditiveBlending, depthWrite: false }));
      root.add(roofLights);
    }
    const adC = document.createElement('canvas'); adC.width = 4096; adC.height = 96;
    {
      const x = adC.getContext('2d'); let o = 0;
      [['UA FC MOBILE', '#0b7a5a', '#34d399', 700], ['UA STUDIOS', '#241a5c', '#c4b5fd', 640], ['UA FC Mobile launching October 20th', '#0a2a6b', '#fbbf24', 1100], ['FSM:S1 launching soon...', '#7a1020', '#fdba74', 900], ['Play your best', '#161616', '#facc15', 756]].forEach(([t, a, b, w]) => {
        const g = x.createLinearGradient(o, 0, o + w, 96); g.addColorStop(0, a); g.addColorStop(1, '#000'); x.fillStyle = g; x.fillRect(o, 0, w, 96);
        x.fillStyle = b; x.fillRect(o, 0, 6, 96);
        let s = 56; x.font = `900 ${s}px system-ui,sans-serif`; while (x.measureText(t).width > w - 50) { s -= 2; x.font = `900 ${s}px system-ui,sans-serif`; }
        x.textAlign = 'center'; x.textBaseline = 'middle'; x.fillText(t, o + w / 2, 50); o += w;
      });
    }
    const adT = canvasTex(adC); adT.wrapS = THREE.RepeatWrapping;
    adTex = [];
    const board = (len, x, z, ry) => {
      const t = adT.clone(); t.needsUpdate = true; t.wrapS = THREE.RepeatWrapping; t.anisotropy = 4; t.repeat.set(len / 597, 1);
      const m = new THREE.Mesh(new THREE.PlaneGeometry(len, 14), new THREE.MeshBasicMaterial({ map: t, toneMapped: false }));
      m.position.set(x, 8, z); m.rotation.y = ry; root.add(m); adTex.push(t);
    };
    board(PL + 160, 0, HZ + 34, PI); board(PL + 160, 0, -HZ - 34, 0);
    board(2 * (HZ + 34), HX + 66, 0, -PI / 2); board(2 * (HZ + 34), -HX - 66, 0, PI / 2);

    // Scoreboards show the game's own live score/clock: reuse drawBigScreen().
    {
      const c = document.createElement('canvas'); c.width = 512; c.height = 288;
      bigScreenCtx = c.getContext('2d');
      bigScreenTex = canvasTex(c);
      const mat = new THREE.MeshBasicMaterial({ map: bigScreenTex, toneMapped: false });
      [-1, 1].forEach((s) => { const m = new THREE.Mesh(new THREE.PlaneGeometry(304, 171), mat); m.position.set(s * (HX + 350), 330, 0); m.rotation.y = -s * PI / 2; root.add(m); });
      drawBigScreen();
    }
    flags = [];
    [-1, 1].forEach((s) => [-1, 1].forEach((t) => {
      const pole = new THREE.Mesh(new THREE.CylinderGeometry(.5, .5, 24, 6), new THREE.MeshLambertMaterial({ color: 0xffffff })); pole.position.set(s * HX, 12, t * HZ); root.add(pole);
      const f = new THREE.Mesh(new THREE.PlaneGeometry(12, 8, 6, 2).translate(6, 0, 0), new THREE.MeshBasicMaterial({ color: 0xfacc15, side: DS })); f.position.set(s * HX, 20, t * HZ); root.add(f); flags.push(f);
    }));

    /* ---- goals: frame + verlet net (ripples on goalHit) ---- */
    goals = [];
    [-1, 1].forEach((s) => {
      const g = new THREE.Group(); g.position.x = s * HX; root.add(g);
      const m = new THREE.MeshStandardMaterial({ color: 0xf4f4f4, roughness: .35, metalness: .1 });
      const cy = (r, l) => new THREE.CylinderGeometry(r, r, l, 10);
      [-1, 1].forEach((t) => {
        const p = new THREE.Mesh(cy(1.4, GH), m); p.position.set(0, GH / 2, t * GW / 2); g.add(p);
        const b = new THREE.Mesh(cy(.8, Math.hypot(GD, GH)), m); b.position.set(s * GD / 2, GH / 2, t * GW / 2); b.rotation.z = -Math.atan2(s * GD, -GH); g.add(b);
      });
      const bar = new THREE.Mesh(cy(1.2, GW + 2.8), m); bar.rotation.x = PI / 2; bar.position.y = GH; g.add(bar);
      const nm = new THREE.LineBasicMaterial({ color: 0xffffff, transparent: true, opacity: .5 }), pos = new Float32Array(NU * NV * 3), idx = [];
      for (let i = 0; i < NU; i++) for (let j = 0; j < NV; j++) {
        const k = (i * NV + j) * 3; pos[k] = s * GD; pos[k + 1] = GH * j / (NV - 1); pos[k + 2] = -GW / 2 + GW * i / (NU - 1);
        if (i < NU - 1) idx.push(i * NV + j, (i + 1) * NV + j); if (j < NV - 1) idx.push(i * NV + j, i * NV + j + 1);
      }
      const geo = new THREE.BufferGeometry(); geo.setAttribute('position', new THREE.BufferAttribute(pos, 3)); geo.setIndex(idx); g.add(new THREE.LineSegments(geo, nm));
      const sp = [];
      for (let i = 0; i <= 12; i++) { const x = s * GD * i / 12; sp.push(x, GH, -GW / 2, x, GH, GW / 2); sp.push(x, 0, -GW / 2, x, GH, -GW / 2, x, 0, GW / 2, x, GH, GW / 2); }
      for (let i = 0; i <= NU; i++) { const z = -GW / 2 + GW * i / NU; sp.push(0, GH, z, s * GD, GH, z); }
      g.add(new THREE.LineSegments(new THREE.BufferGeometry().setAttribute('position', new THREE.Float32BufferAttribute(sp, 3)), nm));
      goals.push({ s, GW, GH, GD, geo, pos, d: new Float32Array(NU * NV), v: new Float32Array(NU * NV), energy: 0 });
    });

    /* ---- camera flashes in the stands ---- */
    {
      const m = Q.flashes, fp = new Float32Array(m * 3), fa = new Float32Array(m);
      for (let i = 0; i < m; i++) { const j = (Math.random() * crowdList.length / 3 | 0) * 3; fp[i * 3] = crowdList[j]; fp[i * 3 + 1] = crowdList[j + 1] + 10; fp[i * 3 + 2] = crowdList[j + 2]; fa[i] = Math.random(); }
      const fg = new THREE.BufferGeometry(); fg.setAttribute('position', new THREE.BufferAttribute(fp, 3)); fg.setAttribute('aP', new THREE.BufferAttribute(fa, 1));
      const pts = new THREE.Points(fg, new THREE.ShaderMaterial({
        transparent: true, depthWrite: false, blending: THREE.AdditiveBlending, uniforms: { uT: U.uT, uOn: U.uFl, uPx: U.uPx },
        vertexShader: 'attribute float aP;uniform float uT,uOn,uPx;varying float vA;void main(){vA=step(.985,fract(uT*.7+aP*37.))*uOn;gl_PointSize=vA>0.?22.*uPx:0.;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}',
        fragmentShader: 'varying float vA;void main(){float d=length(gl_PointCoord-.5);if(d>.5)discard;gl_FragColor=vec4(vec3(1.),(1.-d*2.)*vA);}',
      }));
      pts.frustumCulled = false; root.add(pts);
    }

    /* ---- weather particles (world space, metres): rain / snow / leaves ---- */
    {
      const NP = Q.parts, pl = new Float32Array(NP * 3), pq = new Float32Array(NP * 3);
      for (let i = 0; i < NP * 3; i++) pl[i] = Math.random() * (i % 3 === 1 ? WY : WX);
      const geo = new THREE.BufferGeometry(); geo.setAttribute('position', new THREE.BufferAttribute(pq, 3));
      const mat = new THREE.ShaderMaterial({
        transparent: true, depthWrite: false,
        uniforms: { uSize: { value: .15 }, uCol: { value: new THREE.Color(1, 1, 1) }, uScale: { value: 400 }, uMax: { value: 7 }, uA: { value: .8 } },
        vertexShader: 'uniform float uSize,uScale,uMax;void main(){vec4 mv=modelViewMatrix*vec4(position,1.);gl_PointSize=clamp(uSize*uScale/max(-mv.z,.1),1.,uMax);gl_Position=projectionMatrix*mv;}',
        fragmentShader: 'uniform vec3 uCol;uniform float uA;void main(){float d=length(gl_PointCoord-.5);if(d>.5)discard;gl_FragColor=vec4(uCol,uA*(1.-d*1.6));}',
      });
      const pts = new THREE.Points(geo, mat); pts.frustumCulled = false; pts.visible = false; scene.add(pts);
      weather = { NP, pl, pq, geo, mat, pts };
    }

    scene.add(root);
    st.root = root; st.active = true; st.ex = 0; st.hour = 15; st.lt = 6; st.roll = 0; st.lastVy = 0;
    st.gov = { acc: 0, n: 0 }; st.last = 0;
    env(10);   // snap environment to current settings before first frame
  }

  /* ------------------------------------------------------------- pitch wear */
  function stamp(x, z, r, a, c) {
    const a1 = (x + (FIELD.halfLen * K + 120)) * SK, b1 = (z + (FIELD.halfWid * K + 120)) * SK, rr = r * SK;
    const g = px.createRadialGradient(a1, b1, 0, a1, b1, rr);
    g.addColorStop(0, c.replace('A', a)); g.addColorStop(1, c.replace('A', 0));
    px.fillStyle = g; px.fillRect(a1 - rr, b1 - rr, rr * 2, rr * 2);
    st.dirty = true;
  }

  /* -------------------------------------------------------------- environment */
  function timeSet(h) {
    const a = (h - 6) / 12 * PI, sy = Math.sin(a), sx = Math.cos(a), day = clamp((sy + .12) / .4, 0, 1), w = sy > -.3 ? Math.max(0, 1 - Math.abs(sy) / .35) : 0;
    U.uSun.value.set(-sx * 800, sy * 900, 400);
    U.uWarm.value = w;
    const vx = -sx * .8, vy = Math.max(sy, .3), vz = .4, l = Math.hypot(vx, vy, vz);
    sunVec.x = vx / l; sunVec.y = vy / l; sunVec.z = vz / l;
    return 1 - day;
  }

  function env(dt) {
    const t = U.uT.value, k = Math.min(1, dt * 1.5), rig = st.rig;
    const wx = settings.weather || 'clear';
    let si = SEASONS.indexOf(settings.season || 'summer'); if (si < 0) si = 1;

    // time of day
    let tgt;
    if (settings.tod === 'auto') tgt = 15 + clamp(match.clock / (2 * (settings.halfDur || 180)), 0, 1) * 5.5;
    else tgt = TOD_PRESET[settings.tod] !== undefined ? TOD_PRESET[settings.tod] : TOD_PRESET.day;
    st.hour += (tgt - st.hour) * Math.min(1, dt * 1.2);
    const night = timeSet(st.hour);
    U.uNight.value = night;

    // weather state
    U.uOver.value += ((wx === 'rain' ? .75 : wx === 'snow' ? .5 : 0) - U.uOver.value) * k;
    U.uWet.value += (((settings.wetPitch || wx === 'rain') ? 1 : 0) - U.uWet.value) * k;
    const T = TINT[si], c = U.uTint.value;
    c.x += (T[0] - c.x) * k; c.y += (T[1] - c.y) * k; c.z += (T[2] - c.z) * k;
    const snTgt = si === 3 ? (wx === 'snow' ? .9 : .3) : (wx === 'snow' ? .25 : 0);
    U.uSnow.value += (snTgt - U.uSnow.value) * dt * .5;
    grassMat.uniforms.uWind.value = .8 + .6 * Math.sin(t * .35) * Math.sin(t * .13) + (wx === 'rain' ? .9 : 0);
    U.uW.value += ((settings.wave ? 1 : 0) - U.uW.value) * Math.min(1, dt * 2);

    // lightning (rain only)
    if (wx === 'rain') { st.lt -= dt; if (st.lt <= 0) { U.uFlash.value = 1; st.lt = 7 + Math.random() * 14; } }
    U.uFlash.value *= Math.exp(-5 * dt);
    const fl = U.uFlash.value, ov = U.uOver.value;

    // lighting rig follows time of day + weather
    rig.hemi.intensity = LIGHT.hemi * (1 + LIGHT.nightFill * night) * (1 - .15 * ov) + fl * 1.3;
    rig.amb.intensity = LIGHT.amb * (1 + LIGHT.nightFill * .85 * night);
    rig.key.intensity = LIGHT.key * (1 - LIGHT.nightKey * night) * (1 - .35 * ov);
    rig.fill.intensity = LIGHT.fill * (1 - .3 * night);
    const w = U.uWarm.value;
    // warm at golden hour, cool floodlight-white at night
    rig.key.color.setRGB((1) * (1 - night) + .7 * night, (1 - .28 * w) * (1 - night) + .8 * night, (1 - .55 * w) * (1 - night) + 1 * night);
    rig.key.position.set(sunVec.x * 85, sunVec.y * 85, sunVec.z * 85);
    const spotI = LIGHT.spot * Math.pow(night, 1.2) * (1 + .3 * ov);
    for (const s of rig.spots) s.intensity = spotI;
    U.uLum.value = rig.key.intensity * sunVec.y / PI + (rig.hemi.intensity * .9 + rig.amb.intensity) / PI + rig.fill.intensity * .1 / PI;
    roofLights.material.size = (10 + 20 * night) / K;
    roofLights.material.opacity = .55 + .45 * night;

    // fog + background track sky horizon / weather
    const fr = FOG[wx] || FOG.clear, f = scene.fog;
    if (f) {
      f.near += (fr[0] - f.near) * k; f.far += (fr[1] - f.far) * k;
      const dayAmt = 1 - night;
      const r = (.78 * (1 - ov) + .66 * ov) * dayAmt + .02 * night, gg = (.88 * (1 - ov) + .7 * ov) * dayAmt + .04 * night, b = (.98 * (1 - ov) + .75 * ov) * dayAmt + .09 * night;
      f.color.setRGB(r, gg, b, THREE.SRGBColorSpace);
      if (scene.background && scene.background.setRGB) scene.background.setRGB(r, gg, b, THREE.SRGBColorSpace);
    }

    // crowd excitement + flashes
    st.ex = Math.max(0, st.ex - dt * .25);
    U.uJ.value = st.ex;
    U.uFl.value = settings.flashes ? ((night > .35 || st.ex > .3) ? 1 : 0) : 0;

    // seasonal particles
    const ty = wx === 'rain' ? 1 : wx === 'snow' ? 2 : (si === 2 ? 3 : 0);
    weatherUpdate(dt, t, ty);
  }

  function weatherUpdate(dt, t, ty) {
    const W = weather;
    W.pts.visible = ty > 0;
    if (!ty) return;
    const u = W.mat.uniforms;
    u.uSize.value = [0, .15, .2, .27][ty]; u.uA.value = [0, .7, .9, .95][ty];
    u.uCol.value.setRGB(...[[0, 0, 0], [.74, .83, 1], [1, 1, 1], [.85, .51, .17]][ty]);
    u.uScale.value = renderer.domElement.height / 2;
    const vy = [0, -28, -2.3, -1.5][ty], wd = grassMat.uniforms.uWind.value, cp = camera.position, pl = W.pl, pq = W.pq;
    for (let i = 0; i < W.NP; i++) {
      const k = i * 3;
      pl[k + 1] += vy * dt; if (pl[k + 1] < 0) pl[k + 1] += WY;
      pl[k] += (ty === 1 ? -4.7 * wd : Math.sin(t * .8 + i) * .9 * wd) * dt;
      pl[k + 2] += (ty === 3 ? Math.cos(t * .7 + i) * .9 : 0) * dt;
      pl[k] = (pl[k] % WX + WX) % WX; pl[k + 2] = (pl[k + 2] % WX + WX) % WX;
      pq[k] = cp.x + pl[k] - WX / 2; pq[k + 1] = pl[k + 1]; pq[k + 2] = cp.z + pl[k + 2] - WX / 2;
    }
    W.geo.attributes.position.needsUpdate = true;
  }

  /* -------------------------------------------------------------------- nets */
  function netStep(o, dt) {
    const { d, v, pos, s, GD } = o;
    for (let i = 1; i < NU - 1; i++) for (let j = 1; j < NV - 1; j++) { const k = i * NV + j, lap = (d[k - NV] + d[k + NV] + d[k - 1] + d[k + 1]) / 4 - d[k]; v[k] += (-12 * d[k] + 160 * lap) * dt; v[k] *= 1 - 2.2 * dt; }
    for (let i = 1; i < NU - 1; i++) for (let j = 1; j < NV - 1; j++) { const k = i * NV + j; d[k] += v[k] * dt; pos[k * 3] = s * (GD + d[k]); }
    o.geo.attributes.position.needsUpdate = true;
  }
  function netHit(o, z, y, sp) {
    sp = Math.min(sp, 450);
    for (let i = 1; i < NU - 1; i++) for (let j = 1; j < NV - 1; j++) {
      const dz = z - (-o.GW / 2 + o.GW * i / (NU - 1)), dy = y - o.GH * j / (NV - 1), r = Math.hypot(dz, dy);
      if (r < 45) o.v[i * NV + j] += sp * .22 * (1 - r / 45);
    }
    o.energy = 3;
  }

  /* ------------------------------------------------------------------ update */
  function update() {
    if (!st.active) return;
    const now = performance.now();
    const rawDt = Math.min(.05, (now - (st.last || now)) / 1000 || .016); st.last = now;
    U.uT.value += rawDt;
    env(rawDt);

    // grass: follows the view; bends around the live ball
    const cp = camera.position, u = grassMat.uniforms;
    if (cp.y < 10) { camera.getWorldDirection(_dir); const l = Math.hypot(_dir.x, _dir.z) || 1; u.uC.value.set((cp.x + _dir.x / l * 7.3) * K, (cp.z + _dir.z / l * 7.3) * K); }
    else u.uC.value.set(camState.look.x * K, camState.look.z * K);
    let spd = 0;
    if (ball) {
      spd = ball.vel.length();
      u.uBall.value.set(ball.pos.x * K, ball.pos.y * K, ball.pos.z * K);
      u.uSp.value = spd * K;
      if (st.Q.stamps) {
        st.roll -= rawDt;
        const onGround = ball.pos.y <= PHYS.ballRadius + .08;
        if (onGround && st.lastVy < -4 && ball.vel.y > 0) stamp(ball.pos.x * K, ball.pos.z * K, 9, .22, 'rgba(70,50,30,A)');
        else if (onGround && spd > 4 && st.roll <= 0) { st.roll = .09; stamp(ball.pos.x * K, ball.pos.z * K, 6, .05, 'rgba(40,70,25,A)'); }
        st.lastVy = ball.vel.y;
      }
    }
    if (st.dirty && now - st.lastStamp > 250) { ptex.needsUpdate = true; st.dirty = false; st.lastStamp = now; }

    // flags, scrolling ads, nets
    for (let i = 0; i < flags.length; i++) {
      const a = flags[i].geometry.attributes.position;
      for (let k = 0; k < a.count; k++) { const uu = a.getX(k) / 12; a.setZ(k, Math.sin(U.uT.value * 7 + uu * 9 + i) * 2.2 * uu); }
      a.needsUpdate = true;
    }
    for (const tx of adTex) tx.offset.x += rawDt * .015;
    for (const o of goals) if (o.energy > 0) { o.energy -= rawDt; netStep(o, rawDt); }

    // adaptive quality: shed grass, then crowd, if the frame rate is struggling in a live match
    if (match.screen === 'match' && !match.paused && !document.hidden) {
      const g = st.gov; g.acc += rawDt; g.n++;
      if (g.n >= 120) {
        if (g.acc / g.n > .024) {
          if (grassGeo.instanceCount > 3000) grassGeo.instanceCount = Math.floor(grassGeo.instanceCount * .7);
          else if (crowd.body.count > crowd.max * .25) crowd.body.count = crowd.head.count = Math.floor(crowd.body.count * .8);
        }
        g.acc = 0; g.n = 0;
      }
    }
  }

  /* --------------------------------------------------------------- public API */
  function goalHit(team) {
    if (!st.active) return;
    const o = goals.find((g) => g.s === (team === 0 ? 1 : -1));
    if (!o) return;
    if (ball) netHit(o, ball.pos.z * K, ball.pos.y * K, Math.max(120, ball.vel.length() * K));
    st.ex = 1;
    if (st.Q.stamps) stamp(o.s * (FIELD.halfLen * K - 45), 0, 90, .12, 'rgba(95,70,40,A)');
  }
  function abort() {
    st.active = false;
    if (st.root && st.root.parent) st.root.parent.remove(st.root);
    if (weather && weather.pts && weather.pts.parent) weather.pts.parent.remove(weather.pts);
    st.root = null;
  }
  function fail(e) { ; st.active = false; }

  return { lights, build, update, goalHit, abort, fail, get active() { return st.active; } };
})();
