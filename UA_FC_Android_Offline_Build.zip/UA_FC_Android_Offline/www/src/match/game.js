function freshMatchStats() {
  return {
    shots: [0, 0], passes: [0, 0], tackles: [0, 0], fouls: [0, 0],
    yellows: [0, 0], reds: [0, 0], corners: [0, 0], poss: [0, 0],
    saves: [0, 0], onTarget: [0, 0],
  };
}
const match = {
  screen: 'load', state: 'idle', half: 1, clock: 0, timeScale: 1, slowmoT: 0,
  score: [0, 0], kickTeam: 0, restartType: 'kickoff', restartTeam: 0,
  awaitUser: false, restartTimer: 0, lastTouchTeam: -1, lastTouchPlayer: null,
  possTeam: 0, stats: freshMatchStats(), goalTimer: 0, goalTeam: -1, paused: false, over: false,
  pendingTaker: null, goalAge: 0, goalFxT: 0, introT: 0, halfScore: null,
  lastPasser: null, playerStats: {}, goalScorers: [],
  stateAge: 0, watchdogState: null,
};
/* Self-healing watchdog: if any non-'play' state overstays a sane max
   duration (e.g. a timer got skipped, a flag desynced, controlled went
   stale), force the match back into a safe state instead of hanging
   forever. This is a backstop on top of the direct fixes above, not a
   replacement for them. */
const STATE_MAX_AGE = { goal: 8, setpiece: 12, halftime: 9999, fulltime: 9999, idle: 9999, play: 9999 };
function watchdogTick(rawDt) {
  if (REPLAY.playing) return; // don't let the watchdog fire mid-replay — playback legitimately holds the match state open longer than normal
  if (match.watchdogState !== match.state) { match.watchdogState = match.state; match.stateAge = 0; }
  else match.stateAge += rawDt;
  const max = STATE_MAX_AGE[match.state] ?? 20;
  if (match.stateAge > max) {
    ;
    match.paused = false;
    $('scr-pause') && $('scr-pause').classList.add('hidden');
    if (match.state === 'goal') {
      endGoalCelebration();
    } else if (match.state === 'setpiece') {
      match.awaitUser = false;
      match.restartTimer = 0.05;
    }
    match.stateAge = 0;
  }
}
function freshStats() {
  return { shots: [0, 0], onTarget: [0, 0], passes: [0, 0], tackles: [0, 0], poss: [1, 1], corners: [0, 0], saves: [0, 0], fouls: [0, 0], yellows: [0, 0], reds: [0, 0] };
}
function trackStat(p, key, amt = 1) {
  if (!p) return;
  const k = p.name + '|' + p.team;
  if (!match.playerStats[k]) {
    match.playerStats[k] = {
      name: p.name, team: p.team, goals: 0, assists: 0, saves: 0, tackles: 0,
      passes: 0, shots: 0, rating: 6.0, pos: p.role, ovr: p.ovr, regId: p._regId || null,
    };
  }
  match.playerStats[k][key] += amt;
}
const input = { mx: 0, my: 0, sprint: false, charging: false, power: 0 };
let lastMoveDir = { x: 0, z: 1 };
let flickCd = 0;
let elapsedT = 0;
let flashTimer = 1;
let bsTimer = 0;
let crowdTimer = 0;
let revealTO = null;
let chain = [0, 0];
let passStreak = [0, 0];
let lastPossTeam = -1;
let netShake = 0;
let netShakeSide = 1;
let perfectTrailT = 0;
let curlTrailT = 0;
let goalCountByName = {};
let onFireNotified = false;
let lastRunTap = 0;
let fpsAcc = 0, fpsFrames = 0, fpsLast = performance.now();

let renderer, scene, camera;
let players = [];
let teamDefs = [null, null];
let squads = [null, null];
let benches = [null, null]; // [homeReserves[5], awayReserves[5]] — see generateBench()
let subsUsed = [0, 0];      // per-team sub count this match, capped at 5
let ball = null;
let controlled = null;
let controlledP2 = null;


/* Networked-match mode:
   'off'   -> normal single-player, zero behavior change anywhere.
   'host'  -> this device runs the real sim; team 1's active player takes
              guest input instead of AI; sim state is streamed to guest.
   'guest' -> this device sends input only; ball/players/score are painted
              directly from host snapshots — no local physics runs. */
const NET = { mode: 'off', lastSnapT: 0, snapHz: 20, seq: 0, lastAppliedSeq: -1, guestOrigKit: null };
/* The single choke point for "which local variable is the human-controlled
   player for team N". Off-network: only team 0 is ever human (unchanged
   behavior, controlledP2 stays null and this always returns 'controlled').
   On a host during a networked match: team 0 is the host's own player,
   team 1 is the remote guest's player (driven by their input, see
   applyRemoteInputToTeam1). Kept as one function so every one of the ~15
   restart/goal/set-piece call sites that used to hardcode "team 0 controlled"
   route through the same place instead of being patched ad hoc. */
function humanSlotForTeam(team) {
  if (team === 0) return 'controlled';
  return (NET.mode === 'host') ? 'controlledP2' : null; // null = AI still owns team 1 (normal single-player)
}
function setHumanControlled(team, player) {
  const slot = humanSlotForTeam(team);
  if (slot === 'controlled') controlled = player;
  else if (slot === 'controlledP2') controlledP2 = player;
}
function isHumanControlledTeam(team) { return humanSlotForTeam(team) !== null; }
let indicator = null;
let shakeAmt = 0;
let aiThinkTimer = 0;
let switchCooldown = 0;
let trickIndex = 0;
let camAz = 0;
let referee = null;
let linesmen = [];
let bigScreenCtx = null;
let bigScreenTex = null;
const crowdTiers = [];
const backNets = {};
const TRICKS = ['STEPOVER', 'BALL ROLL', 'ROULETTE', 'RAINBOW FLICK', 'NUTMEG RUSH', 'LA CROQUETA'];
const scrollAdMats = [];
const waveFlags = [];
/* ==========================================================================
   04 · THREE SETUP
   ========================================================================== */
// On desktop the game renders inside a CSS-scaled 1280x720 frame
// (#desktop-frame — see the inline bootstrap script and ui.css), so Three.js
// must size/aspect its canvas to that logical resolution, not the raw
// browser window, or the 3D scene would misalign with the 2D UI on top of it.
function getGameViewportSize() {
  if (document.body.classList.contains('pc-framed')) return { w: 1280, h: 720 };
  return { w: window.innerWidth, h: window.innerHeight };
}
const _isTouchGPU = ('ontouchstart' in window) || navigator.maxTouchPoints > 0;
function initThree() {
  // Phones: native devicePixelRatio (often 2.6-3.5) + MSAA + soft shadows is
  // far too heavy and gave ~15 FPS. On touch devices render at a capped
  // pixel ratio with no MSAA; desktop keeps the original high-quality path.
  renderer = new THREE.WebGLRenderer({ canvas: $('game-canvas'), antialias: !_isTouchGPU, powerPreference: 'high-performance' });
  renderer.setPixelRatio(_isTouchGPU ? Math.min(window.devicePixelRatio, 1.25) : Math.min(window.devicePixelRatio, 2));
  const vp0 = getGameViewportSize();
  renderer.setSize(vp0.w, vp0.h);
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = _isTouchGPU ? THREE.PCFShadowMap : THREE.PCFSoftShadowMap;
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1.15;
  scene = new THREE.Scene();
  scene.background = new THREE.Color('#071022');
  scene.fog = new THREE.Fog('#071022', 110, 250);
  camera = new THREE.PerspectiveCamera(settings.camFov, vp0.w / vp0.h, 0.1, 1200);
  camera.position.set(0, 30, 52);
}
function addSceneLights() {
  try { UAStadium.lights(); }
  catch (e) { ; addSceneLightsLegacy(); }
}
function addSceneLightsLegacy() {
  scene.add(new THREE.HemisphereLight('#bfd8ff', '#1c3a20', 0.55));
  scene.add(new THREE.AmbientLight('#22334d', 0.5));
  const key = new THREE.DirectionalLight('#fff6e0', 2.3);
  key.position.set(-40, 70, -30);
  key.castShadow = true;
  key.shadow.mapSize.set(_isTouchGPU ? 1024 : 2048, _isTouchGPU ? 1024 : 2048);
  key.shadow.camera.left = -70;
  key.shadow.camera.right = 70;
  key.shadow.camera.top = 60;
  key.shadow.camera.bottom = -60;
  key.shadow.camera.near = 10;
  key.shadow.camera.far = 200;
  key.shadow.bias = -0.0006;
  scene.add(key);
  const fill = new THREE.DirectionalLight('#9fc0ff', 0.7);
  fill.position.set(50, 40, 40);
  scene.add(fill);
  buildFloodlights();
}

/* ==========================================================================
   05 · TEXTURES
   ========================================================================== */
function canvasTex(w, h, draw) {
  const c = document.createElement('canvas');
  c.width = w; c.height = h;
  const g = c.getContext('2d');
  draw(g, w, h);
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  t.anisotropy = 8;
  return t;
}
/* Direct port of PLAYER_MODEL_EDITOR.html's updateSkinFaceTexture(): a flat
   fill of the chosen skin tone plus subtle pore noise, used as the map for
   the whole rigged body's skin material (head, neck, arms). This replaces
   the game's own separate faceTexture() decal (eyebrows/hairline baked into
   a flat plane) — that was a different, game-only texture never present in
   the editor, so using it here would still leave a visible old-model trace
   even with the new geometry. */
function editorSkinTexture(skinHex) {
  return canvasTex(512, 512, (g, w, h) => {
    g.fillStyle = skinHex;
    g.fillRect(0, 0, w, h);
    g.fillStyle = 'rgba(0,0,0,0.03)';
    for (let i = 0; i < 600; i++) g.fillRect(Math.random() * w, Math.random() * h, 1.5, 1.5);
  });
}
function grassTexture() {
  return canvasTex(1024, 680, (g, w, h) => {
    const stripes = 14;
    const sw = w / stripes;
    for (let i = 0; i < stripes; i++) {
      g.fillStyle = i % 2 === 0 ? '#2f9441' : '#26823a';
      g.fillRect(i * sw, 0, sw + 1, h);
    }
    for (let i = 0; i < 3200; i++) {
      g.fillStyle = `rgba(${randInt(20, 60)},${randInt(120, 175)},${randInt(40, 70)},0.16)`;
      g.fillRect(rand(w), rand(h), rand(1, 3), rand(1, 3));
    }
    g.strokeStyle = 'rgba(255,255,255,0.94)';
    g.lineWidth = 5;
    const mx = w * 0.028, my = h * 0.045;
    const pw2 = w - mx * 2, ph = h - my * 2;
    g.strokeRect(mx, my, pw2, ph);
    g.beginPath(); g.moveTo(w / 2, my); g.lineTo(w / 2, my + ph); g.stroke();
    g.beginPath(); g.arc(w / 2, h / 2, (FIELD.circleR / FIELD.wid) * ph, 0, Math.PI * 2); g.stroke();
    g.beginPath(); g.arc(w / 2, h / 2, 6, 0, Math.PI * 2); g.fillStyle = 'rgba(255,255,255,0.94)'; g.fill();
    const bx = (FIELD.boxLen / FIELD.len) * pw2;
    const bw = (FIELD.boxWid / FIELD.wid) * ph;
    const sx = (FIELD.sixLen / FIELD.len) * pw2;
    const sw2 = (FIELD.sixWid / FIELD.wid) * ph;
    for (const side of [0, 1]) {
      const x0 = side === 0 ? mx : mx + pw2;
      const dir = side === 0 ? 1 : -1;
      g.strokeRect(Math.min(x0, x0 + dir * bx), h / 2 - bw / 2, bx, bw);
      g.strokeRect(Math.min(x0, x0 + dir * sx), h / 2 - sw2 / 2, sx, sw2);
      const px = x0 + dir * (11 / FIELD.len) * pw2;
      g.beginPath(); g.arc(px, h / 2, 5, 0, Math.PI * 2); g.fill();
    }
  });
}
function crowdTexture(teamA, teamB) {
  return canvasTex(1024, 512, (g, w, h) => {
    g.fillStyle = '#12182a';
    g.fillRect(0, 0, w, h);
    const palette = [teamA, teamB, '#e8e8e8', '#31405c', '#c9a24b', '#7d8aa5', teamA, teamB];
    for (let y = 10; y < h; y += 9) {
      for (let x = 6; x < w; x += 8) {
        const jx = x + ((y / 9) % 2) * 4 + rand(-1, 1);
        g.fillStyle = pick(palette);
        g.globalAlpha = rand(0.55, 1);
        g.beginPath();
        g.arc(jx, y + rand(-1, 1), rand(1.8, 2.9), 0, Math.PI * 2);
        g.fill();
      }
    }
    g.globalAlpha = 1;
  });
}
function adTexture(text, bg, fg) {
  return canvasTex(512, 96, (g, w, h) => {
    g.fillStyle = bg;
    g.fillRect(0, 0, w, h);
    g.fillStyle = fg;
    g.font = '700 52px Rajdhani, sans-serif';
    g.textAlign = 'center';
    g.textBaseline = 'middle';
    g.fillText(text, w / 2, h / 2 + 4);
    g.fillText(text, w / 2 + w, h / 2 + 4);
  });
}
function kitTexture(teamDef) {
  return canvasTex(256, 256, (g, w, h) => {
    g.fillStyle = teamDef.c1;
    g.fillRect(0, 0, w, h);
    g.fillStyle = teamDef.c2;
    if (teamDef.pat === 'stripes') { for (let x = 16; x < w; x += 64) g.fillRect(x, 0, 26, h); }
    else if (teamDef.pat === 'hoops') { for (let y = 20; y < h; y += 64) g.fillRect(0, y, w, 26); }
    else if (teamDef.pat === 'sash') {
      g.save(); g.translate(w / 2, h / 2); g.rotate(-0.6); g.fillRect(-w, -26, w * 2, 52); g.restore();
    }
  });
}
function numberTexture(num, color) {
  return canvasTex(128, 128, (g, w, h) => {
    g.clearRect(0, 0, w, h);
    if (num === '' || num === undefined) return;
    g.fillStyle = color;
    g.font = '700 88px Rajdhani, sans-serif';
    g.textAlign = 'center';
    g.textBaseline = 'middle';
    g.strokeStyle = 'rgba(0,0,0,0.55)';
    g.lineWidth = 8;
    g.strokeText(String(num), w / 2, h / 2 + 6);
    g.fillText(String(num), w / 2, h / 2 + 6);
  });
}
function ballTexture() {
  return canvasTex(256, 256, (g, w, h) => {
    g.fillStyle = '#ffffff';
    g.fillRect(0, 0, w, h);
    g.fillStyle = '#101418';
    for (let y = 0; y < 4; y++) {
      for (let x = 0; x < 4; x++) {
        const cx = (x + (y % 2) * 0.5) * (w / 4) + w / 8;
        const cy = y * (h / 4) + h / 8;
        g.beginPath();
        for (let i = 0; i < 5; i++) {
          const a = (i / 5) * Math.PI * 2 - Math.PI / 2;
          const px = cx + Math.cos(a) * 20;
          const py = cy + Math.sin(a) * 20;
          if (i === 0) g.moveTo(px, py); else g.lineTo(px, py);
        }
        g.closePath();
        g.fill();
      }
    }
  });
}
function crestTexture(teamDef) {
  return canvasTex(128, 144, (g, w, h) => {
    g.clearRect(0, 0, w, h);
    g.beginPath();
    g.moveTo(w / 2, 6); g.lineTo(w - 8, 26); g.lineTo(w - 12, h * 0.62);
    g.lineTo(w / 2, h - 6); g.lineTo(12, h * 0.62); g.lineTo(8, 26);
    g.closePath();
    g.fillStyle = teamDef.c1;
    g.fill();
    g.lineWidth = 6;
    g.strokeStyle = teamDef.c2;
    g.stroke();
    g.fillStyle = contrastText(teamDef.c1);
    g.font = '700 44px Rajdhani, sans-serif';
    g.textAlign = 'center';
    g.textBaseline = 'middle';
    g.fillText(teamDef.abbr, w / 2, h * 0.34);
  });
}
function tifoTexture(txt, c1, c2) {
  return canvasTex(512, 128, (g, w, h) => {
    const grad = g.createLinearGradient(0, 0, w, 0);
    grad.addColorStop(0, c1);
    grad.addColorStop(0.5, c2);
    grad.addColorStop(1, c1);
    g.fillStyle = grad;
    g.fillRect(0, 0, w, h);
    g.fillStyle = 'rgba(255,255,255,0.92)';
    g.font = '700 74px Rajdhani, sans-serif';
    g.textAlign = 'center';
    g.textBaseline = 'middle';
    g.strokeStyle = 'rgba(0,0,0,.5)';
    g.lineWidth = 8;
    g.strokeText(txt, w / 2, h / 2);
    g.fillText(txt, w / 2, h / 2);
  });
}

/* ==========================================================================
   06 · STADIUM
   ========================================================================== */
function buildStadium() {
  try { UAStadium.build(); }
  catch (e) {
    ;
    try { UAStadium.abort(); } catch (e2) {}
    buildStadiumLegacy();
  }
}
function buildStadiumLegacy() {
  const stadium = new THREE.Group();
  scene.add(stadium);
  const apron = new THREE.Mesh(new THREE.PlaneGeometry(220, 160), new THREE.MeshStandardMaterial({ color: '#17301c', roughness: 1 }));
  apron.rotation.x = -Math.PI / 2;
  apron.position.y = -0.02;
  apron.receiveShadow = true;
  stadium.add(apron);
  const pitch = new THREE.Mesh(new THREE.PlaneGeometry(FIELD.len + 8, FIELD.wid + 8), new THREE.MeshStandardMaterial({ map: grassTexture(), roughness: 0.95 }));
  pitch.rotation.x = -Math.PI / 2;
  pitch.receiveShadow = true;
  stadium.add(pitch);
  buildGoal(stadium, 1);
  buildGoal(stadium, -1);
  buildStands(stadium);
  buildAdBoards(stadium);
  buildLedRing(stadium);
  buildCornerFlags(stadium);
  buildDugouts(stadium);
  buildTunnel(stadium);
  buildBigScreens(stadium);
  buildTifos(stadium);
  buildCameraJib(stadium);
  buildSky(stadium);
}
function buildGoal(parent, side) {
  const goal = new THREE.Group();
  const gx = FIELD.halfLen * side;
  const postMat = new THREE.MeshStandardMaterial({ color: '#ffffff', roughness: 0.35, metalness: 0.1 });
  const postGeo = new THREE.CylinderGeometry(0.06, 0.06, FIELD.goalH, 10);
  for (const zs of [-1, 1]) {
    const post = new THREE.Mesh(postGeo, postMat);
    post.position.set(gx, FIELD.goalH / 2, (FIELD.goalW / 2) * zs);
    post.castShadow = true;
    goal.add(post);
  }
  const bar = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.06, FIELD.goalW + 0.12, 10), postMat);
  bar.rotation.x = Math.PI / 2;
  bar.position.set(gx, FIELD.goalH, 0);
  bar.castShadow = true;
  goal.add(bar);
  const netMat = new THREE.MeshBasicMaterial({ color: '#dfe8ff', wireframe: true, transparent: true, opacity: 0.32 });
  const depth = FIELD.goalDepth;
  const backNet = new THREE.Mesh(new THREE.PlaneGeometry(FIELD.goalW, FIELD.goalH, 12, 5), netMat);
  backNet.position.set(gx + depth * side, FIELD.goalH / 2, 0);
  backNet.rotation.y = Math.PI / 2;
  backNet.userData.baseX = backNet.position.x;
  goal.add(backNet);
  backNets[side] = backNet;
  const topNet = new THREE.Mesh(new THREE.PlaneGeometry(depth, FIELD.goalW, 5, 12), netMat);
  topNet.rotation.x = Math.PI / 2;
  topNet.rotation.z = Math.PI / 2;
  topNet.position.set(gx + (depth / 2) * side, FIELD.goalH, 0);
  goal.add(topNet);
  for (const zs of [-1, 1]) {
    const sideNet = new THREE.Mesh(new THREE.PlaneGeometry(depth, FIELD.goalH, 5, 5), netMat);
    sideNet.position.set(gx + (depth / 2) * side, FIELD.goalH / 2, (FIELD.goalW / 2) * zs);
    sideNet.rotation.y = Math.PI / 2;
    goal.add(sideNet);
  }
  parent.add(goal);
}
function buildStands(parent) {
  const crowdA = teamDefs[0] ? teamDefs[0].c1 : '#00e5ff';
  const crowdB = teamDefs[1] ? teamDefs[1].c1 : '#ff2d78';
  const standMatS = new THREE.MeshStandardMaterial({ map: crowdTexture(crowdA, crowdB), roughness: 1 });
  const standMatE = new THREE.MeshStandardMaterial({ map: crowdTexture(crowdB, crowdA), roughness: 1 });
  const wallMat = new THREE.MeshStandardMaterial({ color: '#0d1626', roughness: 1 });
  const makeStand = (len, mat) => {
    const grp = new THREE.Group();
    const wall = new THREE.Mesh(new THREE.BoxGeometry(len, 2.4, 1.2), wallMat);
    wall.position.y = 1.2;
    grp.add(wall);
    const tier = new THREE.Mesh(new THREE.PlaneGeometry(len, 26), mat);
    tier.rotation.x = -Math.PI / 2 + 0.62;
    tier.position.set(0, 12.5, 10.5);
    grp.add(tier);
    crowdTiers.push({ m: tier, base: 12.5, ph: rand(10) });
    const roof = new THREE.Mesh(new THREE.BoxGeometry(len, 0.5, 12), wallMat);
    roof.position.set(0, 24, 14);
    roof.rotation.x = 0.16;
    grp.add(roof);
    return grp;
  };
  const zOff = FIELD.halfWid + 14;
  const standN = makeStand(170, standMatS);
  standN.position.set(0, 0, -zOff);
  standN.rotation.y = Math.PI;
  parent.add(standN);
  const standS = makeStand(170, standMatS);
  standS.position.set(0, 0, zOff);
  parent.add(standS);
  const xOff = FIELD.halfLen + 16;
  const standE = makeStand(120, standMatE);
  standE.position.set(xOff, 0, 0);
  standE.rotation.y = -Math.PI / 2;
  parent.add(standE);
  const standW = makeStand(120, standMatE);
  standW.position.set(-xOff, 0, 0);
  standW.rotation.y = Math.PI / 2;
  parent.add(standW);
}
function buildAdBoards(parent) {
  const ads = [
    ['UA FC 27', '#0a1426', '#00e5ff'], ['LUCK ROYALE', '#101418', '#ffc400'],
    ['VOLTA LEAGUE', '#1a0a14', '#ff2d78'], ['FUT CHAMPIONS', '#04141c', '#00e676'],
    ['STADIUM LIVE', '#101018', '#ffffff'], ['PURE FOOTBALL', '#0a1a10', '#b5e048'],
  ];
  const boardGeo = new THREE.BoxGeometry(10, 1.0, 0.18);
  const positions = [];
  for (let i = 0; i < 6; i++) {
    positions.push({ x: -45 + i * 18, z: FIELD.halfWid + 2.4, ry: 0 });
    positions.push({ x: -45 + i * 18, z: -(FIELD.halfWid + 2.4), ry: Math.PI });
  }
  positions.push({ x: FIELD.halfLen + 2.6, z: 0, ry: Math.PI / 2 });
  positions.push({ x: -(FIELD.halfLen + 2.6), z: 0, ry: -Math.PI / 2 });
  positions.forEach((p, i) => {
    const a = ads[i % ads.length];
    const tex = adTexture(a[0], a[1], a[2]);
    tex.wrapS = THREE.RepeatWrapping;
    const mat = new THREE.MeshStandardMaterial({ map: tex, emissive: new THREE.Color('#ffffff'), emissiveIntensity: 0.22, roughness: 0.6 });
    scrollAdMats.push(mat);
    const board = new THREE.Mesh(boardGeo, mat);
    board.position.set(p.x, 0.5, p.z);
    board.rotation.y = p.ry;
    parent.add(board);
  });
}
function buildLedRing(parent) {
  const tex = adTexture('UA FC · UA FC · UA FC', '#02060f', '#00e5ff');
  tex.wrapS = THREE.RepeatWrapping;
  tex.repeat.x = 6;
  const mat = new THREE.MeshStandardMaterial({ map: tex, emissive: new THREE.Color('#0af'), emissiveIntensity: 0.6, roughness: 0.5 });
  scrollAdMats.push(mat);
  for (const sz of [-1, 1]) {
    const strip = new THREE.Mesh(new THREE.BoxGeometry(FIELD.len + 10, 0.12, 0.3), mat);
    strip.position.set(0, 0.06, (FIELD.halfWid + 1.4) * sz);
    parent.add(strip);
  }
}
function buildCornerFlags(parent) {
  const poleGeo = new THREE.CylinderGeometry(0.02, 0.02, 1.5, 6);
  const poleMat = new THREE.MeshStandardMaterial({ color: '#ffffff' });
  const flagGeo = new THREE.PlaneGeometry(0.5, 0.35);
  const flagMat = new THREE.MeshStandardMaterial({ color: '#ffc400', side: THREE.DoubleSide });
  for (const sx of [-1, 1]) for (const sz of [-1, 1]) {
    const grp = new THREE.Group();
    const pole = new THREE.Mesh(poleGeo, poleMat);
    pole.position.y = 0.75;
    grp.add(pole);
    const flag = new THREE.Mesh(flagGeo, flagMat);
    flag.position.set(0.25, 1.3, 0);
    grp.add(flag);
    grp.position.set(FIELD.halfLen * sx, 0, FIELD.halfWid * sz);
    parent.add(grp);
    waveFlags.push(flag);
  }
}
function buildDugouts(parent) {
  const frameMat = new THREE.MeshStandardMaterial({ color: '#0d1626', roughness: 0.5, metalness: 0.4 });
  const glassMat = new THREE.MeshStandardMaterial({ color: '#1a3a5a', transparent: true, opacity: 0.4, roughness: 0.1 });
  const seatMat = new THREE.MeshStandardMaterial({ color: '#d40019', roughness: 0.8 });
  for (const sz of [-1, 1]) {
    const grp = new THREE.Group();
    const roof = new THREE.Mesh(new THREE.BoxGeometry(10, 0.3, 3.4), glassMat);
    roof.position.y = 2.4;
    grp.add(roof);
    const back = new THREE.Mesh(new THREE.BoxGeometry(10, 2.2, 0.2), glassMat);
    back.position.set(0, 1.1, -1.5);
    grp.add(back);
    for (const px of [-5, 5]) {
      const post = new THREE.Mesh(new THREE.BoxGeometry(0.18, 2.4, 0.18), frameMat);
      post.position.set(px, 1.2, 1.4);
      grp.add(post);
    }
    const bench = new THREE.Mesh(new THREE.BoxGeometry(8.5, 0.25, 0.7), seatMat);
    bench.position.set(0, 0.55, -0.7);
    grp.add(bench);
    grp.position.set(-6 * sz, 0, FIELD.halfWid + 7.5);
    grp.rotation.y = Math.PI;
    parent.add(grp);
  }
}
function buildTunnel(parent) {
  const mat = new THREE.MeshStandardMaterial({ color: '#0a1220', roughness: 0.9 });
  const grp = new THREE.Group();
  const arch = new THREE.Mesh(new THREE.BoxGeometry(7, 5, 6), mat);
  arch.position.y = 2.5;
  grp.add(arch);
  const mouth = new THREE.Mesh(new THREE.BoxGeometry(4.4, 3.4, 6.2), new THREE.MeshBasicMaterial({ color: '#02040a' }));
  mouth.position.y = 1.7;
  mouth.position.z = 0.2;
  grp.add(mouth);
  const glow = new THREE.Mesh(new THREE.BoxGeometry(4.6, 0.24, 0.24), new THREE.MeshStandardMaterial({ color: '#00e5ff', emissive: new THREE.Color('#00e5ff'), emissiveIntensity: 2 }));
  glow.position.set(0, 3.5, 3.1);
  grp.add(glow);
  grp.position.set(0, 0, -(FIELD.halfWid + 14.6));
  parent.add(grp);
}
function drawBigScreen() {
  if (!bigScreenCtx) return;
  const g = bigScreenCtx, w = 512, h = 288;
  g.fillStyle = '#04101c';
  g.fillRect(0, 0, w, h);
  const grad = g.createLinearGradient(0, 0, w, h);
  grad.addColorStop(0, '#0a2a4a');
  grad.addColorStop(1, '#1a0a3a');
  g.fillStyle = grad;
  g.fillRect(0, 0, w, h);
  g.textAlign = 'center';
  g.fillStyle = '#00e5ff';
  g.font = '700 30px Rajdhani, sans-serif';
  g.fillText('UA FC MOBILE · ULTIMATE', w / 2, 42);
  const a = teamDefs[0] ? teamDefs[0].abbr : 'HOM';
  const b = teamDefs[1] ? teamDefs[1].abbr : 'AWY';
  g.fillStyle = '#ffffff';
  g.font = '700 92px Rajdhani, sans-serif';
  g.fillText(`${a} ${match.score[0]} - ${match.score[1]} ${b}`, w / 2, 160);
  const halfDur = settings.halfDur || 180;
  const inHalf = match.half === 1 ? clamp01(match.clock / halfDur) : clamp01((match.clock - halfDur) / halfDur);
  const minute = Math.floor(inHalf * 45) + (match.half === 2 ? 45 : 0);
  g.fillStyle = '#ffc400';
  g.font = '700 40px Rajdhani, sans-serif';
  g.fillText(`${minute}'  ·  ${match.half === 1 ? '1ST' : '2ND'} HALF`, w / 2, 224);
  g.strokeStyle = 'rgba(0,229,255,.5)';
  g.lineWidth = 6;
  g.strokeRect(6, 6, w - 12, h - 12);
  if (bigScreenTex) bigScreenTex.needsUpdate = true;
}
function buildBigScreens(parent) {
  const c = document.createElement('canvas');
  c.width = 512; c.height = 288;
  bigScreenCtx = c.getContext('2d');
  bigScreenTex = new THREE.CanvasTexture(c);
  bigScreenTex.colorSpace = THREE.SRGBColorSpace;
  drawBigScreen();
  const mat = new THREE.MeshStandardMaterial({ map: bigScreenTex, emissive: new THREE.Color('#ffffff'), emissiveMap: bigScreenTex, emissiveIntensity: 0.55, roughness: 0.4 });
  const geo = new THREE.PlaneGeometry(16, 9);
  const s1 = new THREE.Mesh(geo, mat);
  s1.position.set(-58, 26, -40);
  s1.rotation.y = 0.7;
  parent.add(s1);
  const s2 = new THREE.Mesh(geo, mat);
  s2.position.set(58, 26, 40);
  s2.rotation.y = Math.PI + 0.7;
  parent.add(s2);
}
function buildTifos(parent) {
  if (!teamDefs[0] || !teamDefs[1]) return;
  const geo = new THREE.PlaneGeometry(46, 11);
  const m1 = new THREE.Mesh(geo, new THREE.MeshStandardMaterial({ map: tifoTexture(teamDefs[0].abbr, teamDefs[0].c1, teamDefs[0].c2), roughness: 1 }));
  m1.position.set(FIELD.halfLen + 15.4, 9, 0);
  m1.rotation.y = -Math.PI / 2;
  parent.add(m1);
  const m2 = new THREE.Mesh(geo, new THREE.MeshStandardMaterial({ map: tifoTexture(teamDefs[1].abbr, teamDefs[1].c1, teamDefs[1].c2), roughness: 1 }));
  m2.position.set(-(FIELD.halfLen + 15.4), 9, 0);
  m2.rotation.y = Math.PI / 2;
  parent.add(m2);
}
function buildCameraJib(parent) {
  const grp = new THREE.Group();
  const baseMat = new THREE.MeshStandardMaterial({ color: '#101826', roughness: 0.7 });
  const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.2, 3.2, 8), baseMat);
  pole.position.y = 1.6;
  grp.add(pole);
  const arm = new THREE.Mesh(new THREE.BoxGeometry(3.6, 0.14, 0.14), baseMat);
  arm.position.set(1.4, 3.2, 0);
  arm.rotation.z = 0.18;
  grp.add(arm);
  const camBox = new THREE.Mesh(new THREE.BoxGeometry(0.6, 0.4, 0.4), new THREE.MeshStandardMaterial({ color: '#1c2430', roughness: 0.4 }));
  camBox.position.set(3.1, 3.0, 0);
  grp.add(camBox);
  const lens = new THREE.Mesh(new THREE.CylinderGeometry(0.1, 0.12, 0.3, 8), new THREE.MeshStandardMaterial({ color: '#0a0e14' }));
  lens.rotation.z = Math.PI / 2;
  lens.position.set(3.5, 3.0, 0);
  grp.add(lens);
  grp.position.set(0, 0, FIELD.halfWid + 5.5);
  parent.add(grp);
}
function buildSky(parent) {
  const skyMat = new THREE.ShaderMaterial({
    side: THREE.BackSide,
    uniforms: { top: { value: new THREE.Color('#050a1c') }, bottom: { value: new THREE.Color('#132442') } },
    vertexShader: `varying vec3 vPos; void main(){ vPos = position; gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.0); }`,
    fragmentShader: `uniform vec3 top; uniform vec3 bottom; varying vec3 vPos;
      void main(){ float h = normalize(vPos).y * 0.5 + 0.5; vec3 col = mix(bottom, top, pow(h, 0.7)); gl_FragColor = vec4(col,1.0); }`,
  });
  parent.add(new THREE.Mesh(new THREE.SphereGeometry(240, 24, 12), skyMat));
  const starGeo = new THREE.BufferGeometry();
  const pos = new Float32Array(300 * 3);
  for (let i = 0; i < 300; i++) {
    const a = rand(Math.PI * 2);
    const e = rand(0.12, 1.2);
    pos[i * 3] = Math.cos(a) * Math.cos(e) * 220;
    pos[i * 3 + 1] = Math.sin(e) * 220;
    pos[i * 3 + 2] = Math.sin(a) * Math.cos(e) * 220;
  }
  starGeo.setAttribute('position', new THREE.BufferAttribute(pos, 3));
  parent.add(new THREE.Points(starGeo, new THREE.PointsMaterial({ color: '#cfe4ff', size: 0.7, transparent: true, opacity: 0.8 })));
}
function buildFloodlights() {
  const towerMat = new THREE.MeshStandardMaterial({ color: '#0d1626', roughness: 0.8 });
  const panelMat = new THREE.MeshStandardMaterial({ color: '#ffffff', emissive: new THREE.Color('#fff8d8'), emissiveIntensity: 3.2 });
  for (const sx of [-1, 1]) for (const sz of [-1, 1]) {
    const grp = new THREE.Group();
    const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.5, 0.8, 34, 8), towerMat);
    pole.position.y = 17;
    grp.add(pole);
    const head = new THREE.Mesh(new THREE.BoxGeometry(8, 4.5, 1), panelMat);
    head.position.y = 35;
    head.lookAt(0, 0, 0);
    grp.add(head);
    const spot = new THREE.SpotLight('#fff2cc', 2600, 220, 0.62, 0.5, 1.8);
    spot.position.set(0, 35, 0);
    const tgt = new THREE.Object3D();
    tgt.position.set(-sx * 20, 0, -sz * 14);
    grp.add(tgt);
    spot.target = tgt;
    grp.add(spot);
    grp.position.set(sx * (FIELD.halfLen + 14), 0, sz * (FIELD.halfWid + 12));
    scene.add(grp);
  }
}

/* ==========================================================================
   07 · BALL
   ========================================================================== */
let trailPoints = null;
let trailPositions = null;
function createBall() {
  const mesh = new THREE.Mesh(new THREE.SphereGeometry(PHYS.ballRadius, 20, 14), new THREE.MeshStandardMaterial({ map: ballTexture(), roughness: 0.35 }));
  mesh.castShadow = true;
  scene.add(mesh);
  ball = {
    mesh, pos: mesh.position, vel: new THREE.Vector3(), spin: new THREE.Vector3(),
    owner: null, lastKicker: null, kickCooldown: 0, shotActive: false, shotTeam: -1, trail: [],
    passTarget: null, passTargetT: 0,
  };
  mesh.position.set(0, PHYS.ballRadius, 0);
  const tgeo = new THREE.BufferGeometry();
  trailPositions = new Float32Array(22 * 3);
  tgeo.setAttribute('position', new THREE.BufferAttribute(trailPositions, 3));
  trailPoints = new THREE.Points(tgeo, new THREE.PointsMaterial({
    color: '#9ff3ff', size: 0.22, transparent: true, opacity: 0.55,
    blending: THREE.AdditiveBlending, depthWrite: false,
  }));
  trailPoints.frustumCulled = false;
  scene.add(trailPoints);
}
function updateTrail() {
  const speed = ball.vel.length();
  if (speed > 16 && !ball.owner) ball.trail.unshift(ball.pos.clone());
  if (ball.trail.length > 22) ball.trail.pop();
  for (let i = 0; i < 22; i++) {
    const p = ball.trail[i];
    if (p) { trailPositions[i * 3] = p.x; trailPositions[i * 3 + 1] = p.y; trailPositions[i * 3 + 2] = p.z; }
    else { trailPositions[i * 3] = ball.pos.x; trailPositions[i * 3 + 1] = -10; trailPositions[i * 3 + 2] = ball.pos.z; }
  }
  trailPoints.geometry.attributes.position.needsUpdate = true;
}

/* ==========================================================================
   09 · OFFICIALS
   ========================================================================== */
const REF_DEF = { c1: '#15161a', c2: '#ffd700', gk: '#15161a', pat: 'solid', _kitTex: null };
const LINE_DEF = { c1: '#e6ff00', c2: '#111111', gk: '#e6ff00', pat: 'solid', _kitTex: null };
function makeOfficialInfo() {
  return {
    role: 'CM', num: '', fx: 0, fz: 0, captain: false,
    stats: { pace: 80, shoot: 50, pass: 50, drib: 50, def: 50, gk: 20 },
    ovr: 70, skin: pick(SKIN_TONES), hair: '#141414', hairStyle: 0,
  };
}
function createOfficials() {
  referee = {
    mesh: null, joints: null, pos: null, vel: new THREE.Vector3(),
    facing: Math.PI / 2, animTime: rand(10), speedRatio: 0, turnVel: 0,
    action: null, stunTimer: 0, celebrate: 0, celebStyle: 0, celebration: null, celebT: 0,
    isGK: false, team: -1,
  };
  const model = buildPlayerModel(REF_DEF, makeOfficialInfo());
  referee.mesh = model.root;
  referee.joints = model.joints;
  referee.hipRestX = model.hipRestX || 0;
  referee.hipRestZ = model.hipRestZ || 0;
  referee.mixer = model.mixer;
  referee.actions = model.actions;
  referee.skeletonRootNode = model.skeletonRootNode;
  referee.currentStateName = null;
  referee.pos = model.root.position;
  referee.pos.set(4, 0, 8);
  linesmen = [];
  for (const sz of [-1, 1]) {
    const lm = {
      mesh: null, joints: null, pos: null, vel: new THREE.Vector3(),
      facing: sz > 0 ? Math.PI : 0, animTime: rand(10), speedRatio: 0, turnVel: 0,
      action: null, stunTimer: 0, celebrate: 0, celebStyle: 0, celebration: null, celebT: 0,
      isGK: false, side: sz, team: -1,
    };
    const m2 = buildPlayerModel(LINE_DEF, makeOfficialInfo());
    lm.mesh = m2.root;
    lm.joints = m2.joints;
    lm.hipRestX = m2.hipRestX || 0;
    lm.hipRestZ = m2.hipRestZ || 0;
    lm.mixer = m2.mixer;
    lm.actions = m2.actions;
    lm.skeletonRootNode = m2.skeletonRootNode;
    lm.currentStateName = null;
    lm.pos = m2.root.position;
    lm.pos.set(0, 0, (FIELD.halfWid + 1.4) * sz);
    const stick = new THREE.Mesh(new THREE.CylinderGeometry(0.015, 0.015, 0.55, 6), new THREE.MeshStandardMaterial({ color: '#ffffff' }));
    stick.position.y = -0.5;
    m2.joints.armR.el.add(stick);
    const cloth = new THREE.Mesh(new THREE.PlaneGeometry(0.3, 0.2), new THREE.MeshStandardMaterial({ color: '#ff7b00', side: THREE.DoubleSide }));
    cloth.position.set(0.16, -0.68, 0);
    m2.joints.armR.el.add(cloth);
    linesmen.push(lm);
  }
}
function updateOfficials(dt) {
  if (!referee) return;
  referee.animTime += dt * 2;
  referee.action = null;
  let target;
  if (match.state === 'goal') {
    target = { x: ball.pos.x * 0.8, z: ball.pos.z * 0.8 };
    referee.action = { type: 'point', t: 1, dur: 2, contactAt: 99, done: true, locks: false };
  } else if (match.state === 'setpiece') {
    const cx = clamp(ball.pos.x + Math.sign(-ball.pos.x || 1) * 3.2, -FIELD.halfLen, FIELD.halfLen);
    target = { x: cx, z: ball.pos.z + (ball.pos.z > 0 ? -3 : 3) };
    referee.action = { type: 'signal', t: 1, dur: 2, contactAt: 99, done: true, locks: false };
  } else {
    target = { x: clamp(ball.pos.x + 7, -FIELD.halfLen, FIELD.halfLen), z: clamp(ball.pos.z + 9, -FIELD.halfWid, FIELD.halfWid) };
  }
  const dx = target.x - referee.pos.x;
  const dz = target.z - referee.pos.z;
  const d = Math.hypot(dx, dz);
  const sp = match.state === 'play' ? 5.6 : 4.4;
  if (d > 0.6) {
    referee.vel.x = damp(referee.vel.x, (dx / d) * sp, 6, dt);
    referee.vel.z = damp(referee.vel.z, (dz / d) * sp, 6, dt);
  } else referee.vel.multiplyScalar(Math.exp(-8 * dt));
  referee.pos.addScaledVector(referee.vel, dt);
  referee.speedRatio = damp(referee.speedRatio, clamp01(referee.vel.length() / 6), 6, dt);
  if (referee.vel.length() > 0.5 && !referee.action) referee.facing = angleDamp(referee.facing, Math.atan2(referee.vel.x, referee.vel.z), 8, dt);
  referee.mesh.rotation.y = referee.facing;
  animatePlayer(referee, dt);
  for (const lm of linesmen) {
    lm.animTime += dt;
    const tx = clamp(ball.pos.x, -FIELD.halfLen + 2, FIELD.halfLen - 2);
    const ldx = tx - lm.pos.x;
    lm.vel.x = damp(lm.vel.x, clamp(ldx * 3, -4.4, 4.4), 5, dt);
    lm.pos.x += lm.vel.x * dt;
    lm.speedRatio = damp(lm.speedRatio, clamp01(Math.abs(lm.vel.x) / 5), 6, dt);
    lm.mesh.rotation.y = lm.side > 0 ? Math.PI : 0;
    lm.action = match.state === 'setpiece'
      ? { type: 'signal', t: 1, dur: 2, contactAt: 99, done: true, locks: false }
      : null;
    animatePlayer(lm, dt);
  }
}

/* ==========================================================================
   10 · PARTICLES
   ========================================================================== */
class ParticleSystem {
  constructor(count, colors, size, gravity) {
    this.count = count;
    this.gravity = gravity;
    this.positions = new Float32Array(count * 3);
    this.colors = new Float32Array(count * 3);
    this.vels = new Float32Array(count * 3);
    this.life = new Float32Array(count);
    this.geo = new THREE.BufferGeometry();
    this.geo.setAttribute('position', new THREE.BufferAttribute(this.positions, 3));
    this.geo.setAttribute('color', new THREE.BufferAttribute(this.colors, 3));
    this.mat = new THREE.PointsMaterial({ size, vertexColors: true, transparent: true, opacity: 0.95, depthWrite: false });
    this.points = new THREE.Points(this.geo, this.mat);
    this.points.frustumCulled = false;
    scene.add(this.points);
    this.palette = colors.map((c) => new THREE.Color(c));
    this.cursor = 0;
    for (let i = 0; i < count; i++) this.positions[i * 3 + 1] = -50;
  }
  emit(x, y, z, vx, vy, vz, life) {
    const i = this.cursor;
    this.cursor = (this.cursor + 1) % this.count;
    this.positions[i * 3] = x; this.positions[i * 3 + 1] = y; this.positions[i * 3 + 2] = z;
    this.vels[i * 3] = vx; this.vels[i * 3 + 1] = vy; this.vels[i * 3 + 2] = vz;
    this.life[i] = life;
    const c = pick(this.palette);
    this.colors[i * 3] = c.r; this.colors[i * 3 + 1] = c.g; this.colors[i * 3 + 2] = c.b;
  }
  update(dt) {
    for (let i = 0; i < this.count; i++) {
      if (this.life[i] <= 0) continue;
      this.life[i] -= dt;
      if (this.life[i] <= 0) { this.positions[i * 3 + 1] = -50; continue; }
      this.vels[i * 3 + 1] += this.gravity * dt;
      this.positions[i * 3] += this.vels[i * 3] * dt;
      this.positions[i * 3 + 1] += this.vels[i * 3 + 1] * dt;
      this.positions[i * 3 + 2] += this.vels[i * 3 + 2] * dt;
      if (this.positions[i * 3 + 1] < 0.02) {
        this.positions[i * 3 + 1] = 0.02;
        this.vels[i * 3 + 1] *= -0.3;
      }
    }
    this.geo.attributes.position.needsUpdate = true;
    this.geo.attributes.color.needsUpdate = true;
  }
}
let confetti = null, grassFx = null, sparkFx = null;
function createParticles() {
  confetti = new ParticleSystem(900, ['#ffc400', '#00e5ff', '#ff2d78', '#00e676', '#ffffff'], 0.26, -9);
  grassFx = new ParticleSystem(240, ['#2f8f3f', '#3fa04c', '#27823a'], 0.09, -14);
  sparkFx = new ParticleSystem(320, ['#ffffff', '#9ff3ff', '#ffe27a', '#ffb0c8'], 0.16, -6);
}
function emitConfettiBurst(x, z, n = 220) {
  for (let i = 0; i < n; i++) {
    const a = rand(Math.PI * 2);
    const s = rand(2, 9);
    confetti.emit(x + rand(-2, 2), rand(1, 4), z + rand(-2, 2), Math.cos(a) * s, rand(4, 13), Math.sin(a) * s, rand(1.4, 3.2));
  }
}
function emitGrass(x, z, dirX, dirZ, n = 10) {
  for (let i = 0; i < n; i++) {
    grassFx.emit(x + rand(-0.2, 0.2), 0.05, z + rand(-0.2, 0.2), dirX * rand(0.5, 2.4) + rand(-1, 1), rand(1.5, 4), dirZ * rand(0.5, 2.4) + rand(-1, 1), rand(0.3, 0.7));
  }
}
function emitSpark(x, y, z, n = 14) {
  for (let i = 0; i < n; i++) {
    const a = rand(Math.PI * 2);
    const s = rand(1, 6);
    sparkFx.emit(x, y, z, Math.cos(a) * s, rand(0.5, 5), Math.sin(a) * s, rand(0.25, 0.7));
  }
}
function emitFirework(x, z) {
  for (let i = 0; i < 90; i++) {
    const a = rand(Math.PI * 2);
    const e = rand(-0.4, 1.4);
    const s = rand(4, 12);
    sparkFx.emit(x, rand(6, 12), z, Math.cos(a) * Math.cos(e) * s, Math.sin(e) * s, Math.sin(a) * Math.cos(e) * s, rand(0.8, 1.6));
  }
  audio.firework();
}

/* ==========================================================================
   13 · FORMATIONS + SPAWNING + KICKOFF
   ========================================================================== */
const TEAMS = [
  { name: 'Solaris FC',         abbr: 'SOL', c1: '#ffc400', c2: '#101418', gk: '#00e676', rating: 87, form: '433',  pat: 'sash'   },
  { name: 'Northbridge United', abbr: 'NBU', c1: '#d40019', c2: '#ffffff', gk: '#222222', rating: 86, form: '442',  pat: 'solid'  },
  { name: 'Port Azure',         abbr: 'PAZ', c1: '#6ec6ff', c2: '#ffffff', gk: '#ff8800', rating: 88, form: '433',  pat: 'solid'  },
  { name: 'Iron Harbour',       abbr: 'IRH', c1: '#1d3557', c2: '#a8b8d0', gk: '#ffe14d', rating: 83, form: '442',  pat: 'hoops'  },
  { name: 'Crimson Vale',       abbr: 'CRV', c1: '#a4133c', c2: '#ffd166', gk: '#04e0c0', rating: 85, form: '4231', pat: 'stripes'},
  { name: 'CD Dorada',          abbr: 'DOR', c1: '#ffffff', c2: '#6a0dad', gk: '#ff4d6d', rating: 84, form: '433',  pat: 'stripes'},
  { name: 'FC Bergland',        abbr: 'BER', c1: '#1a936f', c2: '#ffffff', gk: '#ff9f1c', rating: 82, form: '442',  pat: 'hoops'  },
  { name: 'Meridian Wanderers', abbr: 'MER', c1: '#ff7b00', c2: '#111111', gk: '#00c2ff', rating: 81, form: '4231', pat: 'sash'   },
  { name: 'Aurora Rovers',      abbr: 'AUR', c1: '#0fb8a9', c2: '#e8f1f5', gk: '#ff5d8f', rating: 80, form: '433',  pat: 'stripes'},
  { name: 'Vortex SC',          abbr: 'VOR', c1: '#7209b7', c2: '#f0e6ff', gk: '#b5e048', rating: 79, form: '442',  pat: 'solid'  },
];
const FORMATIONS = {
  '433': [
    { role: 'GK', fx: -0.965, fz: 0.0 }, { role: 'LB', fx: -0.56, fz: -0.62 },
    { role: 'CB', fx: -0.68, fz: -0.24 }, { role: 'CB', fx: -0.68, fz: 0.24 },
    { role: 'RB', fx: -0.56, fz: 0.62 }, { role: 'CM', fx: -0.22, fz: -0.40 },
    { role: 'CM', fx: -0.34, fz: 0.0 }, { role: 'CM', fx: -0.22, fz: 0.40 },
    { role: 'LW', fx: 0.20, fz: -0.62 }, { role: 'ST', fx: 0.28, fz: 0.0 },
    { role: 'RW', fx: 0.20, fz: 0.62 },
  ],
  '442': [
    { role: 'GK', fx: -0.965, fz: 0.0 }, { role: 'LB', fx: -0.56, fz: -0.62 },
    { role: 'CB', fx: -0.68, fz: -0.24 }, { role: 'CB', fx: -0.68, fz: 0.24 },
    { role: 'RB', fx: -0.56, fz: 0.62 }, { role: 'LM', fx: -0.14, fz: -0.72 },
    { role: 'CM', fx: -0.30, fz: -0.24 }, { role: 'CM', fx: -0.30, fz: 0.24 },
    { role: 'RM', fx: -0.14, fz: 0.72 }, { role: 'ST', fx: 0.28, fz: -0.18 },
    { role: 'ST', fx: 0.28, fz: 0.18 },
  ],
  '4231': [
    { role: 'GK', fx: -0.965, fz: 0.0 }, { role: 'LB', fx: -0.56, fz: -0.62 },
    { role: 'CB', fx: -0.68, fz: -0.24 }, { role: 'CB', fx: -0.68, fz: 0.24 },
    { role: 'RB', fx: -0.56, fz: 0.62 }, { role: 'CDM', fx: -0.38, fz: -0.20 },
    { role: 'CDM', fx: -0.38, fz: 0.20 }, { role: 'LW', fx: -0.02, fz: -0.60 },
    { role: 'CAM', fx: 0.02, fz: 0.0 }, { role: 'RW', fx: -0.02, fz: 0.60 },
    { role: 'ST', fx: 0.30, fz: 0.0 },
  ],
};
function generateSquad(teamDef) {
  const squad = [];
  const form = FORMATIONS[teamDef.form];
  const numbers = { GK: [1], DEF: [2, 3, 4, 5], MID: [6, 8, 10, 14, 16, 18], FWD: [7, 9, 11, 17, 19, 21] };
  const takenNums = new Set();
  for (let i = 0; i < 11; i++) {
    const slot = form[i];
    const cat = slot.role === 'GK' ? 'GK' : slot.role.includes('B') ? 'DEF' : (slot.role === 'ST' || slot.role.includes('W')) ? 'FWD' : 'MID';
    let num = pick(numbers[cat]);
    let guard = 0;
    while (takenNums.has(num) && guard++ < 30) num = randInt(2, 29);
    takenNums.add(num);
    const base = teamDef.rating;
    squad.push({
      name: 'PLAYER', num, role: slot.role, fx: slot.fx, fz: slot.fz,
      stats: { pace: base, shoot: base, pass: base, drib: base, def: base, gk: base },
      ovr: base, skin: pick(SKIN_TONES), hair: pick(HAIR_COLORS), hairStyle: randInt(0, 3),
      _regId: null, _inj: false, captain: false,
    });
  }
  return squad;
}
/* Bench pool: 5 reserves (1 keeper + 4 outfield), generated the same way
   as the starting XI so a sub looks and plays like a real squad member,
   not a placeholder. Kept separate from generateSquad()'s 11 so nothing
   that assumes an exact starting XI (formation slot indices, squads[t]
   length) has to change anywhere else in the codebase. */
function generateBench(teamDef) {
  const bench = [];
  const numbers = { GK: [13], DEF: [12, 15, 20, 22], MID: [23, 24, 25, 26], FWD: [27, 28, 29] };
  const roles = ['GK', 'CB', 'CM', 'ST', 'RW'];
  const takenNums = new Set([13]);
  for (let i = 0; i < 5; i++) {
    const role = roles[i];
    const cat = role === 'GK' ? 'GK' : role.includes('B') ? 'DEF' : (role === 'ST' || role.includes('W')) ? 'FWD' : 'MID';
    let num = pick(numbers[cat]);
    let guard = 0;
    while (takenNums.has(num) && guard++ < 30) num = randInt(30, 40);
    takenNums.add(num);
    const base = Math.max(60, teamDef.rating - randInt(2, 8));
    bench.push({
      name: 'PLAYER', num, role, fx: 0, fz: 0,
      stats: { pace: base, shoot: base, pass: base, drib: base, def: base, gk: base },
      ovr: base, skin: pick(SKIN_TONES), hair: pick(HAIR_COLORS), hairStyle: randInt(0, 3),
      _regId: null, _inj: false, captain: false,
    });
  }
  return bench;
}
function formationWorldPos(teamIdx, fx, fz) {
  const dir = teamIdx === 0 ? 1 : -1;
  return { x: dir * fx * (FIELD.halfLen - 3), z: fz * (FIELD.halfWid - 5) };
}
function placeKickoff(kickTeam) {
  for (const p of players) {
    const isKicker = p.team === kickTeam && p.role === 'ST';
    const wp = formationWorldPos(p.team, p.homeFx, p.homeFz);
    if (isKicker) {
      p.pos.set(0, 0, 0.6);
    } else {
      let x = wp.x;
      if (p.team === 0) x = Math.min(x, -1.4);
      else x = Math.max(x, 1.4);
      p.pos.set(x, 0, wp.z);
      if (p.team === kickTeam && dist2(p.pos.x, p.pos.z, 0, 0) < FIELD.circleR + 1) {
        const pushDir = p.team === 0 ? -1 : 1;
        p.pos.x = pushDir * (FIELD.circleR + 1.6);
      }
    }
    p.vel.set(0, 0, 0);
    p.action = null;
    p.stunTimer = 0;
    p.hasBall = false;
    p.celebrate = 0;
    p.celebration = null;
    p.facing = p.team === 0 ? Math.PI / 2 : -Math.PI / 2;
    p.mesh.rotation.y = p.facing;
  }
  if (ball) {
    ball.pos.set(0, PHYS.ballRadius, 0);
    ball.vel.set(0, 0, 0);
    ball.spin.set(0, 0, 0);
    ball.owner = null;
    ball.shotActive = false;
    ball.trail.length = 0;
    ball.passTarget = null;
  }
}
/* TRASH / GOD difficulty: reshape the opponent squad (team 1) once at kickoff. */
const GOD_STYLES = ['Finesse Expert', 'Power Shot', 'Trickster', 'Clinical Finsher', 'Vision', 'Rapid', 'Chip Shot', 'Sliding Tackle'];
function applyDifficultyBoost() {
  const d = DIFFS[settings.diff] || DIFFS[1];
  for (const p of players) {
    if (p.team !== 1) continue;
    if (d.god) {
      for (const k of Object.keys(p.stats)) if (typeof p.stats[k] === 'number') p.stats[k] = Math.min(99, p.stats[k] + (p.isGK ? 10 : 12));
      p.ovr = Math.min(99, (p.ovr || 80) + 10);
      if (!p.isGK) p.playstyles = normalizePlaystyles(GOD_STYLES.map((name) => ({ name, tier: 'gold' })));
    } else if (d.trash) {
      for (const k of Object.keys(p.stats)) if (typeof p.stats[k] === 'number') p.stats[k] = Math.max(15, p.stats[k] - 35);
      p.ovr = Math.max(20, (p.ovr || 70) - 30);
      p.playstyles = [];
    }
  }
}
function spawnTeams() {
  for (const p of players) scene.remove(p.mesh);
  players = [];
  for (let t = 0; t < 2; t++) for (const info of squads[t]) players.push(new Player(t, info));
  applyDifficultyBoost();
  placeKickoff(match.kickTeam);
  controlled = players.find((p) => p.team === 0 && p.role === 'ST') || players[9];
}

/* ==========================================================================
   15 · AUTO players/ LOADER (+ playerpos.txt)
   ========================================================================== */
let REG = [];
let regIndex = new Map();
const RARITY = {
  bronze: { a: '#b0763a', b: '#4a2c12', glow: '#c98a4b', txt: '#ffd9ae', label: 'BRONZE' },
  silver: { a: '#dfe8f2', b: '#5c6c80', glow: '#cfd8e6', txt: '#f4f9ff', label: 'SILVER' },
  gold:   { a: '#ffd24a', b: '#7a5a00', glow: '#ffdf7e', txt: '#fff6d8', label: 'GOLD' },
  icon:   { a: '#8ef7ff', b: '#5a00c8', glow: '#a0f0ff', txt: '#eaffff', label: 'ICON' },
  hero:   { a: '#e0b3ff', b: '#5c1f96', glow: '#cf9bff', txt: '#f6e9ff', label: 'HERO' },
};
const RARITY_RANK = { bronze: 0, silver: 1, gold: 2, icon: 3, hero: 4 };

/* ==========================================================================
   PACK OPENING ANIMATION (v2 — full EA-FC-style sequence)
   Plays inside #rl-spin-overlay for every way a player is acquired: Luck
   Royale, UA Points boxes, and Market purchases. Flow, timed to ~7s total:
     0.0s  pack appears, floats, "DOUBLE TAP TO OPEN" hint
     (waits for the player's double-tap, or auto-continues after ~2.2s so
      a fast/impatient player — or a non-interactive context — isn't stuck)
     +0.0s pack shakes hard, charges up
     +0.6s burst: flash + rays + sparks, pack destroyed
     +0.9s NATION flag stage
     +2.1s POSITION stage
     +3.3s RATING stage (numbers roll up)
     +4.6s full CARD flies in, flips face-on, shine sweep, settles
     +7.0s auto-advances to onDone() (existing result grid / toast)
   Tapping anywhere after the burst skips straight to the full card.
   ========================================================================== */
function bestRarityOf(list) {
  let best = 'bronze';
  for (const r of list) {
    if ((RARITY_RANK[r] || 0) > (RARITY_RANK[best] || 0)) best = r;
  }
  return best;
}
function flagEmojiGame(iso2) {
  if (!iso2 || iso2.length !== 2) return '🏳️';
  return iso2.toUpperCase().replace(/./g, (c) => String.fromCodePoint(127397 + c.charCodeAt(0)));
}
function spawnPackSparks(big) {
  const wrap = $('pk-particles');
  wrap.innerHTML = '';
  const n = big ? 60 : 24;
  for (let i = 0; i < n; i++) {
    const el = document.createElement('div');
    const isStreak = big && i % 4 === 0;
    const isBigDot = big && i % 3 === 0;
    el.className = 'pk-spark' + (isBigDot ? ' big' : '') + (isStreak ? ' streak' : '');
    const angle = (i / n) * Math.PI * 2 + Math.random() * 0.4;
    const dist = (big ? 140 : 70) + Math.random() * (big ? 260 : 110);
    el.style.setProperty('--sx', (Math.cos(angle) * dist).toFixed(0) + 'px');
    el.style.setProperty('--sy', (Math.sin(angle) * dist).toFixed(0) + 'px');
    el.style.setProperty('--rot', (Math.random() * 720 - 360).toFixed(0) + 'deg');
    el.style.animationDelay = (Math.random() * 0.18).toFixed(2) + 's';
    wrap.appendChild(el);
    requestAnimationFrame(() => el.classList.add('go'));
  }
  if (big) {
    // Expanding shockwave ring, dynamically added so it never lingers
    // between pulls the way a static always-present element would.
    const ring = document.createElement('div');
    ring.className = 'pk-shockwave';
    wrap.appendChild(ring);
    requestAnimationFrame(() => ring.classList.add('go'));
    packAfter(900, () => ring.remove());
  }
}
let packAnimTimers = [];
function clearPackAnimTimers() { packAnimTimers.forEach(clearTimeout); packAnimTimers = []; }
function packAfter(ms, fn) { packAnimTimers.push(setTimeout(fn, ms)); }

/**
 * Normalizes the three different "player just acquired" shapes (raw
 * players_registry row from Royale/Boxes, regById() cloud record from
 * Market, or a plain {name,ovr,rarity,pos,nation,img}) into one shape the
 * animation always reads the same way.
 */
function normalizePackPlayer(p) {
  if (!p) return { name: '???', ovr: 0, rarity: 'bronze', pos: 'CM', nation: null, img: '' };
  return {
    name: p.name || '???',
    ovr: p.ovr != null ? p.ovr : 0,
    rarity: ['bronze', 'silver', 'gold', 'icon', 'hero'].includes(p.rarity) ? p.rarity : 'bronze',
    pos: p.pos || p.position || normalizePos(p.position) || 'CM',
    nation: p.nation || p.nationality || null,
    img: p.img || (p.media_path ? mediaUrlFor(p.media_path) : '') || '',
    pid: p.id != null ? String(p.id).replace(/^cloud-/, '') : (p.player_id != null ? String(p.player_id) : ''),
  };
}

/**
 * Plays the full pack-opening sequence for a single revealed player, then
 * calls onDone(). If `all` (array of normalized players) has more than one
 * entry, only the single highest-rated one is dramatized here — the
 * existing result grid shown in onDone still lists every card from the
 * pull, this is just the "big reveal" moment before it.
 */
function playPackOpenAnimation(playerOrRarity, topOvrMaybe, onDoneMaybe) {
  // Back-compat: earlier call sites passed (rarity, ovr, onDone). Detect
  // that shape and wrap it into a minimal player object.
  let player, done;
  if (typeof playerOrRarity === 'string') {
    player = normalizePackPlayer({ rarity: playerOrRarity, ovr: topOvrMaybe });
    done = onDoneMaybe;
  } else {
    player = normalizePackPlayer(playerOrRarity);
    done = topOvrMaybe;
  }
  clearPackAnimTimers();

  const overlay = $('rl-spin-overlay');
  const layerPack = $('pk-stage-pack');
  const layerFlag = $('pk-stage-flag');
  const layerPos = $('pk-stage-pos');
  const layerRating = $('pk-stage-rating');
  const layerCard = $('pk-stage-card');
  const allLayers = [layerPack, layerFlag, layerPos, layerRating, layerCard];
  const pack = $('pk-pack');
  const rays = $('pk-rays');
  const cardRays = $('pk-card-rays');
  const glow = $('pk-bg-glow');
  const flash = $('pk-flash');
  const card = $('pk-card');
  const packTapHint = $('pk-tap-hint');
  const cardTapHint = $('pk-card-tap-hint');
  const infoFlag = $('pk-info-flag');
  const infoPos = $('pk-info-pos');
  const infoRating = $('pk-info-rating');
  const ratingRing = $('pk-info-rating-ring');

  overlay.classList.remove('hidden');
  // reset every layer/element to a clean state so re-runs never inherit
  // classes from a previous pull (this was the source of prior glitches).
  allLayers.forEach((el) => el.classList.remove('show'));
  pack.className = 'pk-pack';
  rays.className = 'pk-rays';
  cardRays.className = 'pk-card-rays';
  glow.className = 'pk-bg-glow';
  flash.className = 'pk-flash';
  card.className = 'pk-card';
  infoFlag.className = 'pk-info-flag';
  infoPos.className = 'pk-info-pos';
  infoRating.className = 'pk-info-rating';
  ratingRing.className = 'pk-info-rating-ring';
  packTapHint.style.display = '';
  packTapHint.textContent = 'DOUBLE TAP TO OPEN';
  cardTapHint.classList.remove('show');

  const rarityGlow = { bronze: '#c98a4b', silver: '#cfd8e6', gold: '#ffdf7e', icon: '#a0f0ff', hero: '#cf9bff' }[player.rarity];
  overlay.style.setProperty('--pk-glow', rarityGlow);
  card.classList.add('rar-' + player.rarity);
  rays.classList.add('rar-' + player.rarity);
  $('pk-card-ovr').textContent = ovrD(player.ovr);
  $('pk-card-pos2').textContent = player.pos;
  $('pk-card-name').textContent = player.name;
  $('pk-card-flag2').textContent = flagEmojiGame(player.nation);
  const imgEl = $('pk-card-img');
  imgEl.style.visibility = 'hidden';
  if (player.pid && window.UACard) { imgEl.onload = imgEl.onerror = null; imgEl.dataset.pid = player.pid; imgEl.dataset.uac = ''; imgEl.style.visibility = 'visible'; setTimeout(() => UACard.scan(imgEl.parentElement), 0); }
  else {
  imgEl.src = player.img;
  imgEl.onload = () => { imgEl.style.visibility = 'visible'; };
  imgEl.onerror = () => { imgEl.style.visibility = 'hidden'; };
  }
  infoFlag.textContent = flagEmojiGame(player.nation);
  infoPos.textContent = player.pos;
  infoRating.textContent = '';

  let phase = 'pack'; // pack -> opened -> flag -> pos -> rating -> card -> done
  let doubleTapArmed = false, lastTapAt = 0;

  function showLayer(layer) {
    allLayers.forEach((el) => el.classList.toggle('show', el === layer));
  }
  function finish() {
    overlay.classList.add('hidden');
    clearPackAnimTimers();
    overlay.removeEventListener('pointerdown', onOverlayClick, true);
    if (done) done();
  }

  function onOverlayClick(e) {
    if (e && e.preventDefault) e.preventDefault();
    if (e && e.stopPropagation) e.stopPropagation();
    const now = performance.now();
    if (phase === 'pack') {
      // require a double-tap (two taps within 500ms) to open. Uses
      // pointerdown rather than click: mobile browsers can treat a fast
      // double-tap as a zoom gesture and swallow the second click entirely.
      if (now - lastTapAt < 500) { lastTapAt = 0; openPack(); }
      else { lastTapAt = now; }
      return;
    }
    if (phase === 'card') { finish(); return; } // tap anywhere on the final card to close early
    // Mid-sequence tap (flag/pos/rating stages): skip straight to the card.
    if (phase !== 'opening-burst') { jumpToCard(); }
  }
  // Capture phase + stopPropagation guarantees this fires cleanly with no
  // interference from any other global pointer handler in the page.
  overlay.addEventListener('pointerdown', onOverlayClick, true);

  // ---------------------------------------------------------------------
  // Stage 1: UA PACK — shown up to 10s, double-tap opens it early.
  // ---------------------------------------------------------------------
  showLayer(layerPack);
  audio.packAppear();
  requestAnimationFrame(() => pack.classList.add('enter', 'idle'));
  packAfter(500, () => pack.classList.add('armed'));
  packAfter(10000, () => { if (phase === 'pack') openPack(); });

  function jumpToCard() {
    phase = 'card';
    clearPackAnimTimers();
    showLayer(layerCard);
    flash.classList.add('on');
    glow.classList.add('bright');
    cardRays.classList.add('on');
    card.classList.add('fly');
    audio.packCardIn(player.rarity);
    spawnPackSparks(true);
    overlay.classList.add(['icon', 'hero'].includes(player.rarity) ? 'screen-shake-huge' : 'screen-shake');
    packAfter(900, () => overlay.classList.remove('screen-shake', 'screen-shake-huge'));
    packAfter(1000, () => { card.classList.remove('fly'); card.classList.add('settle'); });
    packAfter(1800, () => cardTapHint.classList.add('show'));
    packAfter(10000, () => { if (phase === 'card') finish(); });
  }

  function openPack() {
    if (phase !== 'pack') return;
    phase = 'opening-burst';
    clearPackAnimTimers();
    packTapHint.style.display = 'none';
    pack.classList.remove('idle', 'armed');
    pack.classList.add('shaking');
    glow.classList.add('on');
    audio.packShake();
    packAfter(120, () => audio.packShake());
    packAfter(240, () => audio.packShake());
    packAfter(360, () => audio.packShake());
    packAfter(480, () => audio.packShake());
    packAfter(600, () => audio.packShake());
    packAfter(720, () => audio.packShake());
    packAfter(840, () => audio.packShake());
    packAfter(1000, () => {
      flash.classList.add('on');
      rays.classList.add('on');
      pack.classList.remove('shaking');
      pack.classList.add('burst');
      overlay.classList.add(['icon', 'hero'].includes(player.rarity) ? 'screen-shake-huge' : 'screen-shake');
      packAfter(900, () => overlay.classList.remove('screen-shake', 'screen-shake-huge'));
      audio.packBurst(player.rarity);
      spawnPackSparks(true);
    });

    // ---- Stage 2: NATION — exactly 3s ----
    packAfter(1350, () => {
      phase = 'flag';
      showLayer(layerFlag);
      infoFlag.classList.add('pop');
      audio.packStageIn('flag');
    });
    packAfter(4350, () => {
      // ---- Stage 3: POSITION — exactly 3s ----
      phase = 'pos';
      showLayer(layerPos);
      infoPos.classList.add('pop');
      audio.packStageIn('pos');
    });
    packAfter(7350, () => {
      // ---- Stage 4: RATING — exactly 5s, with a count-up + expanding ring ----
      phase = 'rating';
      showLayer(layerRating);
      infoRating.classList.add('pop');
      ratingRing.classList.add('ring-on');
      audio.packStageIn('rating');
      audio.packRatingRoll(ovrD(player.ovr));
      const target = ovrD(player.ovr);
      const start = Math.max(40, target - 22);
      const steps = 14;
      for (let i = 0; i <= steps; i++) {
        packAfter(i * 26, () => { infoRating.textContent = Math.round(start + (target - start) * (i / steps)); });
      }
      packAfter(600, () => { infoRating.textContent = target; });
    });
    // ---- Stage 5: FULL CARD — shown after rating's 5s, up to 10s / tap to close ----
    packAfter(12350, () => {
      phase = 'card';
      showLayer(layerCard);
      glow.classList.add('bright');
      cardRays.classList.add('on');
      card.classList.add('fly');
      audio.packCardIn(player.rarity);
      spawnPackSparks(true);
      overlay.classList.add(['icon', 'hero'].includes(player.rarity) ? 'screen-shake-huge' : 'screen-shake');
      packAfter(900, () => overlay.classList.remove('screen-shake', 'screen-shake-huge'));
      packAfter(1000, () => { card.classList.remove('fly'); card.classList.add('settle'); });
      packAfter(1800, () => cardTapHint.classList.add('show'));
    });
    packAfter(22350, () => { if (phase === 'card') finish(); }); // 10s after the card appears
  }
}

function rarityFor(name) {
  const h = hashStr(name) % 100;
  return h < 52 ? 'bronze' : h < 82 ? 'silver' : h < 96 ? 'gold' : 'icon';
}
function ovrFor(rarity, seed) {
  const h = seed % 7;
  if (rarity === 'bronze') return 74 + h;
  if (rarity === 'silver') return 80 + h;
  if (rarity === 'gold') return 86 + (h % 5);
  return 91 + (h % 5);
}
function normalizePos(raw) {
  if (!raw) return null;
  const t = raw.trim().toUpperCase().replace(/[^A-Z]/g, '');
  if (['GK', 'CB', 'LB', 'RB', 'DM', 'CM', 'CAM', 'LM', 'RM', 'LW', 'RW', 'ST'].includes(t)) return t;
  if (t.includes('GK') || t.includes('GOALKEEPER') || t.includes('KEEPER')) return 'GK';
  if (t.includes('ST') || t.includes('STR') || t.includes('STRIKER') || t.includes('FORWARD')) return 'ST';
  if (t.includes('CB') || t.includes('DEF') || t.includes('CENTREBACK') || t.includes('CENTERBACK')) return 'CB';
  if (t.includes('LW') || t.includes('LEFTWING')) return 'LW';
  if (t.includes('RW') || t.includes('RIGHTWING')) return 'RW';
  if (t.includes('CAM') || t.includes('ATTACKINGMID')) return 'CAM';
  if (t.includes('LB')) return 'LB';
  if (t.includes('RB')) return 'RB';
  if (t.includes('CM') || t.includes('MID') || t.includes('MIDFIELD')) return 'CM';
  return null;
}
function roundRectPath(g, x, y, w, h, r) {
  g.beginPath();
  g.moveTo(x + r, y);
  g.arcTo(x + w, y, x + w, y + h, r);
  g.arcTo(x + w, y + h, x, y + h, r);
  g.arcTo(x, y + h, x, y, r);
  g.arcTo(x, y, x + w, y, r);
  g.closePath();
}
function proceduralCard(rec) {
  const c = document.createElement('canvas');
  c.width = 300; c.height = 470;
  const g = c.getContext('2d');
  const rc = RARITY[rec.rarity] || RARITY.bronze;
  const grad = g.createLinearGradient(0, 0, 300, 470);
  grad.addColorStop(0, rc.a);
  grad.addColorStop(1, rc.b);
  g.fillStyle = grad;
  roundRectPath(g, 0, 0, 300, 470, 26);
  g.fill();
  g.fillStyle = 'rgba(6,10,20,0.9)';
  roundRectPath(g, 14, 14, 272, 442, 18);
  g.fill();
  g.fillStyle = rc.txt;
  g.font = '700 64px Rajdhani, sans-serif';
  g.textAlign = 'left';
  g.fillText(String(ovrD(rec.ovr)), 34, 108);
  g.font = '700 26px Rajdhani, sans-serif';
  g.fillText(rec.pos || 'ST', 38, 142);
  g.fillStyle = '#ffffff';
  g.font = '700 30px Rajdhani, sans-serif';
  g.textAlign = 'center';
  const words = (rec.name || 'PLAYER').toUpperCase().split(' ');
  g.fillText(words[0] || 'PLAYER', 150, 380);
  if (words[1]) g.fillText(words.slice(1).join(' '), 150, 414);
  g.fillStyle = rc.glow;
  g.font = '700 16px Rajdhani, sans-serif';
  g.fillText('★ UA FC 27 ★', 150, 442);
  return c.toDataURL('image/png');
}
function dedupeReg() {
  const seen = new Set();
  REG = REG.filter((r) => {
    if (seen.has(r.id)) return false;
    seen.add(r.id);
    return true;
  });
  regIndex = new Map(REG.map((r) => [r.id, r]));
}
/* ==========================================================================
   CLOUD PLAYER REGISTRY — the ONLY source of players. Fetches published
   players_registry rows from Supabase (uploaded via UA_FC_MANAGER.html).
   There is no local players/ folder fallback anymore — if Supabase is
   unreachable, the game shows a connection-error screen instead of
   silently trying to scan local files.
   ========================================================================== */
function statsFromCloudRow(row) {
  // Real per-attribute stats from the registry are now 1-500 and OVR is
  // 1-300 (raised from the old FIFA-style 1-99/1-99 caps). The gameplay
  // engine's formulas (sprint speed, tackle success, shot accuracy, etc.)
  // are all tuned around a 1-99 scale, so every incoming value is
  // normalized down to that same 1-99-equivalent range here — this is
  // the single point of conversion, so a 500 really does play like a
  // maxed-out 99 instead of being silently passed through unscaled
  // (which was the actual bug: previously raw 1-500 values went straight
  // into formulas built for 1-99, so 21 and 500 barely differed once
  // clamped by downstream min/max calls).
  const normStat = (v) => clamp(Math.round((v / 500) * 99), 1, 99);
  const normOvr = clamp(Math.round((row.ovr / 300) * 99), 1, 99);
  const base = row.ovr ? normOvr : 70;
  const isGK = row.position === 'GK';
  const isDef = ['CB', 'LB', 'RB'].includes(row.position);
  const isFwd = row.position === 'ST' || (row.position || '').includes('W');
  return {
    pace: row.pace != null ? normStat(row.pace) : clamp(base + randInt(-4, 4), 50, 97),
    shoot: row.shooting != null ? normStat(row.shooting) : clamp(base + randInt(-4, 5) + (isFwd ? 3 : 0) - (isGK ? 12 : 0), 40, 97),
    pass: row.passing != null ? normStat(row.passing) : clamp(base + randInt(-4, 4), 45, 97),
    drib: row.dribbling != null ? normStat(row.dribbling) : clamp(base + randInt(-4, 5), 45, 97),
    def: row.defending != null ? normStat(row.defending) : clamp(base + randInt(-5, 3) + (isDef ? 5 : 0), 40, 96),
    gk: isGK ? (row.defending != null ? clamp(normStat(row.defending) + 3, 1, 99) : clamp(base + 3, 55, 97)) : 25,
  };
}
function cloudRowToRecord(row) {
  // Same shape as a local REG entry ({id, name, pos, rarity, ovr, img})
  // plus the real attribute stats, so everything downstream (spin wheel,
  // squad builder, card rendering) works completely unchanged.
  return {
    id: 'cloud-' + row.id,
    name: row.name,
    pos: normalizePos(row.position) || 'CM',
    rarity: ['bronze', 'silver', 'gold', 'icon', 'hero'].includes(row.rarity) ? row.rarity : 'bronze',
    ovr: row.ovr,
    nation: row.nationality || null,
    img: mediaUrlFor(row.media_path),
    mediaType: row.media_type,
    cloudStats: statsFromCloudRow(row),
    playstyles: normalizePlaystyles(row.playstyles),
    weakFoot: clamp(parseInt(row.weak_foot, 10) || 3, 1, 5),
    model: row.model_data && typeof row.model_data === 'object' ? row.model_data : null,
    modelVersion: row.model_version || 0,
    _cloudRow: row,
  };
}
async function autoLoadRegistryCloud(onProgress) {
  const p = onProgress || (() => {});
  try {
    p('CONNECTING TO PLAYER SERVER…');
    const { data, error } = await sb
      .from('players_registry')
      .select('*')
      .eq('is_active', true)
      .order('ovr', { ascending: false });
    if (error) throw error;
    if (!data || !data.length) return false;
    p(`LOADING ${data.length} PLAYER${data.length === 1 ? '' : 'S'} FROM CLOUD…`);
    REG = data.map(cloudRowToRecord);
    dedupeReg();
    return REG.length > 0;
  } catch (err) {
    ;
    return false;
  }
}
async function autoLoadRegistry(onProgress) {
  REG = [];
  return autoLoadRegistryCloud(onProgress);
}
function regById(id) { return id ? regIndex.get(id) || null : null; }
function regByName(name) {
  for (const r of REG) if (r.name === name) return r;
  return null;
}

/* ==========================================================================
   16 · SQUADS FROM REGISTRY (position-aware + duplicates)
   ========================================================================== */
function roleAccepts(role, pos) {
  if (!pos) return false;
  if (role === 'GK') return pos === 'GK';
  if (role === 'LB' || role === 'RB' || role === 'CB') return ['CB', 'LB', 'RB', 'DM'].includes(pos);
  if (role === 'ST') return ['ST', 'CAM', 'LW', 'RW'].includes(pos);
  if (role === 'LW' || role === 'LM') return ['LW', 'LM', 'CAM', 'ST', 'CM'].includes(pos);
  if (role === 'RW' || role === 'RM') return ['RW', 'RM', 'CAM', 'ST', 'CM'].includes(pos);
  return ['CM', 'CAM', 'CDM', 'DM', 'LM', 'RM'].includes(pos);
}
/* --------------------------------------------------------------------------
   OWNERSHIP-AWARE HOME SQUAD (fixes: new accounts seeing the entire global
   registry instead of only players they actually acquired).

   Source of truth for the human player's (team 0) squad is now:
     1. user_players — players actually acquired via Market, Exchange,
        Luck Royale or UA Box. This is the ONLY way a player should ever
        end up in a real account's pool going forward.
     2. starter_squad — the admin's chosen starting XI (set from the
        "Starter Squad" tab in UA_FC_MANAGER.html), used ONLY to fill a
        brand-new account that owns nothing yet, so kickoff never has to
        fall back to the full global registry or generic placeholders.

   Dev Mode / any local setting NEVER grants players here — this function
   doesn't read `settings` at all, by design, so there's no path for a
   client-side toggle to inflate what a fresh account can field.

   The AI opponent (team 1) is intentionally left untouched: it keeps
   pulling a random spread from the full REG registry, per product
   decision — variety of opposition isn't an ownership concern.
   -------------------------------------------------------------------- */
let starterSquadCache = null; // [{player_id, slot_role, sort_order}], admin-defined, rarely changes
async function fetchStarterSquad() {
  if (starterSquadCache) return starterSquadCache;
  try {
    const { data, error } = await sb.from('starter_squad').select('player_id, slot_role, sort_order').order('sort_order');
    if (error) throw error;
    starterSquadCache = data || [];
  } catch (e) {
    ;
    starterSquadCache = [];
  }
  return starterSquadCache;
}
async function fetchOwnedPlayerRecords() {
  // Returns players_registry rows the signed-in user actually owns, in
  // the same shape as a REG entry so the rest of the pipeline (roleAccepts,
  // stats assignment, model rendering) doesn't need to know the source.
  if (!cloudUser) return [];
  try {
    const { data, error } = await sb.from('user_players').select('player_id, players_registry(*)').eq('user_id', cloudUser.id);
    if (error) throw error;
    return (data || []).filter((r) => r.players_registry).map((r) => cloudRowToRecord(r.players_registry));
  } catch (e) {
    ;
    return [];
  }
}
async function buildHomePlayerPool() {
  const owned = await fetchOwnedPlayerRecords();
  if (owned.length) return owned; // has acquired at least one player themselves — use only that
  // Brand-new / still-empty account: use the admin's curated starter XI,
  // resolved against REG so we get full stats/model data, not a stub.
  const starters = await fetchStarterSquad();
  const resolved = starters.map((s) => regIndex.get('cloud-' + s.player_id) || regIndex.get(String(s.player_id))).filter(Boolean);
  return resolved; // may be empty if admin hasn't set one yet — caller handles that
}
function applySquadFromList(squad, list) {
  if (!list.length) return; // nothing to assign — caller decides the fallback policy
  const assigned = new Set();
  for (const slot of squad) {
    const rec = list.find((r) => !assigned.has(r.id) && roleAccepts(slot.role, r.pos));
    if (rec) {
      assigned.add(rec.id);
      Object.assign(slot, { name: rec.name, ovr: rec.ovr, _regId: rec.id, _inj: true, model: rec.model, modelVersion: rec.modelVersion });
    }
  }
  let cycle = 0;
  for (const slot of squad) {
    if (slot._inj) continue;
    const rec = list[cycle % list.length];
    cycle++;
    Object.assign(slot, { name: rec.name, ovr: rec.ovr, _regId: rec.id, _inj: true, model: rec.model, modelVersion: rec.modelVersion });
  }
  for (const s of squad) {
    const base = s.ovr;
    const isGK = s.role === 'GK';
    const isDef = s.role.includes('B');
    const isFwd = s.role === 'ST' || s.role.includes('W');
    const regRec = regIndex.get(s._regId) || list.find((r) => r.id === s._regId);
    if (regRec && regRec.cloudStats) {
      // Real attributes published from playerregister.html.
      s.stats = { ...regRec.cloudStats };
      s.playstyles = normalizePlaystyles(regRec.playstyles);
      s.weakFoot = regRec.weakFoot || 3;
      continue;
    }
    s.stats = {
      pace: clamp(base + randInt(-4, 4), 50, 97),
      shoot: clamp(base + randInt(-4, 5) + (isFwd ? 3 : 0) - (isGK ? 12 : 0), 40, 97),
      pass: clamp(base + randInt(-4, 4), 45, 97),
      drib: clamp(base + randInt(-4, 5), 45, 97),
      def: clamp(base + randInt(-5, 3) + (isDef ? 5 : 0), 40, 96),
      gk: isGK ? clamp(base + 3, 55, 97) : 25,
    };
    s.playstyles = [];
  }
}
async function buildSquadsFromRegistry() {
  if (!REG.length) return;
  const homeList = await buildHomePlayerPool();
  const awayList = [...REG].sort(() => Math.random() - 0.5);
  // Away team (AI opponent): always a random spread from the full global
  // registry, unchanged from before — this is intentionally not an
  // ownership concern.
  applySquadFromList(squads[1], awayList);
  if (benches[1]) applySquadFromList(benches[1], awayList);
  if (squads[1][6]) squads[1][6].captain = true;
  if (!homeList.length) {
    // No owned players AND no admin starter_squad configured yet. Rather
    // than silently falling back to the full global registry (the exact
    // bug being fixed), leave team 0 on the generic generateSquad()
    // placeholders and surface this clearly so it gets noticed and fixed
    // from the admin side, instead of masked by quietly handing out the
    // entire roster.
    ;
    await applyLockerJerseyNumbers();
    saveCloudSquadSnapshot();
    return;
  }
  applySquadFromList(squads[0], homeList);
  if (benches[0]) applySquadFromList(benches[0], homeList);
  if (squads[0][6]) squads[0][6].captain = true;
  await applyLockerJerseyNumbers();
  saveCloudSquadSnapshot();
}
/* Overlays the user's custom Locker Room squad numbers (user_players.
   jersey_number) onto squads[0] after the registry assigns default numbers
   above. Best-effort and non-blocking: if it fails or the user has no
   custom numbers set, squads[0] simply keeps its generated numbers — this
   never affects squads[1] (the opponent) or touches any model_data. */
let lockerNumbersCache = null;
async function applyLockerJerseyNumbers() {
  if (!cloudUser) return;
  try {
    const { data, error } = await sb.from('user_players').select('player_id, jersey_number').eq('user_id', cloudUser.id).not('jersey_number', 'is', null);
    if (error) throw error;
    lockerNumbersCache = new Map((data || []).map((r) => [r.player_id, r.jersey_number]));
    for (const s of squads[0]) {
      const regId = s._regId && typeof s._regId === 'string' ? s._regId.replace('cloud-', '') : null;
      if (regId && lockerNumbersCache.has(regId)) s.num = lockerNumbersCache.get(regId);
    }
  } catch (e) { ; }
}
/* Saves a lightweight snapshot of the player's current home squad to
   user_squads when signed in — a cloud record of the lineup they've
   played with, without requiring a full squad-editor UI. Best-effort:
   never blocks match start, never surfaces errors to the player. */
let squadSyncTimer = null;
function saveCloudSquadSnapshot() {
  if (!cloudUser) return;
  clearTimeout(squadSyncTimer);
  squadSyncTimer = setTimeout(async () => {
    try {
      const ids = squads[0].map((s) => s._regId).filter((id) => id && id.startsWith('cloud-')).map((id) => id.replace('cloud-', ''));
      if (!ids.length) return;
      const { data: existing } = await sb.from('user_squads').select('id').eq('user_id', cloudUser.id).eq('is_active', true).maybeSingle();
      const row = {
        user_id: cloudUser.id,
        squad_name: `${teamDefs[0].name} XI`,
        formation: '4-4-2',
        player_ids: ids,
        is_active: true,
      };
      if (existing) await sb.from('user_squads').update(row).eq('id', existing.id);
      else await sb.from('user_squads').insert(row);
    } catch (err) {
      ;
    }
  }, 1500);
}

/* ==========================================================================
   17 · AI ASSISTANT (live API + offline brain)
   ========================================================================== */
const aiHistory = [];
let aiBusy = false;
function aiContext() {
  const roster = REG.map(r => `${r.name} (${r.pos}, OVR ${ovrD(r.ovr)}, ${r.rarity})`).join(', ') || 'none registered yet';
  const vaultN = Object.values(vault).reduce((a, b) => a + b, 0);
  const coinsLabel = coins;
  return `You are UA AI, the assistant inside the football game "${APP_NAME}". Answer briefly (2-4 sentences), friendly, like a football game companion.
Game facts you know:
- Coins: ${coinsLabel}. Earned after each match; spent in Luck Royale spins.
- Registered players from the cloud registry: ${roster}.
- Vault: ${vaultN} player copies collected via Luck Royale.
- Controls: left stick moves, SHOOT button shoots (hold=power, swipe up=chip, swipe left=curl), PASS passes (swipe up=through), SKILL does tricks, RUN sprints (double-tap=speed burst). Keyboard: WASD move, C shoot, X pass, E skill, Shift sprint, Z/V/B through/chip/curl, Space switch, Q cycle camera.
- There are ${CELEBRATIONS.length} celebrations, ${CAM_MODES.length} camera modes, and post-match awards (Golden Boot, Golden Glove, Player of the Match).
- The user can open Settings for control size, and camera height/FOV.
Current user question follows.`;
}
function hasValidKey(p) {
  return p.key && p.key.length > 8 && !p.key.startsWith('PASTE_');
}
async function callProvider(p, messages) {
  const controller = new AbortController();
  const to = setTimeout(() => controller.abort(), 15000);
  try {
    if (p.style === 'openai') {
      const res = await fetch(p.url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + p.key },
        body: JSON.stringify({ model: p.model, messages, temperature: 0.7 }),
        signal: controller.signal,
      });
      clearTimeout(to);
      if (!res.ok) throw new Error('HTTP ' + res.status);
      const data = await res.json();
      return (data.choices && data.choices[0] && data.choices[0].message && data.choices[0].message.content) || '';
    } else if (p.style === 'gemini') {
      const url = p.url + '?key=' + p.key;
      const prompt = messages.map(m => m.role + ': ' + m.content).join('\n');
      const res = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ contents: [{ parts: [{ text: prompt }] }] }),
        signal: controller.signal,
      });
      clearTimeout(to);
      if (!res.ok) throw new Error('HTTP ' + res.status);
      const data = await res.json();
      return (data.candidates && data.candidates[0] && data.candidates[0].content && data.candidates[0].content.parts && data.candidates[0].content.parts[0].text) || '';
    }
  } catch (e) {
    clearTimeout(to);
    throw e;
  }
  clearTimeout(to);
  throw new Error('Unknown provider');
}
function localAI(q) {
  const t = q.toLowerCase();
  const best = REG.length ? [...REG].sort((a, b) => b.ovr - a.ovr)[0] : null;
  const gks = REG.filter(r => r.pos === 'GK');
  const vaultN = Object.values(vault).reduce((a, b) => a + b, 0);
  if (/(coin|money|cash|rich)/.test(t)) {
    return `You currently have <b>${coins}</b> coins. Win matches to earn more (win = 300 + 30 per goal, clean sheet +100, comeback +100), then spend them on Luck Royale spins.`;
  }
  if (/(best|top|highest|strongest|greatest)/.test(t) && /(player|card|squad)/.test(t)) {
    return best
      ? `Your best registered player is <b>${best.name}</b> — ${best.pos}, OVR <b>${ovrD(best.ovr)}</b>, ${best.rarity} rarity. Build the team around them! ⭐`
      : 'No players are registered yet. Publish players via UA FC MANAGER to get started.';
  }
  if (/(goalkeeper|gk|keeper)/.test(t)) {
    return gks.length
      ? `You have ${gks.length} registered goalkeeper(s): ${gks.map(g => `${g.name} (OVR ${ovrD(g.ovr)})`).join(', ')}. They will automatically guard the net.`
      : 'No dedicated GK is registered, so an outfield player will fill in. Add one with playerpos.txt set to GK.';
  }
  if (/(how many|count|number)/.test(t) && /(player|roster|card)/.test(t)) {
    return `You have <b>${REG.length}</b> registered player(s) in the cloud registry and <b>${vaultN}</b> copies collected in your vault.`;
  }
  if (/(roster|squad|list|who|players)/.test(t)) {
    if (!REG.length) return 'No players registered yet. Publish players via UA FC MANAGER to get started.';
    return `Here's your squad: ${REG.slice(0, 8).map(r => `<b>${r.name}</b> (${r.pos}, ${ovrD(r.ovr)})`).join(', ')}${REG.length > 8 ? ` and ${REG.length - 8} more.` : '.'}`;
  }
  if (/(control|button|play|how to|tutorial|help)/.test(t)) {
    return 'Left stick moves your player. SHOOT fires (hold for power, release in the green zone for a PERFECT shot, swipe ▲ to chip, ◀ to curl). PASS aims to your stick (swipe ▲ for a through ball). SKILL does tricks, RUN sprints — double-tap it for a speed burst. On keyboard: WASD, C shoot, X pass, E skill, Shift sprint.';
  }
  if (/(camera|view|angle)/.test(t)) {
    return `There are ${CAM_MODES.length} cameras: ${CAM_MODES.map(c => CAM_LABELS[c]).join(', ')}. Press Q in a match to cycle them, or pick one in Settings → Camera.`;
  }
  if (/(celebration|celebrate|dance)/.test(t)) {
    return `There are ${CELEBRATIONS.length} celebrations, picked randomly when you score — including ${CELEBRATIONS.slice(0, 6).map(c => c.name).join(', ')} and more. Score a goal to see one! 🎉`;
  }
  if (/(bicycle|overhead|volley)/.test(t)) {
    return 'To do a BICYCLE KICK, let the ball rise in the air near you and press SHOOT at the right moment. Timing is everything — it fires a rocket if you nail it.';
  }
  if (/(spin|royale|pack|luck)/.test(t)) {
    return `Luck Royale costs 120 coins per spin (350 for a Gold spin with better odds). It pulls players straight from the cloud registry. Duplicates still count toward your vault collection.`;
  }
  if (/(award|trophy|golden|boot|glove)/.test(t)) {
    return 'After every match you get awards: 🥇 Golden Boot (top scorer), 🧤 Golden Glove (best keeper), 🏆 Player of the Match, plus Playmaker and The Wall. Check the full-time screen!';
  }
  if (/(setting|camera|sound|control)/.test(t)) {
    return 'Open Settings (⚙) to change controls, camera, sound, commentary and stadium weather.';
  }
  if (/(position|pos|formation)/.test(t)) {
    return 'playerpos.txt decides where a player plays: GK, CB, LB, RB, CM, CAM, LW, RW, ST, etc. The game places them in their real position and fills any gaps with duplicates.';
  }
  if (/(hello|hi|hey|sup|yo)/.test(t)) {
    return 'Hey coach! 👋 Ask me about your players, coins, controls, cameras, celebrations or awards. I know everything happening in UA FC MOBILE.';
  }
  if (/(win|tip|advice|better|improve|tactic)/.test(t)) {
    return 'Pro tips: pass quickly to build the 🔥 CHAIN meter (8+ = speed boost), release shots in the green zone for PERFECT power, use SKILL to nutmeg defenders, and keep an eye on stamina. You got this, coach!';
  }
  return `I'm your ${APP_NAME} assistant. Ask me about your <b>players</b>, <b>coins</b>, <b>controls</b>, <b>cameras</b>, <b>celebrations</b> or <b>awards</b>. For example: "Who is my best player?"`;
}
function aiAddMsg(text, cls) {
  const box = $('ai-msgs');
  const div = document.createElement('div');
  div.className = 'ai-msg ' + cls;
  div.innerHTML = text;
  box.appendChild(div);
  box.scrollTop = box.scrollHeight;
  return div;
}
async function askAI(question) {
  if (!question.trim() || aiBusy) return;
  aiAddMsg(question.replace(/</g, '&lt;'), 'user');
  $('ai-input').value = '';
  aiBusy = true;
  const typing = document.createElement('div');
  typing.className = 'ai-typing';
  typing.textContent = 'UA AI is thinking…';
  $('ai-msgs').appendChild(typing);
  $('ai-msgs').scrollTop = $('ai-msgs').scrollHeight;
  aiHistory.push({ role: 'user', content: question });
  if (aiHistory.length > 8) aiHistory.shift();
  let answer = null;
  let usedProvider = null;
  const messages = [{ role: 'system', content: aiContext() }, ...aiHistory];
  for (const p of AI_CONFIG.providers) {
    if (!hasValidKey(p)) continue;
    try {
      answer = await callProvider(p, messages);
      if (answer && answer.trim()) { usedProvider = p.name; break; }
    } catch (e) { /* try next */ }
  }
  if (!answer) {
    answer = localAI(question);
    usedProvider = 'LOCAL AI';
  }
  aiHistory.push({ role: 'assistant', content: answer });
  if (aiHistory.length > 8) aiHistory.shift();
  typing.remove();
  aiAddMsg(answer, 'bot');
  $('ai-prov').textContent = usedProvider.toUpperCase();
  aiBusy = false;
}
function toggleAI(open) {
  const panel = $('ai-panel');
  const fab = $('btn-ai-fab');
  if (open === undefined) open = !panel.classList.contains('open');
  panel.classList.toggle('open', open);
  fab.classList.toggle('show', !open && match.screen !== 'match');
  if (open) $('ai-input').focus();
}

/* ==========================================================================
   PLAYER REVEAL OVERLAY
   ========================================================================== */
function closeReveal() {
  const reveal = $('ov-reveal');
  if (reveal) reveal.classList.remove('show');
}

/* ==========================================================================
   PLAYER CARD PREVIEW — tap any player card anywhere to open a big preview
   with a × close button. Call openPlayerPreview({name, ovr, rarity/pos, img})
   with whatever fields are available; missing ones are just left blank.
   ========================================================================== */
function openPlayerPreview(p) {
  if (!p) return;
  const img = p.img || '';
  const imgEl = $('pcard-preview-img');
  const wrap = $('pcard-preview-img-wrap') || imgEl.parentElement;
  imgEl.onerror = null;
  imgEl.onload = null;
  imgEl.style.visibility = 'hidden';
  if (p.pid && window.UACard) {
    imgEl.dataset.pid = p.pid; imgEl.dataset.uac = ''; imgEl.style.visibility = 'visible';
    if (wrap) wrap.classList.remove('loading');
    setTimeout(() => UACard.scan(wrap || document), 0);
  } else {
  if (wrap) wrap.classList.toggle('loading', !!img);
  if (img) {
    let retried = false;
    imgEl.onload = () => { imgEl.style.visibility = 'visible'; if (wrap) wrap.classList.remove('loading'); };
    imgEl.onerror = () => {
      if (!retried) {
        // One retry — Supabase Storage / mobile networks occasionally
        // drop the first request for large GIFs, so a retry clears most
        // "preview sometimes doesn't load" cases without user action.
        retried = true;
        setTimeout(() => { imgEl.src = img + (img.includes('?') ? '&' : '?') + 'retry=1'; }, 400);
      } else {
        if (wrap) wrap.classList.remove('loading');
        imgEl.style.visibility = 'hidden';
      }
    };
    imgEl.src = img;
  } else {
    if (wrap) wrap.classList.remove('loading');
  }
  }
  $('pcard-preview-ovr').textContent = (p.ovr !== undefined && p.ovr !== null) ? p.ovr : '';
  $('pcard-preview-ovr').style.display = (p.ovr !== undefined && p.ovr !== null) ? '' : 'none';
  $('pcard-preview-name').textContent = p.name || '—';
  const metaParts = [p.rarity, p.pos].filter(Boolean);
  $('pcard-preview-meta').textContent = metaParts.length ? metaParts.join(' · ').toUpperCase() : '';
  $('pcard-preview').classList.add('show');
}
function closePlayerPreview() {
  $('pcard-preview').classList.remove('show');
}
$('pcard-preview-close').addEventListener('click', (e) => { e.stopPropagation(); audio.ui(); closePlayerPreview(); });
$('pcard-preview').addEventListener('click', (e) => { if (e.target === $('pcard-preview')) closePlayerPreview(); });

/* ==========================================================================
   18 · COMMENTARY
   ========================================================================== */
const COM_GOAL = [
  'GOAL! WHAT A FINISH!', 'THE ROOF COMES OFF!', 'ABSOLUTE SCREAMER!',
  'BURIED INTO THE NET!', 'THE KEEPER HAD NO CHANCE!', 'CLINICAL FINISHING!',
  'SENSATIONAL STRIKE!', 'THE NET IS BULGING!', 'TAKE A BOW — GOAL!',
];
const COM_SAVE = ['GREAT SAVE!', 'FINGERTIPS!', 'DENIED BY THE KEEPER!', 'WHAT A STOP!', 'PARRIED AWAY!', 'STANDING ON HIS HEAD!'];
const COM_TACKLE = ['CRUNCHING TACKLE!', 'HE WINS IT CLEANLY!', 'DISPOSSESSED!', 'SLIDING IN!', 'STRIPPED THE BALL!', 'TIMED TO PERFECTION!'];
const COM_SHOT = ['shoots!', 'fires goalward!', 'unleashes an effort!', 'tries his luck!', 'rips a shot!', 'goes for goal!'];
const COM_FRAME = ['OFF THE POST!', 'CROSSBAR! SO CLOSE!', 'THE WOODWORK SAYS NO!'];
function sayPick(pool, extra = '') {
  if (!settings.commentary) return;
  say(pick(pool) + (extra ? ' ' + extra : ''));
}

/* ==========================================================================
   19 · KICK LIBRARY
   ========================================================================== */
function attackGoalX(teamIdx) { return teamIdx === 0 ? FIELD.halfLen : -FIELD.halfLen; }
function teammatesOf(p) { return players.filter((q) => q.team === p.team && !q.sentOff); }
function nearestOpponentDistOf(p) {
  let best = 1e9;
  for (const q of players) {
    if (q.team === p.team) continue;
    best = Math.min(best, dist2(p.pos.x, p.pos.z, q.pos.x, q.pos.z));
  }
  return best;
}
function laneBlocked(a, b, team) {
  for (const q of players) {
    if (q.team === team || q === a || q === b) continue;
    const ax = a.pos.x, az = a.pos.z;
    const abx = b.pos.x - ax, abz = b.pos.z - az;
    const t = clamp01(((q.pos.x - ax) * abx + (q.pos.z - az) * abz) / (abx * abx + abz * abz + 1e-6));
    if (Math.hypot(ax + abx * t - q.pos.x, az + abz * t - q.pos.z) < 1.6 && t > 0.08 && t < 0.92) return true;
  }
  return false;
}
function findBestPass(kicker, aimX, aimZ) {
  const hasAim = aimX !== undefined && aimZ !== undefined && Math.hypot(aimX, aimZ) > 0.25;
  let best = null, bestScore = -1e9;
  const gx = attackGoalX(kicker.team);
  for (const mate of teammatesOf(kicker)) {
    if (mate === kicker || mate.isGK) continue;
    const d = dist2(kicker.pos.x, kicker.pos.z, mate.pos.x, mate.pos.z);
    if (d < 2.5 || d > 50) continue;
    const dx = (mate.pos.x - kicker.pos.x) / d;
    const dz = (mate.pos.z - kicker.pos.z) / d;
    let score;
    if (hasAim) {
      const al = Math.hypot(aimX, aimZ) || 1;
      const dot = (dx * aimX + dz * aimZ) / al;
      if (dot < 0.30) continue;
      score = dot * 42 - d * 0.35 + Math.min(nearestOpponentDistOf(mate), 9) * 1.2;
      if (laneBlocked(kicker, mate, kicker.team)) score -= 10;
    } else {
      score = dx * Math.sign(gx - kicker.pos.x) * 16 - Math.abs(d - 17) * 0.55;
      score += Math.min(nearestOpponentDistOf(mate), 9) * 1.5;
      if (laneBlocked(kicker, mate, kicker.team)) score -= 14;
    }
    if (score > bestScore) { bestScore = score; best = mate; }
  }
  if (best) return best;
  let fb = null, fbd = 1e9;
  for (const mate of teammatesOf(kicker)) {
    if (mate === kicker || mate.isGK) continue;
    const d = dist2(kicker.pos.x, kicker.pos.z, mate.pos.x, mate.pos.z);
    if (d > 4 && d < fbd) { fbd = d; fb = mate; }
  }
  return fb || teammatesOf(kicker).find((m) => m !== kicker && !m.isGK);
}
function releaseBall(p) {
  if (ball.owner === p) { ball.owner = null; p.hasBall = false; }
  ball.lastKicker = p;
  ball.kickCooldown = 0.35;
  match.lastTouchTeam = p.team;
  match.lastTouchPlayer = p;
}
function registerShot(p) {
  match.stats.shots[p.team]++;
  trackStat(p, 'shots');
  ball.shotActive = true;
  ball.shotTeam = p.team;
  sayPick(COM_SHOT.map(s => p.name + ' ' + s));
}
/* Elite Power Shot: plans an exact flight (air drag + gravity solved in closed form) that ends inside
   the goal from any distance, then flies the ball along it frame-rate independently. The flag
   (eliteShotT) makes the keeper and defenders unable to touch it. */
function launchEliteShot(gx, aimZ, v0) {
  const k = PHYS.airDrag, g = -PHYS.gravity;
  const tz = clamp(aimZ, -2.9, 2.9);
  const ty = rand(0.7, 1.5);
  // The path passes exactly through (goal line, tz) and carries on 0.5 further, so the goal is
  // registered on the planned path, whatever the angle.
  const cx = gx + Math.sign(gx) * 0.12 - ball.pos.x, cz = tz - ball.pos.z;
  const D0 = Math.hypot(cx, cz) || 1;
  const ux = cx / D0, uz = cz / D0, D = D0 + 0.5;
  v0 = Math.max(v0, D * 0.69); // long shots get extra pace so the arc stays flat (flight <= ~1.6 s)
  const T = -Math.log(1 - (D * k) / v0) / k;
  const vy = (ty - ball.pos.y + 0.5 * g * T * T) / T;
  ball.eliteFlight = { t: 0, T, k, g, vh: v0, vy, dx: ux, dz: uz, x0: ball.pos.x, y0: ball.pos.y, z0: ball.pos.z };
  ball.vel.set(ux * v0, vy, uz * v0);
  ball.spin.set(0, 0, 0);
  ball.eliteShotT = T + 1.5;
}
function stepEliteFlight(dt) {
  const f = ball.eliteFlight;
  if (!f) return false;
  f.t = Math.min(f.T, f.t + dt);
  const e = Math.exp(-f.k * f.t), sH = (f.vh / f.k) * (1 - e);
  ball.pos.set(f.x0 + f.dx * sH, f.y0 + f.vy * f.t - 0.5 * f.g * f.t * f.t, f.z0 + f.dz * sH);
  ball.vel.set(f.dx * f.vh * e, f.vy - f.g * f.t, f.dz * f.vh * e);
  if (f.t >= f.T) ball.eliteFlight = null; // lands on the goal line; normal physics carries it in
  return true;
}
/* Finesse flight: ball path measured frame-by-frame from the reference clip (camera calibrated on the pitch
   lines, height from the ball shadow). Reference shot: ~12.2 m out, flight 0.63 s, forward progress
   s = 1-(1-t)^1.25 (fast off the foot, slowing), height pops to ~0.55 m after one frame, peaks ~1.57 m at 58%
   of the flight, then flattens to ~1.4 m on the goal line; lateral = straight line to the post corner plus a
   ~0.3 m bow toward the centre. Distance scales time (t ~ D^0.8) and arch height; keepers CAN still save it. */
const FIN_H = [[0, null], [0.05, 0.54], [0.16, 0.85], [0.26, 1.08], [0.32, 1.20], [0.42, 1.35], [0.53, 1.52], [0.58, 1.57], [0.68, 1.52], [0.79, 1.48], [1, 'end']];
function finHeight(f, u) {
  const P = FIN_H.map(([t, h]) => [t, h === null ? f.y0 : h === 'end' ? f.hEnd : f.y0 + (h - 0.14) * f.arch + 0]);
  let i = 0; while (i < P.length - 2 && u > P[i + 1][0]) i++;
  const p0 = P[Math.max(0, i - 1)], p1 = P[i], p2 = P[i + 1], p3 = P[Math.min(P.length - 1, i + 2)];
  const w = clamp((u - p1[0]) / (p2[0] - p1[0]), 0, 1);
  const m1 = (p2[1] - p0[1]) / (p2[0] - p0[0]) * (p2[0] - p1[0]);
  const m2 = (p3[1] - p1[1]) / (p3[0] - p1[0]) * (p2[0] - p1[0]);
  const w2 = w * w, w3 = w2 * w;
  const base = (2 * w3 - 3 * w2 + 1) * p1[1] + (w3 - 2 * w2 + w) * m1 + (-2 * w3 + 3 * w2) * p2[1] + (w3 - w2) * m2;
  if (!f.corner) return base;
  const climb = f.y0 + (f.hEnd - f.y0) * Math.pow(clamp(u, 0, 1), 1.3); // Finesse Expert: rises straight into the top corner
  return base * (1 - f.corner) + climb * f.corner;
}
function finPosRaw(f, u) {
  const s = 1 - Math.pow(1 - u, 1.25);
  const env = f.corner ? 6.75 * u * (1 - u) * (1 - u) : Math.sin(Math.PI * u); // expert: bend eases to zero slope at the line
  return { x: f.x0 + f.dirX * f.D * s, y: finHeight(f, u), z: f.z0 + (f.tz - f.z0) * s + f.bow * env };
}
// u = 1 is exactly the goal line (hits tz / hEnd); past it the path carries straight on into the net.
function finPos(f, t) {
  const u = t / f.Tl;
  if (u <= 1) return finPosRaw(f, Math.max(0, u));
  const a = finPosRaw(f, 1), b = finPosRaw(f, 0.99), k = (u - 1) / 0.01;
  const sz = (a.z - b.z) * Math.sign(a.z || 1) > 0 ? 0 : (a.z - b.z); // past the line never drift out toward the post
  const sy = Math.min(0, a.y - b.y);                                    // ...nor rise into the bar
  return { x: a.x + (a.x - b.x) * k, y: Math.max(0.14, a.y + sy * k), z: a.z + sz * k };
}
/* Finesse goal chance by distance to goal (m): 8m 57%, 20m 45%, 40m 20%, 70m 12%, 100m -2%,
   times the tier: none 0.7x, silver 1.3x, gold 1.6x, diamond 2x, black(elite) 3.5x. */
const FIN_CHANCE = [[0, 0.57], [8, 0.57], [20, 0.45], [40, 0.20], [70, 0.12], [100, -0.02]];
const FIN_TIER_MUL = { silver: 1.3, gold: 1.6, diamond: 2, elite: 3.5 };
function finesseGoalChance(d, tier) {
  let base = FIN_CHANCE[FIN_CHANCE.length - 1][1];
  for (let i = 0; i < FIN_CHANCE.length - 1; i++) {
    const [d0, c0] = FIN_CHANCE[i], [d1, c1] = FIN_CHANCE[i + 1];
    if (d <= d1) { base = c0 + (c1 - c0) * clamp((d - d0) / (d1 - d0), 0, 1); break; }
  }
  return clamp(base * (FIN_TIER_MUL[tier] || 0.7), 0, 1);
}
function launchFinesseShot(gx, tz, speedMul, bowMul, hEnd, corner, sure) {
  const dirX = Math.sign(gx) || 1;
  const D = Math.abs(gx - ball.pos.x); // exactly to the goal line
  // Shooting from wide at the post on the SAME side: the shallow angle would clip the post, so aim a touch further in.
  if (corner && Math.sign(ball.pos.z) === Math.sign(tz) && Math.abs(ball.pos.z) > Math.abs(tz)) {
    tz -= Math.sign(tz) * 0.32 * clamp((Math.abs(ball.pos.z) - Math.abs(tz)) / 6, 0, 1);
  }
  const dz = tz - ball.pos.z;
  const ref = 12.2;
  const Tl = (0.63 * Math.pow(D / ref, 0.8)) / Math.max(0.5, speedMul);
  const f = {
    t: 0, Tl: Math.min(Tl, 2.6), T: Math.min(Tl, 2.6) * (1 + 0.45 / Math.max(D, 3)), // flight runs ~0.45 m past the line so the goal registers
    D, dirX, x0: ball.pos.x, y0: Math.max(ball.pos.y, 0.14), z0: ball.pos.z, tz,
    hEnd, arch: clamp(0.7 + 0.3 * (D / ref), 0.85, 1.6),
    bow: -Math.sign(dz || 1) * Math.min(0.5 * D + 1, (0.02 * D + 0.04 * Math.abs(dz)) * bowMul),
    corner: corner || 0,
    sure: !!sure, // a finesse that was rolled as 'goes in': keeper and defenders can't touch it
    lv: null,
  };
  ball.finesseFlight = f;
  const a = finPos(f, 0), b = finPos(f, 1 / 120);
  ball.vel.set((b.x - a.x) * 120, (b.y - a.y) * 120, (b.z - a.z) * 120);
  f.lv = ball.vel.clone();
  ball.spin.set(0, 0, 0);
}
function stepFinesseFlight(dt) {
  const f = ball.finesseFlight;
  if (!f) return false;
  // anything else touching the ball (keeper, defender, post) changes its velocity -> hand back to normal physics
  if (ball.owner || match.state !== 'play' || ball.vel.distanceTo(f.lv) > 0.75) { ball.finesseFlight = null; return false; }
  f.t = Math.min(f.T, f.t + dt);
  const p = finPos(f, f.t), q = finPos(f, Math.min(f.T, f.t + 1 / 120));
  ball.pos.set(p.x, p.y, p.z);
  const span = Math.max(1e-4, Math.min(f.T, f.t + 1 / 120) - f.t) || 1 / 120;
  if (f.t >= f.T) { const r = finPos(f, f.T - 1 / 120); ball.vel.set((p.x - r.x) * 120, (p.y - r.y) * 120, (p.z - r.z) * 120); ball.finesseFlight = null; return true; }
  ball.vel.set((q.x - p.x) / span, (q.y - p.y) / span, (q.z - p.z) / span);
  f.lv.copy(ball.vel);
  return true;
}
/* ---- v2 PlayStyle helpers ---- */
// Closed-form lob: initial velocity that lands the ball at (tx,tz) after T seconds (matches the ball's drag + gravity).
function lobVelocity(tx, tz, T) {
  const k = PHYS.airDrag, g = -PHYS.gravity;
  const f = (1 - Math.exp(-k * T)) / k;
  return { x: (tx - ball.pos.x) / f, z: (tz - ball.pos.z) / f, y: (PHYS.ballRadius - ball.pos.y + 0.5 * g * T * T) / T };
}
// Shot-speed multiplier from Thunder (shot speed/power) and Hardshot. Power is treated as energy -> speed x sqrt(1+power).
function psShotMul(p, power, isClear) {
  let m = 1, boost = 0;
  const ts = psThunder(p, 'shot_speed'), tp = psThunder(p, 'shot_power');
  if (ts > 0) { m *= 1 + ts; boost += ts * 0.5; }
  if (tp > 0) { m *= Math.sqrt(1 + tp); boost += tp * 0.5; }
  if (hasStyle(p, 'Hardshot') && (isClear || power >= 0.8)) { const hp = psStat(p, 'Hardshot', 'shot_power'); m *= Math.sqrt(1 + hp); boost += hp; }
  return { m, boost, hard: hasStyle(p, 'Hardshot') && (isClear || power >= 0.8), thunder: ts > 0 || tp > 0 };
}
// Pickup radius for a player going for the ball: Reach, Vision first touch, Thunder control penalty, interception resistance.
function psPickupRadius(p, base) {
  let r = base;
  const reach = psStat(p, 'Reach', 'reach');
  if (reach > 0) r *= 1 + reach;
  if (p === ball.passTarget) r *= 1 + psStat(p, 'Vision', 'first_touch') * 0.5;
  r *= psControlMul(p);
  if (ball.intRes > 0 && ball.lastKicker && p.team !== ball.lastKicker.team) r *= Math.max(0.3, 1 - ball.intRes);
  return r;
}
function psPickupHeight(p) {
  let y = 1.1;
  y += psStat(p, 'Reach', 'reach') * 0.8;
  if (hasStyle(p, 'Power Header') && psPowerHeaderOn(p)) y += psStat(p, 'Power Header', 'head_reach') * 0.9;
  return y;
}
function activateThunder(p, byAI = false) {
  if (!p || p.thunderT > 0 || match.state !== 'play') return false;
  const name = psThunderName(p);
  if (!name) return false;
  const spec = PS_NEW_SPEC[name];
  const used = p.thunderUses || 0;
  if (used >= spec.uses) { if (!byAI) toast('THUNDER USED'); return false; }
  const second = used >= 1;
  if (second && name === 'Thunder+') {
    if (!hasStyle(p, 'Relentless')) { if (!byAI) toast('NEEDS RELENTLESS'); return false; }
    if (!settings.godStamina && p.stamina < spec.second_min_stamina) { if (!byAI) toast('NEEDS ' + spec.second_min_stamina + '% STAMINA'); return false; }
  }
  p.thunderUses = used + 1;
  p.thunderName = name;
  p.thunderT = spec.duration;
  if (!settings.godStamina) p.stamina = Math.max(0, p.stamina - (second ? spec.drain_second : spec.drain_first));
  triggerStyleBadge(p, name);
  toast(name.toUpperCase() + '!');
  emitSpark(p.pos.x, 0.8, p.pos.z, 22);
  audio.perfect();
  haptic(80);
  return true;
}
function performKick(p, type, opts = {}) {
  const gx = attackGoalX(p.team);
  releaseBall(p);
  ball.passAcc = 0; ball.intRes = 0; ball.powerBoost = 0; ball.throughTarget = null; // per-kick PlayStyle flags (set again below when a style applies)
  const aim = opts.aim || { x: 0, z: 0 };
  const power = opts.power !== undefined ? opts.power : 0.6;
  const acc = (p.stats.shoot + p.stats.pass) / 200;
  const highAssist = settings.passAssist === 'high';
  if (type === 'pass') {
    const mate = opts.target || findBestPass(p, aim.x, aim.z);
    if (!mate) return;
    const lead = highAssist ? 0.75 : 0.45;
    const tx = mate.pos.x + mate.vel.x * lead;
    const tz = mate.pos.z + mate.vel.z * lead;
    const d = dist2(p.pos.x, p.pos.z, tx, tz);
    const dirv = new THREE.Vector3(tx - p.pos.x, 0, tz - p.pos.z).normalize();
    // Bullet Pass: passes travel noticeably faster along the ground.
    // Tiki Taka: short-range passes (under ~9 units) land with pinpoint
    // accuracy — reflected here as tighter target leading on close balls.
    const bulletAmt = styleBonus(p, 'Bullet Pass', 0.18, 0.4);
    const tikiRange = hasStyle(p, 'Tiki Taka') === 'elite' ? 27 : 9; // Elite: pinpoint out to 3x the range
    const tikiAmt = d < tikiRange ? Math.min(1, styleBonus(p, 'Tiki Taka', 0.5, 1.0, 1.0)) : 0; // lerp ceiling is 1
    const tightTx = lerp(tx, mate.pos.x, tikiAmt);
    const tightTz = lerp(tz, mate.pos.z, tikiAmt);
    const dirv2 = new THREE.Vector3(tightTx - p.pos.x, 0, tightTz - p.pos.z).normalize();
    psRotate(dirv2, psPassSpread(p)); // Thunder: passing penalty = wild aim
    ball.vel.copy(dirv2).multiplyScalar(clamp(9 + d * 0.5, 10, 22) * (1 + bulletAmt));
    ball.vel.y = 0.6;
    ball.spin.set(0, 0, 0);
    ball.passTarget = mate;
    ball.passTargetT = 2.6;
    ball.passAcc = psStat(p, 'Vision', 'passing_accuracy');            // Vision: stronger pass homing
    ball.intRes = psStat(p, 'Vision', 'pass_interception_resistance'); // Vision: harder to intercept
    if (hasStyle(p, 'Vision')) triggerStyleBadge(p, 'Vision');
    match.lastPasser = p;
    match.stats.passes[p.team]++;
    trackStat(p, 'passes');
    audio.pass();
    if (bulletAmt > 0) triggerStyleBadge(p, 'Bullet Pass');
    if (tikiAmt > 0) triggerStyleBadge(p, 'Tiki Taka');
    p.startAction('pass', 0.42, 0.16, null);
    // Hand control to the receiver immediately rather than leaving the
    // player on the passer, who is locked mid-animation for the next
    // 0.42s — otherwise the joystick looks dead for that stretch.
    if (p.team === 0 && mate.team === 0) controlled = mate;
  } else if (type === 'through') {
    const mate = opts.target || findBestPass(p, aim.x || Math.sign(gx - p.pos.x), aim.z || 0);
    if (!mate) return;
    const tx = clamp(mate.pos.x + Math.sign(gx - mate.pos.x) * 9, -FIELD.halfLen + 3, FIELD.halfLen - 3);
    const tz = mate.pos.z * 0.8;
    const d = dist2(p.pos.x, p.pos.z, tx, tz);
    const dirv = new THREE.Vector3(tx - p.pos.x, 0, tz - p.pos.z).normalize();
    psRotate(dirv, psPassSpread(p));
    ball.vel.copy(dirv).multiplyScalar(clamp(11 + d * 0.5, 12, 23));
    ball.vel.y = 5.4;
    ball.throughTarget = mate; ball.throughT = 3.4;                      // Target / Target+: receiver gets the buff on pickup
    ball.intRes = psStat(p, 'Vision', 'pass_interception_resistance');
    if (hasStyle(p, 'Vision')) triggerStyleBadge(p, 'Vision');
    match.lastPasser = p;
    match.stats.passes[p.team]++;
    trackStat(p, 'passes');
    audio.pass();
    p.startAction('through', 0.45, 0.18, null);
  } else if (type === 'cross') {
    // Whipped Cross: faster, more accurately whipped crosses into the box.
    const whipAmt = styleBonus(p, 'Whipped Cross', 0.16, 0.35);
    const tz = -Math.sign(p.pos.z || 1) * 2.2 * (1 - whipAmt * 0.3);
    const tx = gx - Math.sign(gx) * 6;
    const dirv = new THREE.Vector3(tx - p.pos.x, 0, tz - p.pos.z).normalize();
    psRotate(dirv, psPassSpread(p));
    ball.vel.copy(dirv).multiplyScalar(19 * (1 + whipAmt));
    ball.vel.y = 8.2 * (1 - whipAmt * 0.15); // whipped crosses fly flatter/faster, less lofted
    match.lastPasser = p;
    match.stats.passes[p.team]++;
    trackStat(p, 'passes');
    audio.pass();
    if (whipAmt > 0) triggerStyleBadge(p, 'Whipped Cross');
    p.startAction('cross', 0.5, 0.2, null);
  } else if (type === 'shoot') {
    const assist = p.team === 0 ? 0.55 : 1.0;
    const perfect = !!opts.perfect;
    const inForm = !!p.inForm;
    // Power Shot: faster, harder shots with tighter accuracy (less noise).
    // Clinical Finisher: general shot-accuracy boost across all finishing.
    const powerShotAmt = styleBonus(p, 'Power Shot', 0.09, 0.2);
    const clinicalAmt = styleBonus(p, 'Clinical Finsher', 0.12, 0.26);
    const penaltyAmt = opts.isPenalty ? styleBonus(p, 'Penalty Expert', 0.15, 0.35) : 0;
    let noise = rand(-1, 1) * (1.25 - acc) * 1.8 * assist;
    const red = (a) => Math.max(0, 1 - a); // Elite amounts can exceed 1 -> floor at 0 (= perfect)
    if (Math.random() < 0.5) noise *= 1 + (3 - (p.weakFoot || 3)) * 0.12; // weak-foot shot: 1★ = +24% error, 5★ = -24%
    noise *= red(powerShotAmt * 0.5) * red(clinicalAmt) * red(penaltyAmt) * red(psTargetBuff(p, 'finishing'));
    if (perfect) noise *= 0.45;
    if (inForm) noise *= 0.7;
    // Elite Clinical Finisher: with no aim given, the shot is placed in the corner farthest from the keeper.
    let aimZ = opts.targetZ !== undefined ? opts.targetZ : rand(-2.4, 2.4);
    if (hasStyle(p, 'Clinical Finsher') === 'elite' && opts.targetZ === undefined) {
      const gkp = players.find((q) => q.isGK && q.team !== p.team);
      if (gkp) aimZ = gkp.pos.z > 0 ? -2.9 : 2.9;
    }
    const tz = clamp(aimZ + noise, -3.4, 3.4);
    const ty = 0.35 + power * 1.7 + rand(0, 0.5);
    const target = new THREE.Vector3(gx, ty, tz);
    const dirv = target.sub(ball.pos).normalize();
    const psm = psShotMul(p, power, false);
    const shotSpeed = Math.min(58, (19 + power * 14) * (perfect ? 1.13 : 1) * (1 + powerShotAmt) * psm.m);
    ball.powerBoost = psm.boost; // goalkeepers find big-power shots harder to hold
    if (hasStyle(p, 'Power Shot') === 'elite' && power >= PS_ELITE_POWERSHOT_MINPOWER && Math.random() < PS_ELITE_POWERSHOT_CHANCE) {
      // Elite Power Shot signature: only a FULL-POWER shot, and only 20% of the time. From ANYWHERE (even the
      // halfway line) it flies a calculated arc into the goal and cannot be saved or blocked.
      // Every other Elite Power Shot is a normal (very fast, very accurate) shot that can be saved.
      launchEliteShot(gx, aimZ, shotSpeed);
      toast('ELITE POWER SHOT!');
      emitSpark(ball.pos.x, 0.6, ball.pos.z, 16);
      perfectTrailT = 1.5;
    } else {
      ball.vel.copy(dirv).multiplyScalar(shotSpeed);
    }
    registerShot(p);
    audio.kick(power);
    if (psm.hard) triggerStyleBadge(p, 'Hardshot');
    if (psm.thunder) triggerStyleBadge(p, p.thunderName);
    if (opts.isPenalty) triggerStyleBadge(p, 'Penalty Expert');
    else if (powerShotAmt > 0) triggerStyleBadge(p, 'Power Shot');
    if (clinicalAmt > 0) triggerStyleBadge(p, 'Clinical Finsher');
    if (perfect) {
      audio.perfect();
      toast('PERFECT POWER SHOT!');
      haptic(90);
      perfectTrailT = 1.5;
      emitSpark(ball.pos.x, 0.4, ball.pos.z, 12);
    }
    emitGrass(ball.pos.x, ball.pos.z, dirv.x, dirv.z, 14);
    shakeAmt = Math.min(1, shakeAmt + 0.25 + power * 0.3);
    p.startAction('shoot', 0.62, 0.24, null);
  } else if (type === 'curl' || type === 'curl2') {
    // curl: bends toward goal-center from the player's current side (drag-down).
    // curl2: bends the opposite way — an outswinger (drag-right).
    // Finesse Expert: more curve and better accuracy on finesse-style shots.
    const finesseAmt = styleBonus(p, 'Finesse Expert', 0.16, 0.35);
    const clinicalAmt2 = styleBonus(p, 'Clinical Finsher', 0.12, 0.26);
    const autoSide = p.pos.z > 0 ? -1 : 1;
    const side = type === 'curl2' ? -autoSide : autoSide;
    // Base finesse = the reference clip. Finesse Expert scales with tier (silver < gold < diamond < elite):
    // far bigger bend, more pace/range, near-zero error, and the ball is sent into the top corner of the post.
    // Elite is exact: 0.26 m inside the post, 0.3 m under the bar, zero spread, on either side.
    const FX = { silver: { bow: 7, err: 0.07, tz: 3.32, h: 2.05, c: 0.45 },
                 gold: { bow: 12, err: 0.025, tz: 3.36, h: 2.1, c: 0.6 },
                 diamond: { bow: 20, err: 0.008, tz: 3.39, h: 2.14, c: 0.75 },
                 elite: { bow: 34, err: 0, tz: 3.40, h: 2.17, c: 0.9 } }[hasStyle(p, 'Finesse Expert')] || null;
    // ---- Will this finesse actually go in? Chance depends on distance, then is scaled by the playstyle tier. ----
    const dShot = Math.hypot(gx - p.pos.x, p.pos.z);
    const psPow = hasStyle(p, 'Power Shot');
    const finTier = hasStyle(p, 'Finesse Expert');
    // Power Shot (diamond / black) + any Finesse Expert = long-range finesse specialist: distance counts as much shorter + pace.
    const combo = finTier && (psPow === 'diamond' || psPow === 'elite') ? (psPow === 'elite' ? 0.4 : 0.55) : 0;
    const chance = finesseGoalChance(dShot * (combo || 1), finTier);
    const sure = Math.random() < chance;
    let tz, hEnd, spdMul = 1, bowMul = 1, corner = 0;
    if (FX) { bowMul = FX.bow; corner = FX.c; } else bowMul = 2.6;
    if (combo) spdMul = psPow === 'elite' ? 1.6 : 1.35;
    if (sure) {
      if (FX) {
        tz = side * FX.tz + rand(-1, 1) * FX.err * Math.max(0, 1 - clinicalAmt2);
        hEnd = FX.h + rand(-1, 1) * FX.err * 0.6;
      } else {
        tz = clamp(side * 3.0 + rand(-0.45, 0.45) * Math.max(0, 1 - clinicalAmt2), -3.25, 3.25);
        hEnd = clamp(1.4 + rand(-0.12, 0.12), 0.9, 1.9);
      }
    } else {
      // Doesn't go in: wide of the post, over the bar, or a weaker effort the keeper can still deal with.
      const r = Math.random();
      if (r < 0.4) { tz = side * rand(4.2, 7.5); hEnd = rand(0.6, 2.2); }
      else if (r < 0.75) { tz = side * rand(1.2, 3.4); hEnd = rand(3.0, 5.0); }
      else { tz = side * rand(1.0, 2.6); hEnd = rand(0.5, 1.3); }
    }
    launchFinesseShot(gx, tz, spdMul, bowMul, hEnd, corner, sure);
    curlTrailT = 1.2;
    registerShot(p);
    audio.kick(0.7);
    if (finesseAmt > 0) triggerStyleBadge(p, 'Finesse Expert');
    if (clinicalAmt2 > 0) triggerStyleBadge(p, 'Clinical Finsher');
    p.startAction('curl', 0.58, 0.22, null);
  } else if (type === 'chip') {
    // Chip Shot: faster and more accurately placed chips over the keeper.
    const chipAmt = styleBonus(p, 'Chip Shot', 0.14, 0.3);
    const tz = clamp(rand(-1.6, 1.6) * Math.max(0, 1 - chipAmt), -3, 3);
    const dirv = new THREE.Vector3(gx - p.pos.x, 0, tz - p.pos.z).normalize();
    ball.vel.copy(dirv).multiplyScalar(13.5 * (1 + chipAmt * 0.4));
    ball.vel.y = 9.2;
    registerShot(p);
    audio.kick(0.5);
    if (chipAmt > 0) triggerStyleBadge(p, 'Chip Shot');
    p.startAction('chip', 0.55, 0.2, null);
  } else if (type === 'volley') {
    const tz = clamp(rand(-2.6, 2.6), -3.3, 3.3);
    const target = new THREE.Vector3(gx, 1.0, tz);
    const dirv = target.sub(ball.pos).normalize();
    ball.vel.copy(dirv).multiplyScalar(24 + power * 8);
    registerShot(p);
    audio.kick(1);
    p.startAction('shoot', 0.6, 0.2, null);
  } else if (type === 'bicycle') {
    const tz = clamp(rand(-1.8, 1.8), -3.2, 3.2);
    const target = new THREE.Vector3(gx, 1.1, tz);
    const dirv = target.sub(ball.pos).normalize();
    ball.vel.copy(dirv).multiplyScalar(27 + power * 6);
    registerShot(p);
    audio.kick(1);
    toast('BICYCLE KICK!');
    haptic(120);
    emitSpark(ball.pos.x, ball.pos.y, ball.pos.z, 18);
    p.startAction('bicycle', 0.85, 0.42, null);
  } else if (type === 'header') {
    // Header PlayStyle: more accurate, more powerful headers.
    const headerAmt = styleBonus(p, 'Header', 0.18, 0.4);
    const phOn = psPowerHeaderOn(p); // Power Header: 70% chance per contest; big power, but less accurate
    const phPow = phOn ? psStat(p, 'Power Header', 'header_power') : 0;
    const phAcc = phOn ? psStat(p, 'Power Header', 'accuracy') : 0; // negative
    const tz = clamp(rand(-2.8, 2.8) * (Math.max(0, 1 - headerAmt) + Math.max(0, -phAcc)), -3.3, 3.3);
    const target = new THREE.Vector3(gx, 0.9, tz);
    const dirv = target.sub(ball.pos).normalize();
    ball.vel.copy(dirv).multiplyScalar(Math.min(48, (17 + power * 6) * (1 + headerAmt * 0.35) * Math.sqrt(1 + phPow)));
    ball.powerBoost = phPow * 0.6;
    if (phOn) { triggerStyleBadge(p, 'Power Header'); p._phRollT = 0; }
    registerShot(p);
    audio.pass();
    if (headerAmt > 0) triggerStyleBadge(p, 'Header');
    p.startAction('header', 0.7, 0.3, null);
  } else if (type === 'clear') {
    const dirv = new THREE.Vector3(Math.sign(gx) * 0.8, 0, rand(-0.6, 0.6)).normalize();
    const clr = psShotMul(p, 1, true);
    ball.vel.copy(dirv).multiplyScalar(Math.min(46, 22 * (clr.hard ? clr.m : 1)));
    ball.vel.y = 9;
    if (clr.hard) triggerStyleBadge(p, 'Hardshot');
    audio.kick(0.9);
    p.startAction('shoot', 0.6, 0.22, null);
  } else if (type === 'chipPass') {
    // Chip Pass: a lofted ball over the defence. Anyone can lob; the PlayStyle makes it accurate, flat-consistent, quick and hard to pick off.
    const mate = opts.target || findBestPass(p, aim.x, aim.z);
    if (!mate) return;
    const cpAcc = psStat(p, 'Chip Pass', 'chip_pass_accuracy'), cpH = psStat(p, 'Chip Pass', 'chip_pass_height_control');
    const cpSp = psStat(p, 'Chip Pass', 'chip_pass_speed'), cpInt = psStat(p, 'Chip Pass', 'pass_interception_resistance');
    const d = dist2(p.pos.x, p.pos.z, mate.pos.x, mate.pos.z);
    let T = clamp(0.62 + d * 0.034, 0.75, 1.9) / (1 + cpSp);
    T = Math.max(0.5, T * (1 + rand(-0.22, 0.22) * Math.max(0, 1 - cpH))); // flight-time wobble = poor height control
    const errR = 2.4 * Math.max(0.08, 1 - cpAcc), ang = rand(0, Math.PI * 2), er = rand(0, errR);
    const tx = clamp(mate.pos.x + mate.vel.x * T * 0.8 + Math.cos(ang) * er, -FIELD.halfLen + 1, FIELD.halfLen - 1);
    const tz = clamp(mate.pos.z + mate.vel.z * T * 0.8 + Math.sin(ang) * er, -FIELD.halfWid + 1, FIELD.halfWid - 1);
    const L = lobVelocity(tx, tz, T);
    ball.vel.set(L.x, L.y, L.z);
    psRotate(ball.vel, psPassSpread(p));
    ball.spin.set(0, 0, 0);
    ball.passTarget = mate;
    ball.passTargetT = T + 1.2;
    ball.intRes = Math.max(cpInt, psStat(p, 'Vision', 'pass_interception_resistance'));
    match.lastPasser = p;
    match.stats.passes[p.team]++;
    trackStat(p, 'passes');
    audio.pass();
    if (hasStyle(p, 'Chip Pass')) triggerStyleBadge(p, 'Chip Pass');
    p.startAction('pass', 0.45, 0.16, null);
    if (p.team === 0 && mate.team === 0) controlled = mate;
  } else if (type === 'throw') {
    const mate = opts.target || findBestPass(p, aim.x, aim.z);
    if (!mate) return;
    const dirv = new THREE.Vector3(mate.pos.x - p.pos.x, 0, mate.pos.z - p.pos.z).normalize();
    if (hasStyle(p, 'Long Throw')) {
      // Long Throw: +distance/+power make the throw fly far, +hang time lofts it, +accuracy tightens where it lands.
      const dist = psStat(p, 'Long Throw', 'throw_distance'), pow = psStat(p, 'Long Throw', 'throw_power');
      const acc = psStat(p, 'Long Throw', 'throw_accuracy'), hang = psStat(p, 'Long Throw', 'ball_hang_time');
      const d = dist2(p.pos.x, p.pos.z, mate.pos.x, mate.pos.z);
      const vh = 14 * (1 + dist) * (1 + pow * 0.4);
      const T = clamp((d / vh) * (1 + hang), 0.55, 2.4);
      const errR = 2.0 * Math.max(0.1, 1 - acc), ang = rand(0, Math.PI * 2), er = rand(0, errR);
      const tx = clamp(mate.pos.x + mate.vel.x * T * 0.6 + Math.cos(ang) * er, -FIELD.halfLen + 1, FIELD.halfLen - 1);
      const tz = clamp(mate.pos.z + mate.vel.z * T * 0.6 + Math.sin(ang) * er, -FIELD.halfWid + 1, FIELD.halfWid - 1);
      const L = lobVelocity(tx, tz, T);
      ball.vel.set(L.x, L.y, L.z);
      triggerStyleBadge(p, 'Long Throw');
    } else {
      ball.vel.copy(dirv).multiplyScalar(14);
      ball.vel.y = 3.4;
    }
    ball.passTarget = mate;
    ball.passTargetT = 2.2;
    match.stats.passes[p.team]++;
    trackStat(p, 'passes');
    audio.pass();
    p.startAction('throw', 0.55, 0.25, null);
  } else if (type === 'gkThrow') {
    const mate = opts.target || findBestPass(p, 0, 0);
    if (!mate) return;
    const dirv = new THREE.Vector3(mate.pos.x - p.pos.x, 0, mate.pos.z - p.pos.z).normalize();
    ball.vel.copy(dirv).multiplyScalar(16);
    ball.vel.y = 1.6;
    ball.passTarget = mate;
    ball.passTargetT = 2.2;
    audio.pass();
    p.startAction('throw', 0.5, 0.2, null);
  }
}

/* ==========================================================================
   20 · SKILLS + TACKLES
   ========================================================================== */
function checkNutmeg(p) {
  const fwd = new THREE.Vector3(S(p.facing), 0, C(p.facing));
  for (const q of players) {
    if (q.team === p.team || q.stunTimer > 0) continue;
    const dx = q.pos.x - p.pos.x, dz = q.pos.z - p.pos.z;
    const d = Math.hypot(dx, dz);
    if (d < 1.8 && d > 0.2) {
      const dot = (dx / d) * fwd.x + (dz / d) * fwd.z;
      if (dot > 0.5) {
        q.stunTimer = 0.55;
        toast('NUTMEG!');
        haptic(50);
        chain[p.team] = Math.min(10, chain[p.team] + 1);
        return true;
      }
    }
  }
  return false;
}
function doTrick(p, idx) {
  if (p.action || p.stunTimer > 0) return;
  try { doTrickInner(p, idx); } finally { if (p.action) p.action.fromTrick = true; }
}
function doTrickInner(p, idx) {
  p._trickIdx = idx; // consumed by animatePlayer()'s stateForTrick() to pick the right baked clip (Stepover/BallRoll/RainbowFlick) instead of one generic 'trick' pose
  const fwd = new THREE.Vector3(S(p.facing), 0, C(p.facing));
  const right = new THREE.Vector3(fwd.z, 0, -fwd.x);
  // Trickster: skill moves hold off defenders for longer and carry more
  // burst out of the move, making 1v1s genuinely more winnable.
  const trickAmt = styleBonus(p, 'Trickster', 0.15, 0.35) + psTargetBuff(p, 'dribbling');
  p.trickShield = 0.55 * (1 + trickAmt);
  toast(TRICKS[idx]);
  audio.ui();
  haptic(20);
  if (trickAmt > 0) triggerStyleBadge(p, 'Trickster');
  chain[p.team] = Math.min(10, chain[p.team] + 0.5);
  checkNutmeg(p);
  if (idx === 0) p.startAction('trick', 0.5, 0.1, () => p.vel.addScaledVector(fwd, 5.5 * (1 + trickAmt * 0.3)));
  else if (idx === 1) p.startAction('trick', 0.45, 0.1, () => {
    p.vel.addScaledVector(right, 5 * (1 + trickAmt * 0.3));
    if (ball.owner === p) ball.pos.addScaledVector(right, 0.8);
  });
  else if (idx === 2) { p.startAction('trick', 0.6, 0.1, () => p.vel.addScaledVector(fwd, 6 * (1 + trickAmt * 0.3))); spinPlayer(p); }
  else if (idx === 3) {
    if (ball.owner === p) {
      releaseBall(p);
      ball.vel.copy(fwd).multiplyScalar(7.5);
      ball.vel.y = 8.5;
      p.vel.addScaledVector(fwd, 6.5);
    }
    p.startAction('header', 0.7, 0.2, null);
  } else if (idx === 4) {
    p.startAction('trick', 0.55, 0.12, () => p.vel.addScaledVector(fwd, 7.5));
  } else if (idx === 5) {
    p.startAction('trick', 0.5, 0.1, () => {
      p.vel.addScaledVector(right, 3.5);
      p.vel.addScaledVector(fwd, 4);
    });
  }
}
function spinPlayer(p) {
  const start = performance.now();
  const from = p.facing;
  const step = () => {
    const t = clamp01((performance.now() - start) / 500);
    p.facing = from + t * t * (3 - 2 * t) * Math.PI * 2;
    if (t < 1) requestAnimationFrame(step);
  };
  step();
}
function standingTackle(p) {
  if (p.tackleCd > 0 || p.action || p.stunTimer > 0 || p.sentOff) return;
  p.tackleCd = 0.8;
  p.vel.addScaledVector(new THREE.Vector3(S(p.facing), 0, C(p.facing)), 6);
  p.startAction('tackle', 0.4, 0.15, () => trySteal(p, 0.78, false), false);
  audio.tackle();
  haptic(40);
}
function slideTackle(p) {
  if (p.tackleCd > 0 || p.action || p.stunTimer > 0 || p.sentOff) return;
  // Sliding Tackle: longer slide, faster recovery (success / ball-winning bonuses live in trySteal).
  const stRange = psStat(p, 'Sliding Tackle', 'slide_range'), stRec = psStat(p, 'Sliding Tackle', 'recovery_speed_after_tackle');
  p.tackleCd = 1.4 / (1 + stRec);
  const fwd = new THREE.Vector3(S(p.facing), 0, C(p.facing));
  p.vel.addScaledVector(fwd, 10 * (1 + stRange));
  p.startAction('slide', 0.75, 0.25, () => {
    const ok = trySteal(p, 0.92, true);
    if (!ok) p.stunTimer = 1.0 / (1 + stRec);
  }, true);
  audio.tackle();
  emitGrass(p.pos.x, p.pos.z, fwd.x, fwd.z, 16);
  shakeAmt = Math.min(1, shakeAmt + 0.2);
  haptic(60);
}
function trySteal(p, chance, isSlide = false) {
  const owner = ball.owner;
  if (!owner || owner.team === p.team) return false;
  // Only an ELITE Anticipate defender can read through a skill move (everyone else is shut out
  // while the Trickster's shield is up) and he also reaches further to make the challenge.
  const eliteAnticipate = hasStyle(p, 'Anticipate') === 'elite';
  if (owner.trickShield > 0 && !eliteAnticipate) return false;
  const d = dist2(p.pos.x, p.pos.z, ball.pos.x, ball.pos.z);
  const slideReach = isSlide ? 1 + psStat(p, 'Sliding Tackle', 'slide_range') * 0.5 : 1;
  const tackleR = (eliteAnticipate ? 2.6 : 1.8) * slideReach;
  if (d > tackleR) return false;
  // Anticipate: higher tackle success with a lower fouling rate.
  // Bruiser: wins physical (standing) duels more often through sheer imposition.
  const anticipateAmt = styleBonus(p, 'Anticipate', 0.1, 0.22);
  const bruiserAmt = !isSlide ? styleBonus(p, 'Bruiser', 0.12, 0.26) : 0;
  const skill = (p.stats.def / 100) * chance * (p.team === 1 ? DIFFS[settings.diff].aiTackle + 0.3 : 1.25)
    * (1 + anticipateAmt + bruiserAmt + (isSlide ? psStat(p, 'Sliding Tackle', 'tackle_success') : 0))
    * (1 - Math.min(0.5, psTargetBuff(owner, 'dribbling') * 0.8)); // Target: the receiver's dribbling makes him harder to dispossess
  if (Math.random() < skill) {
    owner.hasBall = false;
    ball.owner = null;
    owner.controlCd = 0.6;
    const dirv = new THREE.Vector3(ball.pos.x - owner.pos.x, 0, ball.pos.z - owner.pos.z).normalize();
    ball.vel.copy(dirv).multiplyScalar(4);
    ball.vel.y = 1;
    if (isSlide && hasStyle(p, 'Sliding Tackle')) {
      // Ball-winning accuracy: a clean slide knocks the ball toward the tackler instead of loose.
      if (Math.random() < Math.min(1, psStat(p, 'Sliding Tackle', 'ball_winning_accuracy') * 2)) {
        const toP = new THREE.Vector3(p.pos.x - ball.pos.x, 0, p.pos.z - ball.pos.z).normalize();
        ball.vel.copy(toP).multiplyScalar(2.2);
        owner.controlCd = 1.0;
        p.controlCd = 0;
      }
      triggerStyleBadge(p, 'Sliding Tackle');
    }
    match.stats.tackles[p.team]++;
    trackStat(p, 'tackles');
    chain[p.team] = Math.min(10, chain[p.team] + 2);
    sayPick(COM_TACKLE, p.name);
    audio.tackle();
    if (anticipateAmt > 0) triggerStyleBadge(p, 'Anticipate');
    if (bruiserAmt > 0) triggerStyleBadge(p, 'Bruiser');
    return true;
  }
  // Missed tackle -> chance of a foul, higher for slide tackles and
  // tackles thrown in from close/behind (mistimed challenges).
  const closeness = clamp01(1 - d / tackleR);
  const baseFoulChance = (isSlide ? 0.34 : 0.16) * closeness;
  const recklessness = 1 - p.stats.def / 130; // weaker defenders foul more often
  const foulChance = clamp(baseFoulChance * (0.7 + recklessness) * (1 - anticipateAmt * 1.4), 0.02, 0.6);
  if (Math.random() < foulChance) {
    commitFoul(p, owner, isSlide);
  }
  return false;
}
/* ==========================================================================
   REFEREE · FOULS, CARDS, PENALTIES, FREE KICKS
   ========================================================================== */
function commitFoul(offender, victim, severe = false) {
  if (match.state !== 'play') return; // don't double-whistle mid-restart
  if (match.evRules && match.evRules.noFouls) return; // event rule: play on
  const inBox = inPenaltyAreaOf(offender.team, victim.pos.x, victim.pos.z);
  offender.foulsCommitted++;
  match.stats.fouls[offender.team]++;
  audio.whistle('short');
  victim.stunTimer = Math.max(victim.stunTimer, 0.4);
  offender.vel.multiplyScalar(0.2);
  haptic(70);
  // Card decision: escalates with repeat offenses + a chance of a
  // straight red on a bad/reckless (slide) foul.
  let card = null;
  const straightRedChance = severe ? 0.05 : 0.012;
  if (Math.random() < straightRedChance) {
    card = 'red';
  } else if (offender.foulsCommitted >= 3 || (severe && offender.foulsCommitted >= 2)) {
    card = offender.yellowCards >= 1 ? 'red' : 'yellow';
  } else if (severe && Math.random() < 0.3) {
    card = 'yellow';
  }
  if (card && match.evRules && match.evRules.noCards) card = null; // event rule: no cards
  const spot = { x: victim.pos.x, z: victim.pos.z };
  if (card) bookCard(offender, card);
  sayPick(['FOUL!', 'THE REFEREE STOPS PLAY.', 'THAT WAS A CHALLENGE.'], offender.name);
  toast(inBox ? '⚠ FOUL — PENALTY!' : '⚠ FOUL');
  const doRestart = () => {
    if (inBox) startPenalty(victim.team);
    else startSetPiece('freekick', victim.team, spot);
  };
  setTimeout(() => {
    if (settings.instantReplay && NET.mode !== 'guest') {
      replayTrigger(4.5);
      if (REPLAY.playing) { REPLAY.afterPlaybackFn = doRestart; return; }
    }
    doRestart();
  }, card ? 900 : 400);
}
function bookCard(p, kind) {
  if (kind === 'yellow') {
    p.yellowCards++;
    match.stats.yellows[p.team]++;
    toast('🟨 YELLOW CARD — ' + p.name);
    sayPick([`Booking for ${p.name}.`]);
    if (p.yellowCards >= 2) { bookCard(p, 'red'); return; }
  } else if (kind === 'red') {
    match.stats.reds[p.team]++;
    toast('🟥 RED CARD — ' + p.name + ' IS OFF!');
    sayPick([`${p.name} is sent off!`]);
    sendOff(p);
  }
  showCardOverlay(p, kind);
}
function sendOff(p) {
  if (p.sentOff) return;
  p.sentOff = true;
  if (p.team === 0 && controlled === p) manualSwitch();
  // Remove from active play: push far off-pitch and disable AI/collision relevance.
  p.pos.set(p.team === 0 ? -FIELD.halfLen - 12 : FIELD.halfLen + 12, 0, FIELD.halfWid + 10);
  p.vel.set(0, 0, 0);
  p.hasBall = false;
  p.stunTimer = 9999;
}
function showCardOverlay(p, kind) {
  const el = $('card-overlay');
  if (!el) return;
  el.className = 'show ' + kind;
  el.querySelector('.co-name').textContent = p.name;
  el.querySelector('.co-kind').textContent = kind === 'red' ? 'RED CARD' : 'YELLOW CARD';
  clearTimeout(showCardOverlay._to);
  showCardOverlay._to = setTimeout(() => { el.className = ''; }, 2200);
}
function startPenalty(team) {
  if (!['play', 'setpiece', 'goal', 'idle'].includes(match.state)) return;
  match.state = 'setpiece';
  match.restartType = 'penalty';
  match.restartTeam = team;
  match.awaitUser = isHumanControlledTeam(team);
  match.restartTimer = 1.8;
  match.pendingTaker = null;
  ball.owner = null;
  ball.passTarget = null;
  for (const pl of players) pl.hasBall = false;
  ball.vel.set(0, 0, 0);
  ball.spin.set(0, 0, 0);
  const gx = team === 0 ? FIELD.halfLen - 11 : -FIELD.halfLen + 11;
  ball.pos.set(gx, PHYS.ballRadius, 0);
  const taker = pickPenaltyTaker(team);
  if (taker) {
    taker.pos.set(gx - Math.sign(gx) * 1.2, 0, 0);
    setHumanControlled(team, taker);
    match.pendingTaker = taker;
  }
  // Position keeper on their line.
  const gk = players.find((pl) => pl.team !== team && pl.isGK);
  if (gk) gk.pos.set(team === 0 ? FIELD.halfLen - 0.3 : -FIELD.halfLen + 0.3, 0, 0);
  // Clear everyone else outside the box for a clean penalty picture.
  for (const pl of players) {
    if (pl === taker || pl === gk) continue;
    const outX = team === 0 ? FIELD.halfLen - FIELD.boxLen - 3 : -FIELD.halfLen + FIELD.boxLen + 3;
    if (inPenaltyAreaOf(team, pl.pos.x, pl.pos.z) || inPenaltyAreaOf(1 - team, pl.pos.x, pl.pos.z)) {
      pl.pos.x = outX;
    }
  }
  audio.whistle('short');
  sayPick(['PENALTY!', 'IT\'S A SPOT KICK!']);
  updateHintForSetPiece();
}
function pickPenaltyTaker(team) {
  const cands = players.filter((pl) => pl.team === team && !pl.isGK && !pl.sentOff);
  if (!cands.length) return null;
  if (team === 0 && clubPenaltyRegId) {
    const chosen = cands.find((pl) => pl._regId === clubPenaltyRegId);
    if (chosen) return chosen;
  }
  return cands.reduce((best, pl) => (!best || pl.stats.shoot > best.stats.shoot ? pl : best), null);
}
function doBurst() {
  if (!controlled || match.state !== 'play' || match.paused) return;
  if (!settings.godStamina && controlled.stamina < 20) { toast('TOO TIRED'); return; }
  if (!settings.godStamina) controlled.stamina -= 15;
  const f = new THREE.Vector3(S(controlled.facing), 0, C(controlled.facing));
  controlled.vel.addScaledVector(f, 6.5);
  emitGrass(controlled.pos.x, controlled.pos.z, f.x, f.z, 8);
  haptic(30);
}

/* ==========================================================================
   21 · BALL PHYSICS
   ========================================================================== */
function updateBall(dt) {
  ball.kickCooldown = Math.max(0, ball.kickCooldown - dt);
  if (ball.eliteShotT > 0) ball.eliteShotT = (ball.owner || match.state !== 'play') ? 0 : ball.eliteShotT - dt;
  if (ball.eliteFlight && (ball.owner || match.state !== 'play' || !(ball.eliteShotT > 0))) ball.eliteFlight = null;
  if (ball.owner) {
    const o = ball.owner;
    const fwd = new THREE.Vector3(S(o.facing), 0, C(o.facing));
    const right = new THREE.Vector3(fwd.z, 0, -fwd.x);
    const target = o.pos.clone().addScaledVector(fwd, 0.62).addScaledVector(right, S(o.animTime * 9) * 0.16 * o.speedRatio);
    target.y = PHYS.ballRadius;
    ball.pos.lerp(target, 1 - Math.exp(-18 * dt));
    ball.vel.copy(o.vel);
    ball.spin.multiplyScalar(Math.exp(-3 * dt));
    updateTrail();
    return;
  }
  if (!stepEliteFlight(dt) && !stepFinesseFlight(dt)) {
    ball.vel.y += PHYS.gravity * dt;
    if (PHYS.adv) {
      // Quadratic air drag on all axes (fast shots decay, slow balls float) + a little linear term.
      const spd = ball.vel.length();
      const dk = Math.exp(-(0.03 + 0.0062 * spd) * dt);
      ball.vel.multiplyScalar(dk);
      // Knuckle effect: hard, near-spinless strikes wobble sideways in flight.
      if (spd > 20 && ball.spin.length() < 1.5 && ball.pos.y > 0.6) {
        ball._kt = (ball._kt || 0) + dt * 17;
        const w = Math.sin(ball._kt) * Math.cos(ball._kt * 0.63) * 2.4 * dt;
        ball.vel.x += -ball.vel.z / spd * w;
        ball.vel.z += ball.vel.x / spd * w;
        ball.vel.y += Math.sin(ball._kt * 1.3) * 0.9 * dt;
      }
      // Spin shows on the ball in flight.
      const sl = ball.spin.length();
      if (sl > 0.05) ball.mesh.rotateOnWorldAxis(ball.spin.clone().multiplyScalar(1 / sl), sl * dt * 2.2);
    } else {
    const drag = Math.exp(-PHYS.airDrag * dt);
    ball.vel.x *= drag;
    ball.vel.z *= drag;
    }
    const m = PHYS.magnus, s = ball.spin, v = ball.vel;
    ball.vel.x += (s.y * v.z - s.z * v.y) * m * dt * 60;
    ball.vel.y += (s.z * v.x - s.x * v.z) * m * dt * 60;
    ball.vel.z += (s.x * v.y - s.y * v.x) * m * dt * 60;
    ball.spin.multiplyScalar(Math.exp(-PHYS.spinDecay * dt));
    ball.pos.addScaledVector(ball.vel, dt);
  }
  if (ball.pos.y < PHYS.ballRadius) {
    ball.pos.y = PHYS.ballRadius;
    if (ball.vel.y < -1.5) audio.bounce(Math.abs(ball.vel.y));
    const vn = -ball.vel.y;
    // Restitution drops for soft landings and a hard impact loses more energy.
    const eN = PHYS.adv ? PHYS.restitution * (vn < 3 ? 0.72 : vn > 12 ? 0.86 : 1) : PHYS.restitution;
    ball.vel.y = -ball.vel.y * eN;
    if (Math.abs(ball.vel.y) < 1.2) ball.vel.y = 0;
    if (PHYS.adv) {
      const sp = Math.hypot(ball.vel.x, ball.vel.z);
      if (vn > 1.5 && sp > 0.3) {
        // Spin <-> ground coupling: topspin kicks the ball forward off the bounce, backspin checks it.
        const px = ball.vel.z / sp, pz = -ball.vel.x / sp;                 // rolling-axis direction
        const roll = ball.spin.x * px + ball.spin.z * pz;                    // + = topspin
        const dv = Math.max(-0.35 * sp, Math.min(0.35 * sp, roll * 0.18)) * Math.min(1, vn / 8);
        ball.vel.x += (ball.vel.x / sp) * dv;
        ball.vel.z += (ball.vel.z / sp) * dv;
        ball.spin.x *= 0.55; ball.spin.z *= 0.55;
      }
      // Rolling resistance: bleeds fast at low speed (settles cleanly), lets quick balls run.
      const sp2 = Math.hypot(ball.vel.x, ball.vel.z);
      const fr2 = Math.exp(-(1.4 + 1.7 * Math.exp(-sp2 / 4)) * dt);
      ball.vel.x *= fr2; ball.vel.z *= fr2;
      if (sp2 < 0.12) { ball.vel.x = 0; ball.vel.z = 0; }
      ball.spin.multiplyScalar(0.94);
    } else {
    const fr = Math.exp(-PHYS.groundFriction * dt);
    ball.vel.x *= fr;
    ball.vel.z *= fr;
    ball.spin.multiplyScalar(0.9);
    }
  }
  if (ball.pos.y <= PHYS.ballRadius + 0.01) {
    const sp = Math.hypot(ball.vel.x, ball.vel.z);
    if (sp > 0.1) ball.mesh.rotateOnWorldAxis(new THREE.Vector3(ball.vel.z, 0, -ball.vel.x).normalize(), (sp * dt) / PHYS.ballRadius);
  }
  collideGoalFrame();
  if (match.state === 'play') {
    for (const side of [1, -1]) {
      const gx = FIELD.halfLen * side;
      if ((side === 1 && ball.pos.x > gx + 0.1) || (side === -1 && ball.pos.x < gx - 0.1)) {
        if (Math.abs(ball.pos.z) < FIELD.goalW / 2 && ball.pos.y < FIELD.goalH) {
          onGoal(side === 1 ? 0 : 1);
          return;
        }
      }
    }
    checkOutOfBounds();
  }
  for (const side of [1, -1]) {
    const gx = FIELD.halfLen * side;
    const inMouth = Math.abs(ball.pos.z) < FIELD.goalW / 2 && ball.pos.y < FIELD.goalH;
    if (inMouth && Math.abs(ball.pos.x) > FIELD.halfLen && Math.abs(ball.pos.x) < FIELD.halfLen + FIELD.goalDepth) {
      ball.vel.multiplyScalar(Math.exp(-6 * dt));
      const back = FIELD.halfLen + FIELD.goalDepth - 0.2;
      if (Math.abs(ball.pos.x) > back) { ball.pos.x = Math.sign(ball.pos.x) * back; ball.vel.x *= -0.2; }
    } else if (!inMouth) {
      const lim = FIELD.halfLen + 1.2;
      if (Math.abs(ball.pos.x) > lim) { ball.pos.x = Math.sign(ball.pos.x) * lim; ball.vel.x *= -0.4; }
      const wlim = FIELD.halfWid + 1.2;
      if (Math.abs(ball.pos.z) > wlim) { ball.pos.z = Math.sign(ball.pos.z) * wlim; ball.vel.z *= -0.4; }
    }
  }
  if (ball.throughT > 0) { ball.throughT -= dt; if (ball.throughT <= 0) ball.throughTarget = null; }
  if (ball.passTarget && match.state === 'play' && !ball.owner) {
    ball.passTargetT -= dt;
    const t = ball.passTarget;
    if (ball.passTargetT <= 0) ball.passTarget = null;
    else {
      const d = dist2(ball.pos.x, ball.pos.z, t.pos.x, t.pos.z);
      if (d > 0.8 && d < 7.5 && ball.pos.y < 1.6) {
        const dir = new THREE.Vector3(t.pos.x - ball.pos.x, 0, t.pos.z - ball.pos.z).normalize();
        ball.vel.addScaledVector(dir, (settings.passAssist === 'high' ? 16 : 8) * (1 + (ball.passAcc || 0)) * dt);
      }
      if (d <= 0.8) ball.passTarget = null;
    }
  }
  if (match.state === 'play' && controlled && ball.kickCooldown <= 0) {
    const d = dist2(controlled.pos.x, controlled.pos.z, ball.pos.x, ball.pos.z);
    if (d < 3.2 && d > 0.4 && ball.vel.length() < 10 && ball.pos.y < 0.9) {
      const dir = new THREE.Vector3(controlled.pos.x - ball.pos.x, 0, controlled.pos.z - ball.pos.z).normalize();
      ball.vel.addScaledVector(dir, 12 * dt);
    }
  }
  if (match.state === 'play' && ball.kickCooldown <= 0 && !(ball.eliteShotT > 0) && !(ball.finesseFlight && ball.finesseFlight.sure)) {
    let bestP = null, bestD = 99; // (radius per player is applied below; 1.45 is the classic pickup radius)
    for (const p of players) {
      if (p.stunTimer > 0 || p.controlCd > 0) continue;
      if (p.action && p.action.locks) continue;
      const d = dist2(p.pos.x, p.pos.z, ball.pos.x, ball.pos.z);
      const radius = psPickupRadius(p, 1.45);
      if (d < bestD && d < radius && ball.pos.y < psPickupHeight(p)) { bestD = d; bestP = p; }
    }
    if (bestP) {
      if (ball.lastKicker && ball.lastKicker !== bestP) {
        if (ball.lastKicker.team === bestP.team) {
          passStreak[bestP.team]++;
          chain[bestP.team] = Math.min(10, chain[bestP.team] + 1);
          const n = passStreak[bestP.team];
          if (n === 5 || n === 8 || n === 12) sayPick([`${teamDefs[bestP.team].name} on a ${n}-pass chain!`]);
          if (match.lastPasser && match.lastPasser.team === bestP.team && match.lastPasser !== bestP) {
            trackStat(match.lastPasser, 'assists', 0);
          }
        } else {
          passStreak[ball.lastKicker.team] = 0;
        }
      }
      if (lastPossTeam >= 0 && lastPossTeam !== bestP.team) {
        chain[lastPossTeam] = Math.max(0, chain[lastPossTeam] - 4);
        passStreak[lastPossTeam] = 0;
      }
      // ---- v2 PlayStyle triggers on receiving the ball ----
      const baseR = 1.45;
      if (hasStyle(bestP, 'Reach') && (bestD > baseR || ball.pos.y > 1.1)) triggerStyleBadge(bestP, 'Reach'); // only counts when the extra reach actually mattered
      if (hasStyle(bestP, 'Vision') && bestP === ball.passTarget && ball.lastKicker && ball.lastKicker.team === bestP.team) triggerStyleBadge(bestP, 'Vision');
      if (ball.throughTarget === bestP && ball.throughT > 0) {
        const tn = hasStyle(bestP, 'Target+') ? 'Target+' : (hasStyle(bestP, 'Target') ? 'Target' : null);
        if (tn) { bestP.targetT = 4.5; bestP.targetName = tn; triggerStyleBadge(bestP, tn); } // Target: buff window after receiving a through pass
      }
      ball.throughTarget = null;
      lastPossTeam = bestP.team;
      ball.owner = bestP;
      bestP.hasBall = true;
      match.possTeam = bestP.team;
      ball.passTarget = null;
      onPossessionChange(bestP);
    }
  }
  updateTrail();
}
function collideGoalFrame() {
  for (const side of [1, -1]) {
    const gx = FIELD.halfLen * side;
    for (const zs of [-1, 1]) {
      const pz = (FIELD.goalW / 2) * zs;
      const d = dist2(ball.pos.x, ball.pos.z, gx, pz);
      if (d < 0.24 && ball.pos.y < FIELD.goalH + 0.1) {
        const nx = (ball.pos.x - gx) / d, nz = (ball.pos.z - pz) / d;
        const dot = ball.vel.x * nx + ball.vel.z * nz;
        if (dot < 0) {
          ball.vel.x -= 2 * dot * nx;
          ball.vel.z -= 2 * dot * nz;
          ball.vel.multiplyScalar(0.55);
          audio.post();
          emitSpark(gx, ball.pos.y, pz, 12);
          sayPick(COM_FRAME);
        }
      }
    }
    if (Math.abs(ball.pos.x - gx) < 0.24 && Math.abs(ball.pos.y - FIELD.goalH) < 0.2 && Math.abs(ball.pos.z) < FIELD.goalW / 2) {
      ball.vel.y = -Math.abs(ball.vel.y) * 0.5;
      ball.vel.x *= -0.4;
      audio.post();
      emitSpark(gx, FIELD.goalH, ball.pos.z, 12);
      sayPick(COM_FRAME);
    }
  }
}

/* ==========================================================================
   22 · RESTARTS + LAWS
   ========================================================================== */
function checkOutOfBounds() {
  const x = ball.pos.x, z = ball.pos.z;
  const lastT = match.lastTouchTeam >= 0 ? match.lastTouchTeam : 0;
  if (Math.abs(z) > FIELD.halfWid + 1.4) {
    startSetPiece('throw', 1 - lastT, { x: clamp(x, -FIELD.halfLen + 1, FIELD.halfLen - 1), z: Math.sign(z) * (FIELD.halfWid + 0.4) });
  } else if (Math.abs(x) > FIELD.halfLen + 1.4) {
    const scoringSide = Math.sign(x);
    const defendingTeam = scoringSide === 1 ? 0 : 1;
    if (lastT === defendingTeam) {
      match.stats.corners[1 - defendingTeam]++;
      startSetPiece('corner', 1 - defendingTeam, { x: FIELD.halfLen * scoringSide, z: Math.sign(z || 1) * (FIELD.halfWid - 0.4) });
    } else startSetPiece('goalkick', defendingTeam, { x: 0, z: 0 });
  }
}
function startSetPiece(type, team, spot) {
  if (!['play', 'setpiece', 'goal', 'idle'].includes(match.state)) return;
  match.state = 'setpiece';
  match.restartType = type;
  match.restartTeam = team;
  match.awaitUser = isHumanControlledTeam(team);
  match.restartTimer = 1.6;
  match.pendingTaker = null;
  match.autoKickoffTimer = 0;
  ball.owner = null;
  ball.passTarget = null;
  for (const p of players) p.hasBall = false;
  ball.vel.set(0, 0, 0);
  ball.spin.set(0, 0, 0);
  audio.whistle('short');
  if (type === 'throw') {
    ball.pos.set(spot.x, PHYS.ballRadius, spot.z);
    const taker = nearestPlayerOf(team, spot.x, spot.z, true);
    if (taker) {
      taker.pos.set(spot.x, 0, spot.z + (spot.z > 0 ? -0.6 : 0.6));
      setHumanControlled(team, taker);
      match.pendingTaker = taker;
    }
    sayPick([`Throw-in for ${teamDefs[team].name}`]);
  } else if (type === 'corner') {
    ball.pos.set(spot.x, PHYS.ballRadius, spot.z);
    const taker = nearestPlayerOf(team, spot.x, spot.z, true);
    if (taker) {
      taker.pos.set(spot.x - Math.sign(spot.x) * 0.8, 0, spot.z - Math.sign(spot.z) * 0.8);
      setHumanControlled(team, taker);
      match.pendingTaker = taker;
    }
    sayPick([`Corner for ${teamDefs[team].name}`]);
  } else if (type === 'goalkick') {
    const gk = players.find((p) => p.team === team && p.isGK);
    const gx = team === 0 ? -FIELD.halfLen + 5.5 : FIELD.halfLen - 5.5;
    ball.pos.set(gx, PHYS.ballRadius, 0);
    if (gk) { gk.pos.set(gx - Math.sign(gx) * 0.8, 0, 0); match.pendingTaker = gk; setHumanControlled(team, gk); }
    sayPick([`Goal kick for ${teamDefs[team].name}`]);
  } else if (type === 'kickoff') {
    placeKickoff(team);
    match.pendingTaker = players.find((p) => p.team === team && p.role === 'ST');
    if (match.pendingTaker) setHumanControlled(team, match.pendingTaker);
  } else if (type === 'freekick') {
    const sx = clamp(spot.x, -FIELD.halfLen + 1, FIELD.halfLen - 1);
    const sz = clamp(spot.z, -FIELD.halfWid + 1, FIELD.halfWid - 1);
    ball.pos.set(sx, PHYS.ballRadius, sz);
    const taker = pickPenaltyTaker(team) || nearestPlayerOf(team, sx, sz, true);
    if (taker) {
      taker.pos.set(sx - Math.sign(sx - attackGoalX(team)) * 1.1, 0, sz);
      setHumanControlled(team, taker);
      match.pendingTaker = taker;
    }
    // Push defenders back to a lawful wall distance (10 units ~ 9.15m rule).
    for (const pl of players) {
      if (pl.team === team || pl === taker) continue;
      const d = dist2(pl.pos.x, pl.pos.z, sx, sz);
      if (d < 10) {
        const nx = (pl.pos.x - sx) / (d || 1), nz = (pl.pos.z - sz) / (d || 1);
        pl.pos.x = sx + nx * 10;
        pl.pos.z = sz + nz * 10;
      }
    }
    sayPick([`Free kick for ${teamDefs[team].name}`]);
  }
  updateHintForSetPiece();
}
function nearestPlayerOf(team, x, z, excludeGK = false) {
  let best = null, bd = 1e9;
  for (const p of players) {
    if (p.team !== team || p.sentOff) continue;
    if (excludeGK && p.isGK) continue;
    const d = dist2(p.pos.x, p.pos.z, x, z);
    if (d < bd) { bd = d; best = p; }
  }
  return best;
}
function inPenaltyAreaOf(team, x, z) {
  const gx = team === 0 ? -FIELD.halfLen : FIELD.halfLen;
  return Math.abs(x - gx) < FIELD.boxLen && Math.abs(z) < FIELD.boxWid / 2;
}
function enforceSetPieceLaws(dt) {
  if (!ball) return;
  const bp = ball.pos;
  for (const p of players) {
    if (p === match.pendingTaker) continue;
    if (match.restartType === 'goalkick') {
      const team = match.restartTeam;
      if (p.team !== team && inPenaltyAreaOf(team, p.pos.x, p.pos.z)) {
        const gx = team === 0 ? -FIELD.halfLen : FIELD.halfLen;
        const dirOut = team === 0 ? 1 : -1;
        p.pos.x = damp(p.pos.x, gx + dirOut * (FIELD.boxLen + 1.5), 5, dt);
      }
    }
    if (match.restartType !== 'kickoff') {
      const d = dist2(p.pos.x, p.pos.z, bp.x, bp.z);
      if (d < 4 && d > 0.001) {
        const nx = (p.pos.x - bp.x) / d;
        const nz = (p.pos.z - bp.z) / d;
        p.pos.x = bp.x + nx * 4.2;
        p.pos.z = bp.z + nz * 4.2;
      }
    }
  }
}
function executeSetPiece() {
  const team = match.restartTeam;
  const taker = match.pendingTaker || nearestPlayerOf(team, ball.pos.x, ball.pos.z, match.restartType !== 'goalkick');
  if (!taker) { match.state = 'play'; return; }
  if (match.restartType === 'throw') performKick(taker, 'throw', {});
  else if (match.restartType === 'corner') performKick(taker, 'cross', {});
  else if (match.restartType === 'goalkick') performKick(taker, 'clear', {});
  else if (match.restartType === 'freekick') {
    const gx = attackGoalX(team);
    const d = Math.hypot(gx - ball.pos.x, ball.pos.z);
    performKick(taker, d < 24 ? 'shoot' : 'through', { aim: { x: gx - ball.pos.x, z: -ball.pos.z } });
  } else if (match.restartType === 'penalty') {
    // Penalty Expert: AI-taken penalties place more accurately too.
    const peAmt = styleBonus(taker, 'Penalty Expert', 0.15, 0.35);
    performKick(taker, 'shoot', { targetZ: rand(-2.6, 2.6) * Math.max(0, 1 - peAmt), power: rand(0.75, 1), isPenalty: true });
  }
  match.pendingTaker = null;
  match.state = 'play';
  setHint('');
}

/* ==========================================================================
   23 · GOAL CUTSCENE + AWARDS TRACKING
   ========================================================================== */
function cardForPlayer(p) {
  if (!p) return null;
  const rec = regById(p._regId) || regByName(p.name);
  if (rec) return rec;
  const fake = { id: 'tmp', name: p.name, pos: p.role, ovr: p.ovr, rarity: 'bronze', img: null };
  fake.img = proceduralCard(fake);
  return fake;
}
function setGoalLetters() {
  const txt = 'GOAL!';
  const el = $('goal-text');
  el.innerHTML = '';
  for (let i = 0; i < txt.length; i++) {
    const span = document.createElement('span');
    span.className = 'goal-letter';
    span.textContent = txt[i];
    span.style.animationDelay = (0.06 * i) + 's';
    el.appendChild(span);
  }
}
function showGoalCard(team, scorer, celebrationName) {
  const gc = $('goal-card');
  if (scorer) {
    const rec = cardForPlayer(scorer);
    gc.className = 'rar-' + rec.rarity;
    $('gc-img').src = rec.img;
    $('gc-name').textContent = scorer.name;
    $('gc-ovr').textContent = `${RARITY[rec.rarity].label} · ${ovrD(rec.ovr)} ${rec.pos}`;
    $('gc-celeb').textContent = '🎉 ' + celebrationName;
  } else {
    gc.className = 'rar-bronze';
    $('gc-img').src = '';
    $('gc-name').textContent = teamDefs[team].name;
    $('gc-ovr').textContent = '';
    $('gc-celeb').textContent = '';
  }
}
function bumpScore(team) {
  const el = team === 0 ? $('sb-score-h') : $('sb-score-a');
  el.classList.remove('bump');
  void el.offsetWidth;
  el.classList.add('bump');
}
function onGoal(team) {
  if (match.state === 'goal') return;
  match.state = 'goal';
  match.goalTeam = team;
  match.goalTimer = 5.0;
  match.goalAge = 0;
  match.goalFxT = 0;
  match.score[team] += (team === 0 && match.evRules && match.evRules.homeGoalValue > 1) ? match.evRules.homeGoalValue : 1;
  if (typeof UAStadium !== 'undefined') UAStadium.goalHit(team); // net ripple + crowd jump (before ball.vel is damped)
  match.slowmoT = 1.6;
  match.timeScale = 0.3;
  // Capture the replay window right now, at the moment of the goal — by the
  // time the live celebration finishes several seconds from now, the ring
  // buffer will have long since rolled past this moment. Playback itself is
  // deferred until endGoalCelebration() so it never competes with the live
  // celebration cam/goal card.
  REPLAY.pendingGoalFrames = REPLAY.buffer.slice();
  ball.vel.multiplyScalar(0.12);
  ball.passTarget = null;
  netShakeSide = team === 0 ? 1 : -1;
  netShake = 1;
  setTimeout(() => { if (settings.commentary) toast('✓ GOAL CONFIRMED · GLT'); }, 1100);
  const scorer = match.lastTouchPlayer && match.lastTouchPlayer.team === team ? match.lastTouchPlayer : null;
  let celebName = '';
  if (scorer) {
    scorer.celebrate = 4.6;
    match.celScorer = scorer;
    scorer.celebration = pickCelebration();
    scorer.celebT = 0;
    celebName = scorer.celebration.name;
    trackStat(scorer, 'goals');
    goalCountByName[scorer.name] = (goalCountByName[scorer.name] || 0) + 1;
    match.goalScorers.push({ name: scorer.name, team });
    if (match.lastPasser && match.lastPasser.team === team && match.lastPasser !== scorer) {
      trackStat(match.lastPasser, 'assists');
    }
    const c = goalCountByName[scorer.name];
    if (c === 2) setTimeout(() => { toast('BRACE! ' + scorer.name); sayPick([`A brace for ${scorer.name}!`]); }, 2400);
    if (c === 3) setTimeout(() => {
      toast('🎩 HAT-TRICK! ' + scorer.name);
      sayPick([`HAT-TRICK! ${scorer.name} takes the ball home!`]);
      emitConfettiBurst(0, 0, 260);
      haptic(250);
    }, 2400);
  }
  for (const p of players) {
    if (p.team === team && p !== scorer) { p.celebrate = 4.0; p.celebration = pickCelebration(); p.celebT = 0; }
    else if (p !== scorer) p.celebrate = 0;
  }
  setGoalLetters();
  showGoalCard(team, scorer, celebName);
  if (NET.mode === 'host') {
    // The guest never runs onGoal() itself (their whole match-flow/physics
    // block is intentionally skipped — see the NET.mode==='guest' gating in
    // loopInner), so without this they'd only ever see match.score silently
    // tick up via the regular position snapshots, with zero goal card, zero
    // scorer name, zero celebration — exactly the "who scored?" gap. This
    // is sent once, as its own message, separate from the 20Hz snapshot
    // stream, so it can't be dropped/superseded the way a position update
    // legitimately can be under unordered delivery.
    rtcSend({ t: 'goal', team, scorerName: scorer ? scorer.name : '', celebName, score: match.score.slice() });
  }
  // Manual celebration picker: only offered for the human player's own
  // goals (team 0). A celebration is already playing by default (assigned
  // above) so there's never a gap — picking one here just swaps it live.
  if (scorer && team === 0) showCelebPicker(scorer);
  else hideCelebPicker();
  $('ov-goal').classList.add('show');
  document.body.classList.add('goal-cine');
  audio.goalRoar();
  audio.whistle('short');
  emitConfettiBurst(ball.pos.x * 0.6, ball.pos.z * 0.6, 300);
  emitConfettiBurst(rand(-20, 20), rand(-12, 12), 220);
  emitFirework(rand(-30, 30), rand(-20, 20));
  flashScreen();
  shakeAmt = 1;
  haptic(200);
  if (team === 1) chain[0] = 0;
  bumpScore(team);
  drawBigScreen();
  sayPick(COM_GOAL, scorer ? `· ${scorer.name}` : `· ${teamDefs[team].name}`);
  updateScoreboard();
}
/* ==========================================================================
   MANUAL CELEBRATION PICKER — offered on the human player's own goals.
   A celebration is always already playing by default the instant the goal
   is scored (assigned in onGoal above), so this picker never blocks or
   delays anything — selecting an option just swaps the scorer's live
   celebration mid-playback. "Skip" just closes the picker and leaves the
   default celebration running.
   ========================================================================== */
let celebPickerScorer = null;
function showCelebPicker(scorer) {
  celebPickerScorer = scorer;
  const grid = $('celeb-picker-grid');
  grid.innerHTML = '';
  // Offer a curated subset (not all ~15) so the picker stays fast to scan
  // during the short celebration window — favorites + both new ones.
  const featured = ['SIUUU', 'KNEE SLIDE', 'FLIP', 'FIST PUMP', 'ARMS WIDE', 'DAB', 'AIRPLANE', 'POINT TO SKY'];
  const options = CELEBRATIONS.slice();
  for (const cel of options) {
    const btn = document.createElement('button');
    btn.className = 'celeb-opt' + (scorer.celebration === cel ? ' on' : '');
    btn.type = 'button';
    btn.textContent = cel.name;
    btn.addEventListener('click', () => {
      if (!celebPickerScorer || celebPickerScorer.celebrate <= 0) return; // celebration window already ended
      celebPickerScorer.celebration = cel;
      celebPickerScorer.celebT = 0; // restart the animation cleanly from this new celebration's t=0
      $('gc-celeb').textContent = cel.name;
      grid.querySelectorAll('.celeb-opt').forEach((b) => b.classList.remove('on'));
      btn.classList.add('on');
      audio.ui();
    });
    grid.appendChild(btn);
  }
  $('celeb-picker').classList.remove('hidden');
}
function hideCelebPicker() {
  celebPickerScorer = null;
  $('celeb-picker').classList.add('hidden');
}
$('celeb-picker-skip').addEventListener('click', () => { hideCelebPicker(); audio.ui(); });
function flashScreen() {
  const f = $('flash');
  f.style.opacity = 0.55;
  setTimeout(() => { f.style.opacity = 0; }, 130);
}
function endGoalCelebration() {
  $('ov-goal').classList.remove('show');
  document.body.classList.remove('goal-cine');
  hideCelebPicker();
  match.celScorer = null; match.celPartner = null;
  for (const p of players) { p.celebrate = 0; p.celebration = null; }
  if (match.evRules && match.evRules.goldenGoal) { // event rule: first goal ends the match
    match.state = 'fulltime'; match.over = true; audio.whistle('full'); showFulltime(); return;
  }
  match.kickTeam = 1 - match.goalTeam;
  if (settings.instantReplay && REPLAY.pendingGoalFrames && REPLAY.pendingGoalFrames.length >= 8) {
    replayPlayFrames(REPLAY.pendingGoalFrames);
    REPLAY.pendingGoalFrames = null;
    REPLAY.afterPlaybackFn = () => {
      startSetPiece('kickoff', match.kickTeam, null);
      match.awaitUser = match.kickTeam === 0;
      match.restartTimer = 1.4;
    };
    return;
  }
  startSetPiece('kickoff', match.kickTeam, null);
  match.awaitUser = match.kickTeam === 0;
  match.restartTimer = 1.4;
}
function computeAwards() {
  const stats = Object.values(match.playerStats);
  const awards = [];
  let boot = null;
  for (const s of stats) if (s.goals > 0 && (!boot || s.goals > boot.goals)) boot = s;
  if (boot) awards.push({ icon: '🥇', title: 'Golden Boot', name: boot.name, sub: boot.goals + ' goal' + (boot.goals > 1 ? 's' : '') });
  const gkStats = stats.filter(s => s.pos === 'GK');
  let glove = null;
  for (const s of gkStats) if (s.saves > 0 && (!glove || s.saves > glove.saves)) glove = s;
  if (glove) awards.push({ icon: '🧤', title: 'Golden Glove', name: glove.name, sub: glove.saves + ' saves' });
  let potm = null, potmScore = -1;
  for (const s of stats) {
    const score = s.goals * 1.5 + s.assists * 1 + s.saves * 0.8 + s.tackles * 0.3 + s.passes * 0.05;
    if (score > potmScore) { potmScore = score; potm = s; }
  }
  if (potm && potmScore > 0) awards.push({ icon: '🏆', title: 'Player of the Match', name: potm.name, sub: potm.pos + ' · OVR ' + ovrD(potm.ovr) });
  let maker = null;
  for (const s of stats) if (s.assists > 0 && (!maker || s.assists > maker.assists)) maker = s;
  if (maker) awards.push({ icon: '🎯', title: 'Playmaker', name: maker.name, sub: maker.assists + ' assists' });
  let wall = null;
  for (const s of stats) if (s.tackles > 0 && (!wall || s.tackles > wall.tackles)) wall = s;
  if (wall) awards.push({ icon: '🛡️', title: 'The Wall', name: wall.name, sub: wall.tackles + ' tackles' });
  return awards;
}
function renderAwards() {
  const wrap = $('ft-awards');
  wrap.innerHTML = '';
  const awards = computeAwards();
  if (!awards.length) return;
  for (const a of awards) {
    const div = document.createElement('div');
    div.className = 'award';
    div.innerHTML = `<div class="a-icon">${a.icon}</div><div class="a-title">${a.title}</div><div class="a-name">${a.name}</div><div class="a-sub">${a.sub}</div>`;
    wrap.appendChild(div);
  }
}
function updateMatchFlow(dt) {
  if (match.slowmoT > 0) {
    match.slowmoT -= dt;
    if (match.slowmoT <= 0) match.timeScale = settings.timeScale;
    else if (match.slowmoT < 0.8) match.timeScale = lerp(settings.timeScale, 0.3, match.slowmoT / 0.8);
  }
  if (match.state === 'goal') {
    match.goalTimer -= dt;
    match.goalAge += dt;
    match.goalFxT += dt;
    if (match.goalFxT > 0.6) {
      match.goalFxT = 0;
      emitConfettiBurst(rand(-28, 28), rand(-16, 16), 160);
      audio.chant();
    }
    if (match.goalAge < 2.6 && Math.random() < 0.12) {
      const corner = pick([
        [FIELD.halfLen, FIELD.halfWid], [FIELD.halfLen, -FIELD.halfWid],
        [-FIELD.halfLen, FIELD.halfWid], [-FIELD.halfLen, -FIELD.halfWid],
      ]);
      emitSpark(corner[0], 1.4, corner[1], 10);
    }
    // kickoff only AFTER the celebration has fully finished (celebrate runs on scaled time, goalTimer was cutting it short)
    const celeb = match.celScorer && match.celScorer.celebrate > 0 && match.goalAge < 16;
    if (match.goalTimer <= 0 && !celeb) endGoalCelebration();
    return;
  }
  if (match.state === 'setpiece') {
    if (!match.awaitUser) {
      match.restartTimer -= dt;
      if (match.restartTimer <= 0) {
        if (match.restartType === 'kickoff') {
          const taker = match.pendingTaker;
          if (taker) performKick(taker, 'pass', {});
          match.state = 'play';
        } else executeSetPiece();
      }
    } else {
      // Safety net: if the player doesn't tap PASS/SHOOT within ~4s of a
      // kickoff awaiting them, auto-kick it off anyway so the match never
      // sits permanently frozen on a hint the player missed.
      match.autoKickoffTimer = (match.autoKickoffTimer || 0) + dt;
      if (match.restartType === 'kickoff' && match.autoKickoffTimer > 4) {
        match.autoKickoffTimer = 0;
        match.awaitUser = false;
        const taker = match.pendingTaker;
        if (taker) performKick(taker, 'pass', { aim: { x: 0, z: 0 } });
        match.state = 'play';
        setHint('');
        $('hint').classList.remove('await-user');
      }
    }
    return;
  }
  if (match.state === 'play') {
    match.clock += dt;
    const halfDur = settings.halfDur;
    if (match.half === 1 && match.clock >= halfDur) {
      match.state = 'halftime';
      match.halfScore = [match.score[0], match.score[1]];
      audio.whistle('half');
      showHalftime();
    } else if (match.half === 2 && match.clock >= halfDur * 2) {
      match.state = 'fulltime';
      match.over = true;
      audio.whistle('full');
      showFulltime();
    }
    match.stats.poss[match.possTeam] += dt;
  }
}
function showHalftime() {
  $('ht-score').textContent = `${match.score[0]} - ${match.score[1]}`;
  $('ht-name-h').textContent = teamDefs[0].abbr;
  $('ht-name-a').textContent = teamDefs[1].abbr;
  $('ht-dot-h').style.background = teamDefs[0].c1;
  $('ht-dot-a').style.background = teamDefs[1].c1;
  const s = match.stats;
  const possT = s.poss[0] + s.poss[1];
  const pct = Math.round((s.poss[0] / possT) * 100);
  const cardsTxt = (s.yellows[0] + s.yellows[1] + s.reds[0] + s.reds[1]) > 0
    ? `  ·  🟨${s.yellows[0]}-${s.yellows[1]}${(s.reds[0] + s.reds[1]) ? ` 🟥${s.reds[0]}-${s.reds[1]}` : ''}` : '';
  $('ht-stats').textContent = `SHOTS ${s.shots[0]}-${s.shots[1]}  ·  POSSESSION ${pct}%-${100 - pct}%${cardsTxt}`;
  $('scr-half').classList.remove('hidden');
  emitFirework(-20, -10);
  emitFirework(20, 10);
}
function showFulltime() {
  $('ft-score').textContent = `${match.score[0]} - ${match.score[1]}`;
  $('ft-name-h').textContent = teamDefs[0].name;
  $('ft-name-a').textContent = teamDefs[1].name;
  $('ft-dot-h').style.background = teamDefs[0].c1;
  $('ft-dot-a').style.background = teamDefs[1].c1;
  renderAwards();
  const s = match.stats;
  const possT = s.poss[0] + s.poss[1];
  const possPct = Math.round((s.poss[0] / possT) * 100);
  const mvp = computeAwards().find(a => a.title === 'Player of the Match');
  $('ft-stats').innerHTML = `
    <span class="s-l">${mvp ? '⭐' : ''}</span><span class="s-m">MVP</span><span class="s-r">${mvp ? mvp.name : '—'}</span>
    <span class="s-l">${possPct}%</span><span class="s-m">POSSESSION</span><span class="s-r">${100 - possPct}%</span>
    <span class="s-l">${s.shots[0]}</span><span class="s-m">SHOTS</span><span class="s-r">${s.shots[1]}</span>
    <span class="s-l">${s.onTarget[0]}</span><span class="s-m">ON TARGET</span><span class="s-r">${s.onTarget[1]}</span>
    <span class="s-l">${s.passes[0]}</span><span class="s-m">PASSES</span><span class="s-r">${s.passes[1]}</span>
    <span class="s-l">${s.tackles[0]}</span><span class="s-m">TACKLES</span><span class="s-r">${s.tackles[1]}</span>
    <span class="s-l">${s.corners[0]}</span><span class="s-m">CORNERS</span><span class="s-r">${s.corners[1]}</span>
    <span class="s-l">${s.fouls[0]}</span><span class="s-m">FOULS</span><span class="s-r">${s.fouls[1]}</span>
    <span class="s-l">🟨${s.yellows[0]} 🟥${s.reds[0]}</span><span class="s-m">CARDS</span><span class="s-r">🟨${s.yellows[1]} 🟥${s.reds[1]}</span>`;
  const win = match.score[0] > match.score[1];
  const draw = match.score[0] === match.score[1];
  let reward = (win ? 300 : draw ? 150 : 80) + match.score[0] * 30;
  const notes = [];
  if (win && match.score[1] === 0) { reward += 100; notes.push('CLEAN SHEET +100'); }
  if (win && match.halfScore && match.halfScore[0] < match.halfScore[1]) { reward += 100; notes.push('COMEBACK +100'); }
  if (win && match.score[0] - match.score[1] >= 3) {
    notes.push('DOMINATION!');
    emitConfettiBurst(0, 0, 300);
    emitFirework(-25, -12);
    emitFirework(25, 12);
  }
  addCoins(reward);
  // GEMS: 100 per match + performance bonuses (feeds Luck Royale pulls)
  const gemParts = [];
  let gems = 100;
  const myStats = Object.values(match.playerStats || {}).filter((p) => p.team === 0);
  const myAssists = myStats.reduce((n, p) => n + (p.assists || 0), 0);
  if (win) { gems += 40; gemParts.push('WIN +40'); } else if (draw) { gems += 15; gemParts.push('DRAW +15'); }
  if (match.score[0] > 0) { const gg = Math.min(match.score[0], 5) * 15; gems += gg; gemParts.push(`GOALS +${gg}`); }
  if (myAssists > 0) { const ga = Math.min(myAssists, 5) * 10; gems += ga; gemParts.push(`ASSISTS +${ga}`); }
  if (match.score[1] === 0) { gems += 25; gemParts.push('CLEAN SHEET +25'); }
  if (mvp && myStats.some((p) => p.name === mvp.name)) { gems += 40; gemParts.push('MVP +40'); }
  if (s.onTarget[0] >= 5) { gems += 10; gemParts.push('SHOTS +10'); }
  try { if (typeof addGems === 'function') addGems(gems); } catch (e) {}
  $('ft-coins-n').innerHTML = `+${reward} 🪙 COINS &nbsp;·&nbsp; +${gems} 💎 GEMS<br><small style="opacity:.75;font-size:.72em;letter-spacing:.04em">${[...notes, ...gemParts].join(' · ')}</small>`;
  $('scr-full').classList.remove('hidden');
  // Persist this result to match_history if signed in (best-effort, never blocks the UI).
  pushMatchResult(match.score[0], match.score[1], reward, {
    possession: [possPct, 100 - possPct],
    shots: s.shots, onTarget: s.onTarget, passes: s.passes, tackles: s.tackles,
    corners: s.corners, fouls: s.fouls, yellows: s.yellows, reds: s.reds,
    mvp: mvp ? mvp.name : null,
  });
  // League quest hooks — team 0 is always the human's side. Best-effort,
  // never blocks the full-time screen if the player isn't in a league.
  if (myLeague) {
    leaguePostQuestProgress('play_matches', 1);
    if (win) leaguePostQuestProgress('win_matches', 1);
    if (match.score[0] > 0) leaguePostQuestProgress('score_goals', match.score[0]);
    if (match.score[1] === 0) leaguePostQuestProgress('clean_sheets', 1);
    if (s.tackles && s.tackles[0]) leaguePostQuestProgress('tackles', s.tackles[0]);
    const assistsThisMatch = Object.values(match.playerStats || {}).filter((p) => p.team === 0).reduce((sum, p) => sum + (p.assists || 0), 0);
    if (assistsThisMatch > 0) leaguePostQuestProgress('assists', assistsThisMatch);
    if (mvp && match.playerStats) {
      const mvpTeam = Object.values(match.playerStats).find((p) => p.name === mvp.name);
      if (mvpTeam && mvpTeam.team === 0) leaguePostQuestProgress('mvp_awards', 1);
    }
  }
  // Personal quest hooks (Quests screen) — independent of league
  // membership, unlike the block above. Best-effort; never blocks the
  // full-time screen.
  questPostProgress('play_matches', 1);
  if (win) questPostProgress('win_matches', 1);
  if (match.score[0] > 0) questPostProgress('score_goals', match.score[0]);
  if (match.score[1] === 0) questPostProgress('clean_sheets', 1);
  // PLAY HUB: report event-stage results (no-op for normal / friend matches).
  if (window.PlayHub) PlayHub.onFulltime(match.score[0], match.score[1]);
}

/* ==========================================================================
   24 · USER ACTIONS
   ========================================================================== */
function userDefending() { return ball.owner && ball.owner.team === 1; }
function ownThirdZone() { return controlled && controlled.pos.x < -14; }
function getShootKind() {
  const c = controlled;
  if (!c) return 'shoot';
  if (ball.owner === c) {
    if (ownThirdZone()) return 'clear';
    if (dist2(c.pos.x, c.pos.z, FIELD.halfLen, 0) < 27 && Math.abs(c.pos.z) > 7) return 'curl';
    return 'shoot';
  }
  if (!ball.owner) {
    const dBall = dist2(c.pos.x, c.pos.z, ball.pos.x, ball.pos.z);
    if (ball.pos.y > 0.9 && ball.pos.y < 2.4 && ball.vel.length() > 6 && dBall < 2.2) return 'bicycle';
    if (ball.pos.y > 0.9) return 'header';
    if (ball.pos.y > 0.35) return 'volley';
  }
  return 'shoot';
}
function resetChargeUI() {
  input.charging = false;
  input.power = 0;
  $('power-wrap').classList.remove('show');
  $('power-fill').style.height = '0%';
}
function aimFromInput() { return clamp(-input.mx * 3.2, -3.1, 3.1); }
function currentAim() {
  const mag = Math.hypot(input.mx, input.my);
  if (mag > 0.2) {
    const mv = moveVectorFromInput(input.mx / mag, input.my / mag);
    return { x: mv.x, z: mv.z };
  }
  return { x: lastMoveDir.x, z: lastMoveDir.z };
}
function userAction(kind) {
  if (match.screen !== 'match') return;
  if (match.paused || match.state === 'halftime' || match.state === 'fulltime') return;
  if (NET.mode === 'guest') {
    // Guest never runs performKick/physics locally — send the action to the
    // host, which applies it to controlledP2 via userActionP2. The host's
    // next snapshot reflects the result; nothing happens here but the
    // charge/power UI, which is cosmetic and fine to keep local.
    try { rtcSend({ t: 'action', kind, power: input.power, charging: input.charging }); } catch (e) {}
    if (['pass', 'shoot', 'through', 'chip', 'chippass', 'curl', 'curl2', 'defdrib'].includes(kind)) resetChargeUI();
    return;
  }
  let c = controlled;
  if (!c && match.state === 'setpiece' && match.awaitUser) {
    c = controlled = match.pendingTaker || nearestPlayerOf(match.restartTeam, ball.pos.x, ball.pos.z, false);
  }
  if (!c) return;
  if (match.state === 'setpiece' && match.awaitUser && match.restartTeam === 0) {
    if (['pass', 'shoot', 'through', 'chip'].includes(kind)) {
      match.awaitUser = false;
      const taker = match.pendingTaker || c;
      if (match.restartType === 'kickoff') performKick(taker, 'pass', { aim: currentAim() });
      else if (match.restartType === 'throw') performKick(taker, 'throw', { aim: currentAim() });
      else if (match.restartType === 'corner') performKick(taker, 'cross', {});
      else if (match.restartType === 'goalkick') performKick(taker, 'clear', {});
      else if (match.restartType === 'freekick') {
        if (kind === 'shoot') performKick(taker, 'shoot', { power: Math.max(0.5, input.power || 0.75) });
        else performKick(taker, kind === 'through' ? 'through' : 'pass', { aim: currentAim() });
      } else if (match.restartType === 'penalty') {
        performKick(taker, 'shoot', { targetZ: currentAim().z * 3.2, power: Math.max(0.7, input.power || 0.85), perfect: input.power > 0.7 && input.power < 0.95, isPenalty: true });
      }
      match.pendingTaker = null;
      match.state = 'play';
      match.autoSwitchGraceT = 0.5; // brief window after a kickoff/restart
      // tap where auto-switch is suppressed, so it can't yank control away
      // from the player mid-kick-animation before they've even moved.
      setHint('');
      resetChargeUI();
      updatePlayerCard();
    }
    return;
  }
  if (match.state !== 'play') return;
  const dBall = dist2(c.pos.x, c.pos.z, ball.pos.x, ball.pos.z);
  if (kind === 'switch') { manualSwitch(); return; }
  if (kind === 'thunder') { activateThunder(c); return; }
  if (kind === 'chippass') { if (ball.owner === c) { performKick(c, 'chipPass', { aim: currentAim() }); resetChargeUI(); } return; }
  if (kind === 'through') { if (ball.owner === c) { performKick(c, 'through', { aim: currentAim() }); resetChargeUI(); } return; }
  if (kind === 'chip') { if (ball.owner === c) { performKick(c, 'chip', {}); resetChargeUI(); } return; }
  if (kind === 'curl') { if (ball.owner === c) { performKick(c, 'curl', {}); resetChargeUI(); } return; }
  if (kind === 'curl2') { if (ball.owner === c) { performKick(c, 'curl2', {}); resetChargeUI(); } return; }
  if (kind === 'defdrib') {
    if (ball.owner === c) { doTrick(c, trickIndex); trickIndex = (trickIndex + 1) % TRICKS.length; }
    else standingTackle(c);
    return;
  }
  if (kind === 'pass') {
    if (userDefending()) { slideTackle(c); return; }
    if (ball.owner === c) {
      const wide = Math.abs(c.pos.z) > 20;
      if (wide && c.pos.x > 26) performKick(c, 'cross', {});
      else performKick(c, 'pass', { aim: currentAim() });
      resetChargeUI();
      return;
    }
    if (dBall < 2.6) { performKick(c, 'pass', { aim: currentAim() }); resetChargeUI(); }
    else slideTackle(c);
    return;
  }
  if (kind === 'shoot') {
    if (userDefending()) { standingTackle(c); resetChargeUI(); return; }
    const shotKind = getShootKind();
    const power = Math.max(0.3, input.power);
    const perfect = input.power >= 0.72 && input.power <= 0.92;
    if (shotKind === 'clear') performKick(c, 'clear', {});
    else if (shotKind === 'curl') performKick(c, 'curl', {});
    else if (shotKind === 'header') performKick(c, 'header', { power });
    else if (shotKind === 'volley') performKick(c, 'volley', { power });
    else if (shotKind === 'bicycle') performKick(c, 'bicycle', { power: Math.max(0.7, power) });
    else performKick(c, 'shoot', { power, targetZ: aimFromInput(), perfect });
    haptic(30);
    resetChargeUI();
    return;
  }
}
/* ==========================================================================
   24b · P2 (REMOTE/GUEST) ACTIONS — host-side twin of the block above,
   driving team 1's active player from the guest's network input instead of
   from the local `input`/`controlled` globals. Kept as an explicit parallel
   path rather than threading a "which team is human" flag through the
   heavily-tested team-0 logic above — team 1 attacks the opposite way,
   so "own third", aim sign, and cross-side checks are mirrored here rather
   than shared.
   ========================================================================== */
const inputP2 = { mx: 0, my: 0, sprint: false, charging: false, power: 0 };
function ownThirdZoneP2() { return controlledP2 && controlledP2.pos.x > 14; } // team 1 defends the +x end
function getShootKindP2() {
  const c = controlledP2;
  if (!c) return 'shoot';
  if (ball.owner === c) {
    if (ownThirdZoneP2()) return 'clear';
    if (dist2(c.pos.x, c.pos.z, -FIELD.halfLen, 0) < 27 && Math.abs(c.pos.z) > 7) return 'curl';
    return 'shoot';
  }
  if (!ball.owner) {
    const dBall = dist2(c.pos.x, c.pos.z, ball.pos.x, ball.pos.z);
    if (ball.pos.y > 0.9 && ball.pos.y < 2.4 && ball.vel.length() > 6 && dBall < 2.2) return 'bicycle';
    if (ball.pos.y > 0.9) return 'header';
    if (ball.pos.y > 0.35) return 'volley';
  }
  return 'shoot';
}
function resetChargeUIP2() { inputP2.charging = false; inputP2.power = 0; } // no local power-bar UI on host for P2 (that lives on the guest's own screen)
function aimFromInputP2() { return clamp(inputP2.mx * 3.2, -3.1, 3.1); } // mirrored sign: team 1 faces -x
function currentAimP2() {
  const mag = Math.hypot(inputP2.mx, inputP2.my);
  if (mag > 0.2) return { x: -inputP2.mx / mag, z: inputP2.my / mag };
  return { x: -lastMoveDirP2.x, z: lastMoveDirP2.z };
}
let lastMoveDirP2 = { x: 0, z: -1 };
function updateControlledP2(dt) {
  const c = controlledP2;
  if (!c) return;
  if (match.state !== 'play' && match.state !== 'setpiece') { c.vel.multiplyScalar(Math.exp(-4 * dt)); return; }
  if (match.state === 'setpiece') { c.vel.multiplyScalar(Math.exp(-6 * dt)); return; }
  const locked = c.action && c.action.locks;
  if (c.stunTimer > 0 || locked) { c.vel.multiplyScalar(Math.exp(-3 * dt)); return; }
  let mx = inputP2.mx, my = inputP2.my;
  const mag = Math.hypot(mx, my);
  if (mag > 1) { mx /= mag; my /= mag; }
  // Team 1 faces the opposite way down the pitch, so both axes mirror
  // team 0's plain (non-camera-relative) mapping of {x:mx, z:-my}.
  const mv = { x: -mx, z: my };
  if (mag > 0.2) {
    const ml = Math.hypot(mv.x, mv.z) || 1;
    lastMoveDirP2 = { x: mv.x / ml, z: mv.z / ml };
  }
  const sprinting = inputP2.sprint && (settings.godStamina || c.stamina > 5) && mag > 0.1;
  const fire = chain[1] >= 8 ? 1.08 : 1;
  const maxSp = c.baseSpeed * psSpeedMul(c) * (sprinting ? 1.32 : 1) * (ball.owner === c ? 0.94 : 1) * fire;
  c.vel.x = damp(c.vel.x, mv.x * maxSp, c.accelRate || 22, dt);
  c.vel.z = damp(c.vel.z, mv.z * maxSp, c.accelRate || 22, dt);
  if (sprinting && !settings.godStamina) c.stamina = Math.max(0, c.stamina - 10 * dt);
  if (mag < 0.1 && ball.owner && ball.owner.team === 0) {
    c.facing = angleDamp(c.facing, Math.atan2(ball.pos.x - c.pos.x, ball.pos.z - c.pos.z), 8, dt);
  }
}
function userActionP2(kind) {
  if (NET.mode !== 'host' || match.screen !== 'match') return;
  if (match.paused || match.state === 'halftime' || match.state === 'fulltime') return;
  let c = controlledP2;
  if (!c && match.state === 'setpiece' && match.awaitUser && match.restartTeam === 1) {
    c = controlledP2 = match.pendingTaker || nearestPlayerOf(1, ball.pos.x, ball.pos.z, false);
  }
  if (!c) return;
  if (match.state === 'setpiece' && match.awaitUser && match.restartTeam === 1) {
    if (['pass', 'shoot', 'through', 'chip'].includes(kind)) {
      match.awaitUser = false;
      const taker = match.pendingTaker || c;
      if (match.restartType === 'kickoff') performKick(taker, 'pass', { aim: currentAimP2() });
      else if (match.restartType === 'throw') performKick(taker, 'throw', { aim: currentAimP2() });
      else if (match.restartType === 'corner') performKick(taker, 'cross', {});
      else if (match.restartType === 'goalkick') performKick(taker, 'clear', {});
      else if (match.restartType === 'freekick') {
        if (kind === 'shoot') performKick(taker, 'shoot', { power: Math.max(0.5, inputP2.power || 0.75) });
        else performKick(taker, kind === 'through' ? 'through' : 'pass', { aim: currentAimP2() });
      } else if (match.restartType === 'penalty') {
        performKick(taker, 'shoot', { targetZ: currentAimP2().z * 3.2, power: Math.max(0.7, inputP2.power || 0.85), perfect: inputP2.power > 0.7 && inputP2.power < 0.95, isPenalty: true });
      }
      match.pendingTaker = null;
      match.state = 'play';
      match.autoSwitchGraceT = 0.5;
      resetChargeUIP2();
    }
    return;
  }
  if (match.state !== 'play') return;
  const dBall = dist2(c.pos.x, c.pos.z, ball.pos.x, ball.pos.z);
  const p2Defending = ball.owner && ball.owner.team === 0;
  if (kind === 'thunder') { activateThunder(c); return; }
  if (kind === 'chippass') { if (ball.owner === c) { performKick(c, 'chipPass', { aim: currentAimP2() }); resetChargeUIP2(); } return; }
  if (kind === 'through') { if (ball.owner === c) { performKick(c, 'through', { aim: currentAimP2() }); resetChargeUIP2(); } return; }
  if (kind === 'chip') { if (ball.owner === c) { performKick(c, 'chip', {}); resetChargeUIP2(); } return; }
  if (kind === 'curl') { if (ball.owner === c) { performKick(c, 'curl', {}); resetChargeUIP2(); } return; }
  if (kind === 'curl2') { if (ball.owner === c) { performKick(c, 'curl2', {}); resetChargeUIP2(); } return; }
  if (kind === 'defdrib') {
    if (ball.owner === c) { doTrick(c, trickIndex); trickIndex = (trickIndex + 1) % TRICKS.length; }
    else standingTackle(c);
    return;
  }
  if (kind === 'pass') {
    if (p2Defending) { slideTackle(c); return; }
    if (ball.owner === c) {
      const wide = Math.abs(c.pos.z) > 20;
      if (wide && c.pos.x < -26) performKick(c, 'cross', {});
      else performKick(c, 'pass', { aim: currentAimP2() });
      resetChargeUIP2();
      return;
    }
    if (dBall < 2.6) { performKick(c, 'pass', { aim: currentAimP2() }); resetChargeUIP2(); }
    else slideTackle(c);
    return;
  }
  if (kind === 'shoot') {
    if (p2Defending) { standingTackle(c); resetChargeUIP2(); return; }
    const shotKind = getShootKindP2();
    const power = Math.max(0.3, inputP2.power);
    const perfect = inputP2.power >= 0.72 && inputP2.power <= 0.92;
    if (shotKind === 'clear') performKick(c, 'clear', {});
    else if (shotKind === 'curl') performKick(c, 'curl', {});
    else if (shotKind === 'header') performKick(c, 'header', { power });
    else if (shotKind === 'volley') performKick(c, 'volley', { power });
    else if (shotKind === 'bicycle') performKick(c, 'bicycle', { power: Math.max(0.7, power) });
    else performKick(c, 'shoot', { power, targetZ: aimFromInputP2(), perfect });
    resetChargeUIP2();
    return;
  }
}
function manualSwitch() {
  if (switchCooldown > 0) return;
  switchCooldown = 0.4;
  const c = nearestPlayerOf(0, ball.pos.x, ball.pos.z, false);
  if (c && c !== controlled) { controlled = c; audio.ui(); updatePlayerCard(); }
}
function autoSwitchIfNeeded() {
  if (!settings.autoSwitch || switchCooldown > 0) return;
  if (match.autoSwitchGraceT > 0) return;
  if (ball.owner && ball.owner.team === 0) {
    // We have the ball: only force-switch onto the carrier if we're
    // controlling someone clearly not near the ball (e.g. after a pass).
    if (controlled !== ball.owner && dist2(controlled.pos.x, controlled.pos.z, ball.pos.x, ball.pos.z) > 3) {
      controlled = ball.owner;
      switchCooldown = 0.5;
      updatePlayerCard();
    }
    return;
  }
  // Defending / loose ball: pick whoever is best placed to win it, not
  // just whoever is nearest right now. "Best placed" weighs in how fast
  // each candidate can actually close the gap, using a short predicted
  // ball position rather than its current spot — this stops the switch
  // target from flickering between two similarly-distant defenders.
  const predictT = 0.35;
  const predX = ball.pos.x + ball.vel.x * predictT;
  const predZ = ball.pos.z + ball.vel.z * predictT;
  const candidates = players.filter((p) => p.team === 0 && !p.sentOff && p.stunTimer <= 0);
  if (!candidates.length) return;

  let best = controlled, bestScore = -Infinity;
  for (const p of candidates) {
    const dNow = dist2(p.pos.x, p.pos.z, ball.pos.x, ball.pos.z);
    const dPred = dist2(p.pos.x, p.pos.z, predX, predZ);
    const speed = p.stats ? (p.stats.pace || 70) : 70;
    // Lower is better: blend current distance, predicted distance, and
    // reward faster players for closing the same gap sooner.
    const score = -(dNow * 0.4 + dPred * 0.6) + (speed - 70) * 0.01;
    if (score > bestScore) { bestScore = score; best = p; }
  }
  if (best !== controlled) {
    const curScore = -(dist2(controlled.pos.x, controlled.pos.z, ball.pos.x, ball.pos.z) * 0.4
      + dist2(controlled.pos.x, controlled.pos.z, predX, predZ) * 0.6);
    // Hysteresis margin (1.1 units) so a marginal, momentary advantage
    // doesn't cause rapid back-and-forth flicking between two players.
    if (bestScore > curScore + 1.1) {
      controlled = best;
      switchCooldown = 0.55;
      updatePlayerCard();
    }
  }
}
function onPossessionChange(p) {
  if (p.team === 0 && controlled !== p && dist2(controlled.pos.x, controlled.pos.z, ball.pos.x, ball.pos.z) > 4) controlled = p;
  updatePlayerCard();
}

/* ==========================================================================
   25 · CONTROLLED UPDATE
   ========================================================================== */
function thirdPersonMode() { return ['follow', 'close', 'firstperson', 'playerlock', 'shoulder', 'pro'].includes(settings.camera); }
function moveVectorFromInput(mx, my) {
  if (thirdPersonMode() && camera) {
    const f = new THREE.Vector3();
    camera.getWorldDirection(f);
    f.y = 0;
    if (f.lengthSq() < 1e-4) f.set(0, 0, -1);
    f.normalize();
    const r = new THREE.Vector3(-f.z, 0, f.x);
    return { x: r.x * mx + f.x * my, z: r.z * mx + f.z * my };
  }
  return { x: mx, z: -my };
}
function updateControlled(dt) {
  const c = controlled;
  if (!c) return;
  if (match.state !== 'play' && match.state !== 'setpiece') { c.vel.multiplyScalar(Math.exp(-4 * dt)); return; }
  if (match.state === 'setpiece') { c.vel.multiplyScalar(Math.exp(-6 * dt)); return; }
  const locked = c.action && c.action.locks;
  if (c.stunTimer > 0 || locked) { c.vel.multiplyScalar(Math.exp(-3 * dt)); return; }
  let mx = input.mx, my = input.my;
  const mag = Math.hypot(mx, my);
  if (mag > 1) { mx /= mag; my /= mag; }
  const mv = moveVectorFromInput(mx, my);
  if (mag > 0.2) {
    const ml = Math.hypot(mv.x, mv.z) || 1;
    lastMoveDir = { x: mv.x / ml, z: mv.z / ml };
  }
  const sprinting = input.sprint && (settings.godStamina || c.stamina > 5) && mag > 0.1;
  const fire = chain[0] >= 8 ? 1.08 : 1;
  const maxSp = c.baseSpeed * psSpeedMul(c) * (sprinting ? 1.32 : 1) * (ball.owner === c ? 0.94 : 1) * fire;
  c.vel.x = damp(c.vel.x, mv.x * maxSp, c.accelRate || 22, dt);
  c.vel.z = damp(c.vel.z, mv.z * maxSp, c.accelRate || 22, dt);
  if (sprinting) {
    // Rapid / Accelerator: passive sprint-speed styles have no single
    // "moment" to key off, so their badge fires once a sustained sprint
    // (~0.4s) shows they're actually at full speed, then stays quiet
    // until the player stops and sprints again (handled by the shared
    // debounce in triggerStyleBadge).
    c._sprintHoldT = (c._sprintHoldT || 0) + dt;
    if (c._sprintHoldT > 0.4) {
      if (hasStyle(c, 'Rapid')) triggerStyleBadge(c, 'Rapid');
      if (hasStyle(c, 'Accelerator')) triggerStyleBadge(c, 'Accelerator');
    }
  } else {
    c._sprintHoldT = 0;
  }
  if (sprinting && !settings.godStamina) {
    // Relentless: covers more ground with reduced fatigue loss.
    const relentlessAmt = styleBonus(c, 'Relentless', 0.18, 0.4);
    const drainMul = Math.max(0, 1 - relentlessAmt); // Elite: never tires while sprinting
    c.stamina = Math.max(0, c.stamina - 10 * dt * drainMul);
    if (relentlessAmt > 0) {
      c._relentlessHoldT = (c._relentlessHoldT || 0) + dt;
      if (c._relentlessHoldT > 1.2) triggerStyleBadge(c, 'Relentless'); // shows once fatigue savings are actually adding up
    }
  } else {
    c._relentlessHoldT = 0;
  }
  if (mag < 0.1 && userDefending()) {
    c.facing = angleDamp(c.facing, Math.atan2(ball.pos.x - c.pos.x, ball.pos.z - c.pos.z), 8, dt);
  }
  if (indicator) {
    indicator.grp.position.set(c.pos.x, 0, c.pos.z);
    indicator.t += dt;
    indicator.ring.material.color.set(chain[0] >= 8 ? '#ffc400' : '#00e5ff');
    indicator.ring.material.opacity = 0.75 + S(indicator.t * 6) * 0.25;
    indicator.arrow.position.y = 2.25 + S(indicator.t * 5) * 0.12;
    indicator.arrow.material.color.set(chain[0] >= 8 ? '#ffc400' : '#00e5ff');
  }
}

/* ==========================================================================
   26 · AI (on-pitch)
   ========================================================================== */
function aiUpdate(dt) {
  aiThinkTimer -= dt;
  const think = aiThinkTimer <= 0;
  if (think) aiThinkTimer = DIFFS[settings.diff].aiReact * ((typeof AIBRAIN !== 'undefined' && AIBRAIN.enabled) ? AIBRAIN.reactScale : 1); // ai.js: reacts faster when losing badly
  const diff = DIFFS[settings.diff];
  const setp = match.state === 'setpiece';
  for (const p of players) {
    if (p === controlled || p === controlledP2) continue;
    if (p.stunTimer > 0 || (p.action && p.action.locks)) { p.vel.multiplyScalar(Math.exp(-3 * dt)); continue; }
    if (p.celebrate > 0) {
      p.celebrate -= dt;
      const scorer = match.celScorer || match.lastTouchPlayer;
      if (p === match.celPartner) { /* duo partner is steered by ua_celeb_plus */ }
      else if (scorer && scorer.team === p.team && scorer !== p) {
        const dirv = new THREE.Vector3(scorer.pos.x - p.pos.x, 0, scorer.pos.z - p.pos.z);
        if (dirv.length() > 3) { dirv.normalize(); p.vel.x = damp(p.vel.x, dirv.x * 5, 6, dt); p.vel.z = damp(p.vel.z, dirv.z * 5, 6, dt); }
        else p.vel.multiplyScalar(Math.exp(-6 * dt));
      } else p.vel.multiplyScalar(Math.exp(-4 * dt));
      continue;
    }
    if (p.isGK) { aiKeeper(p, dt, setp); continue; }
    if (p === match.pendingTaker && setp) { p.vel.multiplyScalar(Math.exp(-8 * dt)); continue; }
    if (setp) {
      const wp = formationWorldPos(p.team, p.homeFx, p.homeFz);
      const dx = wp.x - p.pos.x, dz = wp.z - p.pos.z;
      const d = Math.hypot(dx, dz);
      if (d > 0.5) {
        p.vel.x = damp(p.vel.x, (dx / d) * p.baseSpeed * 0.8, 6, dt);
        p.vel.z = damp(p.vel.z, (dz / d) * p.baseSpeed * 0.8, 6, dt);
      } else p.vel.multiplyScalar(Math.exp(-8 * dt));
      continue;
    }
    if (think) aiDecide(p, diff);
    if (p.plan) {
      const dx = p.plan.x - p.pos.x, dz = p.plan.z - p.pos.z;
      const d = Math.hypot(dx, dz);
      const sp = p.baseSpeed * psSpeedMul(p) * diff.aiSpeed * ((p.team === 1 && typeof AIBRAIN !== 'undefined' && AIBRAIN.enabled) ? AIBRAIN.speedMul : 1) * (p.plan.sprint ? 1.22 : 0.95);
      if (d > 0.4) { p.vel.x = damp(p.vel.x, (dx / d) * sp, 8, dt); p.vel.z = damp(p.vel.z, (dz / d) * sp, 8, dt); }
      else p.vel.multiplyScalar(Math.exp(-8 * dt));
    }
    if (ball.owner && ball.owner.team !== p.team) {
      const carrier = ball.owner;
      const d = dist2(p.pos.x, p.pos.z, carrier.pos.x, carrier.pos.z);
      if (d < 1.15 && p.tackleCd > 0) {
        const ax = (p.pos.x - carrier.pos.x) / (d || 1);
        const az = (p.pos.z - carrier.pos.z) / (d || 1);
        p.vel.x += ax * 14 * dt;
        p.vel.z += az * 14 * dt;
      }
    }
    if (ball.owner === p && p.team === 1) aiCarrierAct(p, dt, diff);
    if (p.team === 1 && !diff.trash && ball.owner && ball.owner.team === 0 && p.plan && p.plan.press) {
      const d = dist2(p.pos.x, p.pos.z, ball.owner.pos.x, ball.owner.pos.z);
      if (d < 1.35 && p.tackleCd <= 0 && !p.action) {
        if (typeof AIBRAIN !== 'undefined' && AIBRAIN.enabled && AIBRAIN.tackle) AIBRAIN.tackle(p); // ai.js: jockey / timed tackle / smart slide
        else if (Math.random() < 0.45) standingTackle(p);
        else slideTackle(p);
      }
    }
  }
  separatePlayers();
}
function aiDecide(p, diff) {
  const team = p.team;
  const gx = attackGoalX(team);
  const ownGx = -gx;
  const ballCarrier = ball.owner;
  const shift = clamp(ball.pos.x * 0.42, -26, 26);
  const wp = formationWorldPos(team, p.homeFx, p.homeFz);
  p.plan = { x: wp.x + shift * 0.8, z: wp.z + (ball.pos.z - wp.z) * 0.18, sprint: false, press: false };
  if (diff.trash && team === 1) { p.plan.sprint = false; return; } // TRASH: just drifts around its slot, never chases or presses
  const mates = players.filter((q) => q.team === team && !q.isGK && q !== controlled);
  mates.sort((a, b) => dist2(a.pos.x, a.pos.z, ball.pos.x, ball.pos.z) - dist2(b.pos.x, b.pos.z, ball.pos.x, ball.pos.z));
  const isChaser = mates[0] === p;
  if (!ballCarrier) {
    if (isChaser) { const lead = predictBallPoint(); p.plan = { x: lead.x, z: lead.z, sprint: true, press: false }; }
    return;
  }
  if (ballCarrier.team === team) {
    const fwdSign = Math.sign(gx - p.pos.x);
    if ((p.role === 'ST' || p.role.includes('W')) && ballCarrier !== p) {
      p.plan.x = clamp(ballCarrier.pos.x + fwdSign * 12, -FIELD.halfLen + 4, FIELD.halfLen - 4);
      p.plan.z = wp.z + rand(-4, 4);
      p.plan.sprint = Math.random() < 0.4;
    } else p.plan.x = wp.x + shift;
  } else {
    if (isChaser) {
      const ahead = new THREE.Vector3(ballCarrier.vel.x, 0, ballCarrier.vel.z).normalize().multiplyScalar(1.4);
      p.plan = { x: ballCarrier.pos.x + ahead.x, z: ballCarrier.pos.z + ahead.z, sprint: true, press: true };
    } else {
      p.plan.x = lerp(wp.x + shift, ownGx, 0.25);
      p.plan.z = wp.z + (ballCarrier.pos.z - wp.z) * 0.3;
    }
  }
}
function predictBallPoint() {
  if (ball.owner) return { x: ball.pos.x, z: ball.pos.z };
  const v = ball.vel;
  if (v.y > 0.5 || ball.pos.y > 0.3) {
    const g = -PHYS.gravity;
    const t = (v.y + Math.sqrt(v.y * v.y + 2 * g * Math.max(0, ball.pos.y - 0.1))) / g;
    return { x: clamp(ball.pos.x + v.x * t * 0.85, -FIELD.halfLen, FIELD.halfLen), z: clamp(ball.pos.z + v.z * t * 0.85, -FIELD.halfWid, FIELD.halfWid) };
  }
  return { x: ball.pos.x + v.x * 0.4, z: ball.pos.z + v.z * 0.4 };
}
function aiCarrierAct(p, dt, diff) {
  p.decideTimer -= dt;
  if (diff.trash && p.team === 1) { // TRASH: hands the ball straight to the nearest human-side player
    if (p.decideTimer <= 0) {
      p.decideTimer = 0.35 + rand(0.3);
      let best = null, bd = 1e9;
      for (const q of players) { if (q.team !== 0 || q.isGK || q.sentOff) continue; const d = dist2(p.pos.x, p.pos.z, q.pos.x, q.pos.z); if (d < bd) { bd = d; best = q; } }
      if (best) performKick(p, 'pass', { target: best, power: 0.45 });
    }
    return;
  }
  const gx = attackGoalX(p.team);
  const dGoal = dist2(p.pos.x, p.pos.z, gx, 0);
  const pressure = nearestOpponentDistOf(p);
  if (p.decideTimer <= 0) {
    p.decideTimer = 0.28 + rand(0.25);
    const inRange = dGoal < 24;
    const pressured = pressure < 2.6;
    if (psThunderName(p) && dGoal < 40 && dGoal > 14 && Math.random() < 0.12) activateThunder(p, true); // AI uses its Thunder when bearing down on goal
    if (inRange && (!pressured || Math.random() < 0.25)) {
      performKick(p, Math.random() < 0.22 ? 'curl' : Math.random() < 0.14 ? 'chip' : 'shoot', { power: rand(0.5, 0.95) * diff.aiAcc });
      return;
    }
    if (pressured && Math.random() < 0.75) {
      const mate = findBestPass(p);
      if (mate) { performKick(p, hasStyle(p, 'Chip Pass') && Math.random() < 0.3 ? 'chipPass' : (Math.random() < 0.25 ? 'through' : 'pass'), { target: mate }); return; }
    }
    if (Math.abs(p.pos.z) > 22 && Math.abs(p.pos.x) > 30 && Math.random() < 0.3) { performKick(p, 'cross', {}); return; }
    let dirX = Math.sign(gx - p.pos.x);
    let dirZ = -Math.sign(p.pos.z) * 0.4;
    const nearOpp = nearestOpponentTo(p);
    if (nearOpp && dist2(nearOpp.pos.x, nearOpp.pos.z, p.pos.x, p.pos.z) < 4) dirZ += Math.sign(p.pos.z - nearOpp.pos.z) * 0.9;
    p.plan = { x: clamp(p.pos.x + dirX * 10, -FIELD.halfLen + 2, FIELD.halfLen - 2), z: clamp(p.pos.z + dirZ * 8, -FIELD.halfWid + 2, FIELD.halfWid - 2), sprint: Math.random() < 0.5 };
  }
}
function nearestOpponentTo(p) {
  let best = null, bd = 1e9;
  for (const q of players) {
    if (q.team === p.team) continue;
    const d = dist2(p.pos.x, p.pos.z, q.pos.x, q.pos.z);
    if (d < bd) { bd = d; best = q; }
  }
  return best;
}
function aiKeeper(p, dt, setp) {
  const ownGx = p.team === 0 ? -FIELD.halfLen : FIELD.halfLen;
  const dirSign = p.team === 0 ? 1 : -1;
  if (setp) {
    p.vel.x = damp(p.vel.x, clamp((ownGx + dirSign * 0.6 - p.pos.x) * 6, -5, 5), 8, dt);
    p.vel.z = damp(p.vel.z, clamp((0 - p.pos.z) * 6, -5, 5), 8, dt);
    return;
  }
  if (ball.owner === p) {
    p.vel.multiplyScalar(Math.exp(-8 * dt));
    p.decideTimer -= dt;
    if (p.decideTimer <= 0) { p.decideTimer = 1.4; performKick(p, 'gkThrow', { target: findBestPass(p) }); }
    return;
  }
  const ballComing = isBallComingToGoal(p.team);
  let tx = ownGx + dirSign * 0.6;
  let tz = 0;
  if (Math.abs(ball.pos.x - ownGx) < 14 && !ball.owner) {
    if (Math.abs(ball.pos.z) < 9 && Math.abs(ball.pos.x - ownGx) < 11) { tx = ball.pos.x; tz = ball.pos.z; }
    else tz = clamp(ball.pos.z * 0.4, -3.4, 3.4);
  } else {
    tz = clamp(ball.pos.z * 0.55, -3.3, 3.3);
    if (ballComing) tz = clamp(predictGoalZ(p.team), -3.4, 3.4);
  }
  const sp = 5.2 * (0.7 + DIFFS[settings.diff].gkSkill * 0.4) * (1 + styleBonus(p, 'Rush Out', 0.08, 0.18));
  p.vel.x = damp(p.vel.x, clamp((tx - p.pos.x) * 6, -sp, sp), 10, dt);
  p.vel.z = damp(p.vel.z, clamp((tz - p.pos.z) * 6, -sp, sp), 10, dt);
  if (ballComing && !ball.owner && !(ball.eliteShotT > 0) && !(ball.finesseFlight && ball.finesseFlight.sure)) { // an Elite Power Shot / a 'sure' finesse cannot be saved
    const d = dist2(p.pos.x, p.pos.z, ball.pos.x, ball.pos.z);
    // Rush Out: extended reach for aggressively closing down through balls.
    const rushOutBonus = styleBonus(p, 'Rush Out', 0.15, 0.35);
    const baseReach = 1.25 + DIFFS[settings.diff].gkSkill * 0.5;
    const gkReach = psStat(p, 'Reach', 'reach');
    const reach = (baseReach + rushOutBonus) * (1 + gkReach);
    if (d < reach && ball.pos.y < 2.3 && Math.abs(ball.pos.x - ownGx) < 10) {
      if (rushOutBonus > 0 && d >= baseReach) triggerStyleBadge(p, 'Rush Out');
      if (gkReach > 0 && d >= baseReach + rushOutBonus) triggerStyleBadge(p, 'Reach'); // only "counts" when the extra reach actually closed the gap
      const speed = ball.vel.length();
      const skill = DIFFS[settings.diff].gkSkill;
      // Guardian: broadly better reflexes/reactions -> higher catch chance overall.
      const guardianAmt = styleBonus(p, 'Guardian', 0.08, 0.18);
      const catchChance = clamp01(((speed > 24 ? 0.3 + skill * 0.3 : 0.6 + skill * 0.25) + guardianAmt) * (1 - Math.min(0.55, (ball.powerBoost || 0) * 0.3)));
      p.startAction('dive', 0.7, 0.15, () => {
        if (Math.random() < catchChance) {
          ball.owner = p;
          p.hasBall = true;
          ball.vel.set(0, 0, 0);
          match.stats.saves[p.team]++;
          trackStat(p, 'saves');
          if (ball.shotActive) { match.stats.onTarget[ball.shotTeam >= 0 ? ball.shotTeam : 1 - p.team]++; ball.shotActive = false; }
          match.possTeam = p.team;
          p.decideTimer = 1.2;
          audio.catchBall();
          sayPick(COM_SAVE, `· ${p.name}`);
          if (guardianAmt > 0) triggerStyleBadge(p, 'Guardian');
          onPossessionChange(p);
        } else {
          // Deflector: parries land in safer areas (away from onrushing
          // attackers) instead of a purely fixed outward direction.
          const deflectAmt = styleBonus(p, 'Deflector', 0.3, 0.65);
          const baseOut = new THREE.Vector3(-dirSign * 0.7, 0.3, Math.sign(ball.pos.z || rand(-1, 1)) * 0.8).normalize();
          const safeZ = Math.sign(ball.pos.z || 1) * -1; // push toward the wider, less-crowded side
          const out = new THREE.Vector3(
            lerp(baseOut.x, -dirSign * 0.85, Math.min(1, deflectAmt)),
            baseOut.y,
            lerp(baseOut.z, safeZ * 0.9, Math.min(1, deflectAmt))
          ).normalize();
          ball.vel.copy(out).multiplyScalar(speed * Math.max(0.06, 0.35 - deflectAmt * 0.08)); // Elite: the parry kills the ball's pace
          ball.vel.y = 3;
          ball.kickCooldown = 0.4;
          match.stats.saves[p.team]++;
          trackStat(p, 'saves');
          audio.catchBall();
          sayPick(COM_SAVE, `· ${p.name}`);
          if (deflectAmt > 0) triggerStyleBadge(p, 'Deflector');
        }
      });
      p.diveDir = Math.sign(ball.pos.z - p.pos.z) || 1;
    }
  }
  if (!ball.owner && Math.abs(ball.pos.x - ownGx) < 8 && Math.abs(ball.pos.z) < 10) {
    if (dist2(p.pos.x, p.pos.z, ball.pos.x, ball.pos.z) < 1.1 && ball.kickCooldown <= 0 && !(ball.eliteShotT > 0) && !(ball.finesseFlight && ball.finesseFlight.sure)) performKick(p, 'clear', {});
  }
}
function isBallComingToGoal(team) {
  const ownGx = team === 0 ? -FIELD.halfLen : FIELD.halfLen;
  const toward = team === 0 ? ball.vel.x < -3 : ball.vel.x > 3;
  return toward && Math.abs(ball.pos.x - ownGx) < 34;
}
function predictGoalZ(team) {
  const ownGx = team === 0 ? -FIELD.halfLen : FIELD.halfLen;
  const t = (ownGx - ball.pos.x) / (ball.vel.x || 1e-6);
  if (t < 0 || t > 4) return ball.pos.z;
  return ball.pos.z + ball.vel.z * t;
}
function separatePlayers() {
  for (let i = 0; i < players.length; i++) for (let j = i + 1; j < players.length; j++) {
    const a = players[i], b = players[j];
    const dx = b.pos.x - a.pos.x, dz = b.pos.z - a.pos.z;
    const d = Math.hypot(dx, dz);
    if (d < 0.85 && d > 1e-4) {
      const push = (0.85 - d) * 0.28;
      const nx = dx / d, nz = dz / d;
      a.pos.x -= nx * push; a.pos.z -= nz * push;
      b.pos.x += nx * push; b.pos.z += nz * push;
      const rvx = b.vel.x - a.vel.x, rvz = b.vel.z - a.vel.z;
      const vn = rvx * nx + rvz * nz;
      if (vn < 0) {
        a.vel.x += nx * vn * 0.5; a.vel.z += nz * vn * 0.5;
        b.vel.x -= nx * vn * 0.5; b.vel.z -= nz * vn * 0.5;
      }
    }
  }
}

/* ==========================================================================
   27 · CAMERAS (18 modes)
   ========================================================================== */
const camState = { pos: new THREE.Vector3(0, 26, 46), look: new THREE.Vector3(0, 0, 0), orbitA: 0, shakeX: 0, shakeY: 0 };
function updateCamera(dt) {
  const mode = settings.camera;
  const hMul = settings.camHeight;
  const targetPos = new THREE.Vector3();
  const targetLook = new THREE.Vector3();
  const focus = controlled ? controlled.pos : (ball ? ball.pos : new THREE.Vector3());
  const bpos = ball ? ball.pos : new THREE.Vector3();
  if (match.state === 'goal' || mode === 'replay') {
    const scorer = (match.state === 'goal' && match.celScorer) ? match.celScorer : match.lastTouchPlayer;
    const f = scorer ? scorer.pos : bpos;
    camState.orbitA += dt * 0.85;
    // Close-up celebration cam: tight radius + near player-head height so
    // the celebration animation actually reads clearly, instead of the
    // old wide 8.2-unit orbit that made every celebration look tiny and
    // distant. Slowly pulls back slightly over the first second for a
    // "cinematic push-in" feel rather than snapping straight to close.
    const closeT = clamp01(match.goalAge / 1.0);
    const r = lerp(5.2, 3.6, closeT);
    const camH = lerp(2.4, 1.85, closeT) * hMul;
    targetPos.set(f.x + C(camState.orbitA) * r, camH, f.z + S(camState.orbitA) * r);
    targetLook.set(f.x, 1.35, f.z);
    if (mode !== 'replay' && window.UACeleb && UACeleb.shotFn) UACeleb.shotFn(f, dt, hMul, targetPos, targetLook, camState, match.goalAge, scorer);
    // Cinematic goal opener: low side-on cam tracks the ball into the net, then blends into the celebration shot.
    if (mode !== 'replay' && match.state === 'goal' && match.goalAge < 1.9 && ball) {
      const w = 1 - clamp01((match.goalAge - 1.3) / 0.6);
      const gx = ball.pos.x >= 0 ? 1 : -1;
      const cp = new THREE.Vector3(ball.pos.x - gx * 9, 1.3, ball.pos.z + (ball.pos.z >= 0 ? -1 : 1) * 7);
      const cl = new THREE.Vector3(ball.pos.x + gx * 2, 1.0, ball.pos.z);
      targetPos.lerp(cp, w); targetLook.lerp(cl, w);
    }
  } else if (mode === 'firstperson') {
    const c = controlled || { pos: new THREE.Vector3(), facing: 0 };
    const fwd = new THREE.Vector3(S(c.facing), 0, C(c.facing));
    targetPos.copy(c.pos).add(new THREE.Vector3(0, 1.65 * hMul, 0)).addScaledVector(fwd, 0.25);
    targetLook.copy(c.pos).addScaledVector(fwd, 8);
    targetLook.y = 1.2;
  } else if (mode === 'follow') {
    const c = controlled || { pos: new THREE.Vector3(), facing: 0 };
    camAz = angleDamp(camAz, c.facing, 2.8, dt);
    const dist = 10, h = 4.8 * hMul, ahead = 8;
    const fx = S(camAz), fz = C(camAz);
    targetPos.set(c.pos.x - fx * dist, h, c.pos.z - fz * dist);
    targetLook.set(c.pos.x + fx * ahead, 1.3, c.pos.z + fz * ahead);
  } else if (mode === 'close') {
    const c = controlled || { pos: new THREE.Vector3(), facing: 0 };
    camAz = angleDamp(camAz, c.facing, 2.8, dt);
    const dist = 5.6, h = 2.6 * hMul, ahead = 6;
    const fx = S(camAz), fz = C(camAz);
    targetPos.set(c.pos.x - fx * dist, h, c.pos.z - fz * dist);
    targetLook.set(c.pos.x + fx * ahead, 1.3, c.pos.z + fz * ahead);
  } else if (mode === 'ultraclose') {
    const c = controlled || { pos: new THREE.Vector3(), facing: 0 };
    camAz = angleDamp(camAz, c.facing, 3.4, dt);
    const dist = 3.1, h = 1.75 * hMul, ahead = 5;
    const fx = S(camAz), fz = C(camAz);
    targetPos.set(c.pos.x - fx * dist + fz * 0.5, h, c.pos.z - fz * dist - fx * 0.5);
    targetLook.set(c.pos.x + fx * ahead, 1.15, c.pos.z + fz * ahead);
  } else if (mode === 'playerlock') {
    const c = controlled || { pos: new THREE.Vector3(), facing: 0 };
    targetPos.set(c.pos.x - 8, 5.5 * hMul, c.pos.z + 8);
    targetLook.set(c.pos.x, 1.2, c.pos.z);
  } else if (mode === 'shoulder') {
    const c = controlled || { pos: new THREE.Vector3(), facing: 0 };
    const fwd = new THREE.Vector3(S(c.facing), 0, C(c.facing));
    const right = new THREE.Vector3(fwd.z, 0, -fwd.x);
    targetPos.copy(c.pos).addScaledVector(fwd, -3.5).addScaledVector(right, 1.2);
    targetPos.y = 2.4 * hMul;
    targetLook.copy(c.pos).addScaledVector(fwd, 6);
    targetLook.y = 1.2;
  } else if (mode === 'pro') {
    const c = controlled || { pos: new THREE.Vector3(), facing: 0 };
    const fwd = new THREE.Vector3(S(c.facing), 0, C(c.facing));
    targetPos.copy(c.pos).addScaledVector(fwd, -7.5);
    targetPos.y = 4.2 * hMul;
    targetLook.copy(c.pos).addScaledVector(fwd, 8);
    targetLook.y = 1;
  } else if (mode === 'tv') {
    targetPos.set(bpos.x * 0.82, (24 + Math.abs(bpos.z) * 0.14) * hMul, bpos.z * 0.5 + 42);
    targetLook.set(bpos.x * 0.94, 0.6, bpos.z * 0.82);
  } else if (mode === 'broadcast-wide') {
    targetPos.set(bpos.x * 0.7, 34 * hMul, bpos.z * 0.4 + 55);
    targetLook.set(bpos.x * 0.9, 0.5, bpos.z * 0.7);
  } else if (mode === 'action') {
    targetPos.set(bpos.x * 0.9, 14 * hMul, bpos.z * 0.7 + 26);
    targetLook.set(bpos.x, 0.8, bpos.z * 0.9);
  } else if (mode === 'top') {
    targetPos.set(bpos.x * 0.85, 48 * hMul, bpos.z * 0.5 + 14);
    targetLook.set(bpos.x * 0.9, 0, bpos.z * 0.7);
  } else if (mode === 'tactical') {
    targetPos.set(bpos.x * 0.9, 60 * hMul, bpos.z * 0.9 + 0.01);
    targetLook.set(bpos.x, 0, bpos.z);
  } else if (mode === 'cinema') {
    targetPos.set(clamp(bpos.x - 17, -62, 38), 2.6 * hMul, bpos.z * 0.85 + 5);
    targetLook.set(bpos.x + 7, 1.2, bpos.z);
  } else if (mode === 'sideline') {
    targetPos.set(bpos.x * 0.6, 2.2 * hMul, FIELD.halfWid + 5); // pulled in: new lower stand wall starts at 42 m
    targetLook.set(bpos.x, 1, bpos.z);
  } else if (mode === 'behindGoal') {
    const gx = controlled && controlled.team === 0 ? FIELD.halfLen + 6 : -FIELD.halfLen - 6;
    targetPos.set(gx, 3.5 * hMul, 0);
    targetLook.set(bpos.x, 1, bpos.z);
  } else if (mode === 'drone') {
    camState.orbitA += dt * 0.3;
    const r = 30;
    targetPos.set(bpos.x + C(camState.orbitA) * r, 26 * hMul, bpos.z + S(camState.orbitA) * r);
    targetLook.set(bpos.x, 0.5, bpos.z);
  } else if (mode === 'crane') {
    targetPos.set(bpos.x * 0.6, (30 + S(elapsedT * 0.3) * 8) * hMul, bpos.z * 0.5 + 38);
    targetLook.set(bpos.x, 0.8, bpos.z);
  } else if (mode === 'handheld') {
    camState.shakeX = damp(camState.shakeX, rand(-0.15, 0.15), 8, dt);
    camState.shakeY = damp(camState.shakeY, rand(-0.1, 0.1), 8, dt);
    targetPos.set(bpos.x * 0.82 + camState.shakeX, (22 + Math.abs(bpos.z) * 0.1) * hMul + camState.shakeY, bpos.z * 0.5 + 40);
    targetLook.set(bpos.x * 0.94, 0.6, bpos.z * 0.82);
  }
  if (match.screen === 'match' && match.introT > 0 && mode !== 'firstperson') {
    match.introT -= dt;
    const k = 1 - clamp01(match.introT / 2.4);
    const wide = new THREE.Vector3(C(1.2 + k * 2.2) * 72, 40 * hMul - k * 12, S(1.2 + k * 2.2) * 72);
    targetPos.lerp(wide, 1 - k);
    targetLook.lerp(new THREE.Vector3(0, 3, 0), (1 - k) * 0.7);
  }
  const kPos = match.state === 'goal' ? 4 : settings.camSmooth;
  camState.pos.x = damp(camState.pos.x, targetPos.x, kPos, dt);
  camState.pos.y = damp(camState.pos.y, targetPos.y, kPos, dt);
  camState.pos.z = damp(camState.pos.z, targetPos.z, kPos, dt);
  camState.look.x = damp(camState.look.x, targetLook.x, 5, dt);
  camState.look.y = damp(camState.look.y, targetLook.y, 5, dt);
  camState.look.z = damp(camState.look.z, targetLook.z, 5, dt);
  camera.position.copy(camState.pos);
  if (shakeAmt > 0.001) {
    camera.position.x += rand(-1, 1) * shakeAmt * 0.3;
    camera.position.y += rand(-1, 1) * shakeAmt * 0.2;
    shakeAmt *= Math.exp(-4 * dt);
  }
  camera.lookAt(camState.look);
  const targetFov = match.state === 'goal' ? ((window.UACeleb && UACeleb.fov) ? UACeleb.fov() : Math.max(35, settings.camFov - 8)) : (mode === 'ultraclose' ? Math.min(settings.camFov, 46) : settings.camFov);
  if (Math.abs(camera.fov - targetFov) > 0.05) {
    camera.fov = damp(camera.fov, targetFov, 3.5, dt);
    camera.updateProjectionMatrix();
  }
  const fp = mode === 'firstperson';
  for (const p of players) p.mesh.visible = !(fp && p === controlled);
  if (referee) referee.mesh.visible = !fp;
}

/* ==========================================================================
   28 · HUD
   ========================================================================== */
let commentaryTimer = 0;
/* ==========================================================================
   🎙️ VOICE COMMENTARY — speaks every existing say()/sayPick() commentary
   line out loud using the browser's built-in SpeechSynthesis API. This adds
   no new event triggers of its own: every goal, foul, card, save, and
   restart call already routes through say(), so hooking in here means the
   whole existing commentary system gets a voice for free, and any future
   sayPick() call automatically gets voiced too with no extra wiring.
   ========================================================================== */
let voiceList = [];
function voicePopulateList() {
  if (!window.speechSynthesis) { $('set-voice-pick').innerHTML = '<option value="">Not supported on this device</option>'; return; }
  voiceList = window.speechSynthesis.getVoices().filter((v) => v.lang.startsWith('en'));
  if (!voiceList.length) voiceList = window.speechSynthesis.getVoices(); // fall back to whatever's installed
  const sel = $('set-voice-pick');
  sel.innerHTML = '<option value="">Default</option>' + voiceList.map((v) => `<option value="${v.voiceURI}">${escHtmlGame(v.name)}</option>`).join('');
  sel.value = settings.voiceURI || '';
}
function voiceStopSpeaking() {
  if (window.speechSynthesis) window.speechSynthesis.cancel();
}
function voiceSpeak(text) {
  if (!settings.voiceCommentary || !window.speechSynthesis || !text) return;
  // Cancel any line still being read — commentary comes in short bursts and
  // a queued-up backlog of stale lines reading out of order sounds far
  // worse than clipping the previous one short.
  window.speechSynthesis.cancel();
  const utter = new SpeechSynthesisUtterance(text);
  utter.volume = clamp01(settings.voiceVol / 100);
  utter.rate = 1.05;
  utter.pitch = 1.0;
  if (settings.voiceURI) {
    const v = voiceList.find((x) => x.voiceURI === settings.voiceURI);
    if (v) utter.voice = v;
  }
  try { window.speechSynthesis.speak(utter); } catch (e) { /* some browsers throw if called too early */ }
}
function say(text) {
  if (!settings.commentary) return;
  const el = $('commentary');
  el.textContent = text;
  el.classList.add('show');
  commentaryTimer = 3.4;
  voiceSpeak(text);
}
function updateCommentary(dt) {
  if (commentaryTimer > 0) { commentaryTimer -= dt; if (commentaryTimer <= 0) $('commentary').classList.remove('show'); }
}
let toastTimer = 0;
function toast(text) {
  const el = $('toast');
  el.textContent = text;
  el.classList.add('show');
  toastTimer = 1.1;
}
function updateToast(dt) {
  if (toastTimer > 0) { toastTimer -= dt; if (toastTimer <= 0) $('toast').classList.remove('show'); }
}
function updateScoreboard() {
  $('sb-score-h').textContent = match.score[0];
  $('sb-score-a').textContent = match.score[1];
  const halfDur = settings.halfDur;
  const inHalf = match.half === 1 ? clamp01(match.clock / halfDur) : clamp01((match.clock - halfDur) / halfDur);
  $('sb-clock').textContent = (Math.floor(inHalf * 45) + (match.half === 2 ? 45 : 0)) + "'";
  $('sb-half').textContent = match.half === 1 ? '1ST' : '2ND';
}
function updatePossBar() {
  const s = match.stats;
  if (!s) return;
  const tot = s.poss[0] + s.poss[1];
  $('poss-home').style.width = Math.round((s.poss[0] / tot) * 100) + '%';
}
function updateChainUI() {
  const el = $('chain');
  if (chain[0] >= 3) {
    el.textContent = chain[0] >= 8 ? '🔥 ON FIRE · CHAIN ' + Math.floor(chain[0]) : '⚡ CHAIN ' + Math.floor(chain[0]);
    el.classList.add('show');
  } else el.classList.remove('show');
  if (chain[0] >= 8 && !onFireNotified) {
    onFireNotified = true;
    toast('🔥 ON FIRE! SPEED BOOST!');
    audio.chant();
    haptic(100);
  }
  if (chain[0] < 8) onFireNotified = false;
}
function updatePlayerCard() {
  if (!controlled) return;
  $('pc-name').textContent = controlled.name;
  $('pc-role').textContent = controlled.role;
  $('pc-ovr').textContent = ovrD(controlled.ovr);
  const rec = cardForPlayer(controlled);
  if (rec && rec.img) {
    const el = $('pc-img');
    if (el.dataset.src !== rec.img) {
      el.dataset.src = rec.img;
      el.onerror = () => { el.style.visibility = 'hidden'; };
      el.onload = () => { el.style.visibility = 'visible'; };
      el.src = rec.img;
    }
  }
}
function updateStaminaBar() {
  if (!controlled) return;
  const st = $('pc-stam');
  st.style.width = controlled.stamina + '%';
  st.style.background = controlled.stamina < 30 ? 'linear-gradient(90deg,#ff3b4b,#ff7a45)' : 'linear-gradient(90deg,var(--fc-green),var(--fc-cyan))';
}
function setHint(text) {
  const el = $('hint');
  el.textContent = text;
  el.style.opacity = text ? 1 : 0;
}
function updateHintForSetPiece() {
  if (match.awaitUser) {
    const map = { kickoff: 'TAP PASS OR SHOOT TO KICK OFF', throw: 'THROW-IN — TAP PASS', corner: 'CORNER — TAP PASS TO CROSS', goalkick: 'GOAL KICK — TAP PASS', freekick: 'FREE KICK — TAP SHOOT OR PASS', penalty: 'PENALTY — TAP SHOOT' };
    setHint(map[match.restartType] || '');
    $('hint').classList.toggle('await-user', match.restartType === 'kickoff');
  } else {
    setHint('');
    $('hint').classList.remove('await-user');
  }
}
function refreshButtons() {
  if (!controlled) return;
  const poss = ball.owner;
  const userPoss = poss === controlled;
  const defending = poss && poss.team === 1;
  let shootLbl = '◀POWER ▲CHIP ▼CURL ▶CURL';
  if (defending) shootLbl = 'TACKLE';
  else if (userPoss) {
    const kind = getShootKind();
    if (kind === 'clear') shootLbl = 'CLEAR';
    else if (kind === 'curl') shootLbl = 'CURL';
  } else {
    const kind = getShootKind();
    if (kind === 'header') shootLbl = 'HEADER';
    else if (kind === 'volley') shootLbl = 'VOLLEY';
    else if (kind === 'bicycle') shootLbl = 'BICYCLE!';
  }
  $('lbl-shoot').textContent = shootLbl;
  $('lbl-pass').textContent = defending ? 'SLIDE' : (userPoss && Math.abs(controlled.pos.z) > 20 && controlled.pos.x > 26) ? 'CROSS' : 'AIMED · ▲THRU';
  $('b-def').firstChild.textContent = defending || !userPoss ? 'DEF' : 'SKILL';
  $('lbl-def').textContent = defending ? 'TACKLE' : 'TRICK';
  const dGoal = dist2(controlled.pos.x, controlled.pos.z, FIELD.halfLen, 0);
  $('ctx-chip').classList.toggle('show', userPoss && dGoal < 32);
  $('ctx-chippass').classList.toggle('show', userPoss && dGoal >= 32);
  const thName = psThunderName(controlled);
  const thBtn = $('b-thunder');
  thBtn.classList.toggle('show', !!thName);
  if (thName) {
    const left = PS_NEW_SPEC[thName].uses - (controlled.thunderUses || 0);
    thBtn.classList.toggle('active', controlled.thunderT > 0);
    thBtn.classList.toggle('spent', left <= 0 && !(controlled.thunderT > 0));
    $('lbl-thunder').textContent = controlled.thunderT > 0 ? Math.ceil(controlled.thunderT) + 's' : (left > 0 ? thName.toUpperCase() + ' ×' + left : 'USED');
  }
  $('ctx-thru').classList.toggle('show', userPoss);
  $('ctx-switch').classList.toggle('show', defending || !poss);
}
const mmCtx = $('minimap').getContext('2d');
function drawMinimap() {
  const w = 228, h = 148;
  mmCtx.clearRect(0, 0, w, h);
  mmCtx.fillStyle = 'rgba(10,40,20,0.85)';
  mmCtx.fillRect(0, 0, w, h);
  mmCtx.strokeStyle = 'rgba(255,255,255,0.35)';
  mmCtx.lineWidth = 1;
  mmCtx.strokeRect(4, 4, w - 8, h - 8);
  const mapX = (x) => 4 + ((x + FIELD.halfLen) / FIELD.len) * (w - 8);
  const mapZ = (z) => 4 + ((z + FIELD.halfWid) / FIELD.wid) * (h - 8);
  for (const p of players) {
    mmCtx.fillStyle = p.team === 0 ? teamDefs[0].c1 : teamDefs[1].c1;
    if (p === controlled) {
      mmCtx.strokeStyle = '#ffffff';
      mmCtx.beginPath(); mmCtx.arc(mapX(p.pos.x), mapZ(p.pos.z), 4, 0, Math.PI * 2); mmCtx.stroke();
    }
    mmCtx.beginPath(); mmCtx.arc(mapX(p.pos.x), mapZ(p.pos.z), p.isGK ? 3 : 2.4, 0, Math.PI * 2); mmCtx.fill();
  }
  if (referee) {
    mmCtx.fillStyle = '#ffd700';
    mmCtx.beginPath(); mmCtx.arc(mapX(referee.pos.x), mapZ(referee.pos.z), 2, 0, Math.PI * 2); mmCtx.fill();
  }
  mmCtx.fillStyle = '#ffffff';
  mmCtx.beginPath(); mmCtx.arc(mapX(ball.pos.x), mapZ(ball.pos.z), 2.6, 0, Math.PI * 2); mmCtx.fill();
}
const _tagV = new THREE.Vector3();
function updateOwnerTag() {
  const tag = $('owner-tag');
  const o = ball && ball.owner;
  if (!o || match.screen !== 'match' || match.paused) { tag.style.display = 'none'; return; }
  const rec = cardForPlayer(o);
  _tagV.set(o.pos.x, 0.1, o.pos.z).project(camera);
  if (_tagV.z > 1) { tag.style.display = 'none'; return; }
  const _vpt = getGameViewportSize();
  const x = (_tagV.x * 0.5 + 0.5) * _vpt.w;
  const y = (-_tagV.y * 0.5 + 0.5) * _vpt.h;
  tag.style.display = 'flex';
  tag.style.left = clamp(x, 70, _vpt.w - 70) + 'px';
  tag.style.top = Math.min(_vpt.h - 44, y + 26) + 'px';
  if (tag.dataset.n !== o.name) {
    tag.dataset.n = o.name;
    $('ot-img').src = rec ? rec.img : '';
    $('ot-name').textContent = o.name;
  }
}
function updateFPS() {
  if (!settings.fps) { $('fps').style.display = 'none'; return; }
  const now = performance.now();
  fpsFrames++;
  if (now - fpsLast >= 500) {
    const fps = Math.round((fpsFrames * 1000) / (now - fpsLast));
    $('fps').textContent = fps + ' FPS';
    $('fps').style.display = 'block';
    fpsFrames = 0;
    fpsLast = now;
  }
}

/* ==========================================================================
   29 · INPUT
   ========================================================================== */
const joyZone = $('joy-zone');
const joyBase = $('joy-base');
const joyStick = $('joy-stick');
let joyId = null;
let joyOrigin = { x: 0, y: 0 };
let joyLast = { x: 0, y: 0, t: 0 };
/* Joystick radius scales with the on-screen base so a normal thumb sweep
   reaches full speed, and a small deadzone stops jitter. The stick is
   "floating": if the thumb drags past the radius the origin follows it,
   so the player never has to lift and re-touch to keep running. */
function joyRadius() {
  const r = joyBase ? joyBase.getBoundingClientRect().width / 2 : 0;
  return Math.max(38, (r || 52) * 0.9);
}
function joyReset() {
  joyId = null;
  joyBase.style.display = 'none';
  joyStick.style.left = '50%';
  joyStick.style.top = '50%';
  input.mx = 0;
  input.my = 0;
}
joyZone.addEventListener('pointerdown', (e) => {
  e.preventDefault();
  // A stale joyId (pointer lost without pointerup/cancel) must never lock
  // the stick out — a new touch always takes over.
  joyId = e.pointerId;
  joyOrigin = { x: e.clientX, y: e.clientY };
  joyLast = { x: e.clientX, y: e.clientY, t: e.timeStamp };
  joyBase.style.display = 'block';
  joyBase.style.left = e.clientX + 'px';
  joyBase.style.top = e.clientY + 'px';
  joyStick.style.left = '50%';
  joyStick.style.top = '50%';
  try { joyZone.setPointerCapture(e.pointerId); } catch (e2) {}
});
joyZone.addEventListener('pointermove', (e) => {
  if (e.pointerId !== joyId) return;
  e.preventDefault();
  const max = joyRadius();
  let dx = e.clientX - joyOrigin.x, dy = e.clientY - joyOrigin.y;
  const len = Math.hypot(dx, dy);
  if (len > max) {
    // floating origin: drag the base along with the thumb
    const over = len - max;
    joyOrigin.x += (dx / len) * over;
    joyOrigin.y += (dy / len) * over;
    joyBase.style.left = joyOrigin.x + 'px';
    joyBase.style.top = joyOrigin.y + 'px';
    dx = (dx / len) * max;
    dy = (dy / len) * max;
  }
  joyStick.style.left = `calc(50% + ${dx}px)`;
  joyStick.style.top = `calc(50% + ${dy}px)`;
  let nx = dx / max, ny = -dy / max;
  const mag = Math.hypot(nx, ny);
  const dead = 0.12;
  if (mag < dead) { nx = 0; ny = 0; }
  else {
    // rescale so output ramps 0..1 after the deadzone
    const k = (mag - dead) / (1 - dead) / mag;
    nx *= k; ny *= k;
  }
  input.mx = nx;
  input.my = ny;
  const dtt = Math.max(1, e.timeStamp - joyLast.t);
  const spd = Math.hypot(e.clientX - joyLast.x, e.clientY - joyLast.y) / dtt;
  if (spd > 1.9 && flickCd <= 0 && ball && ball.owner === controlled && match.state === 'play') {
    flickCd = 1.2;
    doTrick(controlled, randInt(0, TRICKS.length - 1));
  }
  joyLast = { x: e.clientX, y: e.clientY, t: e.timeStamp };
});
const joyEnd = (e) => {
  if (e.pointerId !== joyId) return;
  joyReset();
};
joyZone.addEventListener('pointerup', joyEnd);
joyZone.addEventListener('pointercancel', joyEnd);
joyZone.addEventListener('lostpointercapture', joyEnd);
// Safety nets: if the window loses focus/visibility or a system gesture
// steals the touch, never leave the stick "held" with no finger on it.
window.addEventListener('blur', () => { if (joyId !== null) joyReset(); });
document.addEventListener('visibilitychange', () => { if (document.hidden && joyId !== null) joyReset(); });
// Block the browser's native touch gestures (scroll/zoom/long-press) that
// trigger pointercancel mid-drag on Android Chrome.
['touchstart', 'touchmove'].forEach((t) =>
  joyZone.addEventListener(t, (e) => { if (e.cancelable) e.preventDefault(); }, { passive: false })
);
function bindHold(el, onDown, onUp) {
  el.addEventListener('pointerdown', (e) => {
    e.preventDefault();
    e.stopPropagation();
    try { el.setPointerCapture(e.pointerId); } catch (e2) {}
    if (onDown) onDown();
  });
  el.addEventListener('pointerup', () => { if (onUp) onUp(); });
  el.addEventListener('pointercancel', () => { if (onUp) onUp(); });
}
/* 4-directional drag binder. Direction is resolved once a deadzone is
   crossed and locked to whichever axis had the larger delta at that
   moment. A live drag indicator (arrow + distance ring) can be shown
   via onDragMove so the player gets visual feedback while dragging —
   this is what makes "drag left = power shot" etc. discoverable
   instead of a hidden gesture. */
function bindDrag4(el, handlers) {
  const { onDown, onTap, onUp, onSwipeUp, onSwipeDown, onSwipeLeft, onSwipeRight, onDragMove, deadzone = 30 } = handlers;
  let sx = 0, sy = 0, down = false, dir = null;
  el.addEventListener('pointerdown', (e) => {
    e.preventDefault();
    e.stopPropagation();
    try { el.setPointerCapture(e.pointerId); } catch (e2) {}
    down = true;
    dir = null;
    sx = e.clientX;
    sy = e.clientY;
    if (onDown) onDown();
  });
  el.addEventListener('pointermove', (e) => {
    if (!down) return;
    const dx = e.clientX - sx;
    const dy = e.clientY - sy;
    const adx = Math.abs(dx), ady = Math.abs(dy);
    if (adx < deadzone && ady < deadzone) { if (onDragMove) onDragMove(0, 0, null); return; }
    dir = adx > ady ? (dx > 0 ? 'right' : 'left') : (dy > 0 ? 'down' : 'up');
    if (onDragMove) onDragMove(dx, dy, dir);
  });
  const finish = () => {
    if (!down) return;
    down = false;
    if (onUp) onUp();
    if (!dir) { if (onTap) onTap(); }
    else if (dir === 'up' && onSwipeUp) onSwipeUp();
    else if (dir === 'down' && onSwipeDown) onSwipeDown();
    else if (dir === 'left' && onSwipeLeft) onSwipeLeft();
    else if (dir === 'right' && onSwipeRight) onSwipeRight();
    if (onDragMove) onDragMove(0, 0, null);
    dir = null;
  };
  el.addEventListener('pointerup', finish);
  el.addEventListener('pointercancel', finish);
}
