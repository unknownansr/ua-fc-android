/* UA FC — Celebration+ : new celebrations, pick-your-celebration sheet (mobile bottom sheet,
   live animated previews), favourite/random, cinematic goal camera shots, scaled goal effects,
   and a light rim-light/grade pass. Everything degrades cheaply on phones. */
(function () {
  'use strict';
  const LOW = (typeof _isTouchGPU !== 'undefined') ? _isTouchGPU : false;
  const KEY = 'uafc-celeb-fav';
  const $q = (id) => document.getElementById(id);
  const S = Math.sin, C = Math.cos;

  /* ---------- 1 · new celebrations ---------- */
  const E = (a, b, x) => { const k = Math.max(0, Math.min(1, (x - a) / (b - a))); return k * k * (3 - 2 * k); };
  const NEW = [
    // 1 · SIUUU — jump, land with legs apart, arms straight down-and-out, chest up
    { name: 'SIUUU', run: (pose, p, t) => {
      const air = t < 0.62 ? Math.sin(Math.PI * t / 0.62) : 0;       // 0..1..0 jump arc
      const land = E(0.55, 0.85, t);                                   // 0 → 1 pose settle
      pose.hipY = 0.92 + air * 0.34 - land * 0.07;
      pose.torsoX = -0.16 * land + 0.1 * air;
      pose.headX = -0.28 * land;
      const ax = 0.08 * land - 0.7 * air;                              // arms swing up in the jump then down
      pose.armLX = ax; pose.armRX = ax;
      pose.armLZ = 0.2 + 0.38 * land + 0.25 * air; pose.armRZ = -pose.armLZ;
      pose.armLEl = 0.12 * land + 0.5 * air; pose.armREl = pose.armLEl;
      pose.legLX = -0.25 * air; pose.legRX = -0.25 * air;
      pose.legLK = 0.9 * air + 0.05; pose.legRK = 0.9 * air + 0.05;
      pose.legLZ = 0.03 + 0.34 * land; pose.legRZ = -pose.legLZ;       // wide stance
    }},
    // 2 · KNEE SLIDE — slide on knees, arms thrown wide, head back
    { name: 'KNEE SLIDE', slide: true, run: (pose, p, t) => {
      const k = E(0, 0.55, t);
      p._slideOffset = 0;
      pose.hipY = 0.92 - 0.5 * k;
      pose.torsoX = -0.38 * k; pose.headX = -0.4 * k;
      pose.legLX = 0.0 * k; pose.legRX = 0.0 * k;                      // thighs straight down
      pose.legLK = 1.5 * k; pose.legRK = 1.5 * k;                      // shins folded back along the ground
      pose.legLZ = 0.03 + 0.06 * k; pose.legRZ = -pose.legLZ;
      pose.armLX = -0.5 * k; pose.armRX = -0.5 * k;
      pose.armLZ = 0.08 + 1.05 * k; pose.armRZ = -pose.armLZ;          // wide open
      pose.armLEl = 0.2; pose.armREl = 0.2;
    }},
    // 3 · ARMS WIDE ROAR — hop, arms raised in a V, chest out
    { name: 'ARMS WIDE', run: (pose, p, t) => {
      const up = E(0, 0.35, t), b = Math.abs(Math.sin(t * 6.5)) * up;
      pose.hipY = 0.92 + b * 0.14;
      pose.torsoX = -0.18 * up; pose.headX = -0.3 * up;
      pose.armLX = -0.22 * up; pose.armRX = -0.22 * up;
      pose.armLZ = 0.08 + 2.45 * up; pose.armRZ = -pose.armLZ;
      pose.armLEl = 0.1; pose.armREl = 0.1;
      pose.legLX = -b * 0.35; pose.legRX = -b * 0.35; pose.legLK = 0.1 + b * 0.5; pose.legRK = 0.1 + b * 0.5;
    }},
    // 4 · HIGH CLASP (duo) — runs to a teammate; each raises the near arm and they clasp hands overhead
    { name: 'HIGH CLASP', duo: true, hands: ['RightHand', 'RightHand'], dist: 0.62, lat: 0.36, run: (pose, p, t) => {
      const up = E(0, 0.45, t), sw = Math.sin(t * 5) * 0.02 * up;
      pose.armRX = 2.3 * up + (p._xAdj || 0); pose.armRZ = -(0.1 + 0.12 * up); pose.armREl = 0.45 * up;
      pose.armLX = 0.05; pose.armLZ = 0.14; pose.armLEl = 0.1;
      pose.torsoX = 0.06 * up; pose.headX = -0.12 * up;
      pose.hipY = 0.92 - 0.02 * up + Math.abs(Math.sin(t * 5.5)) * 0.04 * up;
      pose.legLZ = 0.07 * up; pose.legRZ = -0.07 * up;
    }},
    // 5 · DOUBLE HIGH-FIVE (duo) — face to face, both hands up, jump and slap palms
    { name: 'DOUBLE HIGH-FIVE', duo: true, hands: ['RightHand', 'LeftHand'], dist: 1.15, lat: 0, run: (pose, p, t) => {
      const up = E(0, 0.4, t), j = t > 0.5 ? Math.max(0, Math.sin((t - 0.5) * 6.2)) * (t < 1.5 ? 1 : 0) : 0;
      pose.armLX = 2.2 * up + (p._xAdj || 0); pose.armRX = 2.2 * up + (p._xAdj || 0);
      pose.armLZ = 0.12 * up + 0.05; pose.armRZ = -pose.armLZ; pose.armLEl = 0.3 * up; pose.armREl = 0.3 * up;
      pose.hipY = 0.92 + j * 0.22; pose.legLX = -j * 0.3; pose.legRX = -j * 0.3; pose.legLK = j * 0.7; pose.legRK = j * 0.7;
      pose.headX = -0.1 * up;
    }},
  ];
  CELEBRATIONS.length = 0;
  // test hook: UACeleb.freezeT pins the animation time (used for screenshots only)
  for (const c of NEW) { const r = c.run; c.run = (pose, p, t) => r(pose, p, (window.UACeleb && UACeleb.freezeT != null) ? UACeleb.freezeT : t); }
  for (const c of NEW) CELEBRATIONS.push(c);
  // KNEE SLIDE is the only celebration the renderer let move the root; allow any `slide` entry.
  // (player.js patched: `!p.celebration.slide`)


  /* ---------- duo celebrations: partner runs to the scorer, both strike the pose ---------- */
  let duo = null;
  function setupDuo(sc, cel) {
    duo = null; match.celPartner = null;
    let best = null, bd = 1e9;
    for (const p of players) if (p.team === sc.team && p !== sc && !p.isGK) {
      const d = Math.hypot(p.pos.x - sc.pos.x, p.pos.z - sc.pos.z); if (d < bd) { bd = d; best = p; }
    }
    if (!best) { sc.celebration = CELEBRATIONS[0]; return; }
    let ux = best.pos.x - sc.pos.x, uz = best.pos.z - sc.pos.z; const L = Math.hypot(ux, uz) || 1; ux /= L; uz /= L;
    window.UACeleb.partner = null;
    sc._xAdj = 0; best._xAdj = 0;
    duo = { sc, pt: best, cel, ux, uz, arrived: false, t0: 0, ox: 0, oz: 0 };
    match.celPartner = best;
    sc.celebration = null; best.celebration = null;
    sc.celebrate = Math.max(sc.celebrate, 4 + Math.min(4, bd / 7)); best.celebrate = sc.celebrate;
    const g = $q('gc-celeb'); if (g) g.textContent = '🎉 ' + cel.name;
  }
  function duoTarget(d) {
    const rx = -d.uz, rz = d.ux; // right-hand vector of the scorer (faces +u)
    return { x: d.sc.pos.x + d.ux * d.cel.dist + (-rx) * d.cel.lat * -1, z: d.sc.pos.z + d.uz * d.cel.dist + (-rz) * d.cel.lat * -1 };
  }
  const V1 = new THREE.Vector3(), V2 = new THREE.Vector3();
  function handOf(pl, name) {
    if (!pl._hc) pl._hc = {};
    if (pl._hc[name] === undefined) { let r = null; pl.mesh.traverse((n) => { if (!r && n.name === name && n.isBone) r = n; }); pl._hc[name] = r; }
    const h = pl._hc[name]; if (h) h.updateWorldMatrix(true, false); return h;
  }
  function face(p, yaw) { p.facing = yaw; if (p.mesh) p.mesh.rotation.y = yaw; }

  /* ---------- real knee slide: translate the scorer along the ground ---------- */
  const SLIDE_LEN = 3.6;
  function slideTick() {
    const sc = (typeof match !== 'undefined') ? match.celScorer : null;
    if (!sc || match.state !== 'goal' || !sc.celebration || sc.celebration.name !== 'KNEE SLIDE' || sc.celebrate <= 0) { if (sc) sc._slide0 = null; return; }
    if (!sc._slide0) {
      let dx = sc.vel.x, dz = sc.vel.z; const L = Math.hypot(dx, dz);
      if (L > 0.5) { dx /= L; dz /= L; } else { dx = S(sc.facing); dz = C(sc.facing); }
      // keep the slide on the pitch
      const lim = (v, m) => Math.max(-m, Math.min(m, v));
      let len = SLIDE_LEN;
      for (let i = 0; i < 8; i++) { const ex = sc.pos.x + dx * len, ez = sc.pos.z + dz * len; if (Math.abs(ex) < FIELD.halfLen + 3 && Math.abs(ez) < FIELD.halfWid + 3) break; len *= 0.7; }
      sc._slide0 = { x: sc.pos.x, z: sc.pos.z, dx, dz, len, yaw: Math.atan2(dx, dz) };
      sc.celebT = 0;
    }
    const d = sc._slide0, t = sc.celebT, k = Math.max(0, Math.min(1, t / 0.95)), e = 1 - Math.pow(1 - k, 2.2);
    sc.pos.x = d.x + d.dx * d.len * e; sc.pos.z = d.z + d.dz * d.len * e;
    sc.vel.set(0, 0, 0); face(sc, d.yaw);
  }
  function duoTick() {
    requestAnimationFrame(duoTick);
    slideTick();
    const d = duo; if (!d) return;
    if (match.state !== 'goal' || !d.sc.celebrate || d.sc.celebrate <= 0) { duo = null; match.celPartner = null; return; }
    const p = d.pt, sc = d.sc, yaw = Math.atan2(d.ux, d.uz);
    if (!d.arrived) {
      const T = duoTarget(d), dx = T.x - p.pos.x, dz = T.z - p.pos.z, dist = Math.hypot(dx, dz);
      if (dist < 0.3) {
        d.arrived = true; p.pos.x = T.x; p.pos.z = T.z; p.vel.set(0, 0, 0);
        sc.vel.set(0, 0, 0); sc.celebration = d.cel; p.celebration = d.cel; sc.celebT = 0; p.celebT = 0;
        window.UACeleb.partner = p; d.t0 = performance.now();
      } else { const sp = Math.min(8.5, 2 + dist * 2.2); p.vel.x = dx / dist * sp; p.vel.z = dz / dist * sp; }
      // scorer turns to face the incoming partner
      face(sc, Math.atan2(p.pos.x - sc.pos.x, p.pos.z - sc.pos.z));
    } else {
      // closed loop: nudge the partner / arm heights so the two hands really meet whatever the body sizes
      const T = duoTarget(d), hA = handOf(sc, d.cel.hands[0]), hB = handOf(p, d.cel.hands[1]);
      if (hA && hB && (performance.now() - d.t0) > 450) {
        const a = hA.getWorldPosition(V1), b = hB.getWorldPosition(V2);
        const ex = b.x - a.x, ez = b.z - a.z, ey = b.y - a.y;
        d.ox = Math.max(-0.4, Math.min(0.4, d.ox - 0.3 * ex)); d.oz = Math.max(-0.4, Math.min(0.4, d.oz - 0.3 * ez));
        sc._xAdj = Math.max(-0.7, Math.min(0.7, sc._xAdj + 0.2 * ey)); p._xAdj = Math.max(-0.7, Math.min(0.7, p._xAdj - 0.2 * ey));
      }
      p.pos.x = T.x + d.ox; p.pos.z = T.z + d.oz;
      p.vel.set(0, 0, 0); sc.vel.set(0, 0, 0);
      face(sc, yaw); face(p, yaw + Math.PI);
    }
  }
  requestAnimationFrame(duoTick);

  /* ---------- 2 · favourite store ---------- */
  let fav = 'RANDOM';
  try { fav = localStorage.getItem(KEY) || 'RANDOM'; } catch (e) {}
  function setFav(n) { fav = n; try { localStorage.setItem(KEY, n); } catch (e) {} refreshFavLabels(); }
  function favCel() { return fav === 'RANDOM' ? null : CELEBRATIONS.find((c) => c.name === fav) || null; }

  /* ---------- 3 · pose → 2D preview ---------- */
  function drawPose(ctx, W, cel, t) {
    const pose = emptyPose(), fp = { _slideOffset: 0, facing: 0, pos: { x: 0, z: 0 } };
    try { cel.run(pose, fp, t); } catch (e) {}
    ctx.clearRect(0, 0, W, W);
    const s = W * 0.4, gx = W / 2 + (fp._slideOffset ? Math.min(fp._slideOffset, 3) * W * 0.04 - W * 0.06 : 0), gy = W * 0.94;
    const hipY = (pose.hipY || 0.92), hx = gx, hy = gy - hipY * s;
    const lean = (pose.torsoZ || 0), pit = Math.cos(pose.torsoX || 0);
    const shx = hx + S(lean) * 0.55 * s, shy = hy - C(lean) * 0.55 * s * (0.4 + 0.6 * pit);
    ctx.lineCap = 'round'; ctx.lineJoin = 'round';
    ctx.strokeStyle = '#e8eefc'; ctx.fillStyle = '#e8eefc';
    ctx.lineWidth = W * 0.05;
    ctx.beginPath(); ctx.moveTo(hx, hy); ctx.lineTo(shx, shy); ctx.stroke();           // torso
    const hr = W * 0.06;
    ctx.beginPath(); ctx.arc(shx + S(pose.headZ || 0) * 6, shy - hr * 1.7, hr, 0, 7); ctx.fill(); // head
    ctx.lineWidth = W * 0.035;
    const arm = (side, ax, az, el) => {
      const out = side < 0 ? az : -az;
      let dx = side * S(out), dy = -C(ax) * C(out);
      const L = Math.hypot(dx, dy) || 1; dx /= L; dy /= L;
      const ex = shx + dx * 0.3 * s, ey = shy - dy * 0.3 * s;
      const bend = (el || 0) * 0.9 * side * -1, ca = C(bend), sa = S(bend);
      const fx = ex + (dx * ca - dy * sa) * 0.3 * s, fy = ey - (dx * sa + dy * ca) * 0.3 * s;
      ctx.beginPath(); ctx.moveTo(shx, shy); ctx.lineTo(ex, ey); ctx.lineTo(fx, fy); ctx.stroke();
    };
    arm(-1, pose.armLX || 0, pose.armLZ || 0.1, pose.armLEl);
    arm(1, pose.armRX || 0, pose.armRZ || -0.1, pose.armREl);
    const leg = (side, lx, lk) => {
      const fx = hx + side * 0.13 * s + S(lx || 0) * 0.22 * s;
      const lift = Math.max(0, (lk || 0) - 0.4) * 0.3 * s + Math.max(0, S(lx || 0)) * 0.1 * s;
      const fy = Math.min(gy, hy + 0.9 * s * (1 - Math.min(0.5, Math.abs(lk || 0) * 0.3)) - lift);
      const kx = hx + side * 0.15 * s + S(lx || 0) * 0.1 * s + (lk > 0.5 ? side * 0.0 : 0), ky = (hy + fy) / 2 + (lk || 0) * 0.05 * s;
      ctx.beginPath(); ctx.moveTo(hx, hy); ctx.lineTo(kx, ky); ctx.lineTo(fx, Math.min(gy, fy + 0.0)); ctx.stroke();
    };
    leg(-1, pose.legLX, pose.legLK); leg(1, pose.legRX, pose.legRK);
    ctx.globalAlpha = 0.25; ctx.fillRect(W * 0.2, gy + 2, W * 0.6, 2); ctx.globalAlpha = 1;
  }

  /* ---------- 4 · sheet UI ---------- */
  let sheet, grid, tiles = [], mode = 'menu', raf = 0, T0 = 0;
  function css() {
    const st = document.createElement('style');
    st.textContent = `
#uacs{position:fixed;inset:0;z-index:99999;display:none;background:rgba(2,6,14,.55);backdrop-filter:blur(3px)}
#uacs.open{display:block}
#uacs .sh{position:absolute;left:50%;bottom:0;transform:translateX(-50%);width:min(680px,100%);max-height:84dvh;display:flex;flex-direction:column;background:linear-gradient(180deg,#121a2e,#0a1020);border:1px solid rgba(255,255,255,.14);border-bottom:0;border-radius:18px 18px 0 0;padding:8px 12px calc(12px + env(safe-area-inset-bottom));animation:uacsUp .22s ease-out both;font-family:inherit;color:#fff}
@keyframes uacsUp{from{transform:translate(-50%,40px);opacity:0}to{transform:translate(-50%,0);opacity:1}}
#uacs .grab{width:42px;height:4px;border-radius:3px;background:rgba(255,255,255,.25);margin:2px auto 8px}
#uacs .hd{display:flex;align-items:center;gap:8px;margin-bottom:8px}
#uacs .hd b{font-size:15px;letter-spacing:.14em;flex:1}
#uacs .hd small{color:#8a93a8;font-size:11px}
#uacs .x{border:0;background:rgba(255,255,255,.1);color:#fff;width:34px;height:34px;border-radius:50%;font-size:16px}
#uacs .gr{overflow-y:auto;-webkit-overflow-scrolling:touch;display:grid;grid-template-columns:repeat(auto-fill,minmax(92px,1fr));gap:8px;padding:2px 0 6px;overscroll-behavior:contain}
#uacs .tl{position:relative;border:1px solid rgba(255,255,255,.14);background:rgba(255,255,255,.05);border-radius:12px;padding:4px 2px 6px;color:#fff;font-weight:700;font-size:10.5px;letter-spacing:.04em;text-align:center;touch-action:manipulation;min-height:44px}
#uacs .tl{display:block;overflow:hidden}#uacs .gr{grid-auto-rows:116px}#uacs .tl{height:116px}#uacs .tl .cw{height:86px;margin-bottom:3px}#uacs .tl canvas{width:86px;height:86px;display:block;margin:0 auto}
#uacs .tl.on{background:#00e07a;color:#04150c;border-color:transparent}
#uacs .tl.on canvas{filter:invert(1) brightness(.2)}
#uacs .tl i{position:absolute;top:4px;right:6px;font-style:normal;font-size:11px}
#uacs .tl.rnd{display:flex;padding-top:0;flex-direction:column;align-items:center;justify-content:center;gap:4px;font-size:12px}
#uacs .tl.rnd span{font-size:28px}
@media (orientation:landscape) and (max-height:540px){#uacs .sh{max-height:94dvh;width:min(760px,100%)}#uacs .gr{grid-template-columns:repeat(auto-fill,minmax(84px,1fr))}}
#uacs-glow{position:fixed;inset:0;pointer-events:none;z-index:50;opacity:0;background:radial-gradient(ellipse at center,transparent 35%,var(--g,#00e07a) 140%)}
#uacs-glow.go{animation:uacsGlow 1.6s ease-out}
@keyframes uacsGlow{0%{opacity:.0}12%{opacity:.55}100%{opacity:0}}
#celeb-all{border:1px solid rgba(255,255,255,.2);background:rgba(255,255,255,.08);color:#fff;border-radius:8px;padding:6px 12px;font-size:11px;font-weight:700;letter-spacing:.06em}
.uacs-btn{width:100%;border:1px solid rgba(255,255,255,.2);background:rgba(255,255,255,.08);color:#fff;border-radius:10px;padding:10px 14px;font-weight:700;font-size:13px}`;
    document.head.appendChild(st);
  }
  function build() {
    css();
    sheet = document.createElement('div'); sheet.id = 'uacs';
    sheet.innerHTML = '<div class="sh"><div class="grab"></div><div class="hd"><b>CELEBRATIONS</b><small id="uacs-sub"></small><button class="x" type="button" aria-label="Close">✕</button></div><div class="gr"></div></div>';
    document.body.appendChild(sheet);
    grid = sheet.querySelector('.gr');
    sheet.addEventListener('click', (e) => { if (e.target === sheet || e.target.closest('.x')) close(); });
    const rnd = document.createElement('button'); rnd.type = 'button'; rnd.className = 'tl rnd'; rnd.dataset.n = 'RANDOM';
    rnd.innerHTML = '<span>🎲</span>RANDOM';
    grid.appendChild(rnd);
    for (const c of CELEBRATIONS) {
      const b = document.createElement('button'); b.type = 'button'; b.className = 'tl'; b.dataset.n = c.name;
      const cv = document.createElement('canvas'); cv.width = cv.height = 96;
      const cw=document.createElement('div'); cw.className='cw'; cw.appendChild(cv); b.appendChild(cw); b.appendChild(document.createTextNode(c.name));
      if (c.group || c.duo) { const i = document.createElement('i'); i.textContent = '👥'; b.appendChild(i); }
      grid.appendChild(b);
      tiles.push({ el: b, cv, ctx: cv.getContext('2d'), cel: c });
    }
    grid.addEventListener('click', (e) => {
      const b = e.target.closest('.tl'); if (!b) return;
      const n = b.dataset.n; setFav(n);
      try { if (typeof audio !== 'undefined') audio.ui(); } catch (er) {}
      if (mode === 'goal') applyNow(n);
      if (typeof haptic === 'function') haptic(10);
    });
  }
  function refreshFavLabels() {
    if (!grid) return;
    for (const b of grid.querySelectorAll('.tl')) b.classList.toggle('on', b.dataset.n === fav);
    const s = $q('uacs-sub'); if (s) s.textContent = fav === 'RANDOM' ? 'Random each goal' : 'Favourite: ' + fav;
    const mb = $q('uacs-open-settings'); if (mb) mb.textContent = '🎉 Goal Celebration: ' + (fav === 'RANDOM' ? 'Random' : fav);
  }
  function loop(ts) {
    if (!sheet.classList.contains('open')) { raf = 0; return; }
    const t = (ts - T0) / 1000;
    const gr = grid.getBoundingClientRect(), box = grid.getBoundingClientRect();
    for (const tl of tiles) {
      const r = tl.el.getBoundingClientRect();
      if (r.bottom < gr.top || r.top > gr.bottom) continue;          // only visible tiles animate
      drawPose(tl.ctx, 96, tl.cel, ((t + 0.3) % 2.6));
    }
    raf = requestAnimationFrame(loop);
  }
  function open(m) {
    if (!sheet) build();
    mode = m || 'menu'; refreshFavLabels();
    sheet.classList.add('open'); T0 = performance.now();
    if (!raf) raf = requestAnimationFrame(loop);
  }
  function close() { if (sheet) sheet.classList.remove('open'); }

  function applyNow(n) {
    const sc = (typeof match !== 'undefined') ? match.lastTouchPlayer : null;
    if (!sc || sc.celebrate <= 0) return;
    const cel = n === 'RANDOM' ? pickCelebration() : CELEBRATIONS.find((c) => c.name === n);
    if (!cel) return;
    sc.celebration = cel; sc.celebT = 0;
    const g = $q('gc-celeb'); if (g) g.textContent = '🎉 ' + cel.name;
    if (cel.duo) setupDuo(sc, cel); else mirrorGroup(sc, cel);
    close();
  }
  function mirrorGroup(sc, cel) {
    if (!cel.group) return;
    for (const p of players) if (p.team === sc.team && p !== sc && p.celebrate > 0) { p.celebration = cel; p.celebT = 0; }
  }

  /* ---------- 5 · hooks: goal flow, camera, effects ---------- */
  let goals = 0;
  const _onGoal = window.onGoal;
  if (typeof _onGoal === 'function') {
    window.onGoal = function (team) {
      const was = match.state === 'goal';
      const r = _onGoal.apply(this, arguments);
      if (!was && match.state === 'goal') { try { afterGoal(team); } catch (e) { console.warn('celeb+', e); } }
      return r;
    };
  }
  function afterGoal(team) {
    goals++;
    const sc = match.lastTouchPlayer && match.lastTouchPlayer.team === team ? match.lastTouchPlayer : null;
    window.UACeleb.shot = goals % 4;
    if (sc) {
      const f = favCel();
      if (f && sc.team === 0) {
        sc.celebration = f; sc.celebT = 0;
        const g = $q('gc-celeb'); if (g) g.textContent = '🎉 ' + f.name;
      }
      if (sc.celebration && sc.celebration.duo) setupDuo(sc, sc.celebration); else mirrorGroup(sc, sc.celebration);
    }
    // effects (scaled for phones)
    const col = (typeof teamDefs !== 'undefined' && teamDefs[team]) ? teamDefs[team].c1 : '#00e07a';
    const gl = $q('uacs-glow') || (() => { const d = document.createElement('div'); d.id = 'uacs-glow'; document.body.appendChild(d); return d; })();
    gl.style.setProperty('--g', col); gl.classList.remove('go'); void gl.offsetWidth; gl.classList.add('go');
    const px = sc ? sc.pos.x : 0, pz = sc ? sc.pos.z : 0;
    const k = LOW ? 0.5 : 1;
    setTimeout(() => { try { emitConfettiBurst(px, pz, Math.round(160 * k)); emitSpark(px, 1.5, pz, Math.round(30 * k)); } catch (e) {} }, 350);
    setTimeout(() => { try { emitFirework(px, pz); if (!LOW) emitFirework(px + 4, pz - 3); } catch (e) {} }, 900);
    if (!LOW) setTimeout(() => { try { emitConfettiBurst(px, pz, 120); } catch (e) {} }, 1800);
  }

  // Cinematic goal camera. Returns true if it set targets.
  function shot(f0_, dt, hMul, tp, tl, cs, age, scorer) {
    const a = cs.orbitA, ease = Math.min(1, age / 0.8), k = Math.min(1, age / 3);
    const sl = scorer && scorer.celebration && scorer.celebration.name === 'KNEE SLIDE' && scorer._slide0;
    if (sl) {   // close-up from low, ahead of the slide, so the player slides toward the lens
      const endx = sl.x + sl.dx * sl.len, endz = sl.z + sl.dz * sl.len;
      tp.set(endx + sl.dx * 2.7 - sl.dz * 0.9, 0.55 + 0.25 * Math.min(1, age / 2), endz + sl.dz * 2.7 + sl.dx * 0.9);
      tl.set(scorer.pos.x, 0.75, scorer.pos.z);
      tp.x += S(age * 1.3) * 0.04; tp.y += S(age * 1.9) * 0.03;
      return true;
    }
    let f0 = f0_; const pt = window.UACeleb.partner;
    if (pt && scorer && match.celPartner === pt) { f0 = { x: (scorer.pos.x + pt.pos.x) / 2, z: (scorer.pos.z + pt.pos.z) / 2 }; }
    const fc = scorer ? scorer.facing : 0, fx = S(fc), fz = C(fc);
    const so = scorer ? (scorer._slideOffset || 0) * 0.85 : 0;           // follow slides
    const f = { x: f0.x + fx * so, z: f0.z + fz * so };
    switch (window.UACeleb.shot) {
      case 0: { const r = 4.1 - 1.0 * k;                                 // front medium-close, slow push-in
        tp.set(f.x + fx * r, 1.25 * hMul, f.z + fz * r); tl.set(f.x, 1.1, f.z); break; }
      case 1: { const r = 4.4 - 1.2 * k;                                 // low hero, looking up
        tp.set(f.x + fx * r * 0.9 + fz * 0.8, (0.45 + 0.3 * ease) * hMul, f.z + fz * r * 0.9 - fx * 0.8); tl.set(f.x, 1.3, f.z); break; }
      case 2: { const r = 4.0;                                           // tight orbit
        tp.set(f.x + C(a * 0.9) * r, 1.35 * hMul, f.z + S(a * 0.9) * r); tl.set(f.x, 1.1, f.z); break; }
      default: { const r = 4.2;                                          // 3/4 side track
        tp.set(f.x - fz * r + fx * 1.6, 1.3 * hMul, f.z + fx * r + fz * 1.6); tl.set(f.x, 1.1, f.z); }
    }
    // cinematic handheld drift
    tp.x += S(age * 1.3) * 0.07; tp.y += S(age * 1.9 + 1) * 0.05; tp.z += C(age * 1.1) * 0.07;
    tl.y += S(age * 1.6) * 0.04;
    return true;
  }
  const fovFn = () => {
    const sc = (typeof match !== 'undefined') && match.celScorer;
    if (sc && sc.celebration && sc.celebration.name === 'KNEE SLIDE' && sc._slide0) return 38 - 6 * Math.min(1, (match.goalAge || 0) / 1.2);
    return 34 - 4 * Math.min(1, ((typeof match !== 'undefined' && match.goalAge) || 0) / 3);
  };

  /* ---------- 6 · entry points ---------- */
  function hookPicker() {
    const pk = $q('celeb-picker'); if (!pk || $q('celeb-all')) return;
    const b = document.createElement('button'); b.type = 'button'; b.id = 'celeb-all'; b.textContent = 'ALL ›';
    b.addEventListener('click', () => open('goal'));
    const sk = $q('celeb-picker-skip'); pk.insertBefore(b, sk);
  }
  function hookSettings() {
    const row = $q('set-camheight'); if (!row || $q('uacs-open-settings')) return;
    const host = row.closest('.st-row'); if (!host) return;
    const d = document.createElement('div'); d.className = 'st-row';
    d.innerHTML = '<button type="button" id="uacs-open-settings" class="uacs-btn"></button>';
    host.parentNode.insertBefore(d, host);
    d.firstChild.addEventListener('click', () => open('menu'));
    refreshFavLabels();
    if (!sheet) { build(); refreshFavLabels(); }
  }

  /* ---------- 7 · light grade / rim light ---------- */
  function grade() {
    if (typeof scene === 'undefined' || !scene || scene.userData.uaGrade) return false;
    if (!scene.children.length) return false;
    scene.userData.uaGrade = 1;
    const rim = new THREE.DirectionalLight('#9ec8ff', LOW ? 0.55 : 0.85);
    rim.position.set(35, 30, -50); rim.castShadow = false; scene.add(rim);
    const warm = new THREE.DirectionalLight('#ffd9a8', LOW ? 0.25 : 0.4);
    warm.position.set(-45, 20, 45); warm.castShadow = false; scene.add(warm);
    if (typeof renderer !== 'undefined' && renderer) renderer.toneMappingExposure = LOW ? 1.2 : 1.25;
    const cv = document.getElementById('game-canvas');
    if (cv && !LOW) cv.style.filter = 'contrast(1.07) saturate(1.14) brightness(1.02)';
    else if (cv) cv.style.filter = 'contrast(1.05) saturate(1.1)';
    return true;
  }

  window.UACeleb = { _tick: duoTick, setupDuo, _duo: () => duo, _target: duoTarget, open, close, shot: 0, shotFn: shot, fov: fovFn, fav: () => fav, setFav, drawPose, list: () => CELEBRATIONS.map((c) => c.name) };

  let tries = 0;
  const iv = setInterval(() => {
    hookPicker(); hookSettings();
    const g = grade();
    if ((g && $q('celeb-all') && $q('uacs-open-settings')) || ++tries > 120) clearInterval(iv);
  }, 500);
  document.addEventListener('click', () => { hookPicker(); hookSettings(); }, true);
})();
