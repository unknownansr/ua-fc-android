/* new_player_swap.js - match players use the new New_player.glb body.
   The old rig keeps running every existing animation (mixer clips, celebrations, Euler poses) but is hidden;
   each frame its bones' world-rotation change from bind pose is copied to the new skeleton (retargeting).
   Career player = full-detail model + saved Studio face/body shape; everyone else = low-poly build. Kits are tinted
   per team from a UV mask built from the mesh itself. Loaded after player.js, before game.js. */
(function () {
  'use strict';
  const MAP = ['Hips', 'Chest', 'UpperChest', 'Neck', 'Head', 'LeftShoulder', 'LeftUpperArm', 'LeftLowerArm', 'LeftHand', 'RightShoulder', 'RightUpperArm', 'RightLowerArm', 'RightHand',
    'LeftUpperLeg', 'LeftLowerLeg', 'LeftFoot', 'LeftToes', 'RightUpperLeg', 'RightLowerLeg', 'RightFoot', 'RightToes'];
  const NEW_SCALE = 0.9219 / 0.9689;           // old hips height / new hips height: keeps feet on the grass
  const T = window.THREE;
  const tpl = { full: null, lod: null, mask: null, loading: null };
  const NB = new WeakMap(), P3 = new T.Vector3(), SPH = new T.Sphere(), FRU = new T.Frustum(), M4 = new T.Matrix4(), FR = {};
  const tintCache = new Map();

  function parse(buf) { return new Promise((res, rej) => new window.GLTFLoader().parse(buf, '', res, rej)); }
  function prep(gltf) {
    const root = gltf.scene; let sk = null; root.traverse((n) => { if (n.isSkinnedMesh && !sk) sk = n; });
    root.updateMatrixWorld(true);
    return { root, sk, image: sk.material.map && sk.material.map.image };
  }
  function buildMask(t) {                       // UV mask: 255 shirt, 150 shorts, 80 socks/boots, 0 other (from triangle height)
    const size = 1024, c = document.createElement('canvas'); c.width = c.height = size; const x = c.getContext('2d');
    x.fillStyle = '#000'; x.fillRect(0, 0, size, size);
    const g = t.sk.geometry, pa = g.attributes.position, ua = g.attributes.uv, ix = g.index.array, ja = g.attributes.skinIndex;
    const bones = t.sk.skeleton.bones; const headIdx = new Set(); bones.forEach((b, i) => { if (/head|neck/i.test(b.name)) headIdx.add(i); });
    x.imageSmoothingEnabled = false;
    for (let i = 0; i < ix.length; i += 3) {
      const a = ix[i], b = ix[i + 1], d = ix[i + 2];
      const y = (pa.getY(a) + pa.getY(b) + pa.getY(d)) / 3;
      if (y > 1.46) continue;
      const v = y > 1.12 ? 255 : y > 0.80 ? 150 : 80;
      x.fillStyle = x.strokeStyle = 'rgb(' + v + ',' + v + ',' + v + ')'; x.lineWidth = 1.5;
      x.beginPath(); x.moveTo(ua.getX(a) * size, ua.getY(a) * size); x.lineTo(ua.getX(b) * size, ua.getY(b) * size); x.lineTo(ua.getX(d) * size, ua.getY(d) * size); x.closePath(); x.fill(); x.stroke();
    }
    return x.getImageData(0, 0, size, size).data;
  }
  function hex(h) { h = (h || '#ffffff').replace('#', ''); if (h.length === 3) h = h.split('').map((c) => c + c).join(''); const n = parseInt(h, 16); return [(n >> 16) & 255, (n >> 8) & 255, (n >> 0) & 255]; }
  function tintTexture(team) {
    const key = (team.c1 || '#fff') + '|' + (team.c2 || '#fff'); if (tintCache.has(key)) return tintCache.get(key);
    const img = tpl.full.image, w = 1024, h = 1024, c = document.createElement('canvas'); c.width = w; c.height = h;
    const x = c.getContext('2d', { willReadFrequently: true }); x.drawImage(img, 0, 0, w, h);
    const id = x.getImageData(0, 0, w, h), d = id.data, m = tpl.mask, c1 = hex(team.c1), c2 = hex(team.c2);
    for (let i = 0; i < d.length; i += 4) {
      const r = d[i], g = d[i + 1], b = d[i + 2], mv = m[i]; if (mv < 40) continue;
      if (r > 60 && r > g * 1.6 && r > b * 1.6) {
        const k = Math.max(0.35, Math.min(1.35, r / 190)), col = mv > 200 ? c1 : c2;
        d[i] = Math.min(255, col[0] * k); d[i + 1] = Math.min(255, col[1] * k); d[i + 2] = Math.min(255, col[2] * k);
      }
    }
    x.putImageData(id, 0, 0);
    const tex = new T.CanvasTexture(c); tex.flipY = false; tex.colorSpace = T.SRGBColorSpace; tex.anisotropy = 4; tex.wrapS = tex.wrapT = T.ClampToEdgeWrapping;
    tintCache.set(key, tex); return tex;
  }
  function ensure() {
    if (tpl.loading) return tpl.loading;
    tpl.loading = (async () => {
      tpl.full = prep(await parse(window.UA_PLAYER_GLB_BUF()));
      tpl.lod = window.UA_PLAYER_LOD_BUF ? prep(await parse(window.UA_PLAYER_LOD_BUF())) : tpl.full;
      tpl.mask = buildMask(tpl.full);
      return true;
    })().catch((e) => { console.warn('new player model unavailable, keeping old mesh', e); tpl.failed = true; return false; });
    return tpl.loading;
  }

  /* hold the original template promise until the new model is parsed too */
  const origLoad = window.loadPlayerModelTemplate;
  let loadP = null;
  window.loadPlayerModelTemplate = function () { return loadP || (loadP = origLoad().then(async (t) => { await ensure(); return t; })); };

  function qChain(bone, stop, out) {            // root-space world rotation (excludes `stop`)
    out.identity(); const list = []; for (let n = bone; n && n !== stop; n = n.parent) list.push(n);
    for (let i = list.length - 1; i >= 0; i--) out.multiply(list[i].quaternion); return out;
  }
  function applyShape(bones, L) {               // Studio face + body sliders on the new skeleton
    if (!L) return;
    const sc = (b, x, y, z) => { if (b) b.scale.set(x, y, z); };
    const g = (k) => (typeof L[k] === 'number' ? L[k] : 1);
    sc(bones.Head, g('faceWidth'), g('faceHeight'), g('faceDepth')); sc(bones.headfront, g('faceMidWidth'), g('faceMidHeight'), g('faceNoseDepth'));
    sc(bones.Chest, g('bodyShoulders'), 1, g('bodyDepth') * g('bodyChest')); sc(bones.Spine, 1, g('bodyTorso'), 1); sc(bones.Hips, g('bodyWaist'), 1, 1);
    for (const s of ['Left', 'Right']) {
      sc(bones[s + 'UpperArm'], g('bodyArms'), g('bodyArmLength'), g('bodyArms')); sc(bones[s + 'LowerArm'], g('bodyForearms'), 1, g('bodyForearms'));
      sc(bones[s + 'UpperLeg'], g('bodyLegs'), g('bodyLegLength'), g('bodyLegs')); sc(bones[s + 'LowerLeg'], g('bodyCalves'), 1, g('bodyCalves'));
      sc(bones[s + 'Hand'], g('bodyHands'), g('bodyHands'), g('bodyHands')); sc(bones[s + 'Foot'], g('bodyFeet'), g('bodyFeet'), g('bodyFeet'));
    }
    sc(bones.Neck, g('bodyNeck'), g('bodyNeckLength'), g('bodyNeck'));
  }

  /* ---------- per-player random looks (seeded by name/number/role so a player always looks the same) ---------- */
  function hash(str) { let h = 2166136261; for (let i = 0; i < str.length; i++) { h ^= str.charCodeAt(i); h = Math.imul(h, 16777619); } return h >>> 0; }
  function rng(seed) { let a = seed >>> 0; return () => { a = (a + 0x6D2B79F5) >>> 0; let t = a; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }
  const pick = (r, a) => a[Math.floor(r() * a.length) % a.length];
  const wpick = (r, items) => { let t = 0; for (const i of items) t += i[1]; let x = r() * t; for (const i of items) { x -= i[1]; if (x <= 0) return i[0]; } return items[0][0]; };
  const BASE_STYLES = [['crew', 6], ['buzz', 5], ['lowFade', 7], ['sideFade', 6], ['undercut', 5], ['frenchCrop', 4], ['slickBack', 4], ['modern', 6], ['pompadour', 3], ['spiky', 3], ['curlyFade', 4], ['curlyAfro', 3], ['funky', 3], ['oneSide', 3], ['classic', 4], ['mullet', 2], ['mohawk', 1], ['bob', 1], ['ponytail', 1], ['manBun', 2], ['braid', 1], ['longWavy', 1]];
  const HAIR_COL = [['#0d0b0a', 30], ['#2b1a10', 28], ['#5a3a22', 18], ['#d8b26a', 9], ['#7a2f12', 4], ['#8f2d18', 3], ['#8d8f93', 3], ['#f1f0ea', 1]];
  const BODY_TYPES = {
    lean:     { bodyShoulders: 0.95, bodyChest: 0.95, bodyDepth: 0.95, bodyWaist: 0.93, bodyArms: 0.92, bodyForearms: 0.94, bodyLegs: 0.95, bodyCalves: 0.95, bodyNeck: 0.94, h: 1.0 },
    athletic: { bodyShoulders: 1.03, bodyChest: 1.03, bodyDepth: 1.0, bodyWaist: 0.98, bodyArms: 1.03, bodyForearms: 1.02, bodyLegs: 1.03, bodyCalves: 1.02, bodyNeck: 1.0, h: 1.0 },
    stocky:   { bodyShoulders: 1.1, bodyChest: 1.1, bodyDepth: 1.08, bodyWaist: 1.1, bodyArms: 1.12, bodyForearms: 1.08, bodyLegs: 1.1, bodyCalves: 1.06, bodyNeck: 1.1, bodyTorso: 0.98, h: 0.98 },
    tall:     { bodyShoulders: 1.0, bodyChest: 1.0, bodyWaist: 0.96, bodyLegLength: 1.05, bodyArmLength: 1.04, bodyTorso: 1.03, bodyNeckLength: 1.04, bodyArms: 0.98, bodyLegs: 0.98, h: 1.05 },
    compact:  { bodyShoulders: 1.02, bodyChest: 1.02, bodyWaist: 1.0, bodyLegLength: 0.95, bodyArmLength: 0.96, bodyTorso: 0.98, bodyLegs: 1.04, bodyCalves: 1.04, h: 0.96 },
    big:      { bodyShoulders: 1.14, bodyChest: 1.14, bodyDepth: 1.14, bodyWaist: 1.16, bodyArms: 1.16, bodyForearms: 1.1, bodyLegs: 1.14, bodyCalves: 1.08, bodyNeck: 1.14, bodyTorso: 1.0, h: 1.03 },
  };
  const ROLE_BODY = { GK: [['tall', 5], ['athletic', 4], ['big', 1]], CB: [['tall', 4], ['stocky', 4], ['big', 3], ['athletic', 3]], LB: [['lean', 4], ['athletic', 4], ['compact', 2]], RB: [['lean', 4], ['athletic', 4], ['compact', 2]],
    CDM: [['stocky', 4], ['athletic', 4], ['tall', 2], ['big', 2]], CM: [['athletic', 5], ['lean', 3], ['compact', 3]], CAM: [['lean', 4], ['compact', 4], ['athletic', 3]], LW: [['lean', 5], ['compact', 4], ['athletic', 2]], RW: [['lean', 5], ['compact', 4], ['athletic', 2]], LM: [['lean', 4], ['athletic', 4]], RM: [['lean', 4], ['athletic', 4]], ST: [['athletic', 5], ['stocky', 3], ['tall', 3], ['big', 2], ['lean', 2]], CF: [['athletic', 5], ['lean', 3], ['tall', 2]] };
  function makeLook(info, team) {
    const E = window.UAHairEngine, r = rng(hash([info && info.name, info && info.num, info && info.role, info && info.id, team && team.c1, team && team.name].join('|')));
    const look = {};
    const numbered = r() < 0.4 && E.styleKeys.length > 30;
    look.style = numbered ? pick(r, E.styleKeys.filter((k) => /^uaHair/.test(k))) : wpick(r, BASE_STYLES);
    look.color = wpick(r, HAIR_COL);
    const fk = E.facialKeys, fr = r();
    look.facial = fr < 0.6 ? 'none' : fr < 0.7 ? pick(r, ['fuzz', 'goatee', 'mustache']) : pick(r, fk.filter((k) => /^uaFace/.test(k)));
    if (look.facial !== 'none') { look.facialMatch = true; }
    const type = wpick(r, ROLE_BODY[(info && info.role) || 'CM'] || ROLE_BODY.CM), b = BODY_TYPES[type], j = () => 1 + (r() - 0.5) * 0.06;
    for (const k in b) if (k !== 'h') look[k] = b[k] * j();
    look.height = b.h * (0.97 + r() * 0.06);
    look.faceWidth = 0.94 + r() * 0.14; look.faceHeight = 0.96 + r() * 0.1; look.faceDepth = 0.97 + r() * 0.07;
    return look;
  }
  /* hair is grown one player at a time so a match never stalls on kick-off */
  const hairQueue = []; let hairBusy = false;
  function pumpHair() {
    if (hairBusy || !hairQueue.length) return; hairBusy = true;
    const job = hairQueue.shift();
    setTimeout(() => { Promise.resolve().then(job).catch((e) => console.warn('hair job failed', e)).then(() => { hairBusy = false; pumpHair(); }); }, 90);
  }

  const origBuild = window.buildPlayerModel;
  window.buildPlayerModel = function (teamArg, info) {
    const model = origBuild(teamArg, info);
    try {
      if (!tpl.full || tpl.failed) return model;
      const team = typeof teamArg === 'object' ? teamArg : (typeof teamDefs !== 'undefined' && teamDefs[teamArg]) || {};
      const career = !!(info && (info._career || info._regId === 'career-main'));
      const src = career ? tpl.full : tpl.lod;
      const root2 = window.SkeletonUtils.clone(src.root);
      const oldRoot = model.root, bonesOld = {}, bonesNew = {};
      oldRoot.traverse((n) => { if (n.isBone || n.type === 'Bone') bonesOld[n.name] = n; if (n.isSkinnedMesh) n.visible = false; });
      root2.traverse((n) => { if (n.isBone || n.type === 'Bone') bonesNew[n.name] = n; });
      let mesh = null; root2.traverse((n) => { if (n.isSkinnedMesh) mesh = n; });
      const mat = new T.MeshStandardMaterial({ map: tintTexture(team), roughness: 1, metalness: 0 });
      mesh.material = mat; mesh.castShadow = false; mesh.receiveShadow = true; mesh.frustumCulled = true;
      const L0 = career ? ((window.CareerCreate && window.CareerCreate.look && window.CareerCreate.look()) || {}).studio : null;
      const look = L0 || makeLook(info, team), hScale = (L0 ? 1 : look.height) || 1, sc = NEW_SCALE * hScale;
      root2.scale.setScalar(sc); oldRoot.add(root2);
      applyShape(bonesNew, look);
      let eng = null;
      if (window.UAHairEngine && window.UAHairEngine.create && typeof scene !== 'undefined' && typeof camera !== 'undefined') {
        eng = career ? window.UAHairEngine : window.UAHairEngine.create();
        const env = { scene, camera, renderer: typeof renderer !== 'undefined' ? renderer : null, skinned: mesh, analysis: tpl.full.sk, shareKey: 'new-player', quality: career ? 'medium' : 'match', look };
        const run = () => { if (career) eng.dispose(); const t0 = performance.now(); return eng.attach(env).then(() => { if (window.UA_HAIR_DEBUG) console.log('hair ready ms', Math.round(performance.now() - t0), look.style, look.facial); }).catch((e) => console.warn('hair unavailable', e)); };
        if (career) run(); else hairQueue.push(run), pumpHair();
      }
      const pairs = []; const tmp = new T.Quaternion(); const order = []; root2.traverse((n) => { if (MAP.includes(n.name)) order.push(n.name); });
      for (const name of order) {
        const o = bonesOld[name], n = bonesNew[name]; if (!o || !n) continue;
        pairs.push({ o, n, oBindInv: qChain(o, oldRoot, new T.Quaternion()).invert(), nBind: null });
      }
      // new bind world rotations (root2 frame) computed with the skeleton in bind pose
      for (const p of pairs) p.nBind = qChain(p.n, root2, new T.Quaternion());
      NB.set(oldRoot, { eng, sc, pairs, oldRoot, root2, hipsO: bonesOld.Hips, hipsN: bonesNew.Hips, hipsOBind: bonesOld.Hips.position.clone(), hipsNBind: bonesNew.Hips.position.clone(), q: new T.Quaternion(), w: new Map() });
    } catch (e) { console.warn('new body attach failed; keeping old mesh visible', e); model.root.traverse((n) => { if (n.isSkinnedMesh) n.visible = true; }); }
    return model;
  };

  function retargetFixed(st) {
    const W = st.w; W.clear();
    const D = new T.Quaternion(), des = new T.Quaternion(), par = new T.Quaternion();
    const worldOf = (bone) => {                  // world rotation (root2 frame) of any new bone, mapped ones already set
      if (W.has(bone)) return W.get(bone);
      const pw = bone.parent && bone.parent !== st.root2 ? worldOf(bone.parent) : new T.Quaternion();
      const r = pw.clone().multiply(bone.quaternion); W.set(bone, r); return r;
    };
    for (const p of st.pairs) {
      qChain(p.o, st.oldRoot, D); D.multiply(p.oBindInv);               // world-space change of the old bone from bind
      des.copy(D).multiply(p.nBind);                                    // same change applied to the new bind orientation
      const pb = p.n.parent; par.copy(pb && pb !== st.root2 ? worldOf(pb) : par.identity());
      p.n.quaternion.copy(par.invert().multiply(des)); W.delete(p.n);
      W.set(p.n, des.clone());
    }
    if (st.hipsO && st.hipsN) st.hipsN.position.copy(st.hipsNBind).addScaledVector(st.hipsO.position.clone().sub(st.hipsOBind), 1 / st.sc);
  }
  const origAnim = window.animatePlayer;
  window.animatePlayer = function (p, dt) {
    origAnim(p, dt);
    const st = p && p.mesh && NB.get(p.mesh); if (st) {
      retargetFixed(st);
      const e = st.eng;
      if (e && e.ready) {
        if (typeof camera !== 'undefined') e.setCamera(camera);
        let near = true;
        if (e !== window.UAHairEngine && typeof camera !== 'undefined') {                 // match players: skip hair that is far away or off screen
          st.root2.getWorldPosition(P3); const d = P3.distanceTo(camera.position);
          near = d < 70; if (near) P3.y += 1.5;
          if (near) { SPH.center.copy(P3); SPH.radius = 1.1; FRU.setFromProjectionMatrix(M4.multiplyMatrices(camera.projectionMatrix, camera.matrixWorldInverse)); near = FRU.intersectsSphere(SPH); }
        }
        e.show(near); if (near) e.tick(dt);
      }
    }
  };
  window.UANewPlayer = { makeLook, ensure, tpl, NB, retarget: retargetFixed, tintTexture, applyShape, hash, rng, NEW_SCALE, MAP };
})();
