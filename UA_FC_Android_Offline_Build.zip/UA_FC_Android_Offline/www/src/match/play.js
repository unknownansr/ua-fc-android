/* ==========================================================================
   play.js — PLAY HUB
   Opened from the main-menu PLAY tile. Tabs: Recommended · Division Rivals ·
   Career · Play with Friends. (Events were replaced by Player Career in the offline build.)

   Events / Long Events are 100% data-driven from Supabase (play_events,
   play_event_stages, play_event_rewards) and edited in UA FC MANAGER. A stage
   is a configured match (length, start score/clock, opponent, difficulty,
   rules, squad limits, objective, rewards). Results are validated and rewards
   granted server-side by the play_event_begin / play_event_submit RPCs.

   Classic (non-module) script. Load AFTER mainui.js. Exposes window.PlayHub;
   game.js / mainui.js call into it through a handful of small hooks.
   ========================================================================== */
(function () {
  'use strict';

  /* ------------------------------------------------------------------ utils */
  const el = (id) => document.getElementById(id);
  const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const col = (c, d) => (/^#[0-9a-f]{3,8}$/i.test(c || '') ? c : d);
  const int = (v, d = 0) => (Number.isFinite(+v) ? Math.trunc(+v) : d);
  const clampN = (v, a, b) => Math.max(a, Math.min(b, v));
  const cap = (s) => { s = String(s || ''); return s.charAt(0).toUpperCase() + s.slice(1); };
  const lc = (s) => String(s == null ? '' : s).trim().toLowerCase();
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const click = () => { try { audio.ui(); } catch (e) { /* audio not ready */ } };
  const say = (m) => { try { toast(m); } catch (e) { /* no toast */ } };

  const I = {
    back: '<svg viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="3.2" stroke-linecap="round" stroke-linejoin="round"><path d="M15 5l-7 7 7 7"/></svg>',
    cart: '<svg viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M2.5 3.5h3l2.4 11.2h10.2l2.2-8.4H6.6"/><circle cx="9.5" cy="19.4" r="1.6" fill="#fff"/><circle cx="17" cy="19.4" r="1.6" fill="#fff"/></svg>',
    home: '<svg viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M3.5 11.2L12 3.8l8.5 7.4"/><path d="M5.8 9.8V20h4.4v-5.6h3.6V20h4.4V9.8"/></svg>',
    clock: '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10.5" fill="#fff"/><path d="M12 6.2V12l4 2.4" stroke="#171236" stroke-width="2.6" fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg>',
    lock: '<svg viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><rect x="4.5" y="10.5" width="15" height="10" rx="2.4" fill="rgba(255,255,255,.14)"/><path d="M8 10.5V8a4 4 0 018 0v2.5"/></svg>',
    check: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3.6" stroke-linecap="round" stroke-linejoin="round" width="1.3em" height="1.3em"><path d="M5 12.5l4.6 4.6L19 7.4"/></svg>',
    trophy: '<svg class="big" viewBox="0 0 120 120"><defs><linearGradient id="phGold" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#fff2b0"/><stop offset=".55" stop-color="#ffc400"/><stop offset="1" stop-color="#b87400"/></linearGradient></defs><path d="M34 16h52v24c0 19-12 33-26 35-14-2-26-16-26-35z" fill="url(#phGold)" stroke="#7a4a00" stroke-width="3"/><path d="M34 24H17c0 21 8 31 20 35M86 24h17c0 21-8 31-20 35" fill="none" stroke="#e0a000" stroke-width="6" stroke-linecap="round"/><rect x="52" y="75" width="16" height="14" fill="#d99a00"/><rect x="37" y="89" width="46" height="13" rx="3" fill="url(#phGold)" stroke="#7a4a00" stroke-width="3"/><path d="M60 28l5.4 11 12 1.7-8.7 8.5 2 12-10.7-5.7-10.7 5.7 2-12-8.7-8.5 12-1.7z" fill="#fff" opacity=".9"/></svg>',
    bolt: '<svg class="big" viewBox="0 0 120 120"><defs><linearGradient id="phBolt" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#fff"/><stop offset="1" stop-color="#ffb3c8"/></linearGradient></defs><path d="M70 10L26 68h30l-8 42 46-62H64z" fill="url(#phBolt)" stroke="#8a0f3c" stroke-width="3" stroke-linejoin="round"/></svg>',
    friends: '<svg class="big" viewBox="0 0 120 120"><circle cx="42" cy="40" r="17" fill="#fff"/><path d="M12 98c0-20 13-31 30-31s30 11 30 31z" fill="#fff"/><circle cx="82" cy="46" r="15" fill="#c8e8ff"/><path d="M56 100c0-18 11-28 26-28s26 10 26 28z" fill="#c8e8ff"/></svg>',
    ball: '<svg viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2" stroke-linejoin="round"><circle cx="12" cy="12" r="9.5"/><path d="M12 7.4l4 2.9-1.5 4.7h-5L8 10.3z" fill="#fff"/></svg>',
  };

  /* ------------------------------------------------------------------ state */
  const TABS = [
    ['recommended', 'RECOMMENDED'],
    ['rivals', 'DIVISION RIVALS'],
    ['career', 'CAREER'],
    ['friends', 'PLAY WITH FRIENDS'],
  ];
  const TTL = 45000;
  const S = { tab: 'recommended', ev: null, sec: null, spot: null, built: false, loadedAt: 0, loading: null, error: false, ticker: null, sheet: null };
  let D = emptyData();
  let ctx = null; // active event match: { event, stage, attemptId, startedAt, saved, score, done }
  const squadCache = new Map();

  function emptyData() { return { events: [], stages: {}, sections: {}, rewards: {}, prog: {}, done: new Set(), secDone: new Set() }; }

  /* ------------------------------------------------------------------ media */
  const mediaMemo = new Map();
  function media(path) {
    if (!path) return null;
    let u = mediaMemo.get(path);
    if (!u) {
      try { u = getAssetUrl('event-media', path); } catch (e) { u = null; }
      mediaMemo.set(path, u);
    }
    return u;
  }
  const bgImg = (u) => (u ? `background-image:url('${String(u).replace(/['"<>\\]/g, (c) => '%' + c.charCodeAt(0).toString(16).toUpperCase())}');` : '');

  /* ------------------------------------------------------------------- data */
  function load(force) {
    if (S.loading) return S.loading;
    if (!force && S.loadedAt && Date.now() - S.loadedAt < TTL) return Promise.resolve();
    S.loading = (async () => {
      try {
        let evQ = sb.from('play_events').select('*');
        if (!isAdmin()) evQ = evQ.eq('is_active', true); // players only ever need published events
        const evR = await evQ.order('sort_order', { ascending: true }).order('created_at', { ascending: false });
        if (evR.error) throw evR.error;
        const nd = emptyData();
        nd.events = evR.data || [];
        const ids = nd.events.map((e) => e.id);
        if (ids.length) {
          const [stR, rwR, scR] = await Promise.all([
            sb.from('play_event_stages').select('*').in('event_id', ids).order('stage_no', { ascending: true }),
            sb.from('play_event_rewards').select('*').in('event_id', ids).order('sort_order', { ascending: true }),
            sb.from('play_event_sections').select('*').in('event_id', ids).order('sort_order', { ascending: true }),
          ]);
          if (stR.error) throw stR.error;
          if (rwR.error) throw rwR.error;
          if (scR.error) throw scR.error;
          for (const s of stR.data || []) (nd.stages[s.event_id] = nd.stages[s.event_id] || []).push(s);
          for (const s of scR.data || []) (nd.sections[s.event_id] = nd.sections[s.event_id] || []).push(s);
          for (const r of rwR.data || []) {
            const b = (nd.rewards[r.event_id] = nd.rewards[r.event_id] || { event: [], stage: {}, section: {} });
            if (r.stage_id) (b.stage[r.stage_id] = b.stage[r.stage_id] || []).push(r);
            else if (r.section_id) (b.section[r.section_id] = b.section[r.section_id] || []).push(r);
            else b.event.push(r);
          }
          if (cloudUser) {
            const [pgR, dnR, sdR] = await Promise.all([
              sb.from('play_event_progress').select('event_id,stage_id,attempts,wins,cleared').in('event_id', ids),
              sb.from('play_event_user').select('event_id').in('event_id', ids),
              sb.from('play_event_section_user').select('section_id'),
            ]);
            for (const p of (pgR.data || [])) nd.prog[p.stage_id] = p;
            for (const d of (dnR.data || [])) nd.done.add(d.event_id);
            for (const d of (sdR.data || [])) nd.secDone.add(d.section_id);
          }
        }
        D = nd;
        S.error = false;
        S.loadedAt = Date.now();
      } catch (err) {
        S.error = true;
      } finally {
        S.loading = null;
      }
    })();
    return S.loading;
  }

  const isAdmin = () => !!(cloudProfile && cloudProfile.is_admin);
  function isLive(e) {
    const n = Date.now();
    return !!e.is_active && (!e.starts_at || new Date(e.starts_at).getTime() <= n) && (!e.ends_at || new Date(e.ends_at).getTime() > n);
  }
  function visible(kind) {
    return D.events.filter((e) => (!kind || e.kind === kind) && (isLive(e) || isAdmin()));
  }
  const stagesOf = (e) => D.stages[e.id] || [];
  const evRewards = (e) => (D.rewards[e.id] ? D.rewards[e.id].event : []);
  const stRewards = (e, s) => (D.rewards[e.id] && D.rewards[e.id].stage[s.id]) || [];
  function progressOf(e) {
    const st = stagesOf(e);
    const done = st.filter((s) => D.prog[s.id] && D.prog[s.id].cleared).length;
    return { done, total: st.length };
  }
  function sectionById(id) {
    if (!id) return null;
    for (const k of Object.keys(D.sections)) { const f = D.sections[k].find((x) => x.id === id); if (f) return f; }
    return null;
  }
  function stageState(e, s) {
    const p = D.prog[s.id];
    const cleared = !!(p && p.cleared);
    const now = Date.now();
    const sec = sectionById(s.section_id);
    const future = [s.unlock_at, sec && sec.unlock_at].filter(Boolean).map((x) => new Date(x).getTime()).filter((t) => t > now);
    const timeLock = future.length > 0;
    const unlockAt = timeLock ? new Date(Math.max(...future)).toISOString() : null;
    let locked = timeLock;
    if (e.progression === 'linear' && stagesOf(e).some((x) => x.stage_no < s.stage_no && !(D.prog[x.id] && D.prog[x.id].cleared))) locked = true;
    const used = p ? p.attempts : 0;
    const left = s.attempts_limit == null ? null : Math.max(0, s.attempts_limit - used);
    const blocked = locked || left === 0 || (cleared && !s.repeatable);
    return { cleared, locked, timeLock, unlockAt, left, blocked, used, repeatable: s.repeatable };
  }

  /* ------------------------------------------------------------------ time */
  function fmtLeft(e) {
    if (!e.ends_at) return 'NO END DATE';
    const ms = new Date(e.ends_at).getTime() - Date.now();
    if (e.starts_at && new Date(e.starts_at).getTime() > Date.now()) return 'COMING SOON';
    if (ms <= 0) return 'ENDED';
    const s = Math.floor(ms / 1000);
    if (s >= 48 * 3600) return Math.ceil(s / 86400) + ' Days';
    const p = (n) => String(n).padStart(2, '0');
    return `${p(Math.floor(s / 3600))}:${p(Math.floor((s % 3600) / 60))}:${p(s % 60)}`;
  }
  function startTicker() {
    stopTicker();
    S.ticker = setInterval(() => {
      if (!isOpen()) { stopTicker(); return; }
      document.querySelectorAll('#scr-play [data-end-ev]').forEach((n) => {
        const e = D.events.find((x) => x.id === n.dataset.endEv);
        if (e) n.textContent = (n.dataset.pre || '') + fmtLeft(e);
      });
      let expired = false;
      document.querySelectorAll('#scr-play [data-unl]').forEach((n) => {
        if (new Date(n.dataset.unl).getTime() <= Date.now()) expired = true;
        else n.textContent = PlayRender.fmtUnlock(n.dataset.unl);
      });
      if (expired && S.ev) renderDetail(); // a timed stage/section just unlocked
    }, 1000);
  }
  function stopTicker() { if (S.ticker) { clearInterval(S.ticker); S.ticker = null; } }

  /* ----------------------------------------------------------------- build */
  function build() {
    if (S.built) return;
    S.built = true;
    const root = el('scr-play');
    root.innerHTML = `
      <div class="ph-bg"><i></i><i></i><i></i><i></i><i></i><i></i></div>
      <div class="ph-head">
        <button class="ph-back" data-act="back" aria-label="Back">${I.back}</button>
        <div class="ph-title">PLAY</div>
        <div class="ph-head-sp"></div>
        <div class="ph-bal" id="ph-bal"></div>
        <button class="ph-ico" data-act="store" aria-label="Store">${I.cart}</button>
        <button class="ph-ico" data-act="home" aria-label="Home">${I.home}</button>
      </div>
      <div class="ph-body" id="ph-body"></div>
      <div class="ph-nav" id="ph-nav"></div>`;
    root.addEventListener('click', onClick);
    const r = document.createElement('div');
    r.id = 'ph-result';
    r.addEventListener('click', onClick);
    document.body.appendChild(r);
  }

  function open(opts) {
    build();
    opts = opts || {};
    if (opts.tab) S.tab = opts.tab;
    S.ev = opts.ev || null;
    S.sec = opts.sec || null;
    S.spot = null;
    S.sheet = null;
    match.screen = 'play';
    match.state = 'idle';
    try { voiceStopSpeaking(); } catch (e) { /* optional */ }
    showScreen('scr-play');
    renderAll();
    if (window.CareerCreate) window.CareerCreate.load().then(() => { if (isOpen()) renderAll(); });
    startTicker();
    const stale = !S.loadedAt || Date.now() - S.loadedAt > TTL;
    if (stale || opts.refresh) {
      load(true).then(() => { if (isOpen()) renderAll(); });
    }
  }
  const isOpen = () => { const r = el('scr-play'); return !!r && !r.classList.contains('hidden'); };
  function close() { stopTicker(); enterMenu(); }

  /* ---------------------------------------------------------------- render */
  function renderAll() {
    renderBal();
    renderNav();
    renderBody();
    if (S.ev) renderDetail(); else removeDetail();
  }
  function renderBal() {
    const b = el('ph-bal');
    if (!b) return;
    let c = 0, g = 0;
    try { c = coins; g = userGems; } catch (e) { /* not ready */ }
    b.innerHTML = `<div class="ph-chip">🪙 ${int(c).toLocaleString()}</div>${cloudUser ? `<div class="ph-chip">💎 ${int(g).toLocaleString()}</div>` : ''}`;
  }
  function tabHasNew(id) {
    if (id === 'rivals') return true;
    if (id === 'career') return !(window.CareerCreate && window.CareerCreate.saved());
    return false;
  }
  function renderNav() {
    el('ph-nav').innerHTML = TABS.map(([id, label]) =>
      `<button class="ph-tab ${S.tab === id ? 'on' : ''}" data-tab="${id}"><span>${label}</span>${tabHasNew(id) ? '<b class="ph-new">NEW</b>' : ''}</button>`).join('');
  }
  function setTab(id) {
    if (S.tab === id) return;
    S.tab = id;
    renderNav();
    renderBody();
  }

  function renderBody() {
    const body = el('ph-body');
    if (!body) return;
    let html = '';
    const loading = !S.loadedAt && !S.error;
    const needsData = false; // offline: no server events
    if (needsData && loading) html = `<div class="ph-empty"><div class="ph-spin"></div><span>LOADING…</span></div>`;
    else if (needsData && S.error && !D.events.length) html = `<div class="ph-empty"><b>COULDN'T LOAD EVENTS</b><span>Check your connection and try again.</span><button class="ph-go ghost" data-act="reload">RETRY</button></div>`;
    else if (S.tab === 'recommended') html = viewRecommended();
    else if (S.tab === 'rivals') html = viewRivals();
    else if (S.tab === 'career') html = viewCareer();
    else if (S.tab === 'friends') html = viewFriends();
    body.innerHTML = `<div class="ph-view" data-view="${S.tab}">${html}</div>`;
  }

  /* ---- cards */
  function timeRow(e) {
    if (e.ui && e.ui.show_timer === false) return '';
    return `<div class="ph-foot-time">${I.clock}<span data-end-ev="${esc(e.id)}">${esc(fmtLeft(e))}</span></div>`;
  }
  function eventCard(e, size, extra) {
    const a1 = col(e.accent_color, '#ff2d95'), a2 = col(e.accent_color_2, '#7c3aed'), tag = col(e.tag_color, '#e8431c');
    const bg = media(e.card_bg_path), ico = media(e.icon_path);
    const pr = progressOf(e);
    const done = D.done.has(e.id);
    const ui = e.ui || {};
    const draft = !isLive(e);
    return `<button class="ph-card ${size} ${extra || ''}" data-ev="${esc(e.id)}" style="--a1:${a1};--a2:${a2};--tag:${tag};color:${col(e.text_color, '#fff')}">
      <div class="ph-tag">${esc(e.tag_label || 'LIVE EVENT')}</div>
      ${e.is_new ? `<span class="ph-new red">${esc(ui.new_text || 'NEW')}</span>` : ''}
      <div class="ph-art" style="${bgImg(bg)}">
        ${ico ? `<img class="ph-art-ico" src="${esc(ico)}" alt="" draggable="false">` : ''}
        ${!ico && !bg ? `<div class="ph-art-title">${esc(e.title)}</div>${e.subtitle ? `<div class="ph-art-sub">${esc(e.subtitle)}</div>` : ''}` : ''}
      </div>
      <div class="ph-foot">
        ${e.subtitle && (ico || bg) ? `<div class="ph-foot-sub">${esc(e.subtitle)}</div>` : ''}
        <div class="ph-foot-title">${esc(e.title)}</div>
        ${pr.total && e.kind === 'long_event' ? `<div class="ph-prog"><b style="width:${Math.round((pr.done / pr.total) * 100)}%"></b></div>` : ''}
        ${timeRow(e)}
      </div>
      ${done ? `<div class="ph-done">${I.check} DONE</div>` : ''}
      ${draft ? `<div class="ph-ribbon">${isLive({ ...e, starts_at: null, ends_at: null }) ? 'PREVIEW' : 'DRAFT'}</div>` : ''}
    </button>`;
  }
  function h2hCard(size) {
    return `<button class="ph-card ${size}" data-act="h2h" style="--tag:#2a7de1">
      <div class="ph-tag">DIVISION RIVALS</div><span class="ph-new red">NEW</span>
      <div class="ph-art h2h">${I.trophy}<div class="ph-pill">UNRANKED</div></div>
      <div class="ph-foot"><div class="ph-foot-sub">NORMAL MATCH</div><div class="ph-foot-title">HEAD TO HEAD</div>
        <div class="ph-foot-time">${I.clock}<span>90' · 2 HALVES</span></div></div>
    </button>`;
  }
  function attackCard(size) {
    return `<button class="ph-card ${size}" data-act="locked" style="--tag:#a21caf">
      <div class="ph-tag">DIVISION RIVALS</div>
      <div class="ph-art atk">${I.bolt}</div>
      <div class="ph-foot"><div class="ph-foot-sub">QUICK-FIRE</div><div class="ph-foot-title">VS ATTACK</div><div class="ph-foot-time">${I.clock}<span>SOON</span></div></div>
      <div class="ph-lock">${I.lock}<span>LOCKED</span><small>COMING SOON</small></div>
    </button>`;
  }
  function careerCard(size, extra) {
    const sv = window.CareerCreate ? window.CareerCreate.saved() : null;
    return `<button class="ph-card ${size} ${extra || ''}" data-act="career" style="--tag:#00b8a0">
      <div class="ph-tag">PLAYER CAREER</div>${sv ? '' : '<span class="ph-new red">NEW</span>'}
      <div class="ph-art car">${window.CareerCreate ? window.CareerCreate.miniJersey(sv) : ''}${sv ? '' : '<div class="ph-pill">CREATE PLAYER</div>'}</div>
      <div class="ph-foot"><div class="ph-foot-sub">${sv ? esc(sv.name) : 'START YOUR JOURNEY'}</div><div class="ph-foot-title">${sv ? 'YOUR PLAYER' : 'BE A LEGEND'}</div>
        <div class="ph-foot-time">${I.clock}<span>${sv ? 'TAP TO EDIT' : 'TAKES 1 MINUTE'}</span></div></div>
    </button>`;
  }
  function friendsCard(size, extra) {
    return `<button class="ph-card ${size} ${extra || ''}" data-act="friends" style="--tag:#2a7de1">
      <div class="ph-tag">VS FRIENDS</div>
      <div class="ph-art fri">${I.friends}</div>
      <div class="ph-foot"><div class="ph-foot-title">QUICK MATCH</div><div class="ph-foot-sub">PLAY WITH FRIENDS</div></div>
    </button>`;
  }
  function soonCard(size) {
    return `<button class="ph-card ${size}" data-act="soon" style="--tag:#e8431c">
      <div class="ph-tag">LIVE EVENT</div>
      <div class="ph-art" style="--a1:#ff7a3d;--a2:#7c3aed"><div class="ph-art-title">NEW EVENTS</div><div class="ph-art-sub">COMING SOON</div></div>
      <div class="ph-foot"><div class="ph-foot-title">STAY TUNED</div><div class="ph-foot-time">${I.clock}<span>SOON</span></div></div>
    </button>`;
  }

  /* ---- views */
  function viewRecommended() {
    return `
      ${careerCard('lg')}
      ${h2hCard('md')}
      ${attackCard('md')}`;
  }
  function viewCareer() {
    const sv = window.CareerCreate ? window.CareerCreate.saved() : null;
    return `
      <div class="ph-rail" style="display:flex;gap:1.6vh;flex:1;justify-content:center">
        ${careerCard('rail')}
        <div class="ph-info" style="flex:0 0 38vh;justify-content:center;gap:1.6vh">
          <div class="ph-sec">PLAYER CAREER</div>
          <h2 style="font-size:4.4vh">${sv ? esc(sv.name.toUpperCase()) : 'RISE FROM NOTHING'}</h2>
          <p>${sv ? 'Your player is ready. Position, club and the road to glory come next.' : 'Create your own footballer: pick a name, age, nation and shirt number, then build a legend season by season.'}</p>
          <button class="ph-go" data-act="career">${sv ? 'EDIT PLAYER' : 'CREATE PLAYER'}</button>
        </div>
      </div>`;
  }
  function viewRivals() {
    return `
      <div class="ph-rail" style="display:flex;gap:1.6vh;flex:1;justify-content:center">
        ${h2hCard('rail')}
        ${attackCard('rail')}
        <div class="ph-info" style="flex:0 0 30vh;justify-content:center;gap:1.6vh">
          <div class="ph-sec">DIVISION</div>
          <h2 style="font-size:4.4vh">UNRANKED</h2>
          <p>Ranks, divisions and seasonal rewards are on the way. Play Head to Head now and your wins will count when ranks go live.</p>
        </div>
      </div>`;
  }
  function viewRail(kind) {
    const list = visible(kind);
    if (!list.length) {
      return `<div class="ph-empty"><b>${kind === 'event' ? 'NO LIVE EVENTS' : 'NO LONG EVENTS'}</b><span>New ${kind === 'event' ? 'events' : 'long events'} land here — check back soon.</span></div>`;
    }
    return `<div class="ph-rail" style="display:flex;gap:1.6vh;flex:1">${list.map((e) => eventCard(e, 'rail')).join('')}</div>`;
  }
  function viewFriends() {
    const code = cloudProfile && cloudProfile.friend_code ? esc(cloudProfile.friend_code) : null;
    return `
      <div class="ph-rail" style="display:flex;gap:1.6vh;flex:1;justify-content:center">
        ${friendsCard('rail')}
        <div class="ph-info" style="flex:0 0 38vh;justify-content:center;gap:1.4vh">
          <div class="ph-sec">HOW IT WORKS</div>
          <p>1 · Add a friend with their friend code.<br>2 · Challenge them from your friends list.<br>3 · Play a live match together.</p>
          ${code ? `<div class="ph-sec">YOUR FRIEND CODE</div><div class="ph-chip" style="align-self:flex-start;font-size:3.4vh;height:6.4vh;letter-spacing:.14em">${code}</div>` : `<p>Sign in to add friends and play online.</p>`}
        </div>
      </div>`;
  }

  /* ------------------------------------------------------------ event detail */

  /* big, readable reward tiles (shared renderer) */
  const playerInfo = (id) => { try { const r = typeof regById === 'function' ? regById('cloud-' + id) : null; return r ? { name: r.name, img: r.img } : null; } catch (e) { return null; } };
  function tiles(list, got) { return PlayRender.rewardsHtml(list, { media, player: playerInfo, got: !!got }); }

  /* ----------------------------------------------------- sections + event page */
  function sectionsOf(e) {
    const list = (D.sections[e.id] || []).filter((x) => x.is_visible !== false || isAdmin());
    if (list.length) return list;
    const ui = e.ui || {}; // events created before sections existed: one implicit MAIN section
    return [{ id: '__main', event_id: e.id, title: 'MAIN', layout: ui.stage_layout === 'path' ? 'path' : 'rail', bg_path: e.hero_bg_path || e.card_bg_path, bg_color_1: e.accent_color, bg_color_2: e.accent_color_2,
      bg_dim: ui.overlay == null ? 0.35 : ui.overlay, content: PlayRender.DEFAULT_CONTENT, layers: [], style: { card_theme: 'dark', frame: 'plain' }, unlock_at: null }];
  }
  function stagesIn(e, sec) {
    const all = stagesOf(e);
    if (sec.id === '__main') return all;
    const first = sectionsOf(e)[0];
    return all.filter((x) => x.section_id === sec.id || (!x.section_id && first && first.id === sec.id));
  }
  function pageData(e) {
    const secs = sectionsOf(e);
    const sec = secs.find((x) => x.id === S.sec) || secs[0];
    const stages = stagesIn(e, sec);
    const all = D.rewards[e.id] || { event: [], stage: {}, section: {} };
    const pr = progressOf(e);
    return {
      event: e, sections: secs, section: sec, stages,
      rewards: { stage: all.stage || {}, section: (all.section && all.section[sec.id]) || [], event: all.event || [] },
      secState: { done: stages.filter((x) => D.prog[x.id] && D.prog[x.id].cleared).length, total: stages.length, completed: D.secDone.has(sec.id) },
      evState: { done: pr.done, total: pr.total, completed: D.done.has(e.id) },
      state: (st) => stageState(e, st),
      o: { media, team: (i) => (Number.isInteger(i) && TEAMS[i] ? TEAMS[i] : null), player: playerInfo, btn: (e.ui && e.ui.button_label) || 'START', spot: S.spot, now: Date.now(), event: e },
    };
  }
  function removeDetail() {
    const d = document.querySelector('#scr-play .ph-detail');
    if (d) d.remove();
  }
  function renderDetail() {
    const e = D.events.find((x) => x.id === S.ev);
    if (!e) { if (!S.loadedAt || S.loading) return; S.ev = null; removeDetail(); return; } // still loading: keep the requested event
    const host = document.querySelector('#scr-play .ph-detail');
    let sx = 0, sy = 0;
    if (host) { const sc = host.querySelector('.pe-rail,.pe-grid,.pe-col,.pe-path'); if (sc) { sx = sc.scrollLeft; sy = sc.scrollTop; } }
    const html = PlayRender.pageHtml(pageData(e));
    let d = host;
    if (!d) { d = document.createElement('div'); d.className = 'ph-detail'; el('scr-play').appendChild(d); }
    d.innerHTML = html;
    const sc = d.querySelector('.pe-rail,.pe-grid,.pe-col,.pe-path');
    if (sc) { sc.scrollLeft = sx; sc.scrollTop = sy; }
  }
  const OBJ_SRC = PlayRender;
  const objective = (s) => OBJ_SRC.objective(s);
  function teamOf(s) {
    const t = Number.isInteger(s.opponent_team) && TEAMS[s.opponent_team] ? TEAMS[s.opponent_team] : null;
    const name = s.opponent_name || (t ? t.name : 'Random Opponent');
    return { name, c1: t ? t.c1 : '#8a7cff', c2: t ? t.c2 : '#3b2f9a', ovr: s.opponent_ovr || (t ? t.rating : null), abbr: t ? t.abbr : 'CPU' };
  }
  function conditions(s) {
    const out = [];
    out.push({ i: '⏱', t: `${s.match_minutes} min match` });
    if (s.start_minute > 0) out.push({ i: '🏁', t: `Kick-off at ${s.start_minute}'` });
    if (s.start_home_score || s.start_away_score) out.push({ i: '📊', t: `Starts ${s.start_home_score}-${s.start_away_score}` });
    out.push({ i: '🎚', t: `${(DIFFS[clampN(int(s.difficulty, 1), 0, 4)] || DIFFS[1]).name} difficulty` });
    const r = s.rules || {};
    if (r.golden_goal) out.push({ i: '⚡', t: 'Golden goal — first goal wins', hot: true });
    if (r.no_fouls) out.push({ i: '🚫', t: 'No fouls', hot: true });
    if (r.no_cards) out.push({ i: '🟨', t: 'No cards', hot: true });
    if (int(r.home_goal_value, 1) > 1) out.push({ i: '✖️', t: `Your goals count x${clampN(int(r.home_goal_value, 1), 1, 3)}`, hot: true });
    if (r.weather && r.weather !== 'clear') out.push({ i: r.weather === 'snow' ? '❄️' : '🌧', t: `${cap(r.weather)} weather` });
    if (r.tod && r.tod !== 'day') out.push({ i: r.tod === 'night' ? '🌙' : '🌇', t: `${cap(r.tod)} kick-off` });
    return out;
  }
  function squadText(sr) {
    const p = [];
    if (sr.min_ovr) p.push(`Min OVR ${sr.min_ovr}`);
    if (sr.max_ovr) p.push(`Max OVR ${sr.max_ovr}`);
    if (sr.rarities && sr.rarities.length) p.push(`Rarity: ${sr.rarities.map((x) => String(x).toUpperCase()).join(' / ')}`);
    if (sr.nations && sr.nations.length) p.push(`Nation: ${sr.nations.join(' / ')}`);
    if (sr.clubs && sr.clubs.length) p.push(`Club: ${sr.clubs.join(' / ')}`);
    return p.join(' · ');
  }
  const hasSquadRules = (sr) => !!(sr && (sr.min_ovr || sr.max_ovr || (sr.rarities && sr.rarities.length) || (sr.nations && sr.nations.length) || (sr.clubs && sr.clubs.length)));

  /* ----------------------------------------------------------------- sheet */
  function closeSheet() {
    S.sheet = null;
    document.querySelectorAll('#scr-play .ph-modal').forEach((m) => m.remove());
  }
  async function openSheet(stageId) {
    const e = D.events.find((x) => x.id === S.ev);
    const s = e && stagesOf(e).find((x) => x.id === stageId);
    if (!e || !s) return;
    S.sheet = stageId;
    const st = stageState(e, s);
    const t = teamOf(s);
    const a1 = col(e.accent_color, '#ff2d95'), a2 = col(e.accent_color_2, '#7c3aed');
    const rw = stRewards(e, s);
    const sr = s.squad_rules || {};
    const live = isLive(e);
    const attempts = s.attempts_limit == null ? 'UNLIMITED ATTEMPTS' : `${st.left} OF ${s.attempts_limit} ATTEMPTS LEFT`;
    const blockMsg = !live ? 'Event not live' : st.locked ? 'Clear the previous stage first' : st.left === 0 ? 'No attempts left' : (st.cleared && !s.repeatable) ? 'Already cleared' : '';
    const m = document.createElement('div');
    m.className = 'ph-modal';
    m.innerHTML = `
      <div class="ph-sheet" style="--a1:${a1};--a2:${a2}">
        <div class="ph-sh-head" style="${bgImg(media(s.bg_path))}">
          <div class="ph-sno">${s.stage_no}</div>
          <div><h3>${esc(s.title)}</h3>${s.description ? `<small>${esc(s.description)}</small>` : ''}</div>
          <button class="ph-x" data-act="close-sheet" aria-label="Close">×</button>
        </div>
        <div class="ph-sh-body">
          <div class="ph-sh-col">
            <div class="ph-sec">OPPONENT</div>
            <div class="ph-vs"><span class="ph-crest" style="background:linear-gradient(135deg,${t.c1},${t.c2})"></span>
              <div><b>${esc(t.name)}</b><small>${t.ovr ? 'OVR ' + ovrD(t.ovr) : 'RANDOM SQUAD'}</small></div></div>
            <div class="ph-sec">OBJECTIVE</div>
            <div class="ph-obj" style="font-size:2.6vh">${esc(objective(s))}</div>
            ${hasSquadRules(sr) ? `<div class="ph-sec">SQUAD REQUIREMENTS</div><div class="ph-sq" id="ph-sq">${esc(squadText(sr))}<br><span id="ph-sq-state">Checking your squad…</span></div>` : ''}
          </div>
          <div class="ph-sh-col">
            <div class="ph-sec">MATCH CONDITIONS</div>
            <div class="ph-rules">${conditions(s).map((c) => `<div class="ph-rule ${c.hot ? 'hot' : ''}"><i>${c.i}</i>${esc(c.t)}</div>`).join('')}</div>
            ${rw.length ? `<div class="ph-sec">REWARDS${rw.some((r) => r.grant_mode === 'every_clear') ? ' · EVERY CLEAR' : ' · FIRST CLEAR'}</div><div class="ph-rwbox">${tiles(rw, st.cleared)}</div>` : ''}
          </div>
        </div>
        <div class="ph-sh-foot">
          <small>${esc(blockMsg || attempts)}</small>
          <button class="ph-go" id="ph-go" data-act="play-stage" data-stage="${esc(s.id)}" ${blockMsg ? 'disabled' : ''}>${esc((e.ui && e.ui.button_label) || 'PLAY')}</button>
        </div>
      </div>`;
    closeSheet();
    S.sheet = stageId;
    el('scr-play').appendChild(m);
    m.addEventListener('click', (ev) => { if (ev.target === m) closeSheet(); });
    if (hasSquadRules(sr)) {
      const stat = await squadStatus(s);
      if (S.sheet !== stageId) return;
      const box = el('ph-sq'), lab = el('ph-sq-state');
      if (box && lab) {
        lab.textContent = stat.text;
        box.classList.toggle('bad', !stat.ok);
        const go = el('ph-go');
        if (go && !stat.ok) go.disabled = true;
      }
    }
  }

  /* ------------------------------------------------------------ squad rules */
  function passes(rec, sr) {
    if (sr.min_ovr && rec.ovr < sr.min_ovr) return false;
    if (sr.max_ovr && rec.ovr > sr.max_ovr) return false;
    if (sr.rarities && sr.rarities.length && !sr.rarities.map(lc).includes(lc(rec.rarity))) return false;
    if (sr.nations && sr.nations.length && !sr.nations.map(lc).includes(lc(rec.nation))) return false;
    if (sr.clubs && sr.clubs.length) {
      const club = rec._cloudRow && rec._cloudRow.team;
      if (!club || !sr.clubs.map(lc).includes(lc(club))) return false;
    }
    return true;
  }
  async function squadStatus(s) {
    const sr = s.squad_rules || {};
    if (!hasSquadRules(sr)) return { ok: true, text: '' };
    try {
      const pool = await buildHomePlayerPool();
      const eligible = pool.filter((p) => passes(p, sr));
      const distinct = new Set(eligible.map((p) => p.id)).size;
      squadCache.set(s.id, eligible);
      if (!distinct) return { ok: false, text: 'No eligible players in your club. Collect players that meet the requirements.' };
      return { ok: true, text: distinct >= 11 ? `${distinct} eligible players — you're ready.` : `${distinct} eligible player${distinct === 1 ? '' : 's'} — your XI will repeat them to fill the team.` };
    } catch (err) {
      return { ok: false, text: "Couldn't check your squad. Try again." };
    }
  }

  /* ------------------------------------------------------------- start stage */
  const ERR = {
    stage_locked: 'Clear the previous stage first.',
    no_attempts_left: 'No attempts left for this stage.',
    event_not_live: 'This event is not live right now.',
    already_cleared: 'You already cleared this stage.',
    not_authenticated: 'Sign in to play events.',
    stage_not_found: 'This stage no longer exists.',
    not_unlocked: "This stage hasn't unlocked yet.",
  };
  async function playStage(stageId) {
    let e = null, s = null;
    for (const ev of D.events) { const f = stagesOf(ev).find((x) => x.id === stageId); if (f) { e = ev; s = f; break; } }
    if (!e || !s) return;
    if (!cloudUser) { say('Sign in to play events.'); return; }
    const go = el('ph-go');
    if (go) go.disabled = true;
    const stat = await squadStatus(s);
    if (!stat.ok) { say(stat.text); if (go) go.disabled = false; return; }
    let res = null;
    try {
      const r = await sb.rpc('play_event_begin', { p_stage_id: s.id });
      if (r.error) throw r.error;
      res = r.data;
    } catch (err) {
      say("Couldn't start the match. Check your connection.");
      if (go) go.disabled = false;
      return;
    }
    if (!res || !res.ok) {
      say(ERR[res && res.error] || 'Unable to start this stage.');
      await load(true);
      if (isOpen()) renderAll();
      return;
    }
    const prev = D.prog[s.id] || { event_id: e.id, stage_id: s.id, attempts: 0, wins: 0, cleared: false };
    D.prog[s.id] = { ...prev, attempts: prev.attempts + 1 };
    ctx = { event: e, stage: s, attemptId: res.attempt_id, startedAt: Date.now(), saved: null, score: null, done: false };
    closeSheet();
    stopTicker();
    try { audio.init(); } catch (err) { /* ignore */ }
    await startMatch();
  }

  /* ------------------------------------------------- match configuration */
  function shiftTeamOvr(list, target) {
    const outfield = list.filter((p) => p.role !== 'GK');
    if (!outfield.length) return;
    const avg = outfield.reduce((a, p) => a + (p.ovr || 0), 0) / outfield.length;
    const delta = Math.round(target - avg);
    for (const p of list) {
      p.ovr = clampN((p.ovr || 0) + delta, 1, 300);
      if (p.stats) for (const k of Object.keys(p.stats)) if (p.stats[k] > 30) p.stats[k] = clampN(p.stats[k] + delta, 20, 500);
    }
  }
  async function prepareMatch() {
    if (!ctx) { restore(); match.evRules = null; return; }
    const s = ctx.stage;
    if (!ctx.saved) ctx.saved = { diff: settings.diff, halfDur: settings.halfDur, weather: settings.weather, tod: settings.tod, teamDef1: teamDefs[1] };
    const r = s.rules || {};
    settings.diff = clampN(int(s.difficulty, 1), 0, 4);
    settings.halfDur = Math.max(15, int(s.match_minutes, 6) * 30);
    if (r.weather) settings.weather = r.weather;
    if (r.tod) settings.tod = r.tod;
    match.evRules = {
      goldenGoal: !!r.golden_goal,
      noFouls: !!r.no_fouls,
      noCards: !!r.no_cards,
      homeGoalValue: clampN(int(r.home_goal_value, 1), 1, 3),
    };

    // Opponent: team / name / OVR
    const base = Number.isInteger(s.opponent_team) && TEAMS[s.opponent_team] ? TEAMS[s.opponent_team] : null;
    if (base || s.opponent_name || s.opponent_ovr) {
      const td = Object.assign({}, base || ctx.saved.teamDef1, { c1: '#ffffff', c2: '#ffffff' });
      if (s.opponent_name) { td.name = s.opponent_name; td.abbr = s.opponent_name.replace(/[^A-Za-z0-9]/g, '').slice(0, 3).toUpperCase() || td.abbr; }
      if (s.opponent_ovr) td.rating = s.opponent_ovr;
      teamDefs[1] = td;
      squads[1] = generateSquad(td);
      benches[1] = generateBench(td);
      if (REG.length) {
        const awayList = [...REG].sort(() => Math.random() - 0.5);
        applySquadFromList(squads[1], awayList);
        applySquadFromList(benches[1], awayList);
        if (squads[1][6]) squads[1][6].captain = true;
      }
      if (s.opponent_ovr) shiftTeamOvr(squads[1].concat(benches[1]), s.opponent_ovr);
    }

    // Home squad limits
    const sr = s.squad_rules || {};
    if (hasSquadRules(sr)) {
      let eligible = squadCache.get(s.id);
      if (!eligible || !eligible.length) {
        const pool = await buildHomePlayerPool();
        eligible = pool.filter((p) => passes(p, sr));
      }
      if (eligible.length) {
        squads[0] = generateSquad(teamDefs[0]);
        benches[0] = generateBench(teamDefs[0]);
        applySquadFromList(squads[0], eligible);
        applySquadFromList(benches[0], eligible);
        if (squads[0][6]) squads[0][6].captain = true;
        try { await applyLockerJerseyNumbers(); } catch (e) { /* cosmetic */ }
      }
    }
  }
  /* Called by startMatch right after the scoreboard/clock are reset. */
  function applyMatchStart() {
    if (!ctx) return;
    const s = ctx.stage;
    match.score = [Math.max(0, int(s.start_home_score)), Math.max(0, int(s.start_away_score))];
    const m = clampN(int(s.start_minute), 0, 89);
    if (m > 0) {
      const hd = settings.halfDur;
      if (m < 45) match.clock = (m / 45) * hd;
      else { match.half = 2; match.kickTeam = 1; match.possession = 1; match.clock = hd + ((m - 45) / 45) * hd; }
    }
  }
  function restore() {
    const c = ctx;
    match.evRules = null;
    if (!c || !c.saved) return;
    const sv = c.saved;
    settings.diff = sv.diff; settings.halfDur = sv.halfDur; settings.weather = sv.weather; settings.tod = sv.tod;
    if (sv.teamDef1) { teamDefs[1] = sv.teamDef1; squads[1] = generateSquad(sv.teamDef1); benches[1] = generateBench(sv.teamDef1); }
    c.saved = null;
  }
  function settingsForSave() {
    const c = ctx;
    if (!c || !c.saved) return settings;
    return Object.assign({}, settings, { diff: c.saved.diff, halfDur: c.saved.halfDur, weather: c.saved.weather, tod: c.saved.tod });
  }
  const inEvent = () => !!ctx;

  /* ---------------------------------------------------------- result flow */
  async function onFulltime(h, a) {
    if (!ctx || ctx.done) return;
    ctx.score = [h, a];
    submitFlow();
  }
  async function submitFlow() {
    const c = ctx;
    if (!c) return;
    const box = el('ph-result');
    box.innerHTML = `<div class="ph-res"><div class="ph-res-h" style="--c:#fff">FULL TIME</div><div class="ph-res-s">${c.score[0]} - ${c.score[1]}</div>
      <div class="ph-res-load"><div class="ph-spin" style="width:3.6vh;height:3.6vh;border-width:.5vh"></div>CONFIRMING RESULT…</div></div>`;
    box.classList.add('show');
    const wait = 21500 - (Date.now() - c.startedAt); // server rejects instant submits (anti-cheat floor)
    if (wait > 0) await sleep(wait);
    let res = null;
    try {
      const r = await sb.rpc('play_event_submit', { p_attempt_id: c.attemptId, p_goals_for: c.score[0], p_goals_against: c.score[1] });
      if (r.error) throw r.error;
      res = r.data;
    } catch (err) {
      res = { ok: false, error: 'network' };
    }
    if (ctx !== c) return;
    if (!res || !res.ok) {
      const msg = res && res.error === 'network' ? "Couldn't reach the server." : (ERR[res && res.error] || 'The result could not be saved.');
      box.innerHTML = `<div class="ph-res"><div class="ph-res-h" style="--c:#ffb300">FULL TIME</div><div class="ph-res-s">${c.score[0]} - ${c.score[1]}</div>
        <div class="ph-res-o">${esc(msg)}</div>
        <div class="ph-res-btns">${res && res.error === 'network' ? '<button class="ph-go" data-act="res-submit">RETRY</button>' : ''}<button class="ph-go ghost" data-act="res-back">BACK TO EVENT</button></div></div>`;
      return;
    }
    c.done = true;
    restore();
    const prev = D.prog[c.stage.id] || { event_id: c.event.id, stage_id: c.stage.id, attempts: 1, wins: 0, cleared: false };
    D.prog[c.stage.id] = { ...prev, cleared: prev.cleared || !!res.cleared, wins: prev.wins + (c.score[0] > c.score[1] ? 1 : 0) };
    if (res.event_completed) D.done.add(c.event.id);
    applyRewards((res.rewards || []).concat(res.section_rewards || [], res.event_rewards || []));
    if (res.section_completed && c.stage.section_id) D.secDone.add(c.stage.section_id);
    renderResult(c, res);
  }
  function applyRewards(list) {
    let coinSum = 0, gems = false, uap = false, player = false;
    for (const r of list) {
      if (r.type === 'coins') coinSum += int(r.amount);
      else if (r.type === 'gems') gems = true;
      else if (r.type === 'ua_points') uap = true;
      else if (r.type === 'player') player = true;
    }
    try {
      if (coinSum) { addCoins(coinSum); updateCoinUI(); }
      if (gems) refreshGemsBalance();
      if (uap) refreshUAPointsBalance();
      if (player) reservesOwnedCache = null;
    } catch (err) { /* balances re-sync on next open */ }
  }
  function nextStageOf(c) {
    const all = stagesOf(c.event);
    return all.find((x) => x.stage_no > c.stage.stage_no && !stageState(c.event, x).blocked) || null;
  }
  function renderResult(c, res) {
    const box = el('ph-result');
    const ok = !!res.cleared;
    const rw = res.rewards || [], sr = res.section_rewards || [], er = res.event_rewards || [];
    const st = stageState(c.event, c.stage);
    const next = ok ? nextStageOf(c) : null;
    const canRetry = !st.blocked || (st.cleared && c.stage.repeatable && st.left !== 0);
    const secTitle = (sectionById(c.stage.section_id) || {}).title || 'Section';
    box.innerHTML = `<div class="ph-res">
      <div class="ph-res-h" style="--c:${ok ? '#3bff8f' : '#ff5470'}">${ok ? 'STAGE CLEARED!' : 'NOT CLEARED'}</div>
      <div class="ph-res-s">${c.score[0]} - ${c.score[1]}</div>
      <div class="ph-res-o">${esc(c.stage.title)} · ${esc(objective(c.stage))}</div>
      ${rw.length ? `<div class="ph-res-rw">${tiles(rw, false)}</div>` : (ok && !res.first_clear ? '<div class="ph-res-o">Rewards for this stage were already claimed</div>' : '')}
      ${res.section_completed ? `<div class="ph-res-banner">${esc(secTitle)} COMPLETE!</div>${sr.length ? `<div class="ph-res-rw">${tiles(sr, false)}</div>` : ''}` : ''}
      ${res.event_completed ? `<div class="ph-res-banner">EVENT COMPLETE!</div>${er.length ? `<div class="ph-res-rw">${tiles(er, false)}</div>` : ''}` : ''}
      <div class="ph-res-btns">
        ${next ? '<button class="ph-go" data-act="res-next">NEXT STAGE</button>' : ''}
        ${canRetry ? `<button class="ph-go ${next ? 'ghost' : ''}" data-act="res-retry">${ok ? 'REPLAY' : 'TRY AGAIN'}</button>` : ''}
        <button class="ph-go ghost" data-act="res-back">BACK TO EVENT</button>
      </div></div>`;
    box.classList.add('show');
  }
  function hideResult() {
    const box = el('ph-result');
    if (box) { box.classList.remove('show'); }
  }
  function backToEvent(openStageId) {
    const c = ctx;
    const evId = c ? c.event.id : null;
    const tab = c && c.event.kind === 'long_event' ? 'long' : 'events';
    restore();
    ctx = null;
    hideResult();
    const fl = el('scr-full'); if (fl) fl.classList.add('hidden');
    open({ tab, ev: evId, sec: c ? c.stage.section_id : null, refresh: true });
    if (openStageId) openSheet(openStageId);
  }
  function abort() {
    // Quit mid-match: the attempt stays spent (server-side), nothing is awarded.
    const c = ctx;
    const tab = c && c.event.kind === 'long_event' ? 'long' : 'events';
    const evId = c ? c.event.id : null;
    const secId = c ? c.stage.section_id : null;
    restore();
    ctx = null;
    hideResult();
    open({ tab, ev: evId, sec: secId, refresh: true });
  }
  function retryCurrent() {
    if (!ctx) return;
    const sid = ctx.stage.id;
    restore();
    ctx = null;
    hideResult();
    playStage(sid);
  }

  /* ----------------------------------------------------------------- input */
  function onClick(ev) {
    const t = ev.target.closest('[data-act],[data-ev],[data-tab],[data-stage],[data-sec],[data-spot]');
    if (!t) return;
    const act = t.dataset.act;
    if (t.dataset.tab) { click(); setTab(t.dataset.tab); return; }
    if (t.dataset.sec) { click(); S.sec = t.dataset.sec; S.spot = null; renderDetail(); return; }
    if (t.dataset.spot != null && !act && !t.dataset.stage) { click(); S.spot = +t.dataset.spot; renderDetail(); return; }
    if (act) {
      click();
      switch (act) {
        case 'back': close(); return;
        case 'home': close(); return;
        case 'store': try { enterStore(); } catch (e) { say('Store unavailable.'); } return;
        case 'h2h': enterTeamSelect(); return;
        case 'career': if (window.CareerCreate) window.CareerCreate.open({ onClose: () => { if (isOpen()) renderAll(); } }); else say('Career is not ready yet.'); return;
        case 'friends': enterFriends(); return;
        case 'locked': say('Vs Attack is coming soon.'); return;
        case 'soon': say('New events are coming soon.'); return;
        case 'reload': S.loadedAt = 0; renderBody(); load(true).then(() => { if (isOpen()) renderAll(); }); return;
        case 'close-detail': S.ev = null; closeSheet(); removeDetail(); return;
        case 'close-sheet': closeSheet(); return;
        case 'play-stage': playStage(t.dataset.stage); return;
        case 'res-submit': submitFlow(); return;
        case 'res-back': backToEvent(); return;
        case 'res-retry': retryCurrent(); return;
        case 'res-next': { const n = ctx && nextStageOf(ctx); backToEvent(n ? n.id : null); return; }
        default: return;
      }
    }
    if (t.dataset.stage) { click(); openSheet(t.dataset.stage); return; }
    if (t.dataset.ev) { click(); S.ev = t.dataset.ev; S.sec = null; S.spot = null; renderDetail(); }
  }

  window.PlayHub = { open, close, prepareMatch, applyMatchStart, onFulltime, inEvent, abort, retryCurrent, settingsForSave, backToEvent,
    _debug: { S, get D() { return D; }, set D(v) { D = v; }, get ctx() { return ctx; }, set ctx(v) { ctx = v; }, passes, conditions, objective, load } };
})();
