/* Club Creator Studio — name, badge, colours, identity, stadium. Offline, saved in localStorage.
   Applies to TEAMS[settings.homeTeam] so kit, name and formation work everywhere. */
(function(){
  const KEY='ua_club_v1';
  const PAL=['#d40019','#ff7b00','#ffc400','#2ee37a','#0fb8a9','#6ec6ff','#1d57d6','#7209b7','#e83e8c','#ffffff','#9aa3b0','#101418'];
  const SHAPES=['shield','round','diamond','pennant'];
  const ICONS=['★','⚽','🦁','🦅','🐺','⚡','🔥','👑','🛡','🌊'];
  const IDENT=[
    {k:'poss',n:'Possession',f:'433',d:'Short passing, control'},
    {k:'counter',n:'Counter',f:'442',d:'Quick transitions'},
    {k:'press',n:'High Press',f:'4231',d:'Win it back high'},
    {k:'solid',n:'Solid',f:'442',d:'Compact and tough'}];
  const PATS=['solid','stripes','hoops','sash'];
  const DEF={name:'UA United',abbr:'UAU',shape:'shield',icon:'★',c1:'#2ee37a',c2:'#101418',gk:'#ffc400',pat:'stripes',ident:'poss',motto:'Play the game',stad:'UA Arena',cap:40000};
  let C;
  function load(){try{C=Object.assign({},DEF,JSON.parse(localStorage.getItem(KEY)||'{}'))}catch(e){C=Object.assign({},DEF)}}
  function save(){try{localStorage.setItem(KEY,JSON.stringify(C))}catch(e){}}
  load();
  const esc=s=>String(s).replace(/[&<>"]/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[m]));
  function crest(c){
    const P={shield:'M10 6h80v52c0 22-22 34-40 42C32 92 10 80 10 58z',round:'M50 6a46 46 0 1 0 .1 0z',diamond:'M50 4l44 46-44 46L6 50z',pennant:'M12 6h76v58L50 96 12 64z'}[c.shape]||'';
    return `<svg viewBox="0 0 100 100"><path d="${P}" fill="${c.c1}" stroke="${c.c2}" stroke-width="5"/><path d="${P}" fill="none" stroke="rgba(255,255,255,.25)" stroke-width="1" transform="translate(50 50) scale(.82) translate(-50 -50)"/><text x="50" y="62" text-anchor="middle" font-size="34" fill="${c.c2}" font-family="sans-serif" font-weight="800">${esc(c.icon)}</text></svg>`;
  }
  function apply(){
    try{
      const t=TEAMS[settings.homeTeam]; if(!t)return;
      const id=IDENT.find(i=>i.k===C.ident)||IDENT[0];
      Object.assign(t,{name:C.name,abbr:(C.abbr||C.name.slice(0,3)).toUpperCase().slice(0,3),c1:C.c1,c2:C.c2,gk:C.gk,pat:C.pat,form:id.f});
    }catch(e){}
    const cr=document.getElementById('hub-crest'); if(cr)cr.innerHTML=crest(C);
    const n=document.getElementById('hub-club-name'); if(n)n.textContent=C.name;
    const s=document.getElementById('hub-club-sub'); if(s)s.textContent=C.stad+' · '+Number(C.cap).toLocaleString();
  }
  let ov;
  function chips(arr,cur,attr,label){return arr.map(v=>{const val=typeof v==='object'?v.k:v;const l=label?label(v):v;return `<button class="cs-chip ${val===cur?'on':''}" data-${attr}="${esc(val)}">${esc(l)}</button>`}).join('')}
  function sw(cur,attr){return PAL.map(c=>`<button class="cs-sw ${c.toLowerCase()===String(cur).toLowerCase()?'on':''}" data-${attr}="${c}" style="background:${c}"></button>`).join('')}
  function kit(c){return `<div class="cs-kit" style="background:${c.pat==='stripes'?`repeating-linear-gradient(90deg,${c.c1} 0 9px,${c.c2} 9px 18px)`:c.pat==='hoops'?`repeating-linear-gradient(0deg,${c.c1} 0 9px,${c.c2} 9px 18px)`:c.pat==='sash'?`linear-gradient(135deg,${c.c1} 40%,${c.c2} 40% 60%,${c.c1} 60%)`:c.c1}"></div>`}
  function render(){
    const id=IDENT.find(i=>i.k===C.ident)||IDENT[0];
    ov.innerHTML=`<div class="cs-h"><button class="cs-x" data-a="close">✕</button><b>CLUB CREATOR STUDIO</b><button class="cs-save" data-a="save">SAVE</button></div>
    <div class="cs-body"><div class="cs-prev">${crest(C)}<div style="font-weight:800;font-size:16px">${esc(C.name)}</div>${kit(C)}<div style="font-size:11px;color:var(--fc-dim)">${esc(id.n)} · ${id.f.split('').join('-')}</div></div>
    <div class="cs-form">
      <div><label>Club name</label><input type="text" maxlength="22" data-f="name" value="${esc(C.name)}"></div>
      <div><label>Short name (3)</label><input type="text" maxlength="3" data-f="abbr" value="${esc(C.abbr)}"></div>
      <div><label>Badge shape</label><div class="cs-row">${chips(SHAPES,C.shape,'shape')}</div></div>
      <div><label>Badge icon</label><div class="cs-row">${chips(ICONS,C.icon,'icon')}</div></div>
      <div><label>Primary colour</label><div class="cs-row">${sw(C.c1,'c1')}</div></div>
      <div><label>Secondary colour</label><div class="cs-row">${sw(C.c2,'c2')}</div></div>
      <div><label>Goalkeeper kit</label><div class="cs-row">${sw(C.gk,'gk')}</div></div>
      <div><label>Kit pattern</label><div class="cs-row">${chips(PATS,C.pat,'pat')}</div></div>
      <div><label>Club identity</label><div class="cs-row">${chips(IDENT,C.ident,'ident',i=>i.n)}</div><div style="font-size:11px;color:var(--fc-dim);margin-top:4px">${esc(id.d)}</div></div>
      <div><label>Motto</label><input type="text" maxlength="30" data-f="motto" value="${esc(C.motto)}"></div>
      <div><label>Home stadium</label><input type="text" maxlength="26" data-f="stad" value="${esc(C.stad)}"></div>
      <div><label>Capacity</label><input type="number" min="5000" max="120000" step="1000" data-f="cap" value="${C.cap}"></div>
      <div><label>Build your squad</label><div class="cs-sq"><button data-a="royale">💎 Luck Royale</button><button data-a="market">🛒 Market</button><button data-a="club">👥 My Club</button></div></div>
    </div></div>`;
  }
  function open(){
    if(!ov){ov=document.createElement('div');ov.id='cs-ov';document.body.appendChild(ov);
      ov.addEventListener('click',e=>{
        const b=e.target.closest('button');if(!b)return;const d=b.dataset;
        if(d.a==='close'){load();close();return}
        if(d.a==='save'){save();apply();close();try{toast('Club saved')}catch(_){};return}
        if(d.a==='royale'||d.a==='market'||d.a==='club'){save();apply();close();try{({royale:enterRoyale,market:enterMarket,club:enterClub})[d.a]()}catch(_){};return}
        for(const k of ['shape','icon','c1','c2','gk','pat','ident'])if(d[k]!==undefined){C[k]=d[k];render();return}
      });
      ov.addEventListener('input',e=>{const f=e.target.dataset.f;if(!f)return;C[f]=f==='cap'?(+e.target.value||DEF.cap):e.target.value;
        const pv=ov.querySelector('.cs-prev');const nm=pv.children[1];if(nm&&f==='name')nm.textContent=C.name||' ';});
    }
    load();render();ov.classList.add('on');
  }
  function close(){ov&&ov.classList.remove('on');apply()}
  function wire(){
    const b=document.getElementById('btn-club-studio');if(b)b.addEventListener('click',()=>{try{audio.ui()}catch(e){};open()});
    const r=document.getElementById('btn-hub-royale');if(r)r.addEventListener('click',()=>{try{audio.init();audio.ui();enterRoyale()}catch(e){}});
    const cr=document.getElementById('hub-crest');if(cr)cr.addEventListener('click',open);
    apply();
  }
  const sh=window.showScreen;
  window.showScreen=function(id){const r=sh.apply(this,arguments);apply();return r};
  window.UAClub={open,close,apply,get:()=>C,crest};
  if(document.readyState!=='loading')wire();else document.addEventListener('DOMContentLoaded',wire);
})();
