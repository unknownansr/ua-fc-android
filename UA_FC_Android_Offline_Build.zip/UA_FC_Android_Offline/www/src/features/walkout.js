/* Matchday opening: tunnel run-out -> 6 s of close-ups on 5 players -> dynamic hand-over to kickoff.
   Paths stay inside the pitch apron (no wall clipping). Tap to skip. Sim is gated by match.walkout. */
(function(){
  const A_END=5.5, CU_N=5, CU_T=1.2, T_END=A_END+CU_N*CU_T;           // wide shot, then 5 x 1.2 s = 6 s of close-ups
  let W=null, banner, tunnel, pr0;
  const ease=t=>t<0?0:t>1?1:t*t*(3-2*t);
  const V=()=>new THREE.Vector3();
  function ui(){
    if(banner)return banner;
    banner=document.createElement('div');banner.id='wo-banner';
    banner.style.cssText='position:fixed;left:0;right:0;bottom:12%;z-index:50;display:none;text-align:center;pointer-events:none;font-family:var(--font);color:#fff;text-shadow:0 2px 6px #000';
    document.body.appendChild(banner);
    const sk=document.createElement('div');sk.id='wo-skip';sk.textContent='TAP TO SKIP';
    sk.style.cssText='position:fixed;right:16px;bottom:14px;z-index:51;display:none;font:700 11px var(--font);letter-spacing:.12em;color:#8a94a3';
    document.body.appendChild(sk);return banner;
  }
  function buildTunnel(z){
    const g=new THREE.Group();
    const dark=new THREE.MeshBasicMaterial({color:'#05070b'});
    const glow=new THREE.MeshBasicMaterial({color:'#bfe3ff'});
    const back=new THREE.Mesh(new THREE.PlaneGeometry(7,3.6),glow);back.position.set(0,1.8,z+3.4);back.rotation.y=Math.PI;g.add(back);
    for(const s of[-1,1]){const w=new THREE.Mesh(new THREE.BoxGeometry(.4,3.8,7),dark);w.position.set(s*3.7,1.9,z+3.2);g.add(w)}
    const roof=new THREE.Mesh(new THREE.BoxGeometry(8,.4,7),dark);roof.position.set(0,3.8,z+3.2);g.add(roof);
    const frame=new THREE.Mesh(new THREE.BoxGeometry(8,.18,.18),new THREE.MeshBasicMaterial({color:'#2ee37a'}));frame.position.set(0,3.55,z-.1);g.add(frame);
    scene.add(g);return g;
  }
  function start(){
    if(W||typeof players==='undefined'||!players.length)return;
    const zt=FIELD.halfWid+4.2;
    W={t:0,zt,items:[],shots:[],cam:V(),look:V()};
    for(const ti of[0,1]){
      const arr=players.filter(p=>p.team===ti&&!p.sentOff);
      arr.sort((a,b)=>(b.isGK?1:0)-(a.isGK?1:0)); // GKs first out
      arr.forEach((p,i)=>{
        const lane=(i&1)?1.1:-1.1, row=i>>1;
        const sx=(ti===0?-1:1)*1.6+lane*0.5, delay=row*0.28+ti*0.1;
        const fin={x:p.pos.x,z:p.pos.z,fx:p.facing,vx:0};
        const d=Math.hypot(fin.x-sx,fin.z-zt), dur=Math.max(2,d/6.2);
        W.items.push({p,fin,sx,delay,dur,arr:delay+dur});
      });
    }
    // close-up cast: 5 distinct outfield players, preferring the last to arrive, mixed teams
    const late=W.items.filter(i=>!i.p.isGK).sort((a,b)=>b.arr-a.arr).slice(0,12);
    for(let i=late.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[late[i],late[j]]=[late[j],late[i]]}
    W.shots=late.slice(0,CU_N);
    match.walkout=true;document.body.classList.add('walkout');
    try{pr0=renderer.getPixelRatio();renderer.setPixelRatio(Math.min(pr0,1.25))}catch(e){}
    tunnel=buildTunnel(zt);
    const b=ui(),h=TEAMS[settings.homeTeam],a=TEAMS[settings.awayTeam];
    b.innerHTML=`<div style="font-size:11px;letter-spacing:.3em;opacity:.8">MATCHDAY</div><div style="font-size:clamp(18px,5vh,30px);font-weight:800;letter-spacing:.06em">${h.name} <span style="opacity:.6;font-weight:600">vs</span> ${a.name}</div><div style="font-size:12px;opacity:.8;margin-top:2px">${(window.UAClub&&UAClub.get().stad)||''}</div>`;
    b.style.display='block';document.getElementById('wo-skip').style.display='block';
  }
  function end(){
    if(!W)return;
    for(const it of W.items){const p=it.p;p.pos.x=it.fin.x;p.pos.z=it.fin.z;p.facing=it.fin.fx;p.vel.set(0,0,0);p.speedRatio=0}
    if(tunnel){scene.remove(tunnel);tunnel.traverse(o=>{if(o.geometry)o.geometry.dispose()});tunnel=null}
    try{if(pr0)renderer.setPixelRatio(pr0)}catch(e){}
    // hand the current shot to the gameplay camera so it eases into the kickoff view
    try{camState.pos.copy(camera.position);}catch(e){}
    W=null;match.walkout=false;document.body.classList.remove('walkout');
    if(banner)banner.style.display='none';const sk=document.getElementById('wo-skip');if(sk)sk.style.display='none';
  }
  function tick(dt){
    W.t+=dt;
    if(W.t>A_END&&banner&&banner.style.display!=='none')banner.style.display='none';
    for(const it of W.items){
      const p=it.p,u=(W.t-it.delay)/it.dur,k=ease(u<0?0:u);
      const ox=p.pos.x,oz=p.pos.z;
      let nx,nz;
      if(u<=0){nx=it.sx;nz=W.zt}else{nx=it.sx+(it.fin.x-it.sx)*Math.min(1,u);nz=W.zt+(it.fin.z-W.zt)*Math.min(1,u)}
      // keep inside the pitch apron — never through boards/stands
      nz=Math.min(nz,W.zt);nx=Math.max(-FIELD.halfLen-2,Math.min(FIELD.halfLen+2,nx));
      const mv=u>0&&u<1;
      p.vel.set(mv?(nx-ox)/Math.max(dt,1e-3):0,0,mv?(nz-oz)/Math.max(dt,1e-3):0);
      const sp=Math.hypot(p.vel.x,p.vel.z);if(sp>7.5)p.vel.multiplyScalar(7.5/sp);
      p.pos.x=nx;p.pos.z=nz;
      try{p.updateAnimOnly(dt)}catch(e){}
      if(u>=1)p.facing=it.fin.fx;
    }
    if(W.t>T_END)end();
  }
  function shotCam(){
    const t=W.t;
    if(t<A_END){ // wide: from the far touchline, looking across at the tunnel mouth, slow rise + drift
      const k=t/A_END;
      W.cam.set(-16+k*9,2.6+k*2.2,-FIELD.halfWid+9);
      W.look.set(0+k*-3,1.5,W.zt-9);
      return 50;
    }
    const idx=Math.min(CU_N-1,Math.floor((t-A_END)/CU_T)),it=W.shots[idx],p=it.p;
    const u=((t-A_END)-idx*CU_T)/CU_T;
    let dx=p.vel.x,dz=p.vel.z,m=Math.hypot(dx,dz);
    if(m<0.8){dx=-p.pos.x;dz=-p.pos.z;m=Math.hypot(dx,dz)||1}   // idle: face the centre
    dx/=m;dz/=m;
    const dist=3.7-u*1.1;
    const cx=Math.max(-FIELD.halfLen-1,Math.min(FIELD.halfLen+1,p.pos.x+dx*dist-dz*0.9));
    const cz=Math.max(-FIELD.halfWid-1,Math.min(FIELD.halfWid+1,p.pos.z+dz*dist+dx*0.9));
    W.cam.set(cx,1.25+u*0.25,cz);
    W.look.set(p.pos.x,1.5,p.pos.z);
    return 32;
  }
  const uc=window.updateCamera;
  window.updateCamera=function(dt){
    if(W){
      tick(dt);
      if(W){
        const f=shotCam();
        camera.position.copy(W.cam);camera.lookAt(W.look);
        if(Math.abs(camera.fov-f)>0.2){camera.fov+=(f-camera.fov)*Math.min(1,dt*(W.t<A_END+0.3?2:9));camera.updateProjectionMatrix()}
        try{camState.pos.copy(camera.position);camState.look.copy(W.look)}catch(e){}
        return;
      }
    }
    return uc.apply(this,arguments);
  };
  const sm=window.startMatch;
  window.startMatch=async function(){const r=await sm.apply(this,arguments);try{if(match.screen==='match')start()}catch(e){}return r};
  window.addEventListener('pointerdown',()=>{if(W&&W.t>0.8)end()},true);
  window.UAWalkout={start,end,active:()=>!!W,seek:t=>{if(W){const d=t-W.t;if(d>0)tick(d)}},T_END,A_END};
})();
