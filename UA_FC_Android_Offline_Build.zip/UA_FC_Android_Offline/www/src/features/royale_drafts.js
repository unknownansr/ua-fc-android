/* LUCK ROYALE — 15 offline drafts generated from the local roster.
   Each draft: type, filter, three pools (A rarest .. C common), gem price from its top rating.
   Served to the game through local_backend as the `drafts` and `draft_pool_players` tables. */
(function () {
  'use strict';
  const P = (window.UA_LOCAL && window.UA_LOCAL.players) || [];
  const D = (p) => window.ovrD(p.ovr);

  // Price per pull from the best player a draft can give (display ratings 50-130).
  function priceFor(top) {
    if (top >= 130) return 500;
    if (top >= 121) return 300;
    if (top >= 116) return 240;
    if (top >= 106) return 190;
    if (top >= 96) return 150;
    if (top >= 80) return 110;
    return 80;
  }
  const pos = (...a) => (p) => a.includes(p.position);
  const topBy = (key, n) => { const s = P.slice().sort((a, b) => b[key] - a[key]).slice(0, n); const ids = new Set(s.map((p) => p.id)); return (p) => ids.has(p.id); };
  const topOvr = (n) => { const s = P.slice().sort((a, b) => b.ovr - a.ovr).slice(0, n); const ids = new Set(s.map((p) => p.id)); return (p) => ids.has(p.id); };

  const DEFS = [
    { id: 'rookie',    name: 'Rookie Rush',      type: 'STARTER',   color: ['#3a4a5e', '#1b2430'], f: (p) => p.rarity === 'bronze' || p.rarity === 'silver' },
    { id: 'gold',      name: 'Gold Standard',    type: 'GOLD',      color: ['#8a6d1d', '#2b2208'], f: (p) => p.rarity === 'gold' },
    { id: 'gloves',    name: 'Golden Gloves',    type: 'GOALKEEPER',color: ['#1f7a5a', '#0b2c21'], f: pos('GK') },
    { id: 'wall',      name: 'Iron Wall',        type: 'DEFENDER',  color: ['#34508f', '#101a33'], f: pos('CB', 'LB', 'RB') },
    { id: 'engine',    name: 'Midfield Engine',  type: 'MIDFIELD',  color: ['#2f7f8f', '#0d2a31'], f: pos('DM', 'CM') },
    { id: 'wings',     name: 'Wing Wizards',     type: 'WINGER',    color: ['#8f3f7f', '#2a1026'], f: pos('LW', 'RW') },
    { id: 'strikers',  name: 'Goal Machines',    type: 'STRIKER',   color: ['#a23b2f', '#2e100c'], f: pos('ST') },
    { id: 'maestro',   name: 'Maestro Select',   type: 'PLAYMAKER', color: ['#6a4fb0', '#1c1433'], f: (p) => (p.position === 'CAM' || p.position === 'CM') && p.passing >= 380 },
    { id: 'young',     name: 'Young Guns',       type: 'U22',       color: ['#1d8f4f', '#082b17'], f: (p) => p.age <= 22 },
    { id: 'veterans',  name: 'Veteran Legends',  type: '33+',       color: ['#7d6a4a', '#251f14'], f: (p) => p.age >= 33 },
    { id: 'pace',      name: 'Pace Demons',      type: 'SPEED',     color: ['#c4561b', '#331506'], f: topBy('pace', 50) },
    { id: 'heroes',    name: 'Heroes Rising',    type: 'HERO',      color: ['#b0346a', '#33101f'], f: (p) => p.rarity === 'hero' || (p.rarity === 'gold' && D(p) >= 96) },
    { id: 'home',      name: 'Solaris Pride',    type: 'CLUB',      color: ['#d6a21a', '#33270a'], f: (p) => p.club === 'Solaris FC' },
    { id: 'icons',     name: 'Icon Vault',       type: 'ICON',      color: ['#ffd24a', '#3a2c06'], f: (p) => p.rarity === 'icon' },
    { id: 'ultimate',  name: 'Ultimate Legends', type: 'ULTIMATE',  color: ['#ff4d6d', '#3a0b17'], f: topOvr(60) },
  ];

  const drafts = [], pool = [];
  DEFS.forEach((def, i) => {
    let list = P.filter(def.f);
    if (list.length < 6) list = P.slice().sort((a, b) => b.ovr - a.ovr).slice(0, 12);
    list.sort((a, b) => b.ovr - a.ovr);
    const n = list.length, a = Math.max(1, Math.round(n * 0.12)), b = Math.max(2, Math.round(n * 0.30));
    const top = D(list[0]);
    const price = priceFor(top);
    drafts.push({
      id: 'draft-' + def.id, name: def.name, draft_type: def.type, color_a: def.color[0], color_b: def.color[1],
      top_ovr: top, size: n, is_active: true, sort_order: i, created_at: '2026-01-' + String(30 - i).padStart(2, '0'),
      single_pull_gems: price, bundle_pull_count: 10, bundle_pull_gems: Math.round(price * 9),
      coin_bonus_per_pull: Math.round(price * 0.6), pool_a_odds: 4, pool_b_odds: 26, pool_c_odds: 70, bg_media_path: null,
    });
    list.forEach((p, k) => pool.push({ id: def.id + '-' + p.id, draft_id: 'draft-' + def.id, player_id: p.id, pool: k < a ? 'A' : k < a + b ? 'B' : 'C' }));
  });
  window.UA_DRAFTS = { drafts, pool, priceFor };
})();
