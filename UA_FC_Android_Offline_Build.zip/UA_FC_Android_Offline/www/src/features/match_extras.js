/* Phase 4: fatigue + injuries, referee AI, real-time tactics. Wraps game.js globals; no engine edits. */
(function(){
  const INJ_KEY='ua_inj_v1';
  const ld=()=>{try{return JSON.parse(localStorage.getItem(INJ_KEY)||'{}')}catch(e){return{}}};
  const sv=o=>{try{localStorage.setItem(INJ_KEY,JSON.stringify(o))}catch(e){}};
  const X={ref:{name:'',r:1,label:'Balanced'},tac:[{line:0,name:'BALANCED'},{line:0,name:'BALANCED'}],mgrT:0};
  const NAMES=['M. Rossi','A. Keller','J. Okafor','L. Duarte','S. Tanaka','P. Novak','R. Haddad','C. Moreau'];
  const PRESETS=[{k:'ATK',n:'ATTACK',line:1,drain:1.25},{k:'BAL',n:'BALANCED',line:0,drain:1},{k:'DEF',n:'DEFEND',line:-0.8,drain:0.9},{k:'PARK',n:'PARK THE BUS',line:-1.6,drain:0.8}];

  /* ---------- fatigue ---------- */
  const _ai=window.aiUpdate;
  window.aiUpdate=function(dt){
    if(match.state==='play'&&!match.paused){
      const hd=settings.halfDur||180, rate=64/hd;
      for(const p of players){
        if(p.sentOff||p.isGK)continue;
        if(p.fit==null)p.fit=100;
        const sr=Math.min(1,Math.hypot(p.vel.x,p.vel.z)/8);
        const tm=(PRESETS.find(q=>q.n===X.tac[p.team].name)||PRESETS[1]).drain;
        p.fit=Math.max(p.injured?8:12,p.fit-dt*(sr*rate*tm)+(sr<0.12?dt*1.2:0));
        const k=Math.pow(1-p.fit/100,2)*0.95;
        if(k>0.02)p.vel.multiplyScalar(Math.exp(-k*dt));
      }
      mgr(dt);
    }
    return _ai.apply(this,arguments);
  };

  /* ---------- injuries + referee ---------- */
  function injure(p){
    if(!p||p.injured||p.sentOff)return;
    p.injured=true;p.fit=Math.min(p.fit||100,25);
    try{toast('🚑 '+p.name+' IS INJURED');sayPick([p.name+' is down injured.'])}catch(e){}
    if(p.team===0){const b=ld();b[p.name]=1;sv(b)}
    setTimeout(()=>autoSub(p),2800);
  }
  function autoSub(p){
    try{
      if(!p.injured||p.sentOff||NET.mode!=='off'||match.screen!=='match')return;
      const t=p.team,bench=(benches[t]||[]).filter(b=>!b._subbedIn);
      if(subsUsed[t]>=5||!bench.length){try{toast('No subs left — '+p.name+' plays on injured')}catch(e){}return}
      const inc=bench.find(b=>b.role===p.role)||bench.find(b=>b.role!=='GK')||bench[0];
      performSubstitution(t,p,inc);inc._subbedIn=true;subsUsed[t]++;
      toast('🔄 '+inc.name+' replaces '+p.name);
    }catch(e){}
  }
  const _cf=window.commitFoul;
  window.commitFoul=function(off,vic,severe){
    const r=X.ref.r;
    if(match.state!=='play')return _cf.apply(this,arguments);
    if(r<0.85&&Math.random()<(0.85-r)*1.4){ // lenient: play on
      try{toast('Referee: play on')}catch(e){}return;
    }
    if(r>1.15&&Math.random()<(r-1.15)*1.5)off.foulsCommitted+=2; // strict: card sooner
    const inj=(severe?0.11:0.035)*(1+(100-(vic.fit==null?100:vic.fit))/120);
    const res=_cf.apply(this,arguments);
    if(Math.random()<inj)injure(vic);
    return res;
  };
  const _bc=window.bookCard;
  window.bookCard=function(p,kind){
    const r=X.ref.r;
    if(kind==='yellow'&&r<0.7&&Math.random()<0.4&&!p.sentOff)return;            // lenient waves it on
    if(kind==='red'&&p.yellowCards===0&&r<1&&Math.random()<0.5)kind='yellow';   // lenient downgrades
    return _bc.call(this,p,kind);
  };
  function newRef(){
    const r=0.55+Math.random()*0.9;
    X.ref={name:NAMES[Math.floor(Math.random()*NAMES.length)],r,label:r<0.8?'Lenient':r>1.2?'Strict':'Balanced'};
  }

  /* ---------- tactics ---------- */
  const _fw=window.formationWorldPos;
  window.formationWorldPos=function(team,fx,fz){
    const w=_fw.apply(this,arguments);
    if(match.state==='play'){
      const l=X.tac[team].line, dir=team===0?1:-1;
      w.x=Math.max(-FIELD.halfLen+3,Math.min(FIELD.halfLen-3,w.x+dir*l*8));
      w.z*=1+l*0.04;
    }
    return w;
  };
  function setTac(team,k){const pr=PRESETS.find(q=>q.k===k)||PRESETS[1];X.tac[team]={line:pr.line,name:pr.n};if(team===0)paintBar()}
  function mgr(dt){ // AI manager reacts to score and time
    X.mgrT-=dt;if(X.mgrT>0)return;X.mgrT=8;
    const f=match.clock/((settings.halfDur||180)*2),d=match.score[1]-match.score[0];
    const k=(d<0&&f>0.5)?(d<-1?'ATK':'ATK'):(d>0&&f>0.7)?'DEF':(d<0&&f>0.3)?'ATK':'BAL';
    if(X.tac[1].name!==(PRESETS.find(q=>q.k===k)).n)setTac(1,k);
  }
  let bar;
  function paintBar(){
    if(!bar){
      bar=document.createElement('div');bar.id='tac-bar';
      bar.innerHTML=PRESETS.map(p=>`<button data-k="${p.k}">${p.k}</button>`).join('');
      bar.addEventListener('pointerdown',e=>{const b=e.target.closest('button');if(!b)return;e.stopPropagation();setTac(0,b.dataset.k);try{toast('Tactic: '+X.tac[0].name)}catch(_){}});
      document.body.appendChild(bar);
    }
    bar.style.display=(match.screen==='match')?'flex':'none';
    for(const b of bar.children)b.classList.toggle('on',(PRESETS.find(q=>q.k===b.dataset.k).n)===X.tac[0].name);
  }

  /* ---------- match start / end ---------- */
  const _sm=window.startMatch;
  window.startMatch=async function(){
    const r=await _sm.apply(this,arguments);
    try{
      newRef();X.tac=[{line:0,name:'BALANCED'},{line:0,name:'BALANCED'}];X.mgrT=20;
      for(const p of players){p.fit=100;p.injured=false}
      const bans=ld(),keep={};
      for(const p of players.filter(q=>q.team===0&&!q.isGK)){
        if(bans[p.name]){
          const bench=(benches[0]||[]).filter(b=>!b._subbedIn);
          const inc=bench.find(b=>b.role===p.role)||bench.find(b=>b.role!=='GK');
          if(inc){performSubstitution(0,p,inc);inc._subbedIn=true;setTimeout(()=>{try{toast('🚑 '+p.name+' is injured — unavailable')}catch(e){}},9000)}
        }
      }
      sv(keep); paintBar();
      const iv=setInterval(()=>{if(!match.walkout){clearInterval(iv);try{toast('Referee '+X.ref.name+' · '+X.ref.label)}catch(e){}}},700);
    }catch(e){}
    return r;
  };
  setInterval(()=>{if(bar||match.screen==='match')paintBar()},1500);
  window.UAExtras=X;window.UAExtras.injure=injure;window.UAExtras.setTac=setTac;
})();
