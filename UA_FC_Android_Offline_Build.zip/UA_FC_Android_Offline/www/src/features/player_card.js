/* PLAYER CARD FACES — no images are shipped. Every player has a tiny "look recipe" (hair style + options,
   facial hair + options, face shape, skin) derived from their id; the face is captured on demand from the
   in-game 3D model (with real hair) and kept only in memory. Leaving a screen frees every captured face;
   coming back captures them again.

   Usage: put  data-pid="<player id>"  on an <img> (or any element → background-image) and it fills itself. */
(function () {
  'use strict';
  const T = window.THREE;
  const W = 160, H = 200;
  const byId = new Map(((window.UA_LOCAL && window.UA_LOCAL.players) || []).map((p) => [String(p.id), p]));
  const SILHOUETTE = 'data:image/svg+xml;utf8,' + encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 80 100"><defs><linearGradient id="g" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#fff" stop-opacity=".22"/><stop offset="1" stop-color="#fff" stop-opacity=".06"/></linearGradient></defs><circle cx="40" cy="34" r="17" fill="url(#g)"/><path d="M8 100c2-24 14-36 32-36s30 12 32 36z" fill="url(#g)"/></svg>');
  const SKINS = [['#ffffff', 26], ['#f0d9c2', 14], ['#d9b08a', 18], ['#b98563', 16], ['#a06c4c', 14], ['#7d5238', 9], ['#664030', 3]];
  const KIT = [['#1d3a8a', '#ffffff'], ['#a81019', '#ffffff'], ['#0b7a4b', '#ffd23a'], ['#f2f2f2', '#16213a'], ['#111827', '#ffc400'], ['#6a2fa0', '#ffffff'], ['#e86a10', '#101010'], ['#0aa5c4', '#ffffff']];
  const cache = new Map();            // pid -> object URL (valid until the next screen change)
  const recipes = new Map();

  /* ---------- recipe ---------- */
  function ready() { return !!(window.UAHairEngine && window.UANewPlayer && window.UANewPlayer.tpl.full); }
  function pretty(k) { return String(k).replace(/([a-z])([A-Z])/g, '$1 $2').replace(/^./, (c) => c.toUpperCase()); }
  function recipe(p) {
    if (typeof p !== 'object') p = byId.get(String(p));
    if (!p) return null;
    if (recipes.has(p.id)) return recipes.get(p.id);
    const NP = window.UANewPlayer, E = window.UAHairEngine, r = NP.rng(NP.hash('card|' + p.id + '|' + p.name));
    const base = NP.makeLook({ name: p.name, id: p.id, role: p.position === 'DM' ? 'CDM' : p.position }, { name: p.club, c1: '#223344' });
    const look = Object.assign({}, base);
    const n = (lo, hi) => lo + Math.floor(r() * (hi - lo + 1));
    // wider face variety than match players: each card gets its own face shape
    look.faceWidth = 0.88 + r() * 0.26; look.faceHeight = 0.9 + r() * 0.22; look.faceDepth = 0.95 + r() * 0.12;
    look.faceMidWidth = 0.92 + r() * 0.18; look.faceMidHeight = 0.94 + r() * 0.14; look.faceNoseDepth = 0.9 + r() * 0.26;
    look.bodyNeck = 0.92 + r() * 0.2;
    const hairLen = n(3, 8), hairVol = n(2, 9), fA = n(1, 6), fB = n(1, 6);
    const st = E && E.STYLES ? E.STYLES[look.style] : null, fs = E && E.FSTYLES ? E.FSTYLES[look.facial] : null;
    let skin = SKINS[0][0], tot = 0; for (const s of SKINS) tot += s[1]; let x = r() * tot; for (const s of SKINS) { x -= s[1]; if (x <= 0) { skin = s[0]; break; } }
    const rc = {
      id: p.id, name: p.name, look, skin, kit: KIT[NP.hash(p.club || '') % KIT.length],
      hair: { style: look.style, label: (st && st.label) || pretty(look.style), color: look.color, length: hairLen, volume: hairVol },
      facial: { style: look.facial, label: look.facial === 'none' ? 'Clean shaven' : ((fs && fs.label) || pretty(look.facial)), a: fA, b: fB },
    };
    recipes.set(p.id, rc); return rc;
  }
  function describe(p) {
    const r = recipe(p); if (!r) return '';
    const h = r.hair, f = r.facial;
    return `Name: ${r.name}\nHair: ${h.label} (length:${h.length}) (volume:${h.volume})\nFacial hair: ${f.label}${f.style === 'none' ? '' : ` (optionA:${f.a}) (optionB:${f.b})`}`;
  }
  // engine-ready look: option numbers (1-10) scale the style's own defaults
  function engineLook(rc) {
    const E = window.UAHairEngine, st = E.STYLES[rc.hair.style], d = (st && st.defaults) || {};
    const k = (v) => 0.72 + (v - 1) * 0.07;                 // 1 → 0.72 … 10 → 1.35
    const o = { style: rc.hair.style, color: rc.hair.color, facial: rc.facial.style, facialMatch: 1 };
    if (typeof d.length === 'number') o.length = d.length * k(rc.hair.length);
    if (typeof d.volume === 'number') o.volume = Math.max(0.05, Math.min(1, d.volume * k(rc.hair.volume)));
    o.facialDensity = 0.55 + rc.facial.a * 0.08; o.facialLength = 0.7 + rc.facial.b * 0.07;
    return o;
  }

  /* ---------- offscreen capture rig (created on first use) ---------- */
  let R = null, scene, cam, root2, mesh, bones, eng = null, rigP = null, matCache = new Map();
  async function rig() {
    if (rigP) return rigP;
    rigP = (async () => {
      const NP = window.UANewPlayer; await NP.ensure();
      if (!NP.tpl.full) throw new Error('model unavailable');
      R = new T.WebGLRenderer({ antialias: true, alpha: true, powerPreference: 'low-power' });
      R.setPixelRatio(1); R.setSize(W, H, false); R.setClearColor(0x000000, 0); R.outputColorSpace = T.SRGBColorSpace;
      R.toneMapping = T.ACESFilmicToneMapping; R.toneMappingExposure = 1.05;
      scene = new T.Scene();
      scene.add(new T.HemisphereLight(0xdfe8ff, 0x3a3228, 1.15));
      const key = new T.DirectionalLight(0xfff0dc, 2.3); key.position.set(1.4, 1.9, 2.6); scene.add(key);
      const rim = new T.DirectionalLight(0x9ec8ff, 1.5); rim.position.set(-2.2, 1.6, -1.8); scene.add(rim);
      cam = new T.PerspectiveCamera(26, W / H, 0.05, 20);
      root2 = window.SkeletonUtils.clone(NP.tpl.full.root);
      bones = {}; root2.traverse((n) => { if (n.isBone || n.type === 'Bone') bones[n.name] = n; if (n.isSkinnedMesh) mesh = n; });
      mesh.frustumCulled = false; mesh.material = new T.MeshStandardMaterial({ map: NP.tintTexture({ c1: '#1d3a8a', c2: '#ffffff' }), roughness: 0.85, metalness: 0 });
      root2.scale.setScalar(NP.NEW_SCALE); scene.add(root2); root2.updateMatrixWorld(true);
      eng = window.UAHairEngine.create();
      await eng.attach({ scene, camera: cam, renderer: R, skinned: mesh, analysis: NP.tpl.full.sk, shareKey: 'new-player', quality: 'medium', look: { style: 'crew', color: '#2b1a10', facial: 'none' } });
      return true;
    })();
    rigP.catch(() => { rigP = null; });
    return rigP;
  }
  function kitMaterial(rc) {
    const key = rc.kit.join('|');
    if (!matCache.has(key)) matCache.set(key, window.UANewPlayer.tintTexture({ c1: rc.kit[0], c2: rc.kit[1] }));
    return matCache.get(key);
  }
  async function capture(rc) {
    await rig();
    for (const k in bones) bones[k].scale.set(1, 1, 1);
    window.UANewPlayer.applyShape(bones, rc.look);
    root2.scale.setScalar(window.UANewPlayer.NEW_SCALE * (rc.look.height || 1));
    mesh.material.map = kitMaterial(rc); mesh.material.color.set(rc.skin); mesh.material.needsUpdate = true;
    await eng.applyLook(engineLook(rc));
    eng.show(true);
    root2.updateMatrixWorld(true);
    const hp = new T.Vector3(); (bones.Head || bones.Neck).getWorldPosition(hp);
    cam.position.set(hp.x, hp.y + 0.07, hp.z + 1.05); cam.lookAt(hp.x, hp.y + 0.05, hp.z); cam.updateMatrixWorld(true);
    if (eng.setCamera) eng.setCamera(cam);
    for (let i = 0; i < 12; i++) { root2.updateMatrixWorld(true); eng.tick(0.05); }
    R.render(scene, cam);
    const c = document.createElement('canvas'); c.width = W; c.height = H;
    c.getContext('2d').drawImage(R.domElement, 0, 0);
    const blob = await new Promise((res) => c.toBlob(res, 'image/webp', 0.86));
    c.width = c.height = 1;
    return URL.createObjectURL(blob);
  }

  /* ---------- queue + DOM hookup ---------- */
  const queue = []; let running = false;
  function setArt(el, url) {
    el.dataset.uac = 'done';
    if (el.tagName === 'IMG') { el.src = url; el.style.visibility = 'visible'; }
    else el.style.backgroundImage = `url("${url}")`;
  }
  function placeholder(el) {
    el.dataset.uac = 'pending';
    if (el.tagName === 'IMG') { el.src = SILHOUETTE; el.style.visibility = 'visible'; } else el.style.backgroundImage = `url("${SILHOUETTE}")`;
  }
  function visible(el) { return el.isConnected && el.getClientRects().length > 0; }
  async function pump() {
    if (running) return; running = true;
    while (queue.length) {
      const el = queue.shift();
      if (!el.isConnected || el.dataset.uac === 'done') continue;
      if (!visible(el)) { el.dataset.uac = ''; continue; }       // off-screen: picked up again by the next scan
      const pid = el.dataset.pid;
      try {
        let url = cache.get(pid);
        if (!url) {
          if (!ready()) { await (window.UANewPlayer && window.UANewPlayer.ensure()); if (!ready()) { await new Promise((r) => setTimeout(r, 300)); queue.push(el); continue; } }
          url = await capture(recipe(pid)); cache.set(pid, url);
        }
        // fill every card on screen showing the same player
        document.querySelectorAll('[data-pid="' + pid + '"]').forEach((e) => { if (e.dataset.uac !== 'done') setArt(e, url); });
      } catch (e) { console.warn('card capture failed', e); el.dataset.uac = 'failed'; }
      await new Promise((r) => setTimeout(r, 16));
    }
    running = false;
  }
  function want(el) {
    if (!el || !el.dataset || !el.dataset.pid) return;
    if (el.dataset.uac === 'done' || el.dataset.uac === 'pending') return;
    const url = cache.get(el.dataset.pid);
    if (url) { setArt(el, url); return; }
    placeholder(el); queue.push(el);
  }
  function scan(root) {
    (root || document).querySelectorAll('[data-pid]').forEach((el) => {
      if (el.dataset.uac === 'pending' && !queue.includes(el)) el.dataset.uac = '';
      if (visible(el)) want(el);
    });
    pump();
  }
  /* free every captured face (called when the player leaves a screen) */
  function releaseAll() {
    queue.length = 0;
    for (const u of cache.values()) URL.revokeObjectURL(u);
    cache.clear();
    document.querySelectorAll('[data-pid][data-uac]').forEach((el) => { el.dataset.uac = ''; if (el.tagName === 'IMG') el.src = SILHOUETTE; else el.style.backgroundImage = ''; });
  }
  const mo = new MutationObserver((muts) => {
    let any = false;
    for (const m of muts) for (const n of m.addedNodes) {
      if (n.nodeType !== 1) continue;
      if (n.dataset && n.dataset.pid) { want(n); any = true; }
      if (n.querySelectorAll) n.querySelectorAll('[data-pid]').forEach((e) => { want(e); any = true; });
    }
    if (any) pump();
  });
  function boot() {
    mo.observe(document.body, { childList: true, subtree: true });
    const orig = window.showScreen;
    if (typeof orig === 'function') {
      window.showScreen = function (id) {
        const r = orig.apply(this, arguments);
        releaseAll(); setTimeout(() => scan(document), 120);
        return r;
      };
    }
    scan(document);
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', () => setTimeout(boot, 0)); else setTimeout(boot, 0);

  window.UACard = { recipe, describe, scan, releaseAll, byId, SILHOUETTE, capture: (p) => capture(recipe(p)) };
})();
