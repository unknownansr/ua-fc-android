/* 3D penalty shootout on the real pitch (real players, keeper dive clips, ball). 2D canvas is only the HUD. User kicks with aim (drag) + power meter (tap to stop);
   when defending, tap a goal quadrant to dive. Runs after a drawn knockout match (or if Settings > Shootout on draw). */
(function(){
  let cv,cx,W,H,S=null,raf=0;const PL=()=>typeof players==='undefined'?[]:players;
  const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
  const rnd=()=>Math.random(), gauss=()=>(rnd()+rnd()+rnd()-1.5)*1.15;
  function takers(team){
    const all=PL().filter(p=>p.team===team&&!p.isGK&&!p.sentOff);
    all.sort((a,b)=>(b.ovr||0)-(a.ovr||0));
    const gk=PL().find(p=>p.team===team&&p.isGK);
    return {list:all.length?all:[{name:'Taker',ovr:200}],gk:gk||{name:'Keeper',ovr:200}};
  }
  const skill=p=>clamp(((p.ovr||200)-200)/88,0,1);      // raw 200..288 -> 0..1
  function begin(done){
    if(cv)return;
    const tk=[takers(0),takers(1)];
    S={tk,sc:[0,0],taken:[0,0],hist:[[],[]],turn:0,phase:'intro',t:0,done,msg:'',msgT:0,aim:{x:0,y:.5},pw:0,pwDir:1,shot:null,dive:null,over:false,skip:false};
    cv=document.createElement('canvas');cv.id='so-cv';
    cv.style.cssText='position:fixed;inset:0;width:100%;height:100%;z-index:99980;touch-action:none;background:transparent';
    document.body.appendChild(cv);
    size();addEventListener('resize',size);
    cv.addEventListener('pointerdown',pd);cv.addEventListener('pointermove',pm);cv.addEventListener('pointerup',pu);
    document.body.classList.add('walkout');document.body.classList.add('so3d');match.walkout=true;
    try{audio.whistle('short')}catch(e){}
    setup3d();next();loop(performance.now());
  }
  function size(){const r=Math.min(devicePixelRatio||1,1.5);W=cv.width=innerWidth*r;H=cv.height=innerHeight*r;cx=cv.getContext('2d');}
  function sp(x,y,z){const v=new THREE.Vector3(x,y,z).project(camera);return{x:(v.x*0.5+0.5)*W,y:(-v.y*0.5+0.5)*H}}
  function G(){const gx=FIELD.halfLen,hw=FIELD.goalW/2,a=sp(gx,0,-hw),b=sp(gx,0,hw),c=sp(gx,FIELD.goalH,0);
    const gw=Math.abs(b.x-a.x)||1,gh=Math.abs(a.y-c.y)||1;return{gw,gh,x0:Math.min(a.x,b.x),y0:c.y,cxm:(a.x+b.x)/2,yb:(a.y+b.y)/2}}
  function pt(nx,ny){return sp(FIELD.halfLen,clamp(ny,0,1.3)*FIELD.goalH,nx*FIELD.goalW/2)}
  function cur(){const t=S.turn,n=S.taken[t];return{t,tk:S.tk[t].list[n%S.tk[t].list.length],gk:S.tk[1-t].gk,human:t===0}}
  function next(){
    const c=cur();place();S.phase='aimwait';S.t=0;S.shot=null;S.dive=null;S.aim={x:0,y:.45};S.pw=0;S.pwDir=1;S.aiming=false;
    if(c.human){S.msg='YOUR PENALTY — drag to aim';}else{S.msg=c.tk.name+' steps up — tap to dive';S.phase='defwait'}
    S.msgT=99;
    if(S.skip)autoKick();
  }
  function gpos(e){const r=cv.getBoundingClientRect(),k=W/r.width;return{x:(e.clientX-r.left)*k,y:(e.clientY-r.top)*k}}
  function toN(p){const g=G();return{x:(p.x-g.cxm)/(g.gw/2),y:(g.yb-p.y)/(g.yb-g.y0)}}
  function pd(e){
    const p=gpos(e);
    if(hitSkip(p)){S.skip=true;if(S.phase==='aimwait'||S.phase==='defwait')autoKick();return}
    if(S.phase==='aimwait'){S.aiming=true;S.aim=clampAim(toN(p))}
    else if(S.phase==='power'){lockPower()}
    else if(S.phase==='defwait'){const n=toN(p);dive(n)}
  }
  function pm(e){if(S&&S.phase==='aimwait'&&S.aiming)S.aim=clampAim(toN(gpos(e)))}
  function pu(){if(S&&S.phase==='aimwait'&&S.aiming){S.aiming=false;S.phase='power';S.t=0;S.pw=0;S.msg='TAP to set power — aim for the green';}}
  const clampAim=n=>({x:clamp(n.x,-1.3,1.3),y:clamp(n.y,0,1.25)});
  function hitSkip(p){return p.x>W-110&&p.y<46}
  function lockPower(){
    const c=cur(),sk=skill(c.tk),pw=S.pw;
    const err=(0.08+Math.abs(pw-0.85)*0.55)*(1.25-sk*0.5);
    let tx=S.aim.x+gauss()*err, ty=S.aim.y+gauss()*err*0.8;
    if(pw>0.97)ty+=0.5;                       // blasted over
    if(pw<0.35){/* weak: keeper reads it */}
    S.shot={x:tx,y:ty,pw,weak:pw<0.45};
    S.dive=aiDive(S.shot,c);S.phase='fly';S.t=0;S.msg='';
  }
  function aiDive(s,c){ // keeper picks a side; better keepers guess better
    const g=skill(c.gk), col=rnd()<0.28+g*0.22?(s.x<-0.33?-1:s.x>0.33?1:0):[-1,0,1][Math.floor(rnd()*3)];
    return{col,row:rnd()<0.55?0:1};
  }
  function dive(n){ // human tap while AI shoots
    const c=cur(),sk=skill(c.tk);
    const col=n.x<-0.33?-1:n.x>0.33?1:0,row=n.y>0.5?1:0;
    const aimCol=[-1,-1,0,1,1][Math.floor(rnd()*5)],aimRow=rnd()<0.6?0:1;
    const err=0.1+(1-sk)*0.12;
    let sx=aimCol*0.72+gauss()*err, sy=(aimRow?0.78:0.22)+gauss()*err*0.7;
    const pw=0.7+rnd()*0.25;
    if(rnd()<0.05+(1-sk)*0.07)sy+=0.6;                // skied
    S.shot={x:sx,y:sy,pw,weak:false};S.dive={col,row};S.phase='fly';S.t=0;S.msg='';S.humanDive=true;
  }
  function autoKick(){
    const c=cur();
    if(c.human){S.aim={x:(rnd()*2-1)*0.8,y:0.2+rnd()*0.6};S.pw=0.8+rnd()*0.12;lockPower()}
    else dive({x:(rnd()*2-1)*0.8,y:rnd()})
  }
  function outcome(){
    const s=S.shot,d=S.dive,c=cur();
    const inside=Math.abs(s.x)<=1&&s.y>=0&&s.y<=1;
    let res='goal';
    if(!inside)res=(Math.abs(s.x)<=1.08&&s.y<=1.1&&rnd()<0.5)?'post':'miss';
    else{
      const col=s.x<-0.33?-1:s.x>0.33?1:0,row=s.y>0.5?1:0;
      const corner=Math.abs(s.x)>0.8&&s.y>0.7;
      let p=0;
      if(d.col===col){p=0.5+(d.row===row?0.28:0)-(corner?0.4:0)+(s.weak?0.22:0)+(col===0?0.1:0)}
      else p=s.weak?0.12:0.03;
      if(c.human)p-=skill(c.gk)*0.0; else p+=0; 
      if(rnd()<clamp(p,0,0.92))res='save';
    }
    return res;
  }
  function resolve(){
    const c=cur(),res=S.res0;
    S.res=res;S.phase='result';S.t=0;
    S.msg=res==='goal'?'GOAL!':res==='save'?'SAVED!':res==='post'?'OFF THE POST!':'MISSED!';S.msgT=1.6;
    if(res==='goal')S.sc[c.t]++;
    S.hist[c.t].push(res==='goal'?1:0);S.taken[c.t]++;
    try{res==='goal'?audio.whistle&&0:0;haptic(res==='goal'?60:30)}catch(e){}
  }
  function decided(){
    const [a,b]=S.sc,[ta,tb]=S.taken;
    if(ta<5||tb<5||ta!==tb){
      if(ta>=5&&tb>=5)return false;
      const ra=Math.max(0,5-ta),rb=Math.max(0,5-tb);
      if(a>b+rb)return true;if(b>a+ra)return true;
      return false;
    }
    return a!==b;
  }
  function advance(){
    if(decided()){S.over=true;S.phase='over';S.t=0;const w=S.sc[0]>S.sc[1];S.msg=(w?teamDefs[0].name:teamDefs[1].name)+' WIN '+S.sc[0]+' - '+S.sc[1]+' ON PENALTIES';S.msgT=99;return}
    S.turn=1-S.turn;next();
  }
  function finish(){
    cancelAnimationFrame(raf);removeEventListener('resize',size);cv.remove();cv=null;
    document.body.classList.remove('walkout');
    for(const o of saved){o.p.pos.x=o.x;o.p.pos.z=o.z;o.p.facing=o.f;o.p.action=null}
    camT=null;match.walkout=false;document.body.classList.remove('so3d');
    const r=S;S=null;r.done({h:r.sc[0],a:r.sc[1]});
  }
  function loop(t0){
    let last=t0;
    const f=(now)=>{
      if(!S)return;const dt=Math.min(0.05,(now-last)/1000);last=now;update(dt);draw();raf=requestAnimationFrame(f)};
    raf=requestAnimationFrame(f);
  }
  function update(dt){
    S.t+=dt;
    if(S.phase==='power'){S.pw+=S.pwDir*dt*(1.1+skillSpeed());if(S.pw>=1){S.pw=1;S.pwDir=-1}if(S.pw<=0){S.pw=0;S.pwDir=1}}
    if(S.phase==='fly'){fly3d(dt);if(S.t>1.3)resolve()}
    if(S.phase==='aimwait'||S.phase==='defwait'||S.phase==='power')idle3d(dt);
    if(S.phase==='result')result3d(dt);
    if(S.phase==='result'&&S.t>(S.skip?0.35:1.8))advance();
    if(S.phase==='over'&&(S.t>3.2||(S.skip&&S.t>1.2)))finish();
  }
  const skillSpeed=()=>0.25;
  function draw(){
    const c=cx,cu=cur();c.clearRect(0,0,W,H);
    // aim crosshair + power meter
    if(S.phase==='aimwait'||S.phase==='power'){
      const ap=pt(S.aim.x,S.aim.y);c.strokeStyle='#2ee37a';c.lineWidth=3;c.beginPath();c.arc(ap.x,ap.y,H*0.035,0,7);c.moveTo(ap.x-H*0.05,ap.y);c.lineTo(ap.x+H*0.05,ap.y);c.moveTo(ap.x,ap.y-H*0.05);c.lineTo(ap.x,ap.y+H*0.05);c.stroke();
    }
    if(S.phase==='power'){
      const bw=W*0.5,bx=W/2-bw/2,by=H*0.95;
      c.fillStyle='rgba(0,0,0,.55)';c.fillRect(bx,by-14,bw,16);
      c.fillStyle='rgba(46,227,122,.55)';c.fillRect(bx+bw*0.72,by-14,bw*0.2,16);
      c.fillStyle='#fff';c.fillRect(bx+bw*S.pw-3,by-20,6,28);
    }
    // scoreboard
    c.fillStyle='rgba(14,18,25,.92)';c.fillRect(W/2-W*0.28,0,W*0.56,H*0.12);
    c.fillStyle='#fff';c.font=`800 ${H*0.05}px sans-serif`;c.textAlign='center';
    c.fillText(`${teamDefs[0].abbr||'HOM'}  ${S.sc[0]} - ${S.sc[1]}  ${teamDefs[1].abbr||'AWY'}`,W/2,H*0.065);
    for(const t of[0,1]){for(let i=0;i<Math.max(5,S.hist[t].length);i++){const h=S.hist[t][i];c.fillStyle=h===undefined?'#444':h?'#2ee37a':'#ff5568';c.beginPath();c.arc(W/2+(t?1:-1)*W*0.09+(i-2)*H*0.03*(t?1:1)+(t?W*0.12:-W*0.12),H*0.098,H*0.01,0,7);c.fill()}}
    c.fillStyle='#8a94a3';c.font=`700 ${H*0.028}px sans-serif`;c.fillText('SKIP ▸▸',W-60,30);
    // message
    if(S.msg){c.fillStyle='#fff';c.font=`800 ${H*(S.phase==='result'?0.11:0.05)}px sans-serif`;c.shadowColor='#000';c.shadowBlur=8;
      c.fillStyle=S.phase==='result'?(S.res==='goal'?'#2ee37a':'#ff5568'):'#fff';c.fillText(S.msg,W/2,S.phase==='result'?H*0.52:H*0.17);c.shadowBlur=0}
    if(S.phase==='aimwait'||S.phase==='defwait'){c.fillStyle='#8a94a3';c.font=`600 ${H*0.03}px sans-serif`;c.fillText(cu.tk.name+(cu.human?'':' · you are the keeper'),W/2,H*0.76)}
  }

  /* ---------------- 3D layer ---------------- */
  let saved=[],camT=null,lookT=null;
  const GX=()=>FIELD.halfLen, SPOT=()=>FIELD.halfLen-11;
  const ease=t=>t<0?0:t>1?1:t*t*(3-2*t);
  function setup3d(){
    saved=players.map(p=>({p,x:p.pos.x,z:p.pos.z,f:p.facing}));
    match.state='fulltime';
    const others=players.slice();
    others.forEach((p,i)=>{const a=i/others.length*Math.PI*2;p.pos.set(Math.cos(a)*6,0,Math.sin(a)*6);p.facing=a+Math.PI;p.vel.set(0,0,0);p.speedRatio=0;p.action=null;p.hasBall=false});
    ball.owner=null;ball.vel.set(0,0,0);ball.spin.set(0,0,0);
    camT=new THREE.Vector3(SPOT()-9.5,1.9,2.6);lookT=new THREE.Vector3(GX()-3,1.0,0);
    camera.position.copy(camT);camera.lookAt(lookT);
  }
  function place(){
    const c=cur(),gk=c.gk,tk=c.tk;S.tkr=tk;S.gkp=gk;
    gk.pos.set(GX()-0.4,0,0);gk.facing=-Math.PI/2;gk.vel.set(0,0,0);gk.speedRatio=0;gk.action=null;
    tk.pos.set(SPOT()-5,0,0.9);tk.facing=Math.PI/2;tk.vel.set(0,0,0);tk.speedRatio=0;tk.action=null;
    ball.pos.set(SPOT(),PHYS.ballRadius,0);ball.vel.set(0,0,0);ball.spin.set(0,0,0);ball.mesh.position.copy(ball.pos);
    S.lastGk=gk;S.launched=false;S.flightT=0;
  }
  function anim(p,dt){try{p.updateAnimOnly(dt)}catch(e){}}
  function cam(dt,pos,look,k){
    camT.lerp(pos,1-Math.exp(-k*dt));lookT.lerp(look,1-Math.exp(-k*dt));
  }
  function idle3d(dt){
    const gk=S.gkp,tk=S.tkr;if(!gk)return;
    gk.pos.set(GX()-0.4+Math.sin(S.t*2)*0.05,0,Math.sin(S.t*1.3)*0.5);gk.speedRatio=0;anim(gk,dt);
    tk.speedRatio=0;anim(tk,dt);
    cam(dt,new THREE.Vector3(SPOT()-9.5,1.9,2.6),new THREE.Vector3(GX()-3,1.0,0),4);
  }
  function fly3d(dt){
    const tk=S.tkr,gk=S.gkp,s=S.shot,t=S.t,gx=GX(),sp=SPOT();
    // run-up 0..0.7s
    if(t<0.7){
      const k=ease(t/0.7);tk.pos.x=sp-5+k*4.1;tk.pos.z=0.9*(1-k);
      tk.vel.set(5.8,0,-1.3);tk.speedRatio=0.8;anim(tk,dt);
      if(t>0.5&&!tk.action){try{tk.startAction('shoot',0.5,0.15)}catch(e){}}
    }else{tk.vel.set(0,0,0);tk.speedRatio=0;anim(tk,dt)}
    // launch
    if(t>=0.7&&!S.launched){
      S.launched=true;S.res0=outcome();S.flightT=0;
      if(S.dive){const side=(s.x>=0?1:-1);S.gkTarget=S.dive.col*FIELD.goalW*0.3;
        try{gk.diveDir=S.dive.col===0?1:(S.dive.col>0?1:-1);gk.startAction('dive',0.9,0.2)}catch(e){}}
      try{audio.kick&&audio.kick(1)}catch(e){}
    }
    if(S.launched){
      S.flightT+=dt;const k=Math.min(1,S.flightT/0.55),e=1-(1-k)*(1-k);
      const ty=clamp(s.y,0,1.3)*FIELD.goalH,tz=s.x*FIELD.goalW/2;
      let ex=gx+(S.res0==='miss'?4:0),ez=tz;
      ball.pos.set(sp+(ex-sp)*e,PHYS.ballRadius+(ty-PHYS.ballRadius)*e+Math.sin(k*Math.PI)*0.35,ez*e);
      ball.mesh.position.copy(ball.pos);ball.mesh.rotation.x+=dt*14;
      // keeper dive
      const gk2=S.dive?ease(Math.min(1,S.flightT/0.45)):0;
      gk.pos.z=(S.gkTarget||0)*gk2;gk.vel.set(0,0,0);gk.speedRatio=0;anim(gk,dt);
      cam(dt,new THREE.Vector3(sp-6,1.7,2.4),new THREE.Vector3(gx-2,1.0,0),3.2);
    }else{gk.speedRatio=0;anim(gk,dt)}
  }
  function result3d(dt){
    const s=S.shot,gx=GX();anim(S.gkp,dt);S.tkr.vel.set(0,0,0);S.tkr.speedRatio=0;anim(S.tkr,dt);
    // ball settles by outcome
    const k=Math.min(1,S.t/0.5);
    if(S.res==='goal'){ball.pos.x=Math.min(gx+1.8,ball.pos.x+dt*6*(1-k*0.6));ball.pos.y=Math.max(PHYS.ballRadius,ball.pos.y-dt*3)}
    else if(S.res==='save'){ball.pos.x=Math.max(gx-2.4,ball.pos.x-dt*3);ball.pos.y=Math.max(PHYS.ballRadius,ball.pos.y-dt*3.5)}
    else if(S.res==='post'){ball.pos.x=Math.max(gx-4,ball.pos.x-dt*8*(1-k));ball.pos.y=Math.max(PHYS.ballRadius,ball.pos.y-dt*3)}
    else{ball.pos.x+=dt*5*(1-k);ball.pos.y=Math.max(PHYS.ballRadius,ball.pos.y-dt*2)}
    ball.mesh.position.copy(ball.pos);
    cam(dt,new THREE.Vector3(gx-9,2.1,5.5),new THREE.Vector3(gx-1,0.9,0),2.2);
  }
  const _uc=window.updateCamera;
  window.updateCamera=function(dt){
    if(S&&camT){camera.position.copy(camT);camera.lookAt(lookT);if(Math.abs(camera.fov-40)>.2){camera.fov=40;camera.updateProjectionMatrix()}camera.updateMatrixWorld(true);return}
    return _uc.apply(this,arguments);
  };
  /* hook into full-time */
  const _sf=window.showFulltime;
  window.showFulltime=function(){
    const draw=match.score[0]===match.score[1];
    const ko=match.knockout||match.isCup||settings.shootoutOnDraw;
    if(draw&&ko&&!match.shootout&&NET.mode==='off'&&!window.__soBusy){
      window.__soBusy=true;
      begin(r=>{window.__soBusy=false;match.shootout=r;_sf.apply(window,[]);
        try{const el=document.getElementById('ft-score');el.textContent=`${match.score[0]} - ${match.score[1]}  (${r.h}-${r.a} pens)`}catch(e){}
        if(r.h>r.a){try{coins+=150;toast('Shootout win +150 coins')}catch(e){}}
      });
      return;
    }
    return _sf.apply(this,arguments);
  };
  window.UAShootout={begin,_step:(n)=>{for(let i=0;i<n&&S;i++){update(0.05)}},_s:()=>S};
  function wire(){try{bindSwitch('set-shootout',()=>settings.shootoutOnDraw,(v)=>settings.shootoutOnDraw=v,()=>{try{saveSettings()}catch(e){}})}catch(e){}}
  if(document.readyState!=='loading')wire();else document.addEventListener('DOMContentLoaded',wire);
})();
