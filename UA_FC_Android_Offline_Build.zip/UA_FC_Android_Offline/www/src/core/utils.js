/* ==========================================================================
   01 · UTILITIES
   ========================================================================== */
const APP_NAME = 'UA FC MOBILE';
const $ = (id) => document.getElementById(id);
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const clamp01 = (v) => clamp(v, 0, 1);
function debounce(fn, ms) {
  let t = null;
  return (...args) => { clearTimeout(t); t = setTimeout(() => fn(...args), ms); };
}
const qsa = (sel, root = document) => Array.from(root.querySelectorAll(sel));
const lerp = (a, b, t) => a + (b - a) * t;
const rand = (a = 1, b) => (b === undefined ? Math.random() * a : a + Math.random() * (b - a));
const randInt = (a, b) => Math.floor(rand(a, b + 1));
const pick = (arr) => arr[Math.floor(Math.random() * arr.length)];
const damp = (cur, target, k, dt) => lerp(cur, target, 1 - Math.exp(-k * dt));
const dist2 = (ax, az, bx, bz) => Math.hypot(ax - bx, az - bz);
const S = Math.sin, C = Math.cos;
function haptic(ms) { if (settings.haptics) { try { if (navigator.vibrate) navigator.vibrate(ms); } catch (e) {} } }
function wrapAngle(a) {
  while (a > Math.PI) a -= Math.PI * 2;
  while (a < -Math.PI) a += Math.PI * 2;
  return a;
}
function angleDamp(cur, target, k, dt) {
  return cur + wrapAngle(target - cur) * (1 - Math.exp(-k * dt));
}
function pw(t, keys) {
  if (t <= keys[0][0]) return keys[0][1];
  for (let i = 0; i < keys.length - 1; i++) {
    const a = keys[i], b = keys[i + 1];
    if (t >= a[0] && t <= b[0]) {
      const f = (t - a[0]) / Math.max(1e-6, b[0] - a[0]);
      const s = f * f * (3 - 2 * f);
      return lerp(a[1], b[1], s);
    }
  }
  return keys[keys.length - 1][1];
}
function hexToRgb(hex) {
  const n = parseInt(hex.replace('#', ''), 16);
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
}
function contrastText(hex) {
  const [r, g, b] = hexToRgb(hex);
  return (r * 0.299 + g * 0.587 + b * 0.114) > 140 ? '#101418' : '#ffffff';
}
function hashStr(s) {
  let h = 9;
  for (let i = 0; i < s.length; i++) h = Math.imul(h ^ s.charCodeAt(i), 387420489);
  return Math.abs(h >>> 0);
}
function blobToDataURL(blob) {
  return new Promise((res, rej) => {
    const r = new FileReader();
    r.onload = () => res(r.result);
    r.onerror = rej;
    r.readAsDataURL(blob);
  });
}
async function fetchTextSafe(url) {
  try {
    const r = await fetch(url, { cache: 'no-store' });
    if (!r.ok) return null;
    return (await r.text()).trim();
  } catch (e) { return null; }
}
async function fetchBlobSafe(url) {
  try {
    const r = await fetch(url, { cache: 'no-store' });
    if (!r.ok) return null;
    return await r.blob();
  } catch (e) { return null; }
}

/* ==========================================================================
   02 · CONFIG + SETTINGS
   ========================================================================== */
const FIELD = {
  len: 105, wid: 68, halfLen: 52.5, halfWid: 34,
  goalW: 7.32, goalH: 2.44, goalDepth: 2.4,
  boxLen: 16.5, boxWid: 40.3, sixLen: 5.5, sixWid: 18.3, circleR: 9.15,
};
const PHYS = {
  gravity: -21, ballRadius: 0.14, restitution: 0.56,
  groundFriction: 2.1, airDrag: 0.12, magnus: 0.0062, spinDecay: 1.4, adv: true,
};
const DIFFS = [
  { name: 'AMATEUR', aiSpeed: 0.80, aiReact: 0.50, aiAcc: 0.60, aiTackle: 0.30, gkSkill: 0.36 },
  { name: 'PRO',     aiSpeed: 0.94, aiReact: 0.34, aiAcc: 0.80, aiTackle: 0.45, gkSkill: 0.50 },
  { name: 'LEGEND',  aiSpeed: 1.05, aiReact: 0.24, aiAcc: 0.95, aiTackle: 0.60, gkSkill: 0.66 },
  // 3 = TRASH (lowest): idle, never tackles, gifts the ball to you. 4 = GOD (highest): full-IQ brain + elite playstyles.
  // They sit at the end of the array so saved settings (0-2) keep their meaning; the menus list them at the ends.
  { name: 'TRASH',    aiSpeed: 0.40, aiReact: 1.60, aiAcc: 0.08, aiTackle: 0.00, gkSkill: 0.04, trash: true },
  { name: 'GOD MODE', aiSpeed: 1.16, aiReact: 0.08, aiAcc: 1.00, aiTackle: 0.90, gkSkill: 0.95, god: true },
];
const CAM_MODES = [
  'follow', 'close', 'ultraclose', 'firstperson', 'playerlock', 'shoulder',
  'tv', 'broadcast-wide', 'action', 'pro', 'top', 'tactical',
  'cinema', 'sideline', 'behindGoal', 'drone', 'crane', 'handheld', 'replay',
];
const CAM_LABELS = {
  follow: 'Follow', close: 'Close', ultraclose: 'Ultra Close', firstperson: 'First-Person', playerlock: 'Player-Lock',
  shoulder: 'Shoulder', tv: 'TV', 'broadcast-wide': 'Broadcast Wide', action: 'Action',
  pro: 'Pro', top: 'Top', tactical: 'Tactical', cinema: 'Cinema', sideline: 'Sideline',
  behindGoal: 'Behind Goal', drone: 'Drone', crane: 'Crane', handheld: 'Handheld', replay: 'Replay',
};
const SKIN_TONES = ['#f2c79b', '#e0ac69', '#c68642', '#8d5524', '#6b4423', '#f8d9c0'];
const HAIR_COLORS = ['#141414', '#3b2416', '#6b4a2b', '#c98a3d', '#d9c26b', '#7a1f1f'];
const BOOT_COLORS = ['#111318', '#ff4d00', '#00e5ff', '#ffe600', '#ff2d78'];
const EYE_COLORS = ['#3d2314', '#1e5631', '#1f4e79', '#705128', '#525252', '#0c0c0c'];
/* ==========================================================================
   MODEL DATA — shared schema with PLAYER_MODEL_EDITOR.html / UA_FC_MANAGER.html.
   A player's row in players_registry carries an optional `model_data` JSON
   blob (schemaVersion 1: body proportions, head/hair/eyes, kit overrides).
   If a player has never had a custom model built, this generates a
   deterministic "default" in the SAME shape — so there is only ever one
   model system in the game, never a legacy fallback mesh.
   ========================================================================== */
/* Fixed, non-random default model — used ONLY when a player has never had a
   custom model built in PLAYER_MODEL_EDITOR.html. Previously this hashed the
   player's name into random body/hair/skin values, which meant a player
   whose custom model_data was missing even one field (say hairStyle wasn't
   touched in the editor) silently fell back to a RANDOM value for just that
   field — a custom player rendering as part-edited, part-random hybrid.
   That's gone: this default is one fixed shape, and resolveModel() below no
   longer merges custom + default field-by-field at all. Height 1.34m is the
   explicit "no editor model" height per spec; the editor reports height as
   (1.85 * hScale) meters, so 1.34m = hScale 1.34/1.85. */
const DEFAULT_MODEL = Object.freeze({
  schemaVersion: 2,
  body: { height: 1.34 / 1.85, chest: 1, lats: 1, waist: 1, arms: 1, quads: 1, calves: 1 },
  head: { skin: SKIN_TONES[0], hairStyle: 'h1', hairColor: HAIR_COLORS[0], eyeColor: EYE_COLORS[0] },
  kit: { shortsColor: null, socksColor: null, socksTrimColor: null, bootColor: null, sleeveStyle: 'short', collarStyle: 'round' },
});
function defaultModelFor() {
  // Kept as a function (not just the constant) so existing call sites don't
  // need to change shape; always returns the one fixed default now.
  return DEFAULT_MODEL;
}
function resolveModel(info) {
  // info.model comes straight from a cloud row's model_data column (built in
  // PLAYER_MODEL_EDITOR.html, published via UA FC MANAGER). If it exists,
  // it is used EXACTLY as saved — no merging with defaults, no per-field
  // fallback to a randomized value. Missing sub-objects (body/head/kit) fall
  // back to the fixed default's corresponding section as a WHOLE block, not
  // field-by-field, so a real editor model can never come out part-custom,
  // part-random. If there is no model_data at all, every player uses the
  // exact same fixed 1.34m default — never a per-name random one.
  // schemaVersion 1 saves (pre-sleeve/collar/sock-trim capture) still load
  // fine here — their kit block just won't have those 3 fields, which then
  // fall through to DEFAULT_MODEL.kit's values individually is NOT what
  // happens: per the no-mixing rule, a v1 kit block is used as a WHOLE
  // (shortsColor/socksColor/bootColor from the save, sleeve/collar/trim
  // simply undefined -> buildPlayerModel's own `k.sleeveStyle || 'short'`
  // style fallbacks handle those three specifically, since kit intentionally
  // allows per-property fallbacks for cosmetic accessories that didn't exist
  // when older saves were made — body/head never do this.
  const m = info.model && typeof info.model === 'object' ? info.model : null;
  if (!m) return DEFAULT_MODEL;
  return {
    schemaVersion: m.schemaVersion || 1,
    body: (m.body && typeof m.body === 'object') ? m.body : DEFAULT_MODEL.body,
    head: (m.head && typeof m.head === 'object') ? m.head : DEFAULT_MODEL.head,
    kit: (m.kit && typeof m.kit === 'object') ? m.kit : DEFAULT_MODEL.kit,
  };
}

const settings = {
  sound: true, camera: 'follow', diff: 1, halfDur: 180, homeTeam: 0, awayTeam: 2,
  autoSwitch: true, passAssist: 'high',
  ctlScale: 'normal', haptics: true,
  camHeight: 1, camFov: 50, camSmooth: 3.4,
  crowdVol: 50, commentary: true, sfx: true,
  voiceCommentary: true, voiceVol: 80, voiceURI: '',
  instantReplay: true,
  devMode: false, infMoney: false, infGems: false, godStamina: false, fps: false, timeScale: 1,
};
try {
  const saved = JSON.parse(localStorage.getItem('uafc-settings') || localStorage.getItem('fc27-settings') || 'null');
  if (saved) Object.assign(settings, saved);
} catch (e) {}
// Production build: developer/cheat flags can never be active, even if an older save had them on.
// Beta Test Mode (devMode) is remembered between launches; only the frame-rate overlay and time scale reset.
if (settings.devMode) { settings.infMoney = true; settings.infGems = true; } else { settings.infMoney = false; settings.infGems = false; settings.godStamina = false; }
settings.fps = false; settings.timeScale = 1;
if (settings.autoSwitch === undefined) settings.autoSwitch = true;
if (!settings.passAssist) settings.passAssist = 'high';
if (!settings.ctlScale) settings.ctlScale = 'normal';
if (!settings.camera || !CAM_MODES.includes(settings.camera)) settings.camera = 'follow';
if (!settings.weather) settings.weather = 'clear';
if (!settings.season) settings.season = 'summer';
if (!settings.tod) settings.tod = 'day';
if (settings.wetPitch === undefined) settings.wetPitch = false;
if (settings.flashes === undefined) settings.flashes = true;
if (settings.wave === undefined) settings.wave = false;
if (!settings.stadQuality) settings.stadQuality = 'auto';
function saveSettings() {
  try { localStorage.setItem('uafc-settings', JSON.stringify(window.PlayHub ? PlayHub.settingsForSave() : settings)); } catch (e) {}
  if (typeof markCloudDirty === 'function') markCloudDirty();
}
const CTL_SCALE_MAP = { small: 0.8, normal: 1.0, big: 1.25, huge: 1.6, ultra: 2.0 };
function applyCtlScale() {
  const v = CTL_SCALE_MAP[settings.ctlScale] || 1;
  document.documentElement.style.setProperty('--ctl', v);
}
let coins = 400; // in-memory only — real value is pulled from Supabase on sign-in (pullCloudState in cloud.js). Guests keep this session-only default with no persistence.
function saveCoins() { if (typeof markCloudDirty === 'function') markCloudDirty(); }
function addCoins(n) {
  if (settings.infMoney) { coins = Math.max(coins, 999999); updateCoinUI(); return; }
  coins = Math.max(0, coins + n);
  saveCoins();
  updateCoinUI();
}
function spendCoins(n) {
  if (settings.infMoney) return true;
  if (coins < n) return false;
  coins -= n;
  saveCoins();
  updateCoinUI();
  if (myLeague) leaguePostQuestProgress('spend_coins', n);
  return true;
}
function updateCoinUI() {
  const label = settings.infMoney ? '∞' : coins;
  const hubCoins = $('hub-coins');
  if (hubCoins) hubCoins.textContent = typeof coins === 'number' ? coins.toLocaleString() : label;
  if (settings.infMoney && hubCoins) hubCoins.textContent = '∞';
  const acctStat = $('acct-stat-coins');
  if (acctStat) acctStat.textContent = label;
}
let vault = {}; // in-memory only — real value is pulled from Supabase on sign-in. Guests keep a session-only empty vault with no persistence.
function saveVault() { if (typeof markCloudDirty === 'function') markCloudDirty(); }
function vaultCount(id) { return vault[id] || 0; }
function vaultAdd(id) { vault[id] = (vault[id] || 0) + 1; saveVault(); }

