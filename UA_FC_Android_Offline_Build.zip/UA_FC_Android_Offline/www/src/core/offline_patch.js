/* ==========================================================================
   OFFLINE PATCH - last line of defence so the game can never go online.
   Loads (deferred) right after cloud.js/assets.js, before player.js/game.js.
   ========================================================================== */
(function () {
  'use strict';

  /* 1. three.js is a local file (three_bundle.js). If it is missing, say so
        plainly instead of a blank screen. */
  if (!window.THREE || !window.GLTFLoader || !window.SkeletonUtils) {
    var box = document.createElement('div');
    box.style.cssText = 'position:fixed;inset:0;z-index:99999;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:12px;background:#03060d;color:#fff;font-family:system-ui,Arial,sans-serif;text-align:center;padding:24px';
    box.innerHTML = '<div style="font-size:20px;font-weight:800">three_bundle.js IS MISSING</div>' +
      '<div style="font-size:13px;color:#8ea0b8;max-width:420px;line-height:1.6">The game engine file was not built yet. ' +
      'On a computer with Node.js run once:<br><b>npm i three@0.160.0 esbuild</b><br><b>node tools/build_three.js</b><br>' +
      'then reload. After that the game is 100% offline.</div>';
    (document.body || document.documentElement).appendChild(box);
    window._gameBooted = true;               // stop the generic retry card from covering this message
    return;
  }

  /* 2. No AI providers (they are online APIs). */
  try { if (typeof AI_CONFIG !== 'undefined') AI_CONFIG.providers.length = 0; } catch (e) {}

  /* 3. Block every request that is not to this app's own files. */
  var nativeFetch = window.fetch ? window.fetch.bind(window) : null;
  function isLocal(url) {
    try {
      var u = new URL(url, location.href);
      return u.protocol === 'file:' || u.protocol === 'data:' || u.protocol === 'blob:' || u.origin === location.origin;
    } catch (e) { return false; }
  }
  if (nativeFetch) {
    window.fetch = function (input, init) {
      var url = typeof input === 'string' ? input : (input && input.url) || '';
      if (!isLocal(url)) return Promise.reject(new TypeError('Offline: blocked ' + url));
      return nativeFetch(input, init);
    };
  }
  window.RTCPeerConnection = undefined;       // no peer-to-peer rooms
  window.WebSocket = function () { throw new Error('Offline: WebSocket disabled'); };

  /* 4. No service worker (it only cached online images). */
  try {
    if (navigator.serviceWorker && navigator.serviceWorker.getRegistrations) {
      navigator.serviceWorker.getRegistrations()
        .then(function (rs) { rs.forEach(function (r) { r.unregister(); }); })
        .catch(function () { /* file:// has no service workers; nothing to clean up */ });
    }
  } catch (e) {}
})();
