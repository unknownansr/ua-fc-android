/* ==========================================================================
   ASSET SERVICE — the ONLY place the game builds asset URLs or uploads files.
   Files live in Google Drive (MyGame/Players, UI, Events, League); the browser
   never talks to Google: Browser -> Edge Function "ua-fc-drive" -> Drive.
   No Google login, no Google keys here. Loaded after cloud.js (needs
   SUPABASE_URL and sb), before game.js / mainui.js.
   The rest of the game still says "player-media", "home-banners" ... — this
   table is the single place that turns those names into Drive folders.
   ========================================================================== */
const ASSET_API = SUPABASE_URL + '/functions/v1/ua-fc-drive';
const ASSET_MAP = {
  'player-media':   ['Players', ''],
  'home-banners':   ['UI', 'home-banners/'],
  'draft-media':    ['UI', 'draft-media/'],
  'box-media':      ['UI', 'box-media/'],
  'activity-media': ['UI', 'activity-media/'],
  'trivia-media':   ['UI', 'trivia-media/'],
  'ua-pass-media':  ['UI', 'ua-pass-media/'],
  'event-media':    ['Events', ''],
  'league-media':   ['League', ''],
};
function assetTarget(bucket, path) {
  const m = ASSET_MAP[bucket];
  return m ? { folder: m[0], path: m[1] + path } : { folder: bucket, path: String(path) };
}
const _assetSeg = (p) => String(p).split('/').map(encodeURIComponent).join('/');

/* Public URL for a game asset, e.g. getAssetUrl('player-media', 'athul.png'). */
function getAssetUrl(bucket, path) {
  if (!bucket || !path) return null;
  const t = assetTarget(bucket, path);
  return ASSET_API + '/' + encodeURIComponent(t.folder) + '/' + _assetSeg(t.path);
}
function getAssetUrlById(assetId) {
  return assetId ? ASSET_API + '/id/' + encodeURIComponent(assetId) : null;
}
const getImageUrl = getAssetUrl;
const getModelUrl = getAssetUrl;
const getFileUrl = getAssetUrl;

async function assetAuthHeader() {
  const { data } = await sb.auth.getSession();
  const token = data && data.session && data.session.access_token;
  if (!token) throw new Error('Sign in first.');
  return { Authorization: 'Bearer ' + token };
}

/* Upload a file (signed-in user; server decides what is allowed). */
async function uploadAsset(file, bucket, path) {
  const t = assetTarget(bucket, path || '');
  const form = new FormData();
  form.append('file', file);
  form.append('folder', t.folder);
  if (path) form.append('path', t.path);
  const res = await fetch(ASSET_API, { method: 'POST', headers: await assetAuthHeader(), body: form });
  const out = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(out.error || 'Upload failed (' + res.status + ')');
  return { ...out, url: getAssetUrl(bucket, path) };
}
async function deleteAsset(bucket, path) {
  const t = assetTarget(bucket, path);
  const res = await fetch(ASSET_API + '/' + encodeURIComponent(t.folder) + '/' + _assetSeg(t.path), {
    method: 'DELETE', headers: await assetAuthHeader(),
  });
  if (!res.ok) { const out = await res.json().catch(() => ({})); throw new Error(out.error || 'Delete failed (' + res.status + ')'); }
  return true;
}
async function listAssets(bucket) {
  const t = assetTarget(bucket, '');
  const res = await fetch(ASSET_API + '?folder=' + encodeURIComponent(t.folder), { headers: await assetAuthHeader() });
  const out = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(out.error || 'List failed (' + res.status + ')');
  return out.assets || [];
}
