/* ==========================================================================
   ☁️ SUPABASE — same project used by playerregister.html. All player
   media/data, accounts, and cloud saves flow through this project.
   ========================================================================== */
const SUPABASE_URL = "https://ydkrelrsvhdktalsypqv.supabase.co";
const SUPABASE_ANON_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Inlka3JlbHJzdmhka3RhbHN5cHF2Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTExMDc0MzIsImV4cCI6MjEwNjY4MzQzMn0.A7yGrmFtCoP6QP2ZeSMu94YRWQXbFuRSTwUj-524yRE";
const MEDIA_BUCKET = 'player-media';
const sb = window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
  auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: false },
});
;
;
let cloudUser = null;      // Supabase auth user, or null if playing as guest
let cloudProfile = null;   // row from public.profiles
let userGems = 0;          // live gems balance, synced from user_gems
let cloudReady = false;    // true once we've resolved the initial session check
let cloudSyncEnabled = true;

/* ==========================================================================
   36 · ACHIEVEMENTS — persistent per-user unlocks, backed by
   public.user_achievements (RLS: auth.uid() = user_id, same convention as
   match_history/leagues). Checks hook into existing stat-tracking points
   (trackStat, onGoal, pushMatchResult, performSubstitution, commitFoul)
   rather than polling, mirroring how commentary/replay already hook in.
   ========================================================================== */
const ACHIEVEMENTS = [
  { key: 'first_goal',        icon: '⚽', name: 'On the Board',        desc: 'Score your first goal' },
  { key: 'first_hattrick',    icon: '🎩', name: 'Hat-Trick Hero',      desc: 'Score a hat-trick in one match' },
  { key: 'wins_10',           icon: '🥉', name: 'Getting Started',     desc: 'Win 10 matches' },
  { key: 'wins_50',           icon: '🥈', name: 'Seasoned Pro',        desc: 'Win 50 matches' },
  { key: 'wins_100',          icon: '🥇', name: 'Centurion',           desc: 'Win 100 matches' },
  { key: 'first_friend_win',  icon: '🤝', name: 'Bragging Rights',     desc: 'Win your first friend match' },
  { key: 'unbeaten_5',        icon: '🛡️', name: 'Unbeatable',          desc: '5-match unbeaten streak' },
  { key: 'first_sub',         icon: '🔄', name: 'Tactical Change',     desc: 'Make your first substitution' },
  { key: 'first_var_foul',    icon: '📺', name: 'Replay-Worthy',       desc: 'Trigger your first VAR review' },
];
const ACH_BY_KEY = Object.fromEntries(ACHIEVEMENTS.map(a => [a.key, a]));
let unlockedAchievements = new Set(); // keys unlocked this session/account, loaded from cloud
let achievementsLoaded = false;
let achLoadedForUser = null; // guards against re-fetching on every refreshAccPanel() call for the same user

async function loadAchievements() {
  unlockedAchievements = new Set();
  achievementsLoaded = false;
  if (!cloudUser) { achievementsLoaded = true; return; }
  try {
    const { data, error } = await sb.from('user_achievements').select('achievement_key').eq('user_id', cloudUser.id);
    if (error) throw error;
    unlockedAchievements = new Set((data || []).map(r => r.achievement_key));
  } catch (e) { ; }
  achievementsLoaded = true;
}

// Single choke-point for unlocking — every achievement check in the file
// routes through here, same pattern as say()/rtcSend(). Safe to call
// repeatedly with an already-unlocked key (no-ops).
async function unlockAchievement(key) {
  if (!ACH_BY_KEY[key] || unlockedAchievements.has(key)) return;
  unlockedAchievements.add(key); // optimistic, so a slow/failed write can't cause duplicate toasts
  achievementToast(key);
  if (!cloudUser) return; // guest play: session-only, nothing to persist
  try {
    const { error } = await sb.from('user_achievements').insert({ user_id: cloudUser.id, achievement_key: key });
    if (error && error.code !== '23505') throw error; // 23505 = unique violation (already unlocked elsewhere) — not an error
  } catch (e) { ; }
}

let achToastQueue = [];
let achToastShowing = false;
function achievementToast(key) {
  const a = ACH_BY_KEY[key];
  if (!a) return;
  achToastQueue.push(a);
  if (!achToastShowing) achToastPump();
}
function achToastPump() {
  const a = achToastQueue.shift();
  if (!a) { achToastShowing = false; return; }
  achToastShowing = true;
  const el = document.createElement('div');
  el.className = 'ach-toast';
  el.innerHTML = `<div class="ach-toast-icon">${a.icon}</div><div class="ach-toast-body"><div class="ach-toast-eyebrow">Achievement Unlocked</div><div class="ach-toast-title">${a.name}</div><div class="ach-toast-desc">${a.desc}</div></div>`;
  $('ach-toast-layer').appendChild(el);
  requestAnimationFrame(() => el.classList.add('show'));
  audio.ui?.();
  setTimeout(() => {
    el.classList.remove('show');
    setTimeout(() => { el.remove(); achToastPump(); }, 260);
  }, 3200); // longer + visually distinct from ordinary toast()'s ~1.1s
}

// Win-count / streak / first-friend-win checks: derived from match_history
// (already the source of truth for acc-panel win rate) rather than a
// second local counter, so this can never drift from what's actually saved.
async function checkPostMatchAchievements(userScore, oppScore, isFriendMatch) {
  if (!cloudUser) return;
  try {
    const { data, error } = await sb.from('match_history').select('result, opponent_name')
      .eq('user_id', cloudUser.id).order('played_at', { ascending: false }).limit(200);
    if (error) throw error;
    const rows = data || [];
    const wins = rows.filter(r => r.result === 'win').length;
    if (wins >= 10) unlockAchievement('wins_10');
    if (wins >= 50) unlockAchievement('wins_50');
    if (wins >= 100) unlockAchievement('wins_100');
    if (isFriendMatch && userScore > oppScore) unlockAchievement('first_friend_win');
    // unbeaten streak: walk from most recent until a loss
    let streak = 0;
    for (const r of rows) { if (r.result === 'loss') break; streak++; }
    if (streak >= 5) unlockAchievement('unbeaten_5');
  } catch (e) { ; }
}

function renderTrophyCabinet() {
  const unlockedCount = ACHIEVEMENTS.filter(a => unlockedAchievements.has(a.key)).length;
  $('trophy-progress').textContent = `${unlockedCount} / ${ACHIEVEMENTS.length} unlocked`;
  $('trophy-grid').innerHTML = ACHIEVEMENTS.map(a => {
    const on = unlockedAchievements.has(a.key);
    return `<div class="trophy-badge ${on ? 'unlocked' : 'locked'}">
      <div class="trophy-badge-icon">${on ? a.icon : '🔒'}</div>
      <div class="trophy-badge-name">${a.name}</div>
    </div>`;
  }).join('');
}

function mediaUrlFor(path) {
  if (!path) return null;
  return getAssetUrl(MEDIA_BUCKET, path);
}

/* ==========================================================================
   AI PROVIDER CONFIG — PASTE YOUR API KEYS BELOW ★★★
   Three providers are configured so you get huge combined usage.
   Replace "PASTE_..." with a real key. If no key is present the app
   automatically uses the built-in offline AI (which still knows everything
   about your players, coins, controls and tactics).
   ========================================================================== */
const AI_CONFIG = {
  providers: [
    {
      name: 'OpenAI',
      style: 'openai',
      url: 'https://api.openai.com/v1/chat/completions',
      model: 'gpt-4o-mini',
      key: 'PASTE_OPENAI_KEY_HERE',
    },
    {
      name: 'Groq',
      style: 'openai',
      url: 'https://api.groq.com/openai/v1/chat/completions',
      model: 'llama-3.3-70b-versatile',
      key: 'PASTE_GROQ_KEY_HERE',
    },
    {
      name: 'Gemini',
      style: 'gemini',
      url: 'https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent',
      model: 'gemini-1.5-flash',
      key: 'PASTE_GEMINI_KEY_HERE',
    },
  ],
};

/* ==========================================================================
   ☁️ CLOUD SAVE / LOAD — coins and vault (account/currency data) live in
   Supabase's user_game_state table as the SOLE source of truth. There is
   no localStorage fallback for these: signed-out guests get an in-memory
   default that resets every session (see utils.js), and signed-in users
   are fully driven by this table. `settings` is intentionally excluded —
   it stays local-only (see saveSettings() in utils.js) and is never
   written here.
   ========================================================================== */
let cloudSyncTimer = null;
let cloudSyncDirty = false;
let cloudLastSyncedAt = null;

function collectLocalState() {
  return { coins, vault, savedAt: new Date().toISOString() };
}
function markCloudDirty() {
  cloudSyncDirty = true;
  if (!cloudUser || !cloudSyncEnabled) return;
  clearTimeout(cloudSyncTimer);
  cloudSyncTimer = setTimeout(pushCloudState, 2500); // debounce rapid changes (coin pickups, pack pulls, etc.)
}
async function refreshGemsBalance() {
  if (!cloudUser) { userGems = 0; return; }
  try {
    const { data, error } = await sb.from('user_gems').select('gems').eq('user_id', cloudUser.id).maybeSingle();
    if (error) throw error;
    userGems = (data && data.gems) || 0;
  } catch (err) {
    ;
  }
  updateHubTopbar();
}
async function addGems(amount) {
  // Guests can't earn gems at all — there's no cloud row to credit and no
  // local persistence for currency (see utils.js). Trivia/other reward
  // flows should check for cloudUser themselves and prompt sign-in, but
  // this is a hard backstop either way.
  if (!cloudUser || amount <= 0) return false;
  try {
    const { data, error } = await sb.from('user_gems').select('gems').eq('user_id', cloudUser.id).maybeSingle();
    if (error) throw error;
    const current = (data && data.gems) || 0;
    const next = current + amount;
    const { error: upErr } = await sb.from('user_gems').upsert({ user_id: cloudUser.id, gems: next }, { onConflict: 'user_id' });
    if (upErr) throw upErr;
    userGems = next;
    updateHubTopbar();
    return true;
  } catch (err) {
    ;
    return false;
  }
}
async function spendGems(amount) {
  // Dev-mode override: don't touch the real cloud balance at all, just
  // report success — mirrors how infMoney works for coins.
  if (settings.infGems) { updateHubTopbar(); return true; }
  // Atomic-ish spend: re-read the latest balance right before writing so
  // two rapid spends (e.g. a fast double-tap) can't both succeed against
  // a stale local balance. Returns true only if the spend was applied.
  if (!cloudUser) return false;
  try {
    const { data, error } = await sb.from('user_gems').select('gems').eq('user_id', cloudUser.id).maybeSingle();
    if (error) throw error;
    const current = (data && data.gems) || 0;
    if (current < amount) { userGems = current; updateHubTopbar(); return false; }
    const next = current - amount;
    const { error: upErr } = await sb.from('user_gems').update({ gems: next }).eq('user_id', cloudUser.id);
    if (upErr) throw upErr;
    userGems = next;
    updateHubTopbar();
    return true;
  } catch (err) {
    ;
    toast('Could not complete purchase — try again.');
    return false;
  }
}
async function pushCloudState() {
  if (!cloudUser || !cloudSyncEnabled) return;
  try {
    const state = collectLocalState();
    const { error } = await sb.from('user_game_state').upsert({ user_id: cloudUser.id, state }, { onConflict: 'user_id' });
    if (error) throw error;
    cloudSyncDirty = false;
    cloudLastSyncedAt = new Date();
    updateSyncStatusUI(true);
  } catch (err) {
    ;
    updateSyncStatusUI(false);
  }
}
async function pullCloudState() {
  if (!cloudUser) return false;
  try {
    const { data, error } = await sb.from('user_game_state').select('state').eq('user_id', cloudUser.id).maybeSingle();
    if (error) throw error;
    if (!data || !data.state) {
      // Brand-new account, no row yet — push the current in-memory
      // defaults now so a row exists from this point forward.
      await pushCloudState();
      updateCoinUI();
      return true;
    }
    const cloud = data.state;
    // Cloud data restores account state on sign-in — this is the "play on
    // any device" path. We only overwrite if the cloud save looks valid;
    // this assigns directly rather than calling saveCoins()/saveVault()
    // to avoid an immediate pointless re-push of what we just pulled.
    if (typeof cloud.coins === 'number') coins = cloud.coins;
    if (cloud.vault && typeof cloud.vault === 'object') vault = cloud.vault;
    updateCoinUI();
    return true;
  } catch (err) {
    ;
    return false;
  }
}
async function pushMatchResult(userScore, oppScore, coinsEarned, statsObj) {
  if (!cloudUser) return;
  try {
    const result = userScore > oppScore ? 'win' : userScore < oppScore ? 'loss' : 'draw';
    await sb.from('match_history').insert({
      user_id: cloudUser.id,
      opponent_name: teamDefs && teamDefs[1] ? teamDefs[1].name : 'CPU',
      user_score: userScore, opponent_score: oppScore,
      result, coins_earned: coinsEarned || 0,
      match_stats: statsObj || {},
    });
    await awardMatchXP(result, coinsEarned || 0);
    // UA Pass XP is separate from account-level profile XP above — it's
    // tracked per-season via the ua_pass_add_xp RPC (server-side amount
    // lookup, see the ua_pass_xp_sources table), so the game client only
    // ever sends an action key, never a number.
    awardUAPassXP('play_match');
    if (result === 'win') awardUAPassXP('win_match');
    if (result === 'win' && oppScore === 0) awardUAPassXP('clean_sheet');
    // Keep the account panel's history/stat views current for next time it's opened.
    if (typeof refreshAccPanel === 'function') refreshAccPanel();
    updateHubTopbar();
  } catch (err) {
    ;
  }
}

/* ==========================================================================
   LEVEL / XP — real progression: base XP for playing a match, a bonus for
   winning, plus a small share of coins earned. Level requirement grows
   each level (xpForLevel), matching the "708/3600"-style variable bar
   seen in the reference UI rather than a flat requirement.
   ========================================================================== */
function xpForLevel(level) { return 1000 + (level - 1) * 250; }
async function awardMatchXP(result, coinsEarned) {
  if (!cloudUser || !cloudProfile) return;
  const base = 60;
  const winBonus = result === 'win' ? 120 : result === 'draw' ? 40 : 0;
  const coinShare = Math.floor(coinsEarned * 0.01);
  const gained = base + winBonus + coinShare;

  let xp = (cloudProfile.xp || 0) + gained;
  let level = cloudProfile.level || 1;
  let need = xpForLevel(level);
  while (xp >= need) { xp -= need; level++; need = xpForLevel(level); }

  cloudProfile.xp = xp;
  cloudProfile.level = level;
  try {
    await sb.from('profiles').update({ xp, level }).eq('id', cloudUser.id);
  } catch (err) {
    ;
  }
}
/* Fire-and-forget: UA Pass XP grants never block or fail gameplay flow.
   The RPC itself no-ops safely if there's no active season, the action
   key is unrecognized/disabled, or the user isn't signed in — this
   wrapper just adds a friendly console warning on unexpected errors and
   refreshes the screen if the player happens to be looking at it. */
async function awardUAPassXP(actionKey) {
  if (!cloudUser) return;
  try {
    await sb.rpc('ua_pass_add_xp', { p_action_key: actionKey });
    if (match && match.screen === 'uapass' && typeof loadUAPassProgress === 'function') {
      await loadUAPassProgress();
      if (typeof renderUAPass === 'function') renderUAPass();
    }
  } catch (err) {
    ;
  }
}
function updateHubTopbar() {
  const badge = $('hub-profile-badge');
  const nameEl = $('hub-profile-name');
  const lvlEl = $('hub-lvl');
  const xpFill = $('hub-xp-fill');
  const xpLabel = $('hub-xp-label');
  if (!badge) return; // menu screen not built yet on first call
  if (!cloudUser) {
    badge.textContent = '?';
    nameEl.textContent = 'Guest';
    lvlEl.textContent = '1';
    xpFill.style.width = '0%';
    xpLabel.textContent = '0/1000';
  } else {
    const label = (cloudProfile && (cloudProfile.display_name || cloudProfile.username)) || cloudUser.email.split('@')[0];
    badge.textContent = (label[0] || '?').toUpperCase();
    nameEl.textContent = label;
    const level = (cloudProfile && cloudProfile.level) || 1;
    const xp = (cloudProfile && cloudProfile.xp) || 0;
    const need = xpForLevel(level);
    lvlEl.textContent = level;
    xpFill.style.width = clamp01(xp / need) * 100 + '%';
    xpLabel.textContent = `${xp}/${need}`;
  }
  const hubCoins = $('hub-coins');
  if (hubCoins) hubCoins.textContent = settings.infMoney ? '∞' : coins.toLocaleString();
  const hubGems = $('hub-gems');
  if (hubGems) hubGems.textContent = settings.infGems ? '∞' : (typeof userGems === 'number' ? userGems : 0).toLocaleString();
  const hubUap = $('hub-uap');
  if (hubUap) hubUap.textContent = (typeof userUAPoints === 'number' ? userUAPoints : 0).toLocaleString();
}

/* Daily coin bonus — account data, so its date-stamp lives in the same
   user_game_state row as coins/vault (not localStorage). Guests get no
   daily bonus at all, matching "no persistence" for signed-out play —
   there's nothing to compare "today" against without an account. */
let pendingDaily = 0;
async function grantDailyBonusIfDue() {
  if (!cloudUser) return;
  try {
    const { data, error } = await sb.from('user_game_state').select('state').eq('user_id', cloudUser.id).maybeSingle();
    if (error) throw error;
    const state = (data && data.state) || {};
    const today = new Date().toDateString();
    if (state.lastDaily === today) return; // already claimed today
    pendingDaily = 150;
    coins += 150;
    const { error: upErr } = await sb.from('user_game_state').upsert({
      user_id: cloudUser.id,
      state: { ...state, coins, vault, lastDaily: today, savedAt: new Date().toISOString() },
    }, { onConflict: 'user_id' });
    if (upErr) throw upErr;
    updateCoinUI();
    awardUAPassXP('daily_login');
  } catch (err) {
    ;
  }
}


/* ==========================================================================
   03 · AUDIO
   ========================================================================== */
class AudioEngine {
  constructor() { this.ctx = null; this.master = null; this.crowdGain = null; this.noiseBuf = null; this.crowdBase = 0.16; }
  init() {
    if (this.ctx) return;
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return;
    this.ctx = new AC();
    this.master = this.ctx.createGain();
    this.master.gain.value = settings.sound ? 0.9 : 0;
    this.master.connect(this.ctx.destination);
    this.noiseBuf = this.makeNoise(2.5);
    this.crowdBase = (settings.crowdVol / 100) * 0.32;
    this.startCrowd();
  }
  resume() { if (this.ctx && this.ctx.state === 'suspended') this.ctx.resume(); }
  setEnabled(on) { if (this.master) this.master.gain.value = on ? 0.9 : 0; }
  setCrowdBase(v) { this.crowdBase = v; }
  makeNoise(dur) {
    const len = Math.floor(this.ctx.sampleRate * dur);
    const buf = this.ctx.createBuffer(1, len, this.ctx.sampleRate);
    const d = buf.getChannelData(0);
    let last = 0;
    for (let i = 0; i < len; i++) {
      const white = Math.random() * 2 - 1;
      last = (last + 0.02 * white) / 1.02;
      d[i] = (white * 0.4 + last * 2.2) * 0.5;
    }
    return buf;
  }
  startCrowd() {
    const src = this.ctx.createBufferSource();
    src.buffer = this.noiseBuf;
    src.loop = true;
    const filt = this.ctx.createBiquadFilter();
    filt.type = 'bandpass';
    filt.frequency.value = 620;
    filt.Q.value = 0.6;
    this.crowdGain = this.ctx.createGain();
    this.crowdGain.gain.value = this.crowdBase;
    src.connect(filt).connect(this.crowdGain).connect(this.master);
    src.start();
  }
  setCrowd(tension) {
    if (!this.crowdGain || !this.ctx) return;
    const target = this.crowdBase + (tension ? 0.08 : 0);
    this.crowdGain.gain.setTargetAtTime(target, this.ctx.currentTime, 0.5);
  }
  crowdSwell(amount) {
    if (!this.crowdGain) return;
    const t = this.ctx.currentTime;
    const g = this.crowdGain.gain;
    g.cancelScheduledValues(t);
    g.setValueAtTime(Math.max(g.value, 0.0001), t);
    g.linearRampToValueAtTime(Math.max(this.crowdBase + amount * 0.5, 0.0001), t + 0.25);
    g.exponentialRampToValueAtTime(Math.max(this.crowdBase, 0.0001), t + 3.2);
  }
  blip(freq, dur, type = 'sine', vol = 0.3, slide = 0) {
    if (!this.ctx || !settings.sfx) return;
    const t = this.ctx.currentTime;
    const o = this.ctx.createOscillator();
    const g = this.ctx.createGain();
    o.type = type;
    o.frequency.setValueAtTime(Math.max(freq, 1), t);
    if (slide) o.frequency.exponentialRampToValueAtTime(Math.max(30, freq + slide), t + dur);
    g.gain.setValueAtTime(Math.max(vol, 0.0001), t);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(g).connect(this.master);
    o.start(t);
    o.stop(t + dur + 0.02);
  }
  noiseBurst(dur, vol, freq = 900, q = 0.8) {
    if (!this.ctx || !settings.sfx) return;
    const t = this.ctx.currentTime;
    const src = this.ctx.createBufferSource();
    src.buffer = this.noiseBuf;
    const filt = this.ctx.createBiquadFilter();
    filt.type = 'bandpass';
    filt.frequency.value = freq;
    filt.Q.value = q;
    const g = this.ctx.createGain();
    g.gain.setValueAtTime(vol, t);
    g.gain.exponentialRampToValueAtTime(0.001, t + dur);
    src.connect(filt).connect(g).connect(this.master);
    src.start(t, rand(0.4));
    src.stop(t + dur + 0.05);
  }
  kick(power) { this.blip(95, 0.12, 'sine', 0.5 + power * 0.4, -55); this.noiseBurst(0.08, 0.35 + power * 0.3, 1600, 1.2); }
  bounce(v) { this.blip(70 + v * 6, 0.09, 'sine', clamp01(v / 14) * 0.4, -30); }
  pass() { this.blip(110, 0.08, 'sine', 0.32, -40); this.noiseBurst(0.05, 0.2, 1400, 1.4); }
  tackle() { this.noiseBurst(0.14, 0.5, 500, 0.9); this.blip(70, 0.12, 'triangle', 0.4, -30); }
  post() { this.blip(620, 0.3, 'square', 0.22, -60); this.blip(1240, 0.2, 'sine', 0.14, -120); }
  whistle(kind = 'short') {
    if (!this.ctx || !settings.sfx) return;
    const seq = kind === 'short' ? [[0, 0.28]] : kind === 'half' ? [[0, 0.25], [0.32, 0.25]] : [[0, 0.22], [0.3, 0.22], [0.6, 0.55]];
    for (const [at, dur] of seq) {
      const t = this.ctx.currentTime + at;
      const o = this.ctx.createOscillator();
      const g = this.ctx.createGain();
      o.type = 'square';
      o.frequency.setValueAtTime(2350, t);
      const lfo = this.ctx.createOscillator();
      lfo.frequency.value = 38;
      const lg = this.ctx.createGain();
      lg.gain.value = 180;
      lfo.connect(lg).connect(o.frequency);
      g.gain.setValueAtTime(0.0001, t);
      g.gain.linearRampToValueAtTime(0.16, t + 0.02);
      g.gain.setValueAtTime(0.16, t + dur - 0.04);
      g.gain.exponentialRampToValueAtTime(0.001, t + dur);
      o.connect(g).connect(this.master);
      o.start(t); o.stop(t + dur + 0.02);
      lfo.start(t); lfo.stop(t + dur + 0.02);
    }
  }
  goalRoar() { this.crowdSwell(1); this.noiseBurst(2.6, 0.7, 900, 0.5); this.blip(392, 0.5, 'sawtooth', 0.16); this.blip(523, 0.7, 'sawtooth', 0.14); }
  chant() { this.crowdSwell(0.45); }
  ui() { this.blip(520, 0.07, 'triangle', 0.22, 140); }
  spinTick() { this.blip(900, 0.03, 'square', 0.08, 100); }
  firework() { this.noiseBurst(0.4, 0.3, 300, 0.6); this.blip(180, 0.3, 'sine', 0.18, -120); }
  perfect() { this.blip(880, 0.18, 'triangle', 0.3, 220); this.blip(1320, 0.22, 'sine', 0.2); }
  reveal(rarity) {
    this.crowdSwell(0.7);
    this.blip(523, 0.3, 'sawtooth', 0.14);
    this.blip(659, 0.4, 'sawtooth', 0.14);
    if (rarity === 'gold' || rarity === 'icon') this.blip(784, 0.6, 'sawtooth', 0.16);
  }
  catchBall() { this.noiseBurst(0.07, 0.3, 700, 1); }

  /* ---------- pack opening SFX ---------- */
  packAppear() {
    this.blip(220, 0.5, 'sine', 0.18, 40);
    this.blip(330, 0.6, 'sine', 0.12, 20);
    this.noiseBurst(0.3, 0.1, 1800, 0.5);
  }
  packShake() { this.noiseBurst(0.05, 0.16, 1900, 1.4); this.blip(170, 0.06, 'square', 0.09, -25); }
  packBurst(rarity) {
    // Layered, much bigger burst: sub-bass thump + rising sweep + shimmer,
    // scaled up further for gold/icon/hero pulls (crowd roar joins in).
    this.noiseBurst(0.5, 0.6, 2800, 0.6);
    this.blip(90, 0.55, 'sawtooth', 0.35, -70);
    this.blip(220, 0.4, 'sawtooth', 0.28, -100);
    this.blip(1100, 0.3, 'sine', 0.2, 400);
    this.blip(1700, 0.22, 'sine', 0.14, 500);
    if (['gold', 'icon', 'hero'].includes(rarity)) {
      this.blip(1500, 0.5, 'sine', 0.2, 350);
      this.blip(2000, 0.45, 'sine', 0.16, 300);
      this.crowdSwell(0.85);
    } else {
      this.crowdSwell(0.35);
    }
  }
  packStageIn(stage) {
    // Rising tone per stage — nation (low) -> position (mid) -> rating (high),
    // each now a small two-note stinger instead of one flat blip.
    const freqs = { flag: 392, pos: 523, rating: 659, card: 880 };
    const f = freqs[stage] || 500;
    this.blip(f, 0.16, 'triangle', 0.16, 30);
    this.blip(f * 1.5, 0.22, 'triangle', 0.13, 60);
  }
  packRatingRoll(ovr) {
    // A longer ascending arpeggio whose top note and brightness scale with
    // OVR, so a high pull audibly "feels" bigger even before reading it.
    const top = 480 + clamp01((ovr - 60) / 40) * 620;
    this.blip(300, 0.09, 'triangle', 0.11);
    this.blip(300 + (top - 300) * 0.33, 0.09, 'triangle', 0.12);
    this.blip(300 + (top - 300) * 0.66, 0.11, 'triangle', 0.13);
    this.blip(top, 0.45, 'sawtooth', ovr >= 85 ? 0.26 : 0.16, 140);
    if (ovr >= 85) { this.blip(top * 1.5, 0.5, 'sine', 0.14, 200); this.crowdSwell(0.5); }
  }
  packCardIn(rarity) {
    // The single biggest sting in the sequence: sub thump, ringing chime
    // stack, and a crowd roar sized to rarity — the "hero moment" payoff.
    this.noiseBurst(0.25, 0.35, 1700, 0.9);
    this.blip(80, 0.5, 'sawtooth', 0.32, -60);
    this.reveal(['gold', 'icon', 'hero'].includes(rarity) ? 'gold' : 'bronze');
    if (['icon', 'hero'].includes(rarity)) {
      this.blip(1046, 0.6, 'sine', 0.2, 250);
      this.blip(1568, 0.7, 'sine', 0.16, 300);
      this.crowdSwell(1);
    }
  }
}
const audio = new Proxy(new AudioEngine(), {
  get(target, prop) {
    const val = target[prop];
    if (typeof val !== 'function') return val;
    // Wrap every audio method so a Web Audio quirk (bad ramp target,
    // suspended context, etc.) can never throw up into the game loop.
    return function (...args) {
      try { return val.apply(target, args); }
      catch (err) { ; }
    };
  },
});

const FR = {
  tab: 'list',
  friends: [],          // [{friendship_id, user_id, username, display_name, status}]
  incoming: [],
  outgoing: [],
  presenceMap: new Map(), // user_id -> {status,last_seen}
  channel: null,
  presenceHeartbeat: null,
};

function frMyId() { return cloudUser ? cloudUser.id : null; }

function frRequireLogin() {
  if (!cloudUser) { toast('Sign in to use Friends.'); return false; }
  return true;
}

/* ---------- presence ---------- */
async function frTouchPresence(status) {
  if (!cloudUser) return;
  try {
    await sb.from('user_presence').upsert({ user_id: cloudUser.id, status, last_seen: new Date().toISOString() }, { onConflict: 'user_id' });
  } catch (e) { ; }
}
function frStartPresenceHeartbeat() {
  if (!cloudUser || FR.presenceHeartbeat) return;
  frTouchPresence('online');
  FR.presenceHeartbeat = setInterval(() => frTouchPresence(match.screen === 'match' ? 'in_match' : 'online'), 20000);
  document.addEventListener('visibilitychange', () => {
    if (!cloudUser) return;
    frTouchPresence(document.hidden ? 'offline' : (match.screen === 'match' ? 'in_match' : 'online'));
    // Self-healing net: a locked screen / backgrounded app / dropped wifi
    // while a connection was mid-negotiation could otherwise leave
    // #room-backdrop (z-index 90, above every menu screen) stuck visible
    // forever with no way back in — this was the actual cause of "Start
    // Match does nothing", since the invisible-looking overlay was eating
    // every tap on the menu underneath it. Coming back to a foreground tab
    // with no live connection and no in-progress match is never a state
    // the room dialog should still be showing in, so force it closed.
    if (!document.hidden && !RM.connected && match.screen !== 'match' && $('room-backdrop') && !$('room-backdrop').classList.contains('hidden')) {
      ;
      roomHide();
      roomCleanup();
    }
  });
  window.addEventListener('beforeunload', () => { try { navigator.sendBeacon && frTouchPresence('offline'); } catch (e) {} });
}

/* ---------- data loading ---------- */
async function frLoadAll() {
  if (!cloudUser) return;
  const uid = cloudUser.id;
  try {
    // friendships FKs point to auth.users (not public.profiles), so PostgREST
    // can't auto-embed profiles here — fetch the rows, then batch-fetch the
    // profile info for every other-party id in one extra query.
    const { data: rows, error } = await sb.from('friendships')
      .select('id, requester_id, addressee_id, status')
      .or(`requester_id.eq.${uid},addressee_id.eq.${uid}`);
    if (error) throw error;

    const otherIds = [...new Set((rows || []).map((r) => (r.requester_id === uid ? r.addressee_id : r.requester_id)))];
    let profileMap = new Map();
    if (otherIds.length) {
      const { data: profs } = await sb.from('profiles').select('id,username,display_name').in('id', otherIds);
      for (const p of profs || []) profileMap.set(p.id, p);
    }

    const friends = [], incoming = [], outgoing = [];
    for (const r of rows || []) {
      const isMine = r.requester_id === uid;
      const otherId = isMine ? r.addressee_id : r.requester_id;
      const other = profileMap.get(otherId);
      if (!other) continue;
      const entry = { friendship_id: r.id, user_id: other.id, username: other.username, display_name: other.display_name || other.username, status: r.status };
      if (r.status === 'accepted') friends.push(entry);
      else if (r.status === 'pending' && !isMine) incoming.push(entry);
      else if (r.status === 'pending' && isMine) outgoing.push(entry);
    }
    FR.friends = friends; FR.incoming = incoming; FR.outgoing = outgoing;
    if (otherIds.length) {
      const { data: pres } = await sb.from('user_presence').select('user_id,status,last_seen').in('user_id', otherIds);
      FR.presenceMap.clear();
      for (const p of pres || []) FR.presenceMap.set(p.user_id, p);
    }
    frRenderAll();
  } catch (e) { ; }
}

function frPresenceOf(userId) {
  const p = FR.presenceMap.get(userId);
  if (!p) return 'offline';
  const ageMs = Date.now() - new Date(p.last_seen).getTime();
  if (ageMs > 60000) return 'offline'; // stale heartbeat = treat as offline
  return p.status;
}

/* ---------- rendering ---------- */
function frInitials(name) { return (name || '?').trim().slice(0, 2).toUpperCase(); }

function frRenderAll() {
  $('fr-count-list').textContent = FR.friends.length;
  $('fr-count-req').textContent = FR.incoming.length;
  $('friends-badge-dot').classList.toggle('hidden', FR.incoming.length === 0);

  // Friend list
  const list = $('fr-list');
  list.innerHTML = FR.friends.map((f) => {
    const st = frPresenceOf(f.user_id);
    const canPlay = st === 'online';
    return `<div class="fr-row" data-uid="${f.user_id}">
      <div class="fr-avatar">${frInitials(f.display_name)}<span class="fr-dot ${st}"></span></div>
      <div class="fr-info"><div class="fr-name">${escHtml(f.display_name)}</div><div class="fr-name-sub">${st === 'online' ? 'Online' : st === 'in_match' ? 'In a match' : 'Offline'}</div></div>
      <div class="fr-actions">
        <button class="btn small ${canPlay ? '' : 'ghost'}" data-act="challenge" ${canPlay ? '' : 'disabled'}><span>Play</span></button>
        <button class="fr-icon-btn decline" data-act="remove" title="Remove friend">✕</button>
      </div>
    </div>`;
  }).join('');
  $('fr-list-empty').classList.toggle('hidden', FR.friends.length > 0);

  // Requests
  const inWrap = $('fr-req-in');
  inWrap.innerHTML = FR.incoming.map((f) => `<div class="fr-row" data-uid="${f.user_id}" data-friendship="${f.friendship_id}">
    <div class="fr-avatar">${frInitials(f.display_name)}</div>
    <div class="fr-info"><div class="fr-name">${escHtml(f.display_name)}</div><div class="fr-name-sub">Wants to be friends</div></div>
    <div class="fr-actions">
      <button class="fr-icon-btn accept" data-act="accept" title="Accept">✓</button>
      <button class="fr-icon-btn decline" data-act="decline" title="Decline">✕</button>
    </div>
  </div>`).join('');
  $('fr-req-in-empty').classList.toggle('hidden', FR.incoming.length > 0);

  const outWrap = $('fr-req-out');
  outWrap.innerHTML = FR.outgoing.map((f) => `<div class="fr-row" data-uid="${f.user_id}" data-friendship="${f.friendship_id}">
    <div class="fr-avatar">${frInitials(f.display_name)}</div>
    <div class="fr-info"><div class="fr-name">${escHtml(f.display_name)}</div><div class="fr-name-sub">Request sent</div></div>
    <div class="fr-actions"><button class="fr-icon-btn decline" data-act="cancel" title="Cancel">✕</button></div>
  </div>`).join('');
  $('fr-req-out-empty').classList.toggle('hidden', FR.outgoing.length > 0);
}

/* ---------- actions ---------- */
async function frSendRequest(targetId) {
  if (!frRequireLogin()) return;
  if (targetId === cloudUser.id) { toast("That's you!"); return; }
  try {
    // If the other person already requested us, accept instead of duplicating.
    const { data: reverse } = await sb.from('friendships').select('id,status').eq('requester_id', targetId).eq('addressee_id', cloudUser.id).maybeSingle();
    if (reverse && reverse.status === 'pending') {
      await sb.from('friendships').update({ status: 'accepted' }).eq('id', reverse.id);
      toast('Friend request accepted!');
    } else {
      const { error } = await sb.from('friendships').insert({ requester_id: cloudUser.id, addressee_id: targetId, status: 'pending' });
      if (error) { if (error.code === '23505') toast('Request already sent.'); else throw error; return; }
      toast('Friend request sent!');
    }
    frLoadAll();
  } catch (e) { toast('Could not send request.'); ; }
}
async function frRespond(friendshipId, status) {
  try {
    if (status === 'declined') await sb.from('friendships').delete().eq('id', friendshipId);
    else await sb.from('friendships').update({ status }).eq('id', friendshipId);
    frLoadAll();
  } catch (e) { toast('Action failed.'); ; }
}
async function frRemove(friendshipId) {
  try { await sb.from('friendships').delete().eq('id', friendshipId); frLoadAll(); }
  catch (e) { toast('Could not remove friend.'); }
}
async function frSearch(query) {
  const q = query.trim();
  if (!q) return [];
  try {
    const isCode = /^\d{1,5}$/.test(q); // friend_code is numeric, up to 5 digits
    let req = sb.from('profiles').select('id,username,display_name,friend_code').limit(8);
    req = isCode ? req.eq('friend_code', q.padStart(5, '0')) : req.ilike('username', `%${q}%`);
    const { data, error } = await req;
    if (error) throw error;
    return (data || []).filter((u) => u.id !== frMyId());
  } catch (e) { ; return []; }
}
function frRelationLabel(userId) {
  if (FR.friends.some((f) => f.user_id === userId)) return 'friend';
  if (FR.outgoing.some((f) => f.user_id === userId)) return 'pending_out';
  if (FR.incoming.some((f) => f.user_id === userId)) return 'pending_in';
  return 'none';
}
async function frRenderSearch(query) {
  const results = await frSearch(query);
  const wrap = $('fr-search-results');
  wrap.innerHTML = results.map((u) => {
    const rel = frRelationLabel(u.id);
    const btn = rel === 'friend' ? `<button class="btn ghost small" disabled><span>Friends</span></button>`
      : rel === 'pending_out' ? `<button class="btn ghost small" disabled><span>Requested</span></button>`
      : rel === 'pending_in' ? `<button class="btn small" data-act="accept-uid" data-uid="${u.id}"><span>Accept</span></button>`
      : `<button class="btn small" data-act="add" data-uid="${u.id}"><span>Add</span></button>`;
    return `<div class="fr-row"><div class="fr-avatar">${frInitials(u.display_name || u.username)}</div>
      <div class="fr-info"><div class="fr-name">${escHtml(u.display_name || u.username)}</div><div class="fr-name-sub">ID ${escHtml(u.friend_code || '')}</div></div>
      <div class="fr-actions">${btn}</div></div>`;
  }).join('');
  $('fr-search-empty').classList.toggle('hidden', results.length > 0);
}

/* ---------- screen wiring ---------- */
function frSetTab(tab) {
  FR.tab = tab;
  document.querySelectorAll('#fr-tabs .fr-tab').forEach((b) => b.classList.toggle('on', b.dataset.tab === tab));
  document.querySelectorAll('.fr-pane').forEach((p) => p.classList.add('hidden'));
  $('fr-pane-' + tab).classList.remove('hidden');
}
function enterFriends() {
  if (!frRequireLogin()) return;
  match.screen = 'friends';
  showScreen('scr-friends');
  $('fr-myuid').textContent = cloudProfile?.friend_code || '—';
  frSetTab('list');
  frLoadAll();
}
$('btn-hub-friends').addEventListener('click', () => { audio.ui(); enterFriends(); });
$('fr-back').addEventListener('click', () => { audio.ui(); enterMenu(); });
$('fr-tabs').addEventListener('click', (e) => { const b = e.target.closest('.fr-tab'); if (b) frSetTab(b.dataset.tab); });
$('fr-myuid-wrap').addEventListener('click', () => {
  if (!cloudProfile?.friend_code) return;
  navigator.clipboard?.writeText(cloudProfile.friend_code).then(() => toast('ID copied!')).catch(() => {});
});
$('fr-search-btn').addEventListener('click', () => frRenderSearch($('fr-search-input').value));
$('fr-search-input').addEventListener('keydown', (e) => { if (e.key === 'Enter') frRenderSearch($('fr-search-input').value); });

$('fr-list').addEventListener('click', (e) => {
  const row = e.target.closest('.fr-row'); if (!row) return;
  const uid = row.dataset.uid; const act = e.target.closest('[data-act]')?.dataset.act;
  if (act === 'challenge') roomChallenge(uid, row.querySelector('.fr-name').textContent);
  else if (act === 'remove') frRemove(FR.friends.find((f) => f.user_id === uid)?.friendship_id);
});
$('fr-req-in').addEventListener('click', (e) => {
  const row = e.target.closest('.fr-row'); if (!row) return;
  const act = e.target.closest('[data-act]')?.dataset.act;
  if (act === 'accept') frRespond(row.dataset.friendship, 'accepted');
  else if (act === 'decline') frRespond(row.dataset.friendship, 'declined');
});
$('fr-req-out').addEventListener('click', (e) => {
  const row = e.target.closest('.fr-row'); if (!row) return;
  if (e.target.closest('[data-act="cancel"]')) frRemove(row.dataset.friendship);
});
$('fr-search-results').addEventListener('click', (e) => {
  const btn = e.target.closest('[data-act]'); if (!btn) return;
  const uid = btn.dataset.uid;
  if (btn.dataset.act === 'add') frSendRequest(uid);
  else if (btn.dataset.act === 'accept-uid') {
    const fr = FR.incoming.find((f) => f.user_id === uid);
    if (fr) frRespond(fr.friendship_id, 'accepted');
  }
});

/* ---------- realtime subscriptions (friendships + presence) ---------- */
function frSubscribeRealtime() {
  if (!cloudUser || FR.channel) return;
  FR.channel = sb.channel('friends-' + cloudUser.id)
    .on('postgres_changes', { event: '*', schema: 'public', table: 'friendships', filter: `requester_id=eq.${cloudUser.id}` }, frLoadAll)
    .on('postgres_changes', { event: '*', schema: 'public', table: 'friendships', filter: `addressee_id=eq.${cloudUser.id}` }, frLoadAll)
    .on('postgres_changes', { event: '*', schema: 'public', table: 'user_presence' }, (payload) => {
      const row = payload.new && payload.new.user_id ? payload.new : payload.old;
      if (row) FR.presenceMap.set(row.user_id, row);
      if (match.screen === 'friends') frRenderAll();
    })
    .on('postgres_changes', { event: '*', schema: 'public', table: 'match_rooms', filter: `guest_id=eq.${cloudUser.id}` }, roomOnIncomingChange)
    .on('postgres_changes', { event: '*', schema: 'public', table: 'match_rooms', filter: `host_id=eq.${cloudUser.id}` }, roomOnHostChange)
    .subscribe();
}

/* ==========================================================================
   🔌 WEBRTC — peer-to-peer data channel between two friends.
   Signaling (offer/answer/ICE candidates) rides on the match_rooms row via
   Supabase Realtime; once connected, all traffic goes directly device-to-
   device over the RTCDataChannel — Supabase is never in that path.
   ========================================================================== */
// STUN alone only works when both devices can form a direct route (open
// NAT/same network). Mobile data and many home routers use symmetric NAT,
// which STUN cannot punch through — ICE just sits in "checking" forever
// with no error, which is exactly the "stuck creating peer id for hours"
// symptom. A TURN relay is the fallback for that case: free public
// Open Relay Project credentials are used here so P2P still works with
// zero setup (no server to run/pay for) for the vast majority of pairs;
// swap in a paid TURN provider later if this free tier gets flaky under
// load.
const RTC_CONFIG = {
  iceServers: [
    { urls: ['stun:stun.l.google.com:19302', 'stun:stun1.l.google.com:19302'] },
    { urls: 'turn:openrelay.metered.ca:80', username: 'openrelayproject', credential: 'openrelayproject' },
    { urls: 'turn:openrelay.metered.ca:443', username: 'openrelayproject', credential: 'openrelayproject' },
    { urls: 'turn:openrelay.metered.ca:443?transport=tcp', username: 'openrelayproject', credential: 'openrelayproject' },
  ],
};
// Hard ceiling on how long a connection attempt is allowed to sit
// unresolved before we give up and hand control back to the user with a
// clear message, instead of an infinite spinner.
const RTC_CONNECT_TIMEOUT_MS = 15000;
const RM = { roomId: null, isHost: false, pc: null, dc: null, peerName: '', connected: false, connectTimeout: null };

function roomShow(title, sub, opts = {}) {
  $('room-title').textContent = title;
  $('room-sub').textContent = sub || '';
  $('room-spinner').classList.toggle('hidden', !!opts.hideSpinner);
  $('room-accept').classList.toggle('hidden', !opts.showAccept);
  $('room-decline').classList.toggle('hidden', !opts.showAccept);
  $('room-cancel').classList.toggle('hidden', !!opts.showAccept);
  $('room-backdrop').classList.remove('hidden');
}
function roomHide() { $('room-backdrop').classList.add('hidden'); }

async function roomChallenge(friendId, friendName) {
  if (!frRequireLogin()) return;
  try {
    const { data, error } = await sb.from('match_rooms').insert({ host_id: cloudUser.id, guest_id: friendId, status: 'pending' }).select().single();
    if (error) throw error;
    RM.roomId = data.id; RM.isHost = true; RM.peerName = friendName;
    roomShow('Challenging ' + friendName, 'Waiting for them to accept…');
    // No separate frWatchRoom subscription here — the always-on channel from
    // frSubscribeRealtime() (registered once at sign-in) already listens for
    // every match_rooms row where this user is host or guest. A second,
    // per-room subscription used to be created here AND on the guest's side
    // in roomOnIncomingChange below, so every update to the row fired
    // frHandleRoomUpdate() TWICE, sending duplicate/conflicting SDP answers
    // and ICE candidates — this was the actual cause of "only one side ever
    // seems to progress" and the invite flow feeling completely broken.
  } catch (e) { toast('Could not send challenge.'); ; }
}

function roomOnIncomingChange(payload) {
  const row = payload.new;
  if (!row || row.host_id === cloudUser.id) return;
  if (payload.eventType === 'INSERT' && row.status === 'pending') {
    RM.roomId = row.id; RM.isHost = false;
    sb.from('profiles').select('display_name,username').eq('id', row.host_id).maybeSingle().then(({ data }) => {
      RM.peerName = (data && (data.display_name || data.username)) || 'A friend';
      roomShow(RM.peerName + ' wants to play!', 'Accept to start a match', { showAccept: true, hideSpinner: true });
    });
  } else {
    frHandleRoomUpdate(row, 'guest');
  }
}
function roomOnHostChange(payload) {
  const row = payload.new;
  if (!row || row.id !== RM.roomId) return;
  frHandleRoomUpdate(row, 'host');
}

let roomWatchChannel = null; // kept for roomCleanup's unsubscribe safety-net; frWatchRoom itself is no longer used anywhere (see the comment in roomChallenge above)

async function frHandleRoomUpdate(row, side) {
  if (row.status === 'declined') { toast(RM.peerName + ' declined.'); roomHide(); roomCleanup(); return; }
  if (row.status === 'cancelled') { toast('Challenge cancelled.'); roomHide(); roomCleanup(); return; }

  if (side === 'host') {
    if (row.status === 'accepted' && !RM.pc) {
      roomShow('Connecting to ' + RM.peerName + '…', 'Setting up peer-to-peer link');
      await rtcHostCreateOffer(row.id);
    }
    if (row.answer_sdp && RM.pc && !RM.pc.currentRemoteDescription) {
      await RM.pc.setRemoteDescription(row.answer_sdp);
    }
    if (row.guest_ice && row.guest_ice.length) await rtcApplyIce(row.guest_ice, RM._appliedGuestIce || 0, (n) => RM._appliedGuestIce = n);
  } else {
    if (row.offer_sdp && RM.pc && !RM.pc.currentRemoteDescription) {
      await RM.pc.setRemoteDescription(row.offer_sdp);
      const answer = await RM.pc.createAnswer();
      await RM.pc.setLocalDescription(answer);
      await sb.from('match_rooms').update({ answer_sdp: answer }).eq('id', row.id);
    }
    if (row.host_ice && row.host_ice.length) await rtcApplyIce(row.host_ice, RM._appliedHostIce || 0, (n) => RM._appliedHostIce = n);
  }
}
async function rtcApplyIce(list, fromIdx, setIdx) {
  for (let i = fromIdx; i < list.length; i++) {
    try { await RM.pc.addIceCandidate(list[i]); } catch (e) { ; }
  }
  setIdx(list.length);
}

function rtcSetupPeerConnection(roomId, side) {
  const pc = new RTCPeerConnection(RTC_CONFIG);
  RM.pc = pc;
  const iceField = side === 'host' ? 'host_ice' : 'guest_ice';
  let pending = [];
  let flushTimer = null;
  // Start (or restart) the connect-timeout the moment we begin trying to
  // link up. Cleared the instant we actually reach 'connected' below —
  // see onconnectionstatechange. If it fires first, we know ICE is stuck
  // (almost always a NAT/TURN issue) rather than waiting forever.
  clearTimeout(RM.connectTimeout);
  RM.connectTimeout = setTimeout(() => {
    if (RM.connected) return; // already succeeded, nothing to do
    ;
    toast('Could not connect — try again.');
    if (RM.isHost && RM.roomId) sb.from('match_rooms').update({ status: 'cancelled' }).eq('id', RM.roomId).then(() => {}).catch(() => {});
    roomHide();
    roomCleanup();
  }, RTC_CONNECT_TIMEOUT_MS);
  pc.onicecandidate = (e) => {
    if (!e.candidate) return;
    pending.push(e.candidate.toJSON());
    clearTimeout(flushTimer);
    flushTimer = setTimeout(async () => {
      const batch = pending.splice(0, pending.length);
      const { data } = await sb.from('match_rooms').select(iceField).eq('id', roomId).maybeSingle();
      const merged = [...(data?.[iceField] || []), ...batch];
      await sb.from('match_rooms').update({ [iceField]: merged }).eq('id', roomId);
    }, 250);
  };
  let disconnectGraceTimer = null;
  pc.onconnectionstatechange = () => {
    if (pc.connectionState === 'connected') {
      clearTimeout(disconnectGraceTimer); disconnectGraceTimer = null;
      clearTimeout(RM.connectTimeout); RM.connectTimeout = null;
      RM.connected = true;
      roomHide();
      frTouchPresence('in_match');
      if (RM.isHost) netHostLaunchMatch();
    } else if (pc.connectionState === 'disconnected') {
      // 'disconnected' is often just a brief ICE hiccup (network blip, wifi
      // handoff, a late-arriving candidate) — WebRTC frequently recovers
      // from it on its own within a couple seconds. Ending the match
      // instantly on this was force-quitting the guest out of a match the
      // host was still playing. Give it a grace window; only actually end
      // things if it hasn't recovered by then.
      clearTimeout(disconnectGraceTimer);
      disconnectGraceTimer = setTimeout(() => {
        if (pc.connectionState === 'disconnected') {
          if (RM.connected) toast('Connection lost.');
          RM.connected = false;
          if (NET.mode !== 'off') netEndMatch('Connection lost.');
        }
      }, 6000);
    } else if (['failed', 'closed'].includes(pc.connectionState)) {
      clearTimeout(disconnectGraceTimer); disconnectGraceTimer = null;
      clearTimeout(RM.connectTimeout); RM.connectTimeout = null;
      if (RM.connected) toast('Connection lost.');
      else { toast('Could not connect — try again.'); roomHide(); }
      RM.connected = false;
      if (NET.mode !== 'off') netEndMatch('Connection lost.');
      roomCleanup();
    }
  };
  return pc;
}
function rtcSetupDataChannel(dc) {
  RM.dc = dc;
  dc.onopen = () => {};
  dc.onclose = () => {
    ;
    // Don't force-end the match here — the peer connection's own state
    // (handled in rtcSetupPeerConnection, with its disconnect grace period)
    // is the authoritative signal. The data channel can legitimately blip
    // closed/reopen during ICE renegotiation while the connection itself
    // is still fine; ending the match on this alone was a second path that
    // could kick a player out mid-match even though play could continue.
  };
  dc.onmessage = (e) => {
    try { rtcOnMessage(JSON.parse(e.data)); } catch (err) { /* ignore malformed */ }
  };
}
function rtcSend(obj) {
  if (RM.dc && RM.dc.readyState === 'open') RM.dc.send(JSON.stringify(obj));
}
function rtcOnMessage(msg) {
  if (msg.t === 'ping') { rtcSend({ t: 'pong', at: Date.now() }); return; }
  if (msg.t === 'matchStart') { netGuestOnMatchStart(msg); return; }   // guest receives
  if (msg.t === 'input') { netHostOnRemoteInput(msg); return; }        // host receives
  if (msg.t === 'action') { netHostOnRemoteAction(msg); return; }      // host receives
  if (msg.t === 'snap') { netGuestApplySnapshot(msg); return; }        // guest receives
  if (msg.t === 'goal') { netGuestShowGoal(msg); return; }             // guest receives
  if (msg.t === 'matchEnd') { netEndMatch(msg.reason || 'Match ended.'); return; }
}
/* Guest-side goal announcement. The rich showGoalCard() path needs a real
   Player object (stats/rarity/card image via cardForPlayer) which the guest
   was never sent — only a name string, to keep this message tiny and
   instant. Rather than fake up a fuller card from partial data, this is an
   honest, simpler text announcement: still tells you exactly who scored and
   for which side, which is the actual gap being fixed (previously: nothing
   at all, the guest's score just silently ticked up in the corner). */
function netGuestShowGoal(msg) {
  match.score = msg.score;
  updateScoreboard();
  const teamName = teamDefs[msg.team] ? teamDefs[msg.team].name : (msg.team === 0 ? 'Home' : 'Away');
  const headline = msg.scorerName ? `⚽ GOAL! ${msg.scorerName} (${teamName})` : `⚽ GOAL! ${teamName}`;
  toast(headline);
  say(headline + (msg.celebName ? ' — ' + msg.celebName : ''));
  netShakeSide = msg.team === 0 ? 1 : -1;
  netShake = 1;
  if (typeof UAStadium !== 'undefined') UAStadium.goalHit(msg.team);
  bumpScore(msg.team);
}

/* ==========================================================================
   🕹️ NETWORKED MATCH — host-authoritative sim, guest is input+render only.
   -------------------------------------------------------------------------
   HOST:  runs startMatch() exactly as single-player does, except team 1's
          active player is fed from inputP2/userActionP2 (populated by
          packets from the guest) instead of aiUpdate. Every ~50ms it
          streams a compact snapshot of the ball + all 22 players + match
          state/score/clock to the guest.
   GUEST: never calls updateControlled/aiUpdate/player.update()'s physics
          half/updateMatchFlow/updateBall — all of those are host-only.
          The guest only (a) sends its stick+button input to the host and
          (b) paints incoming snapshots straight onto the same live
          Three.js objects (pos/vel are direct mesh.position references,
          see Player/createBall), then runs the cosmetic-only animation
          half of Player.update so movement still looks smooth between
          the ~20Hz snapshots instead of teleporting.
   ========================================================================== */
async function netHostLaunchMatch() {
  reportedFrameErrors.clear();
  NET.mode = 'host';
  controlledP2 = null;
  teamDefs = [TEAMS[settings.homeTeam], TEAMS[settings.awayTeam]];
  squads = [generateSquad(teamDefs[0]), generateSquad(teamDefs[1])];
  benches = [generateBench(teamDefs[0]), generateBench(teamDefs[1])];
  subsUsed = [0, 0];
  // startMatch() is async: it refreshes the cloud player registry and, if
  // any players are registered, buildSquadsFromRegistry() OVERWRITES the
  // squads set above in place with the real roster (names/stats/model_data)
  // from UA FC MANAGER. We must await that fully before reading `squads`
  // below, or the guest gets the stale generateSquad() placeholders instead
  // of your actual registered players/models.
  await startMatch();
  controlledP2 = players.find((p) => p.team === 1 && p.role === 'ST') || players.find((p) => p.team === 1);
  // Send the FINAL squads (post-registry-refresh) so the guest renders the
  // exact same players/models — positions/score sync fine either way via
  // snapshots, but everyone would look different (or use placeholder
  // generated players instead of your real roster) on each screen without
  // this.
  rtcSend({
    t: 'matchStart',
    homeTeam: settings.homeTeam, awayTeam: settings.awayTeam,
    diff: settings.diff, halfDur: settings.halfDur,
    squads,
    homeKit: { c1: TEAMS[settings.homeTeam].c1, c2: TEAMS[settings.homeTeam].c2 },
    hostName: cloudProfile?.display_name || cloudProfile?.username || 'Host',
  });
  toast('⚽ Match started — you are Home');
}
function netGuestOnMatchStart(msg) {
  reportedFrameErrors.clear();
  NET.mode = 'guest';
  settings.homeTeam = msg.homeTeam;
  settings.awayTeam = msg.awayTeam;
  settings.diff = msg.diff;
  settings.halfDur = msg.halfDur;
  match.screen = 'match';
  match.stats = freshMatchStats();
  match.state = 'idle';
  match.paused = false;
  match.half = 1;
  match.kickTeam = 0;
  match.time = 0;
  match.score = [0, 0];
  showScreen(null);
  teamDefs = [TEAMS[settings.homeTeam], TEAMS[settings.awayTeam]];
  // Use the HOST's actual kit colors, not whatever this device's own
  // Locker Room happens to have saved for that team slot — the host is the
  // one whose match this is, so their kit is the one that must render here.
  // Stash this device's own colors first so netEndMatch can restore them —
  // otherwise this in-place overwrite would permanently corrupt the guest's
  // own single-player kit for that team after the friend match ends.
  if (msg.homeKit) {
    NET.guestOrigKit = { c1: teamDefs[0].c1, c2: teamDefs[0].c2 };
    teamDefs[0].c1 = msg.homeKit.c1; teamDefs[0].c2 = msg.homeKit.c2; teamDefs[0]._kitTex = null;
  }
  squads = msg.squads; // host's final squads post-registry-refresh — not re-rolled or re-fetched locally
  spawnTeams();
  // Guest's camera/HUD follow their own team-1 player locally; this never
  // runs physics for it (see the loop gating below) — it's purely what
  // the camera/indicator/HUD read, kept in sync by incoming snapshots.
  controlled = players.find((p) => p.team === 1 && p.role === 'ST') || players.find((p) => p.team === 1);
  updateScoreboard();
  setupControlsForDevice();
  toast('⚽ Match started — you are Away');
}
function netHostOnRemoteInput(msg) {
  if (NET.mode !== 'host') return;
  inputP2.mx = msg.mx; inputP2.my = msg.my; inputP2.sprint = !!msg.sprint;
}
function netHostOnRemoteAction(msg) {
  if (NET.mode !== 'host') return;
  if (msg.charging !== undefined) inputP2.charging = msg.charging;
  if (msg.power !== undefined) inputP2.power = msg.power;
  if (msg.kind) userActionP2(msg.kind);
}
/* Compact per-player fields only — no THREE objects, no functions, nothing
   that JSON.stringify can't round-trip cleanly. Kept short since this goes
   out ~20x/sec. */
function netBuildSnapshot() {
  return {
    t: 'snap', seq: ++NET.seq,
    score: match.score, half: match.half, clock: match.clock, state: match.state,
    ball: { x: r2(ball.pos.x), y: r2(ball.pos.y), z: r2(ball.pos.z), vx: r2(ball.vel.x), vy: r2(ball.vel.y), vz: r2(ball.vel.z) },
    players: players.map((p) => [r2(p.pos.x), r2(p.pos.z), r2(p.vel.x), r2(p.vel.z), r2(p.facing)]),
  };
}
function r2(n) { return Math.round(n * 100) / 100; }
function netGuestApplySnapshot(msg) {
  if (NET.mode !== 'guest') return;
  if (msg.seq <= NET.lastAppliedSeq) return; // out-of-order packet, drop it
  NET.lastAppliedSeq = msg.seq;
  match.score = msg.score; match.half = msg.half; match.clock = msg.clock; match.state = msg.state;
  if (ball) {
    ball.pos.set(msg.ball.x, msg.ball.y, msg.ball.z);
    ball.vel.set(msg.ball.vx, msg.ball.vy, msg.ball.vz);
  }
  for (let i = 0; i < players.length && i < msg.players.length; i++) {
    const p = players[i], d = msg.players[i];
    p.pos.x = d[0]; p.pos.z = d[1]; p.vel.x = d[2]; p.vel.z = d[3]; p.facing = d[4];
  }
  updateScoreboard();
}
function netEndMatch(reason) {
  if (NET.mode === 'off') return;
  NET.mode = 'off';
  controlledP2 = null;
  // Restore this device's own kit colors if we were a guest and had them
  // temporarily overwritten with the host's colors for that team slot.
  if (NET.guestOrigKit) {
    const def = TEAMS[settings.homeTeam];
    if (def) { def.c1 = NET.guestOrigKit.c1; def.c2 = NET.guestOrigKit.c2; def._kitTex = null; }
    NET.guestOrigKit = null;
  }
  toast(reason);
  frTouchPresence('online');
  roomCleanup();
  enterMenu();
}

async function rtcHostCreateOffer(roomId) {
  const pc = rtcSetupPeerConnection(roomId, 'host');
  // maxRetransmits:0 + ordered:false = unreliable, unordered delivery — the
  // correct mode for real-time position data. The DEFAULT (reliable+ordered,
  // same guarantees as TCP) was the actual cause of the severe multi-second/
  // multi-minute lag: one dropped packet forced the browser to retransmit it
  // and hold EVERY later snapshot in a queue until that one arrived, so the
  // guest kept falling further and further behind the live match instead of
  // just skipping a stale frame and catching up on the next one.
  const dc = pc.createDataChannel('match', { ordered: false, maxRetransmits: 0 });
  rtcSetupDataChannel(dc);
  const offer = await pc.createOffer();
  await pc.setLocalDescription(offer);
  await sb.from('match_rooms').update({ offer_sdp: offer, status: 'signaling' }).eq('id', roomId);
}
function rtcGuestAwaitDataChannel(roomId) {
  const pc = rtcSetupPeerConnection(roomId, 'guest');
  pc.ondatachannel = (e) => rtcSetupDataChannel(e.channel);
  return pc;
}

function roomCleanup() {
  clearTimeout(RM.connectTimeout); RM.connectTimeout = null;
  RM.pc?.close(); RM.pc = null; RM.dc = null; RM.connected = false;
  RM.roomId = null; RM._appliedGuestIce = 0; RM._appliedHostIce = 0;
  roomWatchChannel?.unsubscribe(); roomWatchChannel = null;
}

$('room-cancel').addEventListener('click', async () => {
  if (RM.roomId) await sb.from('match_rooms').update({ status: 'cancelled' }).eq('id', RM.roomId).then(() => {}).catch(() => {});
  roomHide(); roomCleanup();
});
$('room-decline').addEventListener('click', async () => {
  if (RM.roomId) await sb.from('match_rooms').update({ status: 'declined' }).eq('id', RM.roomId);
  roomHide(); roomCleanup();
});
$('room-accept').addEventListener('click', async () => {
  if (!RM.roomId) return;
  audio.init();
  roomShow('Connecting to ' + RM.peerName + '…', 'Setting up peer-to-peer link', { hideSpinner: false });
  rtcGuestAwaitDataChannel(RM.roomId);
  await sb.from('match_rooms').update({ status: 'accepted' }).eq('id', RM.roomId);
});


const LEAGUE_QUESTS = [
  { key: 'play_matches',   label: 'Play matches',          icon: '⚽', target: 1,  pts: 2  },
  { key: 'win_matches',    label: 'Win a match',           icon: '🏆', target: 1,  pts: 4  },
  { key: 'score_goals',    label: 'Score goals',           icon: '🥅', target: 3,  pts: 3  },
  { key: 'clean_sheets',   label: 'Keep a clean sheet',    icon: '🧤', target: 1,  pts: 5  },
  { key: 'assists',        label: 'Make assists',          icon: '🎯', target: 3,  pts: 3  },
  { key: 'tackles',        label: 'Win tackles',           icon: '🛡️', target: 10, pts: 2  },
  { key: 'daily_login',    label: 'Log in today',          icon: '📅', target: 1,  pts: 1  },
  { key: 'spend_coins',    label: 'Spend coins',           icon: '🪙', target: 1000, pts: 2 },
  { key: 'royale_pulls',   label: 'Luck Royale pulls',     icon: '🎰', target: 3,  pts: 2  },
  { key: 'mvp_awards',     label: 'Win Player of the Match', icon: '⭐', target: 1, pts: 6  },
];

// League-wide milestones — hit once per season by the SUM of all members'
// points. Reward mix set by the owner's intent ("all: coins, players, gems,
// more") scaled by milestone size; small ones are coin/gem drops, larger
// ones add a player pack, the top one is the season's big prize.
const LEAGUE_MILESTONES = [
  { pts: 10,   coins: 500,   gems: 0,  pack: null,          label: 'First Whistle'   },
  { pts: 50,   coins: 1500,  gems: 5,  pack: null,          label: 'Getting Going'   },
  { pts: 150,  coins: 3000,  gems: 15, pack: null,          label: 'On a Run'        },
  { pts: 400,  coins: 6000,  gems: 30, pack: 'bronze',       label: 'Squad Goals'     },
  { pts: 800,  coins: 10000, gems: 50, pack: 'silver',       label: 'Table Toppers'   },
  { pts: 1500, coins: 18000, gems: 90, pack: 'gold',         label: 'League Legends'  },
  { pts: 3000, coins: 30000, gems: 150, pack: 'gold',        label: 'Unstoppable'     },
  { pts: 5000, coins: 60000, gems: 300, pack: 'icon',        label: 'Hall of Fame'    },
];

let myLeague = null;          // row from `leagues`, or null if not in one
let myLeagueMembers = [];     // [{user_id, display_name, joined_at}]
let myLeagueProgress = {};    // { quest_key: totalProgressThisSeason }
let myLeagueClaimed = [];     // milestone pts already paid out this season
let leagueChatChannel = null;
let leagueCreatePhotoFile = null;
let leagueBrowseCache = [];

function leagueSeasonDaysLeft(startedAt) {
  const started = new Date(startedAt).getTime();
  const elapsed = (Date.now() - started) / 86400000;
  return Math.max(0, Math.ceil(LEAGUE_SEASON_DAYS - elapsed));
}
function leagueSeasonExpired(startedAt) {
  return leagueSeasonDaysLeft(startedAt) <= 0;
}
function leagueMediaUrl(path) {
  if (!path) return '';
  return getAssetUrl(LEAGUE_MEDIA_BUCKET, path) || '';
}
function leagueDisplayName() {
  return (cloudProfile && (cloudProfile.display_name || cloudProfile.username)) || (cloudUser && cloudUser.email.split('@')[0]) || 'Player';
}
// Daily login quest — guarded by a date-stamp stored in Supabase's
// user_game_state row (not localStorage) so signing in on a different
// device the same day still correctly skips a duplicate post.
async function leagueMarkDailyLogin() {
  if (!cloudUser) return;
  try {
    const todayKey = new Date().toISOString().slice(0, 10);
    const { data, error } = await sb.from('user_game_state').select('state').eq('user_id', cloudUser.id).maybeSingle();
    if (error) throw error;
    const state = (data && data.state) || {};
    if (state.lastLeagueDaily === todayKey) return;
    const { error: upErr } = await sb.from('user_game_state').upsert({
      user_id: cloudUser.id,
      state: { ...state, coins, vault, lastLeagueDaily: todayKey, savedAt: new Date().toISOString() },
    }, { onConflict: 'user_id' });
    if (upErr) throw upErr;
    await leagueRefreshMembership();
    if (myLeague) leaguePostQuestProgress('daily_login', 1);
  } catch (err) {
    ;
  }
}

async function enterLeagues() {
  match.screen = 'league';
  showScreen('scr-league');
  if (!cloudUser) {
    $('league-browse').classList.remove('hidden');
    $('league-home').classList.add('hidden');
    $('league-create').classList.add('hidden');
    $('league-browse-list').innerHTML = `<div class="league-empty">Sign in to join or create a league.</div>`;
    $('league-create-btn').classList.add('hidden');
    return;
  }
  await leagueRefreshMembership();
  if (myLeague) {
    await leagueEnterHome();
  } else {
    await leagueEnterBrowse();
  }
}

async function leagueRefreshMembership() {
  try {
    const { data: memberRow, error } = await sb.from('league_members')
      .select('league_id, leagues(*)')
      .eq('user_id', cloudUser.id).maybeSingle();
    if (error) throw error;
    myLeague = memberRow ? memberRow.leagues : null;
    if (myLeague && leagueSeasonExpired(myLeague.season_started_at)) {
      await leagueRolloverSeasonIfOwner(myLeague);
    }
  } catch (err) {
    ;
    myLeague = null;
  }
}

// Season rollover: any client that notices the 30 days are up resets
// points/progress/claims for that league. Whichever member opens the
// league first after expiry triggers it — the league itself (name, photo,
// members) is untouched, only points/rank/progress reset.
async function leagueRolloverSeasonIfOwner(league) {
  try {
    const nowIso = new Date().toISOString();
    const { error } = await sb.from('leagues')
      .update({ points: 0, season_started_at: nowIso })
      .eq('id', league.id).eq('season_started_at', league.season_started_at);
    if (error) throw error;
    league.points = 0;
    league.season_started_at = nowIso;
    await sb.from('league_progress').delete().eq('league_id', league.id);
    await sb.from('league_milestones_claimed').delete().eq('league_id', league.id);
  } catch (err) {
    ;
  }
}

/* ---------- BROWSE ---------- */
async function leagueEnterBrowse() {
  $('league-header-title').textContent = 'LEAGUES';
  $('league-home').classList.add('hidden');
  $('league-create').classList.add('hidden');
  $('league-browse').classList.remove('hidden');
  $('league-create-btn').classList.add('hidden');
  $('league-browse-list').innerHTML = `<div class="league-empty">Loading leagues…</div>`;
  try {
    const { data, error } = await sb.from('leagues').select('*').order('points', { ascending: false }).limit(100);
    if (error) throw error;
    leagueBrowseCache = data || [];
    renderLeagueBrowseList();
  } catch (err) {
    ;
    $('league-browse-list').innerHTML = `<div class="league-empty">Couldn't load leagues — try again.</div>`;
  }
}
function renderLeagueBrowseList() {
  const list = $('league-browse-list');
  if (!leagueBrowseCache.length) {
    list.innerHTML = `<div class="league-empty">No leagues yet. Be the first to create one!</div>`;
    return;
  }
  list.innerHTML = leagueBrowseCache.map((l) => {
    const full = (l.member_count || 0) >= LEAGUE_MAX_MEMBERS;
    return `
    <div class="league-row" data-id="${l.id}">
      <img class="league-row-crest" src="${l.photo_path ? leagueMediaUrl(l.photo_path) : ''}" alt="" onerror="this.style.display='none'" />
      <div class="league-row-info">
        <div class="league-row-name">${escHtmlGame(l.name)}</div>
        <div class="league-row-meta">${l.member_count || 0}/${LEAGUE_MAX_MEMBERS} members · ${(l.points || 0).toLocaleString()} pts</div>
      </div>
      <button class="btn small ${full ? 'ghost' : 'gold'} league-join-btn" data-id="${l.id}" ${full ? 'disabled' : ''}>${full ? 'Full' : 'Join'}</button>
    </div>`;
  }).join('');
  qsa('.league-join-btn', list).forEach((btn) => {
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      if (btn.disabled) return;
      leagueJoin(btn.dataset.id);
    });
  });
}
async function leagueJoin(leagueId) {
  audio.ui();
  try {
    // Re-check capacity right before inserting to avoid a race where two
    // players both see 19/20 and both try to join the last slot.
    const { data: current, error: checkErr } = await sb.from('leagues').select('member_count').eq('id', leagueId).maybeSingle();
    if (checkErr) throw checkErr;
    if (!current || current.member_count >= LEAGUE_MAX_MEMBERS) { toast('That league just filled up.'); leagueEnterBrowse(); return; }
    const { error } = await sb.from('league_members').insert({ league_id: leagueId, user_id: cloudUser.id });
    if (error) throw error;
    await sb.from('leagues').update({ member_count: current.member_count + 1 }).eq('id', leagueId);
    await leagueRefreshMembership();
    await leagueEnterHome();
  } catch (err) {
    ;
    toast('Could not join league — try again.');
  }
}

/* ---------- CREATE ---------- */
$('league-open-create') && $('league-open-create').addEventListener('click', () => { audio.ui(); leagueShowCreate(); });
function leagueShowCreate() {
  $('league-header-title').textContent = 'CREATE LEAGUE';
  $('league-browse').classList.add('hidden');
  $('league-home').classList.add('hidden');
  $('league-create').classList.remove('hidden');
  $('league-create-name').value = '';
  leagueCreatePhotoFile = null;
  $('league-create-photo-preview').classList.add('hidden');
  $('league-create-photo-placeholder').classList.remove('hidden');
}
$('league-create-btn') && $('league-create-btn').addEventListener('click', () => { audio.ui(); leagueShowCreate(); });
$('league-create-photo-btn').addEventListener('click', () => $('league-create-photo-input').click());
$('league-create-photo-input').addEventListener('change', (e) => {
  const file = e.target.files && e.target.files[0];
  if (!file) return;
  if (!/^image\/(png|jpeg|webp)$/.test(file.type)) { toast('PNG, JPG or WEBP only.'); return; }
  if (file.size > 3 * 1024 * 1024) { toast('Image must be under 3MB.'); return; }
  leagueCreatePhotoFile = file;
  const preview = $('league-create-photo-preview');
  preview.src = URL.createObjectURL(file);
  preview.classList.remove('hidden');
  $('league-create-photo-placeholder').classList.add('hidden');
});
$('league-create-submit').addEventListener('click', async () => {
  audio.ui();
  const name = $('league-create-name').value.trim();
  if (!name) { toast('Enter a league name.'); return; }
  if (name.length < 3) { toast('Name must be at least 3 characters.'); return; }
  if (!cloudUser) { toast('Sign in first.'); return; }
  const btn = $('league-create-submit');
  btn.disabled = true;
  try {
    let photoPath = null;
    if (leagueCreatePhotoFile) {
      const ext = (leagueCreatePhotoFile.type.split('/')[1] || 'png').replace('jpeg', 'jpg');
      photoPath = `${cloudUser.id}/${Date.now()}.${ext}`;
      await uploadAsset(leagueCreatePhotoFile, LEAGUE_MEDIA_BUCKET, photoPath);
    }
    const { data: league, error } = await sb.from('leagues').insert({
      name, photo_path: photoPath, owner_id: cloudUser.id,
      member_count: 1, points: 0, season_started_at: new Date().toISOString(),
    }).select().single();
    if (error) throw error;
    const { error: memErr } = await sb.from('league_members').insert({ league_id: league.id, user_id: cloudUser.id });
    if (memErr) throw memErr;
    myLeague = league;
    toast('League created!');
    await leagueEnterHome();
  } catch (err) {
    ;
    toast('Could not create league — try again.');
  } finally {
    btn.disabled = false;
  }
});

/* ---------- HOME (joined league dashboard) ---------- */
async function leagueEnterHome() {
  if (!myLeague) { leagueEnterBrowse(); return; }
  $('league-header-title').textContent = myLeague.name.toUpperCase();
  $('league-browse').classList.add('hidden');
  $('league-create').classList.add('hidden');
  $('league-home').classList.remove('hidden');
  $('league-create-btn').classList.add('hidden');
  $('league-leave-label').textContent = myLeague.owner_id === cloudUser.id ? 'Disband League' : 'Leave League';

  $('league-home-photo').src = myLeague.photo_path ? leagueMediaUrl(myLeague.photo_path) : '';
  $('league-home-name').textContent = myLeague.name;
  $('league-home-members').textContent = `${myLeague.member_count}/${LEAGUE_MAX_MEMBERS}`;
  $('league-home-days').textContent = `${leagueSeasonDaysLeft(myLeague.season_started_at)}d left in season`;

  await Promise.all([leagueLoadMembers(), leagueLoadProgress(), leagueLoadClaimed()]);
  renderLeaguePoints();
  renderLeagueQuests();
  renderLeagueMembers();
  renderLeagueMilestones();
  leagueSubscribeRealtime();
  leagueLoadChat();
}

async function leagueLoadMembers() {
  try {
    const { data, error } = await sb.from('league_members')
      .select('user_id, joined_at, profiles(display_name, username)')
      .eq('league_id', myLeague.id).order('joined_at', { ascending: true });
    if (error) throw error;
    myLeagueMembers = (data || []).map((r) => ({
      user_id: r.user_id, joined_at: r.joined_at,
      display_name: (r.profiles && (r.profiles.display_name || r.profiles.username)) || 'Player',
    }));
  } catch (err) {
    ;
    myLeagueMembers = [];
  }
}
async function leagueLoadProgress() {
  try {
    const { data, error } = await sb.from('league_progress')
      .select('quest_key, progress').eq('league_id', myLeague.id).eq('season_started_at', myLeague.season_started_at);
    if (error) throw error;
    myLeagueProgress = {};
    for (const row of (data || [])) {
      myLeagueProgress[row.quest_key] = (myLeagueProgress[row.quest_key] || 0) + row.progress;
    }
  } catch (err) {
    ;
    myLeagueProgress = {};
  }
}
async function leagueLoadClaimed() {
  try {
    const { data, error } = await sb.from('league_milestones_claimed')
      .select('milestone_pts').eq('league_id', myLeague.id).eq('season_started_at', myLeague.season_started_at);
    if (error) throw error;
    myLeagueClaimed = (data || []).map((r) => r.milestone_pts);
  } catch (err) {
    ;
    myLeagueClaimed = [];
  }
}

function renderLeaguePoints() {
  const pts = myLeague.points || 0;
  $('league-points-val').textContent = pts.toLocaleString();
  const next = LEAGUE_MILESTONES.find((m) => m.pts > pts);
  $('league-points-next-val').textContent = next ? next.pts.toLocaleString() : 'MAX';
  const prevPts = [...LEAGUE_MILESTONES].reverse().find((m) => m.pts <= pts);
  const floor = prevPts ? prevPts.pts : 0;
  const ceil = next ? next.pts : (prevPts ? prevPts.pts : 10);
  const pct = next ? Math.min(100, Math.round(((pts - floor) / (ceil - floor)) * 100)) : 100;
  $('league-points-fill').style.width = pct + '%';
}

function renderLeagueQuests() {
  $('league-quest-list').innerHTML = LEAGUE_QUESTS.map((q) => {
    const prog = myLeagueProgress[q.key] || 0;
    const pct = Math.min(100, Math.round((prog / q.target) * 100));
    const done = prog >= q.target;
    return `
    <div class="league-quest-row ${done ? 'done' : ''}">
      <div class="league-quest-icon">${q.icon}</div>
      <div class="league-quest-main">
        <div class="league-quest-label">${q.label}</div>
        <div class="league-quest-track"><div class="league-quest-fill" style="width:${pct}%"></div></div>
        <div class="league-quest-sub">${Math.min(prog, q.target).toLocaleString()} / ${q.target.toLocaleString()} · league-wide</div>
      </div>
      <div class="league-quest-pts">+${q.pts}</div>
    </div>`;
  }).join('');
}

function renderLeagueMembers() {
  $('league-member-list').innerHTML = myLeagueMembers.map((m) => `
    <div class="league-member-row">
      <div class="league-member-avatar">${m.display_name.slice(0, 1).toUpperCase()}</div>
      <div class="league-member-name">${escHtmlGame(m.display_name)}</div>
      ${m.user_id === myLeague.owner_id ? '<span class="league-owner-badge">OWNER</span>' : ''}
      ${m.user_id === cloudUser.id ? '<span class="league-you-badge">YOU</span>' : ''}
    </div>`).join('');
}

function renderLeagueMilestones() {
  const pts = myLeague.points || 0;
  $('league-milestone-list').innerHTML = LEAGUE_MILESTONES.map((m) => {
    const reached = pts >= m.pts;
    const claimed = myLeagueClaimed.includes(m.pts);
    const rewardParts = [];
    if (m.coins) rewardParts.push(`🪙${m.coins.toLocaleString()}`);
    if (m.gems) rewardParts.push(`💎${m.gems}`);
    if (m.pack) rewardParts.push(`📦${m.pack}`);
    return `
    <div class="league-ms-row ${reached ? 'reached' : ''}">
      <div class="league-ms-pts">${m.pts.toLocaleString()}</div>
      <div class="league-ms-main">
        <div class="league-ms-label">${m.label}</div>
        <div class="league-ms-reward">${rewardParts.join('  ·  ')}</div>
      </div>
      <div class="league-ms-state">${claimed ? '✅' : reached ? '🎁' : '🔒'}</div>
    </div>`;
  }).join('');
}

/* ---------- posting quest progress (call from match/goal/etc hooks) ---------- */
// Adds `amt` to a quest's league-wide counter for the current season and
// bumps the league's total points by the quest's per-unit reward, capped
// so progress can't exceed the quest target. Also checks for any newly
// reached milestone and grants it once.
async function leaguePostQuestProgress(questKey, amt = 1) {
  if (!cloudUser || !myLeague) return;
  const quest = LEAGUE_QUESTS.find((q) => q.key === questKey);
  if (!quest) return;
  try {
    const already = myLeagueProgress[questKey] || 0;
    const room = Math.max(0, quest.target - already);
    if (room <= 0) return; // quest already complete for this season
    const applied = Math.min(amt, room);
    const { error: progErr } = await sb.from('league_progress').insert({
      league_id: myLeague.id, user_id: cloudUser.id, quest_key: questKey,
      progress: applied, season_started_at: myLeague.season_started_at,
    });
    if (progErr) throw progErr;
    myLeagueProgress[questKey] = already + applied;
    const earnedPts = Math.round(quest.pts * (applied / quest.target));
    if (earnedPts > 0) {
      const { data: updated, error: ptsErr } = await sb.from('leagues')
        .update({ points: (myLeague.points || 0) + earnedPts }).eq('id', myLeague.id).select('points').single();
      if (ptsErr) throw ptsErr;
      myLeague.points = updated.points;
    }
    await leagueCheckMilestones();
    if (match.screen === 'league') { renderLeaguePoints(); renderLeagueQuests(); renderLeagueMilestones(); }
  } catch (err) {
    ;
  }
}
async function leagueCheckMilestones() {
  const pts = myLeague.points || 0;
  const newlyReached = LEAGUE_MILESTONES.filter((m) => pts >= m.pts && !myLeagueClaimed.includes(m.pts));
  for (const m of newlyReached) {
    try {
      const { error } = await sb.from('league_milestones_claimed').insert({
        league_id: myLeague.id, season_started_at: myLeague.season_started_at, milestone_pts: m.pts,
      });
      if (error) { if (error.code === '23505') continue; throw error; } // 23505 = already claimed by another member, fine
      myLeagueClaimed.push(m.pts);
      addCoins(m.coins || 0);
      if (m.gems && cloudUser) { addGems(m.gems); }
      toast(`🏆 League milestone: ${m.label}! +${m.coins} coins${m.gems ? ` +${m.gems} gems` : ''}`);
    } catch (err) {
      ;
    }
  }
}

/* ---------- chat ---------- */
async function leagueLoadChat() {
  if (!myLeague) return;
  try {
    const { data, error } = await sb.from('league_chat').select('*').eq('league_id', myLeague.id).order('created_at', { ascending: true }).limit(100);
    if (error) throw error;
    renderLeagueChat(data || []);
  } catch (err) {
    ;
  }
}
function renderLeagueChat(rows) {
  const log = $('league-chat-log');
  log.innerHTML = rows.map((r) => `
    <div class="league-chat-msg ${r.user_id === cloudUser.id ? 'mine' : ''}">
      <span class="league-chat-name">${escHtmlGame(r.display_name)}</span>
      <span class="league-chat-body">${escHtmlGame(r.body)}</span>
    </div>`).join('');
  log.scrollTop = log.scrollHeight;
}
$('league-chat-send').addEventListener('click', leagueSendChat);
$('league-chat-input').addEventListener('keydown', (e) => { if (e.key === 'Enter') leagueSendChat(); });
async function leagueSendChat() {
  const input = $('league-chat-input');
  const body = input.value.trim();
  if (!body || !myLeague || !cloudUser) return;
  input.value = '';
  try {
    const { error } = await sb.from('league_chat').insert({
      league_id: myLeague.id, user_id: cloudUser.id, display_name: leagueDisplayName(), body,
    });
    if (error) throw error;
  } catch (err) {
    ;
    toast('Message failed to send.');
  }
}
function leagueSubscribeRealtime() {
  if (leagueChatChannel) { sb.removeChannel(leagueChatChannel); leagueChatChannel = null; }
  if (!myLeague) return;
  leagueChatChannel = sb.channel(`league-${myLeague.id}`)
    .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'league_chat', filter: `league_id=eq.${myLeague.id}` }, () => {
      if (match.screen === 'league') leagueLoadChat();
    })
    .on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'leagues', filter: `id=eq.${myLeague.id}` }, (payload) => {
      myLeague = { ...myLeague, ...payload.new };
      if (match.screen === 'league') { renderLeaguePoints(); renderLeagueMilestones(); $('league-home-members').textContent = `${myLeague.member_count}/${LEAGUE_MAX_MEMBERS}`; }
    })
    .subscribe();
}

/* ---------- tabs ---------- */
qsa('.league-tab-btn').forEach((btn) => {
  btn.addEventListener('click', () => {
    audio.ui();
    qsa('.league-tab-btn').forEach((b) => b.classList.toggle('active', b === btn));
    const tab = btn.dataset.tab;
    qsa('.league-tab-pane').forEach((p) => p.classList.toggle('show', p.id === `league-pane-${tab}`));
    if (tab === 'chat') leagueLoadChat();
  });
});

/* ---------- leave / disband ---------- */
$('league-leave-btn').addEventListener('click', async () => {
  audio.ui();
  if (!myLeague || !cloudUser) return;
  const isOwner = myLeague.owner_id === cloudUser.id;
  if (!confirm(isOwner ? `Disband "${myLeague.name}"? This removes the league for everyone.` : `Leave "${myLeague.name}"?`)) return;
  try {
    if (isOwner) {
      await sb.from('league_chat').delete().eq('league_id', myLeague.id);
      await sb.from('league_progress').delete().eq('league_id', myLeague.id);
      await sb.from('league_milestones_claimed').delete().eq('league_id', myLeague.id);
      await sb.from('league_members').delete().eq('league_id', myLeague.id);
      await sb.from('leagues').delete().eq('id', myLeague.id);
    } else {
      await sb.from('league_members').delete().eq('league_id', myLeague.id).eq('user_id', cloudUser.id);
      await sb.from('leagues').update({ member_count: Math.max(0, (myLeague.member_count || 1) - 1) }).eq('id', myLeague.id);
    }
    if (leagueChatChannel) { sb.removeChannel(leagueChatChannel); leagueChatChannel = null; }
    myLeague = null;
    toast(isOwner ? 'League disbanded.' : 'You left the league.');
    await leagueEnterBrowse();
  } catch (err) {
    ;
    toast('Something went wrong — try again.');
  }
});
$('league-back').addEventListener('click', () => { audio.ui(); if (leagueChatChannel) { sb.removeChannel(leagueChatChannel); leagueChatChannel = null; } enterMenu(); });
