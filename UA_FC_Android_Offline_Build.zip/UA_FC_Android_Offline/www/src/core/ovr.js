/* Overall-rating display scale. The roster stores raw ratings (200-288) that the match engine
   normalises; players SEE a 50-130 scale. ovrD(raw) is the only conversion used by the UI. */
(function () {
  'use strict';
  const RAW_MIN = 200, RAW_MAX = 288, D_MIN = 50, D_MAX = 130;
  window.OVR_SCALE = { RAW_MIN, RAW_MAX, D_MIN, D_MAX };
  window.ovrD = function (raw) {
    if (raw == null || isNaN(raw)) return raw;
    const v = D_MIN + (raw - RAW_MIN) * (D_MAX - D_MIN) / (RAW_MAX - RAW_MIN);
    return Math.round(Math.max(D_MIN, Math.min(D_MAX, v)));
  };
  // raw rating values that already fall below the roster range (in-match difficulty shifts) clamp at 50.
  window.ovrColor = function (d) { return d >= 121 ? '#ff4d6d' : d >= 105 ? '#ffc400' : d >= 85 ? '#9be37a' : '#9fb3c8'; };
})();
