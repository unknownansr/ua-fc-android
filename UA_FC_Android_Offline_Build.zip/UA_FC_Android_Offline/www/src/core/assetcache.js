/* UA FC MOBILE — image cache client. Registers sw.js (see that file) and
   exposes diagnostics. Add ?assetdebug=1 to the game URL to show a live
   status badge; UAAssetCache.info / .refresh() / .clear() work in the console. */
(function () {
  var NAME = 'ua-fc-img-v1';
  var info = {
    secure: !!window.isSecureContext, swApi: 'serviceWorker' in navigator, state: 'init',
    controlled: !!(navigator.serviceWorker && navigator.serviceWorker.controller),
    hits: 0, downloads: 0, bytes: 0, cached: '?', persisted: '?', err: '',
  };
  var badge = null, t = null;
  var wantBadge = /[?&]assetdebug/.test(location.search) || (function () { try { return localStorage.getItem('ua_assetdebug') === '1'; } catch (e) { return false; } })();

  function draw() {
    if (!wantBadge) return;
    if (!badge) {
      badge = document.createElement('div');
      badge.style.cssText = 'position:fixed;left:4px;bottom:4px;z-index:2147483647;pointer-events:none;font:10px/1.3 monospace;color:#0f0;background:rgba(0,0,0,.75);padding:3px 5px;border-radius:4px;max-width:92vw';
      (document.body || document.documentElement).appendChild(badge);
    }
    badge.textContent = 'IMG CACHE https:' + (info.secure ? 'Y' : 'NO') + ' sw:' + (info.swApi ? 'Y' : 'NO') + ' ' + info.state +
      ' ctl:' + (info.controlled ? 'Y' : 'N') + ' files:' + info.cached + ' hit:' + info.hits + ' dl:' + info.downloads +
      ' (' + (info.bytes / 1048576).toFixed(1) + 'MB) keep:' + info.persisted + (info.err ? ' ERR:' + info.err : '');
  }
  function refresh() {
    if (!('caches' in window)) { info.cached = 'n/a'; draw(); return Promise.resolve(); }
    return caches.open(NAME).then(function (c) { return c.keys(); }).then(function (k) { info.cached = k.length; draw(); }).catch(function () { draw(); });
  }
  function later() { clearTimeout(t); t = setTimeout(refresh, 300); }

  if (info.swApi) {
    navigator.serviceWorker.addEventListener('message', function (e) {
      var d = e.data; if (!d || d.ua !== 'img') return;
      if (d.hit) info.hits++; else { info.downloads++; info.bytes += d.bytes || 0; }
      later();
    });
    navigator.serviceWorker.addEventListener('controllerchange', function () { info.controlled = true; draw(); });
    navigator.serviceWorker.register('sw.js').then(function () { info.state = 'registered'; draw(); return navigator.serviceWorker.ready; })
      .then(function () { info.state = 'active'; info.controlled = !!navigator.serviceWorker.controller; refresh(); })
      .catch(function (e) { info.state = 'FAILED'; info.err = (e && e.message || String(e)).slice(0, 60); draw(); });
  } else {
    info.state = 'unsupported'; info.err = info.secure ? 'no SW API' : 'needs https';
  }
  try { if (navigator.storage && navigator.storage.persist) navigator.storage.persist().then(function (p) { info.persisted = p ? 'Y' : 'N'; draw(); }); } catch (e) {}
  if (wantBadge) { if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', draw); else draw(); }

  window.UAAssetCache = {
    info: info, refresh: refresh,
    clear: function () { return caches.delete(NAME).then(refresh); },
  };
})();
