/* ==========================================================================
   LANDSCAPE - the app opens in landscape automatically.

   Browsers only allow an orientation lock after a user gesture and (on
   Android Chrome) only while fullscreen, so the very first tap anywhere
   (the TAP TO ENTER splash is that tap) requests fullscreen and then locks
   the screen to landscape. If the browser refuses (iPhone Safari has no
   lock API, some in-app browsers block it) the existing "ROTATE YOUR
   DEVICE" overlay (#rotate-overlay) keeps showing in portrait, and the lock
   is retried on every further tap until it works. Desktop is never touched.
   ========================================================================== */
(function () {
  'use strict';
  var coarse = false;
  try { coarse = window.matchMedia('(pointer: coarse)').matches; } catch (e) {}
  var isTouch = coarse || ('ontouchstart' in window) || (navigator.maxTouchPoints || 0) > 0;
  var smallScreen = Math.min(screen.width || 9999, screen.height || 9999) <= 900;
  if (!(isTouch && smallScreen)) return;                       // desktop / big tablet in a window: leave it alone

  var done = false, tries = 0;
  var root = document.documentElement;
  var orient = screen.orientation || screen.mozOrientation || screen.msOrientation;

  function isLandscape() { return window.innerWidth >= window.innerHeight; }
  function inFullscreen() { return !!(document.fullscreenElement || document.webkitFullscreenElement); }

  function lockLandscape() {
    try {
      if (orient && orient.lock) {
        var p = orient.lock('landscape');
        if (p && p.then) { p.then(function () { done = true; }, function () { /* refused: overlay stays as fallback */ }); }
        else done = true;
      }
    } catch (e) {}
  }
  function goFullscreen() {
    var req = root.requestFullscreen || root.webkitRequestFullscreen || root.msRequestFullscreen;
    if (!req || inFullscreen()) return Promise.resolve();
    try {
      var r = req.call(root, { navigationUI: 'hide' });
      return r && r.then ? r.catch(function () {}) : Promise.resolve();
    } catch (e) { return Promise.resolve(); }
  }
  function attempt() {
    if (done && inFullscreen() && isLandscape()) return;
    if (++tries > 40) return;
    goFullscreen().then(lockLandscape);
    lockLandscape();                                             // some browsers allow the lock without fullscreen
  }

  // First (and every later) real tap re-tries until the lock sticks.
  ['pointerup', 'touchend', 'click'].forEach(function (ev) {
    window.addEventListener(ev, attempt, { capture: true, passive: true });
  });
  // If the user leaves fullscreen (back gesture), go back in on the next tap.
  document.addEventListener('fullscreenchange', function () { if (!inFullscreen()) done = false; });
  window.addEventListener('orientationchange', function () { setTimeout(function () { if (isLandscape()) done = true; }, 300); });
  // Keep the page from being scrolled/rubber-banded while playing.
  document.addEventListener('touchmove', function (e) { if (e.target === document.body || e.target === root) e.preventDefault(); }, { passive: false });
})();
