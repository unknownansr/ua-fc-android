/* ==========================================================================
   LOCAL BACKEND - replaces Supabase so the whole game runs 100% offline.

   Defines window.supabase.createClient(...) with the same surface the game
   already uses (from().select/insert/update/upsert/delete + filters, rpc,
   auth, channel, storage), backed by an in-memory store that is saved to
   localStorage. Must load BEFORE cloud.js. No network access is ever made.

   - players_registry : read-only, served from local_roster.js (200 players)
   - user_* tables    : created on first run, persisted on this device
   - tables for removed online features (friends, leagues, market ...) simply
     return empty results, so any stray call fails soft instead of throwing.
   ========================================================================== */
(function () {
  'use strict';
  const STORE_KEY = 'uafc_offline_db_v1';
  const USER = { id: 'local-player', email: 'player@offline.local', aud: 'authenticated', role: 'authenticated' };
  const LOCAL = window.UA_LOCAL || { players: [], starters: [], nats: {} };

  /* ---------------- persistence ---------------- */
  const PERSIST = ['profiles', 'user_players', 'user_gems', 'user_game_state', 'user_squads', 'match_history',
    'user_achievements', 'user_ua_points', 'career_save', 'draft_pity_counters'];
  let db = {};
  try { db = JSON.parse(localStorage.getItem(STORE_KEY) || '{}') || {}; } catch (e) { db = {}; }
  let saveTimer = null;
  function flush() {
    clearTimeout(saveTimer);
    const out = {};
    for (const t of PERSIST) if (db[t]) out[t] = db[t];
    try { localStorage.setItem(STORE_KEY, JSON.stringify(out)); } catch (e) { /* storage full or blocked: keep playing in memory */ }
  }
  function scheduleSave() { clearTimeout(saveTimer); saveTimer = setTimeout(flush, 400); }
  window.addEventListener('pagehide', flush);
  document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'hidden') flush(); });

  let _uid = 0;
  const uid = () => 'r' + Date.now().toString(36) + (++_uid).toString(36) + Math.random().toString(36).slice(2, 6);
  const clone = (v) => (v === undefined ? v : JSON.parse(JSON.stringify(v)));

  /* ---------------- first-run seed ---------------- */
  function seed() {
    if (!db.profiles || !db.profiles.length) {
      db.profiles = [{ id: USER.id, username: 'player', display_name: 'Player', friend_code: 'OFFLINE', xp: 0, level: 1,
        kit_primary_color: null, kit_secondary_color: null, is_admin: false, created_at: new Date().toISOString() }];
    }
    if (!db.user_gems || !db.user_gems.length) db.user_gems = [{ user_id: USER.id, gems: 500 }];
    if (!db.user_game_state || !db.user_game_state.length) db.user_game_state = [{ user_id: USER.id, state: { coins: 5000, vault: {} } }];
    if (!db.user_ua_points || !db.user_ua_points.length) db.user_ua_points = [{ user_id: USER.id, ua_points: 0 }];
    if (!db.user_players || !db.user_players.length) {
      // Own the whole roster. Starter XI first so a new save fields a balanced team.
      const first = new Set(LOCAL.starters);
      const ordered = LOCAL.starters.concat(LOCAL.players.map((p) => p.id).filter((id) => !first.has(id)));
      db.user_players = ordered.map((pid) => ({ id: 'up-' + pid, user_id: USER.id, player_id: pid, jersey_number: null, pool: null, acquired_at: new Date().toISOString() }));
    }
    for (const t of ['user_squads', 'match_history', 'user_achievements', 'career_save']) if (!db[t]) db[t] = [];
    flush();
  }
  seed();

  /* ---------------- table access ---------------- */
  const READONLY = {
    players_registry: () => LOCAL.players,
    drafts: () => (window.UA_DRAFTS ? window.UA_DRAFTS.drafts : []),
    draft_pool_players: () => (window.UA_DRAFTS ? window.UA_DRAFTS.pool : []),
    starter_squad: () => LOCAL.starters.map((id, i) => ({ id: 'ss' + i, player_id: id, slot_role: null, sort_order: i })),
  };
  function rows(table) {
    if (READONLY[table]) return READONLY[table]();
    if (!db[table]) db[table] = [];
    return db[table];
  }
  // relation name -> [foreign key on the parent row, target table, target key]
  const RELS = {
    players_registry: ['player_id', 'players_registry', 'id'],
    profiles: ['user_id', 'profiles', 'id'],
  };
  function splitTop(s) {
    const parts = []; let depth = 0, cur = '';
    for (const ch of s) {
      if (ch === '(') depth++; if (ch === ')') depth--;
      if (ch === ',' && depth === 0) { parts.push(cur.trim()); cur = ''; } else cur += ch;
    }
    if (cur.trim()) parts.push(cur.trim());
    return parts;
  }
  function project(row, cols) {
    if (!cols || cols === '*') return clone(row);
    const out = {};
    for (const c of splitTop(cols)) {
      if (c === '*') { Object.assign(out, clone(row)); continue; }
      const m = c.match(/^([a-z_]+)\((.*)\)$/i);
      if (m) {
        const rel = RELS[m[1]];
        if (!rel) { out[m[1]] = null; continue; }
        const target = rows(rel[1]).find((r) => r[rel[2]] === row[rel[0]] || String(r[rel[2]]) === String(row[rel[0]]));
        out[m[1]] = target ? project(target, m[2]) : null;
      } else if (c in row) out[c] = clone(row[c]);
    }
    return out;
  }

  /* ---------------- query builder ---------------- */
  class Query {
    constructor(table) {
      this.table = table; this.op = null; this.payload = null; this.cols = '*'; this.returning = false;
      this.filters = []; this.orders = []; this.lim = null; this.mode = 'many'; this.conflict = null; this.countOpt = null;
    }
    select(cols, opts) { if (!this.op) this.op = 'select'; else this.returning = true; this.cols = cols || '*'; if (opts && opts.count) this.countOpt = opts; return this; }
    insert(p) { this.op = 'insert'; this.payload = p; return this; }
    update(p) { this.op = 'update'; this.payload = p; return this; }
    upsert(p, o) { this.op = 'upsert'; this.payload = p; this.conflict = o && o.onConflict ? o.onConflict.split(',').map((s) => s.trim()) : null; return this; }
    delete() { this.op = 'delete'; return this; }
    eq(c, v) { this.filters.push((r) => r[c] === v || (r[c] != null && v != null && String(r[c]) === String(v))); return this; }
    neq(c, v) { this.filters.push((r) => String(r[c]) !== String(v)); return this; }
    in(c, vs) { const s = new Set((vs || []).map(String)); this.filters.push((r) => s.has(String(r[c]))); return this; }
    gt(c, v) { this.filters.push((r) => r[c] > v); return this; }
    gte(c, v) { this.filters.push((r) => r[c] >= v); return this; }
    lt(c, v) { this.filters.push((r) => r[c] < v); return this; }
    lte(c, v) { this.filters.push((r) => r[c] <= v); return this; }
    is(c, v) { this.filters.push((r) => (v === null ? r[c] == null : r[c] === v)); return this; }
    not(c, op, v) {
      if (op === 'is') this.filters.push((r) => (v === null ? r[c] != null : r[c] !== v));
      else if (op === 'eq') this.filters.push((r) => String(r[c]) !== String(v));
      else if (op === 'in') { const s = new Set(String(v).replace(/[()]/g, '').split(',')); this.filters.push((r) => !s.has(String(r[c]))); }
      return this;
    }
    ilike(c, p) { const re = new RegExp('^' + String(p).replace(/[.*+?^${}()|[\]\\]/g, '\\$&').replace(/%/g, '.*') + '$', 'i'); this.filters.push((r) => re.test(String(r[c] || ''))); return this; }
    like(c, p) { return this.ilike(c, p); }
    or() { return this; }
    match(o) { for (const k in o) this.eq(k, o[k]); return this; }
    order(c, o) { this.orders.push([c, !(o && o.ascending === false)]); return this; }
    limit(n) { this.lim = n; return this; }
    range(a, b) { this.lim = b - a + 1; this.off = a; return this; }
    single() { this.mode = 'single'; return this; }
    maybeSingle() { this.mode = 'maybe'; return this; }
    then(res, rej) { return Promise.resolve().then(() => this.run()).then(res, rej); }

    run() {
      const T = this.table;
      const tbl = rows(T);
      const match = (r) => this.filters.every((f) => f(r));
      let out = [];
      try {
        if (this.op === 'insert' || this.op === 'upsert') {
          if (READONLY[T]) return { data: null, error: { message: 'read-only table', code: '42501' } };
          const list = Array.isArray(this.payload) ? this.payload : [this.payload];
          for (const item of list) {
            const row = Object.assign({}, clone(item));
            let existing = null;
            if (this.op === 'upsert') {
              const keys = this.conflict || (tbl.length && 'id' in item ? ['id'] : null);
              if (keys) existing = tbl.find((r) => keys.every((k) => String(r[k]) === String(row[k])));
            }
            if (existing) { Object.assign(existing, row); out.push(existing); continue; }
            const err = this.checkUnique(T, tbl, row, null);
            if (err) return { data: null, error: err };
            if (!('id' in row) && !/^(user_gems|user_game_state|user_ua_points)$/.test(T)) row.id = uid();
            if (!row.created_at && !/^(user_gems|user_game_state)$/.test(T)) row.created_at = new Date().toISOString();
            tbl.push(row); out.push(row);
          }
          scheduleSave();
        } else if (this.op === 'update') {
          if (READONLY[T]) return { data: null, error: { message: 'read-only table', code: '42501' } };
          const targets = tbl.filter(match);
          for (const r of targets) {
            const err = this.checkUnique(T, tbl, Object.assign({}, r, this.payload), r);
            if (err) return { data: null, error: err };
          }
          for (const r of targets) Object.assign(r, clone(this.payload));
          out = targets; scheduleSave();
        } else if (this.op === 'delete') {
          if (READONLY[T]) return { data: null, error: { message: 'read-only table', code: '42501' } };
          out = tbl.filter(match);
          db[T] = tbl.filter((r) => !match(r)); scheduleSave();
        } else {
          out = tbl.filter(match);
        }
        if (this.orders.length) {
          out = out.slice().sort((a, b) => {
            for (const [c, asc] of this.orders) {
              const x = a[c], y = b[c];
              if (x === y) continue;
              if (x == null) return 1; if (y == null) return -1;
              return (x < y ? -1 : 1) * (asc ? 1 : -1);
            }
            return 0;
          });
        }
        const total = out.length;
        if (this.off) out = out.slice(this.off);
        if (this.lim != null) out = out.slice(0, this.lim);
      } catch (e) {
        return { data: null, error: { message: String(e && e.message || e) } };
      }
      const wantRows = this.op === 'select' || this.returning;
      if (!wantRows) return { data: null, error: null };
      const data = out.map((r) => project(r, this.cols));
      const count = this.countOpt ? out.length : null;
      if (this.mode === 'single') return data.length === 1 ? { data: data[0], error: null, count } : { data: null, error: { message: 'No rows', code: 'PGRST116' }, count };
      if (this.mode === 'maybe') return { data: data[0] || null, error: null, count };
      return { data, error: null, count };
    }
    checkUnique(T, tbl, row, self) {
      if (T === 'user_players') {
        if (row.jersey_number != null && tbl.some((r) => r !== self && r.user_id === row.user_id && r.jersey_number === row.jersey_number)) {
          return { message: 'duplicate key value', code: '23505' };
        }
        if (!self && tbl.some((r) => r.user_id === row.user_id && String(r.player_id) === String(row.player_id))) return { message: 'duplicate key value', code: '23505' };
      }
      return null;
    }
  }

  /* ---------------- client ---------------- */
  const session = { access_token: 'local', refresh_token: 'local', user: USER, expires_at: 4102444800 };
  const noopChannel = () => { const c = { on() { return c; }, subscribe(cb) { if (cb) try { cb('SUBSCRIBED'); } catch (e) {} return c; }, unsubscribe() { return Promise.resolve('ok'); }, send() {} }; return c; };
  function createClient() {
    return {
      from: (t) => new Query(t),
      rpc: () => Promise.resolve({ data: null, error: { message: 'Not available offline', code: 'OFFLINE' } }),
      auth: {
        getSession: () => Promise.resolve({ data: { session }, error: null }),
        getUser: () => Promise.resolve({ data: { user: USER }, error: null }),
        signUp: () => Promise.resolve({ data: { user: USER, session }, error: null }),
        signInWithPassword: () => Promise.resolve({ data: { user: USER, session }, error: null }),
        signOut: () => Promise.resolve({ error: null }),
        onAuthStateChange: () => ({ data: { subscription: { unsubscribe() {} } } }),
      },
      channel: noopChannel,
      removeChannel: () => Promise.resolve('ok'),
      storage: { from: () => ({ getPublicUrl: () => ({ data: { publicUrl: '' } }), upload: () => Promise.resolve({ data: null, error: { message: 'offline' } }) }) },
      functions: { invoke: () => Promise.resolve({ data: null, error: { message: 'offline' } }) },
    };
  }
  window.supabase = { createClient };
  window.UA_LOCAL_DB = { flush, reset() { try { localStorage.removeItem(STORE_KEY); } catch (e) {} location.reload(); }, USER };
})();
