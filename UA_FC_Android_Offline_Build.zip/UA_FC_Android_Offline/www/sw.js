/* UA FC MOBILE — image cache service worker.
   Cache-first for Supabase Storage public files (any bucket). Each file is
   downloaded from Supabase ONCE per device, then served from local storage.
   Bump CACHE's suffix to purge every device's copy. */
const CACHE = 'ua-fc-img-v1';
const MAX_BYTES = 15 * 1024 * 1024;           // larger files pass through uncached
const isStorage = (u) => u.pathname.indexOf('/storage/v1/object/public/') !== -1 || u.pathname.indexOf('/functions/v1/ua-fc-drive/') !== -1;

self.addEventListener('install', () => self.skipWaiting());
self.addEventListener('activate', (e) => e.waitUntil((async () => {
  const names = await caches.keys();
  await Promise.all(names.filter((n) => (n.startsWith('ua-fc-img-') || n.startsWith('ua-fc-assets-')) && n !== CACHE).map((n) => caches.delete(n)));
  await self.clients.claim();
})()));

async function tell(msg) {
  try { (await self.clients.matchAll({ includeUncontrolled: true })).forEach((c) => c.postMessage(Object.assign({ ua: 'img' }, msg))); } catch (e) {}
}

async function handle(req) {
  const key = req.url;
  const cache = await caches.open(CACHE);
  const hit = await cache.match(key, { ignoreVary: true });
  if (hit) { tell({ hit: true }); return hit; }
  let res;
  try {
    // Re-request as CORS so the response is real (not opaque) and cacheable.
    res = await fetch(key, { mode: 'cors', credentials: 'omit' });
  } catch (err) {
    return fetch(req);                         // CORS/network trouble: behave exactly as without the worker
  }
  const len = +res.headers.get('content-length') || 0;
  if (res.status === 200 && len <= MAX_BYTES) {
    try { await cache.put(key, res.clone()); } catch (e) { /* quota: still serve this one */ }
  }
  tell({ hit: false, bytes: len, status: res.status });
  return res;
}

self.addEventListener('fetch', (e) => {
  const req = e.request;
  if (req.method !== 'GET' || req.headers.has('range')) return;   // range = video seeking; let it through
  let u; try { u = new URL(req.url); } catch (err) { return; }
  if (!isStorage(u)) return;
  e.respondWith(handle(req));
});
