# UA FC Offline Android Build

This project wraps the existing UA FC web game in a Capacitor Android app.
The original game files are kept under `www/`; gameplay code has not been rewritten.

## Build an APK using GitHub Actions (phone-only workflow)

1. On your phone, sign in to GitHub and create a **new empty repository**.
2. Upload the contents of this folder to the repository (not the containing ZIP folder).
3. Open the repository's **Actions** tab.
4. Select **Build UA FC Offline APK**.
5. Tap **Run workflow**. Wait for the workflow to finish.
6. Open the successful run, scroll to **Artifacts**, and download `UA-FC-Offline-APK`.
7. Extract the downloaded artifact ZIP. It contains `app-debug.apk`.
8. Install the APK on your Android phone. Android may ask you to allow installation from the browser/files app you used.

## Offline design

- All supplied web game files are bundled in `www/`.
- Capacitor serves the bundled files from the app's local WebView origin.
- The build script removes the Android `INTERNET` permission and disables cleartext traffic.
- The game source already includes `local_backend.js` and `offline_patch.js`.
- No online integration source has been deleted; online-only functions simply cannot connect from this APK.

## Important limitations

- Cloud compilation requires internet on GitHub's build servers. The installed APK is designed to run without internet.
- Online-only features (remote uploads, remote AI providers, cloud sync, multiplayer/network services) cannot function without internet. Local equivalents continue to depend on what the game source implements.
- The APK produced by this workflow is a **debug APK**, suitable for personal installation/testing. A release APK with a private signing key can be configured later.
- This wrapper has not yet been run through a real Android build or device test. After the first build, test launch, match loading, Character Studio, Career saves, and offline behavior on the target phone.
