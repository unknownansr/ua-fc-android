import fs from 'node:fs';
import path from 'node:path';

const manifestPath = path.resolve('android/app/src/main/AndroidManifest.xml');
if (!fs.existsSync(manifestPath)) {
  throw new Error(`AndroidManifest.xml not found: ${manifestPath}`);
}
let xml = fs.readFileSync(manifestPath, 'utf8');

// Remove INTERNET from the final merged manifest, including any copy
// contributed by a Capacitor library manifest.
if (!/xmlns:tools=/.test(xml)) {
  xml = xml.replace(/<manifest\b([^>]*)>/, (match, attrs) =>
    `<manifest${attrs} xmlns:tools="http://schemas.android.com/tools">`
  );
}
xml = xml.replace(/^\s*<uses-permission\s+android:name=["']android\.permission\.INTERNET["'][^>]*\/>\s*\r?\n/gm, '');
xml = xml.replace(
  /(<manifest\b[^>]*>)/,
  '$1\n    <uses-permission android:name="android.permission.INTERNET" tools:node="remove" />'
);

// Force the game to open in landscape.
xml = xml.replace(
  /(<activity\b[^>]*android:name=["'][^"']*MainActivity[^"']*["'][^>]*)(>)/,
  (match, before, close) => {
    if (/android:screenOrientation=/.test(before)) {
      return before.replace(/android:screenOrientation=["'][^"']*["']/, 'android:screenOrientation="landscape"') + close;
    }
    return before + ' android:screenOrientation="landscape"' + close;
  }
);

// Explicitly disallow cleartext traffic.
xml = xml.replace(/<application\b([^>]*)>/, (match, attrs) => {
  if (/android:usesCleartextTraffic=/.test(attrs)) {
    attrs = attrs.replace(/android:usesCleartextTraffic=["'][^"']*["']/, 'android:usesCleartextTraffic="false"');
  } else {
    attrs += ' android:usesCleartextTraffic="false"';
  }
  return `<application${attrs}>`;
});

fs.writeFileSync(manifestPath, xml);
console.log('Offline Android manifest enforced: INTERNET permission removed; landscape locked.');
